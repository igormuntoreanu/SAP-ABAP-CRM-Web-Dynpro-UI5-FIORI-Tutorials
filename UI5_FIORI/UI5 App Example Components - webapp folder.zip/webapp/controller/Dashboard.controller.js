sap.ui.define([
	"de/hrk/hochweit/Backend-web/controller/BaseController",
	"de/hrk/hochweit/Backend-web/util/RevealGrid",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/dnd/DragInfo",
	"sap/f/dnd/GridDropInfo"
], function (Controller, RevealGrid, JSONModel, DragInfo, GridDropInfo) {
	"use strict";

	return Controller.extend("de.hrk.hochweit.Backend-web.controller.Dashboard", {
		onInit: function () {

			this.getOwnerComponent().getRouter().getRoute("dashboard").attachPatternMatched(this._onRouteMatched, this);

			var oGrid = this.byId("dashboardGrid");

			oGrid.addDragDropConfig(new DragInfo({
				sourceAggregation: "items"
			}));

			oGrid.addDragDropConfig(new GridDropInfo({
				targetAggregation: "items",
				dropPosition: "Between",
				dropLayout: "Horizontal",
				drop: function (oInfo) {
					var oDragged = oInfo.getParameter("draggedControl"),
						oDropped = oInfo.getParameter("droppedControl"),
						oDragParent = oDragged.getParent(),
						oDropParent = oDropped.getParent(),
						sInsertPosition = oInfo.getParameter("dropPosition"),
						iDragPosition = oDragParent.indexOfItem(oDragged),
						iDropPosition = oDropParent.indexOfItem(oDropped);

					oDragParent.removeItem(oDragged);

					if (oDragParent === oDropParent && iDragPosition < iDropPosition) {
						iDropPosition--;
					}

					if (sInsertPosition === "Before") {
						oDropParent.insertItem(oDragged, iDropPosition);
					} else {
						oDropParent.insertItem(oDragged, iDropPosition + 1);
					}
				}
			}));

			this._getOwnProfile();
		},

		onGridLayoutChange: function (oEvent) {
			var oGrid = oEvent.getSource();
			var sLayout = oEvent.getParameter("layout");

			if (sLayout === "layoutXS" || sLayout === "layoutS") {
				oGrid.removeStyleClass("sapUiSmallMargin");
				oGrid.addStyleClass("sapUiTinyMargin");
			} else {
				oGrid.removeStyleClass("sapUiTinyMargin");
				oGrid.addStyleClass("sapUiSmallMargin");
			}
		},
		onRevealGrid: function () {
			RevealGrid.toggle("dashboardGrid", this.getView());
		},

		onExit: function () {
			RevealGrid.destroy("dashboardGrid", this.getView());
		},

		onMyProfile: function () {
			const oLogin = this.getView().getModel("Profile").getData();
			this.navTo("editUser", {
				userId: oLogin.keycloak_id
			});
		},

		_onRouteMatched: function () {
			this.getView().getModel("app").setProperty("/fullWidth", true);
		},

		_getOwnProfile: function () {
			this.getOwnerComponent().getOwnProfile()
				.then(function (ownProfile) {
					if (ownProfile.data && ownProfile.data.selbst) {
						if (!ownProfile.data.selbst.hochschulName) {
							ownProfile.data.selbst.hochschulName = "HRK";
						}
					}
					this.getView().setModel(new JSONModel(ownProfile.data.selbst), "Profile");
				}.bind(this));
		},
	});
});