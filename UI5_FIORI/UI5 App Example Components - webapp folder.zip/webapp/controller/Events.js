sap.ui.define([], function() {
    "use strict";
    return {
        user: {
            channel: "app.user",
            events: {
                loginSuccess: "app.user.loginSuccess",
                logout: "app.user.logout"
            }
        }
    };
});