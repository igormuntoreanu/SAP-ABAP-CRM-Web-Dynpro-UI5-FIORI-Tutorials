sap.ui.define(
  [
    "de/hrk/hochweit/Backend-web/controller/BaseController",
    "sap/base/Log",
    "de/hrk/hochweit/Backend-web/service/LogoutService",
	  "sap/m/MessageBox"
  ],
  function (BaseController, Log, LogoutService, MessageBox) {
    "use strict";

    return BaseController.extend("de.hrk.hochweit.Backend-web.controller.App", {

      onInit: function () {
        this._appModel = this.getOwnerComponent().getModel("app");
        this._loginModel = this.getOwnerComponent().getModel("login");
        this._logoutService = new LogoutService();

        this.getRouter().attachRoutePatternMatched((oEvent) => {
          let sRouteName = oEvent.getParameter("name");

          if (this._currentHeaderElement) {
            this._currentHeaderElement.removeStyleClass("appHeaderCurrent");
          }
          let oTargetedHeaderElement = this.byId(sRouteName);
          if (oTargetedHeaderElement) {
            this._currentHeaderElement = oTargetedHeaderElement;
            this._currentHeaderElement.addStyleClass("appHeaderCurrent");
          }
        }, this);

        this._attachTargetDisplayHandlers();
        this._enableAdminNavLinkBasedOnRole();

        // Navigation triggered by embedded components
        sap.ui.getCore().getEventBus().subscribe( "rootComponent", "navTo", this._handleNavigationRequest, this);
      },

      _enableAdminNavLinkBasedOnRole: function(){
          const disallowedRoles = ["hsb", "power_user"];
          const hasDisallowedRole = disallowedRoles.includes(this._loginModel.oData.role);
          const adminNavLinkElm = this.byId("administrativeFunktionen");
          adminNavLinkElm.setEnabled(!hasDisallowedRole);
      },

      _attachTargetDisplayHandlers: function () {
        let oTargets = this.getOwnerComponent().getManifestEntry(
          "/sap.ui5/routing/targets"
        );
        if (!oTargets) {
          Log.error("No targets were defined in application descriptor");
          return;
        }

        for (const [sKey, oTarget] of Object.entries(oTargets)) {
          try {
            if (oTarget.type === "Component") {
              this.getRouter().getTarget(sKey).attachEventOnce("display", this._attachComponentNotificationHandlers, this);
						  this.getRouter().getTarget(sKey).attachEvent("display", this._attachComponentNavigationHandler, this);
            }
          } catch (oError) {
            Log.error(oError.message);
          }
        }
      },

      _handleComponentHasPendingChanges: function (oEvent) {
        Log.info(
          `Event notifyPendingChanges caught from component ${oEvent.getParameter("componentName")}`
        );
        this.getModel("components").setProperty(
          `/${oEvent.getParameter("componentName")}`,
          {
            hasPendingChanges: true,
          }
        );
      },

      _handleComponentHasNoMorePendingChanges: function (oEvent) {
        Log.info(
          `Event notifyNoPendingChanges caught from component ${oEvent.getParameter("componentName")}`
        );
        this.getModel("components").setProperty(
          `/${oEvent.getParameter("componentName")}`,
          {
            hasPendingChanges: false,
          }
        );
      },


      /**
       * Attaches handlers for the custom notifyPendingChanges and notifyNoPendingChanges events of an embedded component
       * @param {*} oEvent
       */
      _attachComponentNotificationHandlers: function (oEvent) {
        let oComponentInstance = oEvent
          .getParameter("object")
          .getComponentInstance();
        if (oComponentInstance) {
          try {
            oComponentInstance.attachNotifyPendingChanges(
              this._handleComponentHasPendingChanges,
              this
            );
          } catch (oError) {
            Log.error(
              `Event notifyPendingChanges is not defined in component instance ${oComponentInstance
                .getMetadata()
                .getComponentName()}`
            );
          }
          try {
            oComponentInstance.attachNotifyNoPendingChanges(
              this._handleComponentHasNoMorePendingChanges,
              this
            );
          } catch (oError) {
            Log.error(
              `Event notifyNoPendingChanges is not defined in component instance ${oComponentInstance
                .getMetadata()
                .getComponentName()}`
            );
          }
        }
      },

      /**
       * Registers the component that the app navigated to as the "current" component - enables checking for pending changes from that component
       * @param {*} oEvent the display event of the component route
       */
      _attachComponentNavigationHandler: function (oEvent) {
        let oComponentInstance = oEvent
          .getParameter("object")
          .getComponentInstance();
        if (oComponentInstance) {
          this.getModel("components").setProperty("/", {
            currentComponent: oComponentInstance.getMetadata().getComponentName(),
          });
        }
      },

      _handleNavigationRequest: function(sChannelId, sEventId, oData){
        this.navTo(oData.target, oData.parameters, oData.replace);
      },

      /**
       * @override
       * @param {string} psTarget
       * @param {any} pmParameters
       * @param {any} pbReplace
       */
      navTo: function(psTarget, pmParameters, pbReplace) {
        //check for pending changes prior to navigating
        this._checkNavigationAllowed()
        .then( (bAllowed) => {
          if (bAllowed) {
            BaseController.prototype.navTo.call(this, psTarget, pmParameters, pbReplace);
          }
        });
      },

      processLogout: function () {
        this._checkNavigationAllowed()
        .then( (bAllowed) => {
          if (bAllowed) {
            const apolloService = this.getOwnerComponent().getApolloService();
            this._logoutService.terminateSsoSession(apolloService).then(() => {
              sap.m.URLHelper.redirect(this._logoutService.getLocalLogoutRedirect());
            }).catch(error => {
              // What to do in this case? Navigate to dashboard?
              Log.error(`Could not perform logout: ${error.message} - ${error.stack}`);
            });
          }
        });
      },

      _checkNavigationAllowed: function () {
        return new Promise((resolve) => {
          let sCurrentComponentName = this.getModel("components").getProperty("/currentComponent");
          if (sCurrentComponentName && this.getModel("components").getProperty(`/${sCurrentComponentName}/hasPendingChanges`)) {
            MessageBox.confirm(this.getResourceBundle().getText("app.common.pendingChanges.prompt.text"), {
              // title: ,
              onClose: (oAction) => {
                if (oAction === MessageBox.Action.OK) {
                  this.getModel("components").setProperty(`/${sCurrentComponentName}/hasPendingChanges`, false);
                  sap.ui.getCore().getEventBus().publish("rootComponent", "discardChanges", {componentName: sCurrentComponentName });
                  resolve(true);
                } else {
                  resolve(false);
                }
              }
            });
          } else {
            resolve(true);
          }
        });
      }

  });
});