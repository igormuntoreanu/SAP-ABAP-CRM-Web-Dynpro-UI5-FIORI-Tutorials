sap.ui.define([
    "apollo/client/thirdparty/apollo"
], function (UI5Apollo) {
    "use strict";

    /**
     * Define gql wrapper for Apollo queries;
     * @see https://www.apollographql.com/docs/react/data/queries/
     */
    const { gql } = UI5Apollo;

    const GET_QSTYPEN = gql`
        query qstypen {
                qstypen {
                    id sortingorder bezeichnung
            }
    }`;

    const GET_QUALITAETSSICHERUNG = gql`
        query Qualitaetssicherung($weiterbildungsId: IntID!){
            qualitaetssicherung(weiterbildungsId: $weiterbildungsId) {
                qstypen {
                    id
                    bezeichnung
                }
                qsverifiziertezertifikate { 
                    id
                    qszertifikat {
                        id
                        bezeichnung
                    }
                    qseinrichtung {
      	                id
      	                bezeichnung
    	            }           
                }
                qsunbekanntezertifikate {
                    id
                    zertifikat
                    einrichtung
                }
            }
    }`;

    return {

        /**
         * Returns multiple weiterbildungsangebote at once
         */
        getQsTypen: function (oApolloService) {
            return oApolloService.query({
                query: GET_QSTYPEN
            })
                .then(function (result) {
                    return result.data;
                });
        },

        getQualitaetssicherung: function (oApolloService, sId) {
            return oApolloService.query({
                query: GET_QUALITAETSSICHERUNG,
                variables: {
                    weiterbildungsId: sId
                }
            })
                .then(function (result) {
                    return result.data;
                });
        }
    };
});
