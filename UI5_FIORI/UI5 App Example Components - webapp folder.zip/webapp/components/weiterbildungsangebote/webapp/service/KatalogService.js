sap.ui.define([
    "apollo/client/thirdparty/apollo"
], function(UI5Apollo) {
    "use strict";

    const {gql} = UI5Apollo;

     const GET_REDAKTIONSSTATUSES = gql`
        query Redaktionsstatuses {
            redaktionsstatuses {
                id bezeichnung
            }
        }`;

     const GET_ANGEBOTSBEZEICHNUNGEN = gql`
        query Angebotsbezeichnungen ($hochschulId: Int) {
            angebotsbezeichnungen(hochschulId: $hochschulId) {
                id
                bezeichnung
                istInBenutzungVon
                istzumloeschenvorgesehen
                hochschule
            }
        }`;

     const GET_ANGEBOTSVARIANTEN = gql`
        query AngebotsVarianten {
          angebotsVarianten {
            id
            minects
            angebotstyp
            abschluss
          }
        }`;

    const GET_ANGEBOTSTYPEN = gql`
          query AngebotsTypen {
              angebotsTypen {
                  id,
                  bezeichnung
              }
          }`;

    const GET_SPRACHEN = gql`
            query Sprachen {
                sprachen {
                    id,
                    bezeichnung,
                    istdeaktiviert
                }
            }`;

    const GET_ABSCHLUESSE = gql`
            query Abschluesse {
                abschluesse {
                    id,
                    bezeichnung
                }
            }`;

    const CREATE_ANGEBOTSBEZEICHNUNG = gql`
      mutation createAngebotsbezeichnung ($data: CreateAngebotsbezeichnungInput!) {
        createAngebotsbezeichnung(data: $data) {
          id
          bezeichnung
          isthskimportiert
          istzumloeschenvorgesehen
          istInBenutzungVon
        }
      }
    `;

    const UPDATE_ANGEBOTSBEZEICHNUNG = gql`
      mutation updateAngebotsbezeichnung ($data: UpdateAngebotsbezeichnungInput!) {
        updateAngebotsbezeichnung(data: $data) {
          id
          bezeichnung
          isthskimportiert
          istzumloeschenvorgesehen
          istInBenutzungVon
        }
      }
    `;

    const DELETE_ANGEBOTSBEZEICHNUNG = gql`
      mutation deleteAngebotsbezeichnung ($data: DeleteAngebotsbezeichnungInput!) {
        deleteAngebotsbezeichnung(data: $data) {
          id
          bezeichnung
        }
      }
    `;

    const DELETE_ANGEBOTSBEZEICHNUNGEN = gql`
      mutation deleteAngebotsbezeichnungen ($data: DeleteAngebotsbezeichnungenInput!) {
        deleteAngebotsbezeichnungen(data: $data)
      }
    `;

  const GET_EINHEITENZEITDAUER = gql`
      query EinheitenZeitdauer {
                einheitenZeitdauer {
                    id,
                    category,
                    bezeichnungsingular,
                    bezeichnungplural,
                    bezeichnungkurz
                }
            }`;

  const GET_VERANSTALTUNGSFORMATE = gql`
      query Veranstaltungsformate {
                veranstaltungsformate {
                    id,
                    bezeichnung
                }
            }`;

  const GET_LEHRUNDLERNFORMATE = gql`
      query LehrUndLernformate {
                lehrUndLernformate {
                    id,
                    bezeichnung
                }
            }`;

  const GET_WISSENSGRUPPEN = gql`
          query {
            wissensgruppen {
              id
              bezeichnung
              zumloeschenvorgesehen
              Wissensbereich {
                id
                bezeichnung
                hollandcode
                zumloeschenvorgesehen
              }
            }
          }`;

    const GET_KONTAKTSTELLEN = gql`
            query Hochschule($hochschuleId: IntID!) {
              hochschule(id: $hochschuleId) {
                    kontaktstellen {
                      id,
                      kontaktstellentyp {
                        id,
                        bezeichnung
                      },
                      adresse {
                        id,
                        strasseoderpostfach,
                        plz,
                        ort
                       }
                      email,
                      telefon
                    }
                    }
            }`;

    const GET_KONTAKTPERSONEN = gql`
             query Hochschule($hochschuleId: IntID!) {
              hochschule(id: $hochschuleId) {
                kontaktpersonen {
                  id,
                  anrede {
                    id,
                    bezeichnung
                   }
                  vorname,
                  nachname,
                  email,
                  telefon
                }
                }
            }`;

    const GET_ANRECHNUNGSVORAUSSETZUNGSTYPEN = gql`
            query Anrechnungsvoraussetzungstypen {
              anrechnungsvoraussetzungstypen {
                id,
                bezeichnung
            }
    }`;

  const GET_HOCHSCHULZUGANGSBERECHTIGUNGEN = gql`
            query Hochschulzugangsberechtigungen {
              hochschulzugangsberechtigungen {
                id
                bezeichnung
                sortingorder
              }
    }`;

  const GET_PRAKTISCHEERFAHRUNGTYPEN = gql`
            query PraktischeErfahrungTypen {
              praktischeErfahrungTypen {
                id,
                bezeichnung
              }
    }`;

  const GET_EINHEITENZEITDAUERFORMULAR = gql`
            query EinheitenZeitdauerFormular {
              einheitenZeitdauerFormular(id: 7) {
                id,
                bezeichnungplural
              }
    }`;

  const GET_BILDUNGSTRAEGER = gql`
            query Bildungstraeger {
              bildungstraeger {
                id
                bezeichnung
                plz
                ort
                vordefinierterbildungstraeger
              }
            }`;

  const GET_FOERDERMOEGLICHKEITEN = gql`
            query Foerdermoeglichkeiten {
              foerdermoeglichkeiten {
                id
                bezeichnung
              }
            }`;

	return {
    /**
     * Returns multiple angebotsbezeichnungen at once
     */
    getAngebotsbezeichnungen: function (oApolloService, hochschulId) {
      return oApolloService.query({
        query: GET_ANGEBOTSBEZEICHNUNGEN,
        variables: { hochschulId }
      })
        .then(function (result) {
          return result.data.angebotsbezeichnungen;
        });
    },

    /**
     * Returns multiple angebotsTypen at once
     */
    getAngebotsTypen: function (oApolloService) {
      return oApolloService.query({query: GET_ANGEBOTSTYPEN})
        .then(function (result) {
          return result.data.angebotsTypen;
        });
    },

    /**
     * Returns multiple sprachen at once
     */
    getSprachen: function (oApolloService) {
      return oApolloService.query({query: GET_SPRACHEN})
        .then(function (result) {
          return result.data.sprachen;
        });
    },
    /**
     * Returns multiple sprachen at once
     */
    getAbschluesse: function (oApolloService) {
      return oApolloService.query({query: GET_ABSCHLUESSE})
        .then(function (result) {
          return result.data.abschluesse;
        });
    },
    /**
     * Returns multiple redaktionsstatuses at once
     */
    getRedaktionsstatuses: function (oApolloService) {
      return oApolloService.query({query: GET_REDAKTIONSSTATUSES})
        .then(function (result) {
          // Return all redaktionsstatuses except "Geloescht" (id: 3)
          return result.data.redaktionsstatuses.filter(function(e){ return e.id !== 3; });
        });
    },

    /**
     * Returns multiple angebotsvarianten at once
     */
    getAngebotsvarianten: function (oApolloService) {
      return oApolloService.query({query: GET_ANGEBOTSVARIANTEN})
      .then(function (result) {
        return result.data.angebotsVarianten;
      });
    },

    createAngebotsbezeichnung: function (oApolloService, oData) {
      if (!oData.hochschule) {
        return Promise.reject({message: "Did not provide a valid Id for hochschule"});
      }
      return oApolloService.mutate({
        mutation: CREATE_ANGEBOTSBEZEICHNUNG,
        variables: {
          data: {
            bezeichnung: oData.bezeichnung,
            hochschule: oData.hochschule.id
          }
        }
      });
    },

    updateAngebotsbezeichnung: function (oApolloService, oData) {
      return oApolloService.mutate({
        mutation: UPDATE_ANGEBOTSBEZEICHNUNG,
        variables: {
          data: {
            id: oData.id,
            bezeichnung: oData.bezeichnung,
            hochschule: oData.hochschule,
            istzumloeschenvorgesehen: oData.istzumloeschenvorgesehen
          }
        }
      });
    },

    deleteAngebotsbezeichnung: function (oApolloService, oData) {
      return oApolloService.mutate({
        mutation: DELETE_ANGEBOTSBEZEICHNUNG,
        variables: { data: { id: oData.id } }
      });
    },

    deleteAngebotsbezeichnungen: function (oApolloService, oData) {
      return oApolloService.mutate({
        mutation: DELETE_ANGEBOTSBEZEICHNUNGEN,
        variables: { data: { ids: oData.ids } }
        });
    },

    /**
     * Returns multiple Zeiteinheiten at once
     */
    getEinheitenZeitdauer: function (oApolloService) {
      return oApolloService.query({query: GET_EINHEITENZEITDAUER})
        .then(function (result) {
          return result.data.einheitenZeitdauer;
        });
    },

    /**
     * Returns multiple veranstaltungsformate at once
     */
    getVeranstaltungsformate: function (oApolloService) {
      return oApolloService.query({query: GET_VERANSTALTUNGSFORMATE})
        .then(function (result) {
          return result.data.veranstaltungsformate;
        });
    },

    /**
     * Returns multiple lehrUndLernformate at once
     */
    getLehrUndLernformate: function (oApolloService) {
      return oApolloService.query({query: GET_LEHRUNDLERNFORMATE})
        .then(function (result) {
          return result.data.lehrUndLernformate;
        });
    },

    /**
     * Returns multiple kontaktstellen at once
     */
    getKontaktstellen: function (oApolloService, hochschuleId) {
      return oApolloService.query({query: GET_KONTAKTSTELLEN,
                    variables: {
                      hochschuleId: parseInt(hochschuleId, 10)
                    }})
        .then(function (result) {
          return result.data.hochschule;
        });
    },

    /**
     * Returns multiple kontaktPersonen at once
     */
    getKontaktpersonen: function (oApolloService, hochschuleId) {
      return oApolloService.query({query: GET_KONTAKTPERSONEN,
        variables: {
          hochschuleId: parseInt(hochschuleId, 10)
          }})
        .then(function (result) {
          return result.data.hochschule;
        });
    },

    getWissensgruppen: function (oApolloService) {
      return oApolloService.query({query: GET_WISSENSGRUPPEN})
        .then(function (result) {
          return result.data.wissensgruppen;
        });
    },
    /**
     * Returns multiple anrechnungsvoraussetzungstypen at once
     */
    getAnrechnungsvoraussetzungstypen: function (oApolloService) {
      return oApolloService.query({query: GET_ANRECHNUNGSVORAUSSETZUNGSTYPEN})
        .then(function (result) {
          return result.data.anrechnungsvoraussetzungstypen;
        });
    },

    /**
     * Returns multiple hochschulzugangsberechtigung at once
     */
    getHochschulzugangsberechtigungen: function (oApolloService) {
      return oApolloService.query({query: GET_HOCHSCHULZUGANGSBERECHTIGUNGEN})
        .then(function (result) {
          return result.data.hochschulzugangsberechtigungen;
        });
    },

    /**
     * Returns multiple praktischeErfahrungTypen at once
     */
    getPraktischeErfahrungTypen: function (oApolloService) {
      return oApolloService.query({query: GET_PRAKTISCHEERFAHRUNGTYPEN})
        .then(function (result) {
          return result.data.praktischeErfahrungTypen;
        });
    },

    /**
     * Returns multiple einheitenZeitdauerFormular at once
     */
    getEinheitenZeitdauerFormular: function (oApolloService) {
      return oApolloService.query({query: GET_EINHEITENZEITDAUERFORMULAR})
        .then(function (result) {
          return result.data.einheitenZeitdauerFormular;
        });
    },

    /**
     * Returns multiple bildungstraeger at once
     */
    getBildungstraeger: function (oApolloService) {
      return oApolloService.query({query: GET_BILDUNGSTRAEGER})
        .then(function (result) {
          return result.data.bildungstraeger;
        });
    },

    /**
     * Returns multiple foerdermoeglichkeiten at once
     */
    getFoerdermoeglichkeiten: function (oApolloService) {
      return oApolloService.query({query: GET_FOERDERMOEGLICHKEITEN})
        .then(function (result) {
          return result.data.foerdermoeglichkeiten;
        });
    },

	};
});
