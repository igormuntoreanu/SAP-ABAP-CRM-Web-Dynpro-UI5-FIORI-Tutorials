sap.ui.define([
  "apollo/client/thirdparty/apollo"
], function(UI5Apollo) {
  "use strict";

  /**
   * Define gql wrapper for Apollo queries;
   * @see https://www.apollographql.com/docs/react/data/queries/
   */
  const {gql} = UI5Apollo;

  const GET_HOCHSCHULEN = gql`
        query getHochschulen {
          hochschulen {
            id
            name
            kurzname
          }
        }`;

  return {

    /**
     * Returns all Hochschulen
     */
    getHochschulen: function (oApolloService) {
      return oApolloService.query({query: GET_HOCHSCHULEN})
        .then(function (result) {
          return result.data.hochschulen;
        });
    }
  };
});
