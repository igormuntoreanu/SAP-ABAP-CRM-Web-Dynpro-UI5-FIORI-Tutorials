sap.ui.define([
    "apollo/client/thirdparty/apollo",
    "de/hrk/hochweit/components/Weiterbildungsangebote/model/businessLogic/WSILogic",
    "de/hrk/hochweit/components/Weiterbildungsangebote/model/businessLogic/AllgemeineInformationenLogic"
], function(UI5Apollo, WSILogic, AllgemeineInformationenLogic) {
    "use strict";

    /**
     * Define gql wrapper for Apollo queries;
     * @see https://www.apollographql.com/docs/react/data/queries/
     */
    const {gql} = UI5Apollo;

    const GET_WEITERBILDUNGSANGEBOTE_HSB = gql`
        query TrefferlisteWeiterbildungsangebote($skip: Int!, $take: Int!,
                                     $search: String!,
                                     $filter: String!,
                                     $sortValue: String, $sortOrder: String){
            trefferlisteWeiterbildungsangebote(pagination: {skip: $skip, take: $take},
                                   search: $search,
                                   filter: $filter,
                                   orderBy: {sortValue: $sortValue, sortOrder:$sortOrder}) {
                id,
                bezeichnung{bezeichnung},
                veranstaltungsformate{bezeichnung},
                abschluss{bezeichnung},
                standorte{bezeichnungkurz},
                angebotstyp{bezeichnung}
            }
        }`;

        const GET_WEITERBILDUNGSANGEBOTE_POWER_USER = gql`
        query TrefferlisteWeiterbildungsangebote($skip: Int!, $take: Int!,
                                     $search: String!,
                                     $filter: String!,
                                     $sortValue: String, $sortOrder: String){
            trefferlisteWeiterbildungsangebote(pagination: {skip: $skip, take: $take},
                                   search: $search,
                                   filter: $filter,
                                   orderBy: {sortValue: $sortValue, sortOrder:$sortOrder}) {
                id,
                bezeichnung{bezeichnung},
                veranstaltungsformate{bezeichnung},
                abschluss{bezeichnung},
                standorte{bezeichnungkurz},
                angebotstyp{bezeichnung},
                datenherkunft,
                redaktionsstatus {bezeichnung}
            }
        }`;

        const GET_WEITERBILDUNGSANGEBOTE_ADMIN = gql`
        query TrefferlisteWeiterbildungsangebote($skip: Int!, $take: Int!,
                                     $search: String!,
                                     $filter: String!,
                                     $sortValue: String, $sortOrder: String){
            trefferlisteWeiterbildungsangebote(pagination: {skip: $skip, take: $take},
                                   search: $search,
                                   filter: $filter,
                                   orderBy: {sortValue: $sortValue, sortOrder:$sortOrder}) {
                id,
                bezeichnung{bezeichnung},
                veranstaltungsformate{bezeichnung},
                abschluss{bezeichnung},
                standorte{bezeichnungkurz},
                angebotstyp{bezeichnung},
                hochschule { kurzname },
                datenherkunft,
                redaktionsstatus {bezeichnung}
            }
        }`;

    //TODO: Bottom of query queries mockData
    const GET_WEITERBILDUNGSANGEBOT = gql`
        query Weiterbildungsangebot($weiterbildungsangebotId: Int!) {
            weiterbildungsangebot(id: $weiterbildungsangebotId) {
                id
                datumerstellung
                datumletzteaenderung
                hochschule {id name}
                bezeichnung{id bezeichnung}
                praesenzanteilzeitlich
                praesenzanteiloertlich
                rang
                lernergebnisse
                redaktionsstatus{id}
                angebotsvariante {id}
                abschluss {id bezeichnung}
                angebotstyp {id bezeichnung}
                maxects
                hauptunterichtssprache {id}
                veranstaltungsformenIDs
                praesenzanteiloertlich
                praesenzanteilzeitlich
                LehrUndLernEinheiten{
                  lehrundlernformat
                  asynchron
                  synchron
                  praesenz
                }
                lehrUndLernEinheitenIDs
                anmerkunglehrundlerneinheiten
                zulassungsvoraussetzung {
                  typ { id }
                }
                programmkontext {
                  id
                }
                zielgruppen
                Zeitbereich {
                   id
                   von
                   bis
                   einheit
                }
                zeitaufwandvon,
                zeitaufwandbis,
                zeitaufwandeinheit,
                wissensfeldzuordnungen {
                    id
                    gruppe
                    bereich
                }
                schwerpunkte
                interessenstest {
                    coder
                    codei
                    codea
                    codes
                    codee
                    codec
                    hollandcodeverwendung
                }
                WeiterbildungsangebotKosten{
                  teilkostenbetrag
                  teilkostendauer
                  Zeitlaenge{
                    id
                    wert
                    einheit
                  }
                  gesamtkostenbetrag
                  anmerkungen
                  link {
                    id
                    link
                    linkType
                    language
                    description
                    target
                    status
                    letzteueberpruefung
                    letzteueberpruefungerfolg
                  }
                  kostenwaehrung
                }
                fristAngebotszeitraum {
                  id
                  fristentyp
                  anmerkungen
                  zeitraum {
                  von
                  bis
                  }
                }
                fristAnmeldefrist {
                  id
                  fristentyp
                  anmerkungen
                  zeitraum {
                    von
                    bis
                  }
                }
                fristSpaetereAngebotszeitraeume {
                  id
                  fristentyp
                  anmerkungen
                  zeitraum {
                    von
                    bis
                  }
                }
                anrechnungsansprechpartner {
                  kontaktpersonen {
                    id
                    vorname
                    nachname
                    email
                    telefon
                  }
                  kontaktstelle {
                  id
                  kontaktstellentyp {
                      bezeichnung
                    }
                    adresse {
                      strasseoderpostfach
                      plz
                      ort
                    }
                    email
                    telefon
                  }
                }
                ansprechpartnerfueranerkennungausanrechnung
                voraussetzunganrechnungstyp
                anerkennungwebsiteausanrechnunguebernehmen
                einstufungspruefunginhoeheressemestermoeglich
                anerkennungsansprechpartner {
                  kontaktpersonen {
                    id
                    vorname
                    nachname
                    email
                    telefon
                  }
                  kontaktstelle {
                  id
                  kontaktstellentyp {
                      bezeichnung
                    }
                    adresse {
                      strasseoderpostfach
                      plz
                      ort
                    }
                    email
                    telefon
                  }
                }
                individuelleanrechnungwebsite{
                  id
                  link
                  linkType
                  language
                  description
                  target
                  status
                }
                anrechnungwebsite{
                  id
                  link
                  linkType
                  language
                  description
                  target
                  status
                }
                anerkennungwebsite {
                  id
                  link
                  linkType
                  language
                  description
                  target
                  status
                }
                hochschulzugangsberechtigung
                praktischeerfahrungen {
                  erfahrungstyp{
                    id
                    bezeichnung
                  }
                  erfahrungsdauerwert
                  erfahrungsdauereinheit
                  bereich
                }
                maxanrechenbareects
                BildungstraegerKooperation {
                  id
                  beginn
                  ende
                  Bildungstraeger {
                    id
                    bezeichnung
                    plz
                    ort
                    vordefinierterbildungstraeger
                  }
                }
                sonstigeFoerdermoeglichkeiten {
                  sonstigefoerdermoeglichkeit
                }
                foerdermoeglichkeitenIDs
                isthskimportiert
            }
        }`;

    const CREATE_WEITERBILDUNGSANGEBOT = gql`
        mutation createWeiterbildungsangebot($weiterbildungsangebot: WeiterbildungsangebotCreateInput!) {
            createWeiterbildungsangebot(
                data: $weiterbildungsangebot
            ) {
                id
                bezeichnung{bezeichnung}
            }
        }`;

    const EDIT_WEITERBILDUNGSANGEBOT = gql`
        mutation editWeiterbildungsangebot($weiterbildungsangebot: WeiterbildungsangebotEditInput!) {
            editWeiterbildungsangebot(
                data: $weiterbildungsangebot
            ) {
                id
                bezeichnung{bezeichnung}
            }
        }`;

    const DELETE_WEITERBILDUNGSANGEBOT = gql`
    mutation deleteWeiterbildungsangebot($weiterbildungsangebotId: Int!) {
        deleteWeiterbildungsangebot(
          id: $weiterbildungsangebotId
        ) {
            id
            bezeichnung{ bezeichnung }
        }
    }`;

  const CONVERT_WEITERBILDUNGSANGEBOTE = gql`
     query convert_weiterbildungsangebote($filter: String!, $exportType: String!, $filterInFilename: Boolean!) {
        convert_weiterbildungsangebote(filter: $filter, exportType: $exportType, filterInFilename: $filterInFilename)
     }`;

     const CONVERT_WEITERBILDUNGSANGEBOTDETAIL = gql`
     query convert_weiterbildungsangebotDetail($exportType: String!, $id: Int!, $content: String!) {
        convert_weiterbildungsangebotDetail(exportType: $exportType, id: $id, content: $content)
     }`;

	return {

        /**
         * Returns multiple weiterbildungsangebote at once
         */
        getAllWA: function (oApolloService, oPagination, sSearch, oSorting, sUserRole, oFilter) {
            // Query must contain a value for its variables
            sSearch = (sSearch == null) ? "" : sSearch;
            oSorting = (oSorting == null) ? {} : oSorting;
            oFilter = (oFilter == null) ? "" : JSON.stringify(oFilter);

            let roleSpecificQuery = "";
            switch (sUserRole){
                case "tech_admin":
                case "fach_admin":
                case "ops_admin":
                case "admin":
                    roleSpecificQuery = GET_WEITERBILDUNGSANGEBOTE_ADMIN;
                    break;
                case "power_user":
                    roleSpecificQuery = GET_WEITERBILDUNGSANGEBOTE_POWER_USER;
                    break;
                case "hsb":
                    roleSpecificQuery = GET_WEITERBILDUNGSANGEBOTE_HSB;
                    break;
                default:
                    break;
      }

            return oApolloService.query({query: roleSpecificQuery,
                            variables: {
                                skip: oPagination.skip,
                                take: oPagination.take,
                                search: sSearch,
                                filter: oFilter,
                                sortValue: oSorting.sortValue,
                                sortOrder: oSorting.sortOrder
                            }})
            .then(function(result){
                return result.data.trefferlisteWeiterbildungsangebote;
            });
        },

        /**
         * Returns specific weiterbildungsantebot by ID
         */
        getWA: function (oApolloService, weiterbildungsangebotId) {
            return oApolloService.query({query: GET_WEITERBILDUNGSANGEBOT,
                            variables: {
                                weiterbildungsangebotId: parseInt(weiterbildungsangebotId, 10)
                            }})
            .then(function(result){
                return result.data.weiterbildungsangebot;
            });
        },

    getEmptyWA: function (hochschulId) {
        return {
                  id: null,
                  hochschule: {id: hochschulId, name: null },
                  datumerstellung: null,
                  datumletzteaenderung: null,
                  rang: "Low",
                  lernergebnisse: null,
                  zulassungsvoraussetzung: { typ: { id: 1} },
                  programmkontext: {id: 1},
                  //Header
                  redaktionsstatus: {id: 1},
                  //EF 1
                  bezeichnung: {id: null, bezeichnung: null},
                  angebotsvariante: {id: null},
                  angebotstyp: {id: null},
                  abschluss: {id: null, bezeichnung: null},
                  maxects: 0,
                  hauptunterichtssprache: {id: 1},
                  WeiterbildungsangebotKosten: {teilkostenbetrag: null, teilkostendauer: null,
                                                Zeitlaenge: {id: null, wert: null, einheit: 1},
                                                gesamtkostenbetrag: 0, anmerkungen: null,
                                                link: null,
                                                kostenwaehrung: 20 // €
                                                },
                  //EF 2
                  veranstaltungsformenIDs: [],
                  praesenzanteiloertlich: 0,
                  praesenzanteilzeitlich: 0,
                  LehrUndLernEinheiten: [{lehrundlernformat: null, asynchron: false, synchron: false, praesenz: false}],
                  anmerkunglehrundlerneinheiten: null,
                  zielgruppen: "",
                  Zeitbereich: {von: null, bis: null, einheit: null},
                  zeitaufwandvon: null,
                  zeitaufwandbis: null,
                  zeitaufwandeinheit: null,
                  //EF 3
                  fristAngebotszeitraum: {id: null, fristentyp: "Angebotszeitraum", anmerkungen: null, zeitraum: {von: null, bis: null}},
                  fristAnmeldefrist: {id: null, fristentyp: "Anmeldefrist", anmerkungen: null, zeitraum: {von: null, bis: null}},
                  fristSpaetereAngebotszeitraeume: [],
                  //EF7
                  hochschulzugangsberechtigung: [],
                  anrechnungsansprechpartner: [],
                  anerkennungsansprechpartner: [],
                  voraussetzunganrechnungstyp: null,
                  einstufungspruefunginhoeheressemestermoeglich: false,
                  maxanrechenbareects: null,
                  BildungstraegerKooperation: [],
                  individuelleanrechnungwebsite: null,
                  anrechnungwebsite: null,
                  anerkennungwebsite: null,
                  praktischeerfahrungen: [],
                  // EF 9
                  sonstigeFoerdermoeglichkeiten: [],
                  foerdermoeglichkeitenIDs: [],
                  //EF 11
                  schwerpunkte: [],
                  interessenstest: {coder: null, codei: null, codea: null, codes: null, codee: null, codec: null, hollandcodeverwendung: new WSILogic().getCodeTypes().WITCode},
                  wissensfeldzuordnungen: []
                };
    },

    _omitRecursively: function (oObj, propName) {
      if (oObj === null || typeof oObj !== "object") {
        return oObj;
      }
      let cleaned;
      if (Array.isArray(oObj)) {
        cleaned = oObj;
      } else {
        // eslint-disable-next-line no-unused-vars
        const { [propName]: _, ...cleanedProperties } = oObj;
        cleaned = cleanedProperties;
      }
      for (const objProp of Object.keys(cleaned)) {
        const propertyValue = cleaned[objProp];
        if (typeof propertyValue === "object" && propertyValue !== null) {
          cleaned[objProp] = this._omitRecursively(propertyValue, propName);
        }
      }
      return cleaned;
    },

    createNewWeiterbildungsangebot: function (oApolloService, oWeiterbildungsangebot) {
        //Remove __typename from object
        oWeiterbildungsangebot = this._omitRecursively(oWeiterbildungsangebot, "__typename");
        // Remove UI-Information from model
        // Remove all valueState attribute from object (Fristen & Bildungsträger)
        oWeiterbildungsangebot = this._omitRecursively(oWeiterbildungsangebot, "valueState");
        // Only leave api-relevant attributes for ef11 wsi form
        oWeiterbildungsangebot = Object.assign(oWeiterbildungsangebot, new WSILogic().sanitizeModelData(oWeiterbildungsangebot));
        // Transform values of EF1 data fields into correct data format
        oWeiterbildungsangebot = Object.assign(oWeiterbildungsangebot, AllgemeineInformationenLogic.transformValues(oWeiterbildungsangebot));

      // filter out kontaktpersonen with id === null (created initially to initialize bindings)
      if (oWeiterbildungsangebot.anerkennungsansprechpartner){
        oWeiterbildungsangebot.anerkennungsansprechpartner = oWeiterbildungsangebot.anerkennungsansprechpartner.map(ansprechpartner => {
          const filtered = Object.assign({}, ansprechpartner);
          filtered.kontaktpersonen = filtered.kontaktpersonen.filter(kontaktperson => !!kontaktperson.id);
          return filtered;
        });
      }

      if (oWeiterbildungsangebot.anrechnungsansprechpartner){
        oWeiterbildungsangebot.anrechnungsansprechpartner = oWeiterbildungsangebot.anrechnungsansprechpartner.map(ansprechpartner => {
          const filtered = Object.assign({}, ansprechpartner);
          filtered.kontaktpersonen = filtered.kontaktpersonen.filter(kontaktperson => !!kontaktperson.id);
          return filtered;
        });
      }

        return oApolloService.query({query: CREATE_WEITERBILDUNGSANGEBOT,
            variables: {
                weiterbildungsangebot: oWeiterbildungsangebot
            }})
            .then(function(result){
              if (result.errors && result.errors.length) {
                throw {
                  validationErrors: result.errors
                };
              }
              return result.data.createWeiterbildungsangebot;
            });
    },

    editWeiterbildungsangebot: function (oApolloService, oWeiterbildungsangebot) {
        //Remove __typename from object
        oWeiterbildungsangebot = this._omitRecursively(oWeiterbildungsangebot, "__typename");
        // Remove all valueState attribute from object (Fristen & Bildungsträger)
        oWeiterbildungsangebot = this._omitRecursively(oWeiterbildungsangebot, "valueState");
        // Remove non-api-relevant attributes from EF11 data fields
        oWeiterbildungsangebot = Object.assign(oWeiterbildungsangebot, new WSILogic().sanitizeModelData(oWeiterbildungsangebot));
        // Transform values of EF1 data fields into correct data format
        oWeiterbildungsangebot = Object.assign(oWeiterbildungsangebot, AllgemeineInformationenLogic.transformValues(oWeiterbildungsangebot));

      // filter out kontaktpersonen with id === null (created initially to initialize bindings)
      if (oWeiterbildungsangebot.anerkennungsansprechpartner){
        oWeiterbildungsangebot.anerkennungsansprechpartner = oWeiterbildungsangebot.anerkennungsansprechpartner.map(ansprechpartner => {
          const filtered = Object.assign({}, ansprechpartner);
          filtered.kontaktpersonen = filtered.kontaktpersonen.filter(kontaktperson => !!kontaktperson.id);
          return filtered;
        });
      }

      if (oWeiterbildungsangebot.anrechnungsansprechpartner){
        oWeiterbildungsangebot.anrechnungsansprechpartner = oWeiterbildungsangebot.anrechnungsansprechpartner.map(ansprechpartner => {
          const filtered = Object.assign({}, ansprechpartner);
          filtered.kontaktpersonen = filtered.kontaktpersonen.filter(kontaktperson => !!kontaktperson.id);
          return filtered;
        });
      }

      return oApolloService.query({query: EDIT_WEITERBILDUNGSANGEBOT,
        variables: {
            weiterbildungsangebot: oWeiterbildungsangebot
        }})
        .then(function(result){
          if (result.errors && result.errors.length) {
            throw {
              validationErrors: result.errors
            };
          }
          return result.data.editWeiterbildungsangebot;
        });
    },

    /**
     * Set redaktionsstatus to deleted/3
     */
    deleteWeiterbildungsangebot: function (oApolloService, weiterbildungsangebotId) {
      return oApolloService.query({query: DELETE_WEITERBILDUNGSANGEBOT,
          variables: {
            weiterbildungsangebotId: parseInt(weiterbildungsangebotId, 10)
          }})
          .then(function(result){
              return result.data.deleteWeiterbildungsangebot;
          });
    },

    /**
     * Returns specific weiterbildungsantebotKosten by ID
     */
    getWeiterbildungsangebotKosten: function (oApolloService, weiterbildungsangebotId) {
      return oApolloService.query({query: GET_WEITERBILDUNGSANGEBOTKOSTEN,
        variables: {
          weiterbildungsangebotId: parseInt(weiterbildungsangebotId, 10)
        }})
        .then(function(result){
          return result.data.weiterbildungsangebotKosten;
        });
    },

        /**
         * Takes current list and filter and returns them converted into a file
         */
        exportList: function (oApolloService, oFilter, exportType) {
            oFilter = (oFilter == null) ? "" : JSON.stringify(oFilter);

            return oApolloService.query({query: CONVERT_WEITERBILDUNGSANGEBOTE,
                variables: {
                    filter: oFilter,
                    exportType: exportType,
                    filterInFilename: false
            }})
            .then(function(result){
                // Transform result to JSON
                switch (exportType) {
                    case "csv":
                        let oCSV = JSON.parse(result.data.convert_weiterbildungsangebote);
                        oCSV.content = "data:text/csv;charset=utf-8," + oCSV.content;
                        return oCSV;
                    case "json":
                        let oJSON = JSON.parse(result.data.convert_weiterbildungsangebote);
                        oJSON.content = "data:application/json;charset=utf-8," + oJSON.content;
                        return oJSON;
                    case "xml":
                        let oXML = JSON.parse(result.data.convert_weiterbildungsangebote);
                        oXML.content = "data:text/xml;charset=utf-8," + oXML.content;
                        return oXML;
                    case "xls":
                        let oXLS = JSON.parse(result.data.convert_weiterbildungsangebote);
                        oXLS.content = "data:application/vnd.ms-excel;base64," + oXLS.content;
                        return oXLS;
                    default:
                        break;
                }

            });;
        },

        exportDetail: function (oApolloService, id, oContent, exportType) {
            return oApolloService.query({query: CONVERT_WEITERBILDUNGSANGEBOTDETAIL,
                variables: {
                    exportType: exportType,
                    id: id,
                    content: JSON.stringify(oContent)
            }})
            .then(function(result){
                // Transform result to JSON
                switch (exportType) {
                    case "xml":
                        let oXML = JSON.parse(result.data.convert_weiterbildungsangebotDetail);
                        oXML.content = "data:text/xml;charset=utf-8," + oXML.content;
                        return oXML;
                    case "json":
                        let oJSON = JSON.parse(result.data.convert_weiterbildungsangebotDetail);
                        oJSON.content = "data:application/json;charset=utf-8," + oJSON.content;
                        return oJSON;
                    case "pdf":
                        let oPDF = JSON.parse(result.data.convert_weiterbildungsangebotDetail);
                        oPDF.content = "data:application/pdf;base64," + oPDF.content;
                        return oPDF;
                    default:
                        break;
                }
            });
        },

	};
});
