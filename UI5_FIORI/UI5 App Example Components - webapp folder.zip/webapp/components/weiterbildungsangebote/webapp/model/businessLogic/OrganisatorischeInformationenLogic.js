sap.ui.define([	"sap/ui/base/ManagedObject"
], function() {
	"use strict";

	return {

	      createLehrUndLernEinheitenEntry: function () {
	        return {
            lehrundlernformat: null,
            asynchron: false,
            synchron: false,
            praesenz: false
          };
        },

        getEmptyOrganisatorischeInformationen: function () {
           return {
                veranstaltungsformenIDs: [],
                praesenzanteiloertlich: null,
                praesenzanteilzeitlich: null,
                LehrUndLernEinheiten:[this.createLehrUndLernEinheitenEntry()],
                lehrUndLernEinheitenIDs: [],
                anmerkunglehrundlerneinheiten: "",
                zielgruppen: "",
                Zeitbereich: {
                  id: null,
                  von: null,
                  bis: null,
                  einheit: 1,
                },
                zeitaufwandvon: null,
                zeitaufwandbis: null,
                zeitaufwandeinheit: null
            };
        },

        adaptLoadedWAData: function (oOrganisatorischeInformationen) {
            if (!oOrganisatorischeInformationen) {
                return this.getEmptyOrganisatorischeInformationen();
            }
            if (!oOrganisatorischeInformationen.LehrUndLernEinheiten) {
                oOrganisatorischeInformationen.LehrUndLernEinheiten = this.getEmptyOrganisatorischeInformationen().LehrUndLernEinheiten;
            }
            if (!oOrganisatorischeInformationen.Zeitbereich) {
                oOrganisatorischeInformationen.Zeitbereich = this.getEmptyOrganisatorischeInformationen().Zeitbereich;
            }
            return oOrganisatorischeInformationen;
        }
    };
});
