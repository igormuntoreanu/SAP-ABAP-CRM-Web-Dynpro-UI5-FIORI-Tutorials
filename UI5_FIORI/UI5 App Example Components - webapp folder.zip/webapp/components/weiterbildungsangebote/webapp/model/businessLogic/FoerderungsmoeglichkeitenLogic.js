sap.ui.define([], function () {
  "use strict";
  return {
    /**
     * Method to create a new SonstigeFoerdermoeglichkeit object - needed for the add functionality of the corresponding Feldliste in the UI
     * @return {{sonstigefoerdermoeglichkeit: string}}
     */
    createNewSonstigeFoerdermoeglichkeit: function () {
      return {
        sonstigefoerdermoeglichkeit: ""
      };
    },
  };
});
