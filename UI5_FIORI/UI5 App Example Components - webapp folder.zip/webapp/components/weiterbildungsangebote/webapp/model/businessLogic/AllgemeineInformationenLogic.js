sap.ui.define([], function () {
    "use strict";

    return {
        transformValues: function (oWeiterbildungsangebot) {
            // Transform the cost data to float, to match the db
            if (typeof oWeiterbildungsangebot.WeiterbildungsangebotKosten.teilkostenbetrag == "string"
                && oWeiterbildungsangebot.WeiterbildungsangebotKosten.teilkostenbetrag) {
                oWeiterbildungsangebot.WeiterbildungsangebotKosten.teilkostenbetrag = parseFloat(oWeiterbildungsangebot.WeiterbildungsangebotKosten.teilkostenbetrag.replace(",", "."));
            }
            if (typeof oWeiterbildungsangebot.WeiterbildungsangebotKosten.gesamtkostenbetrag == "string"
                && oWeiterbildungsangebot.WeiterbildungsangebotKosten.gesamtkostenbetrag) {
                oWeiterbildungsangebot.WeiterbildungsangebotKosten.gesamtkostenbetrag = parseFloat(oWeiterbildungsangebot.WeiterbildungsangebotKosten.gesamtkostenbetrag.replace(",", "."));
            }
            if (oWeiterbildungsangebot.WeiterbildungsangebotKosten.gesamtkostenbetragTrueValue){
                delete oWeiterbildungsangebot.WeiterbildungsangebotKosten.gesamtkostenbetragTrueValue;
            }
            if (oWeiterbildungsangebot.WeiterbildungsangebotKosten.teilkostenbetragTrueValue){
                delete oWeiterbildungsangebot.WeiterbildungsangebotKosten.teilkostenbetragTrueValue;
            }
            return oWeiterbildungsangebot;
        }
    };
});