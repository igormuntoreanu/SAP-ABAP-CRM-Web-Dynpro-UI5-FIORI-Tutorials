sap.ui.define([
    "sap/base/Log"
], function (Log) {
    "use strict";

    return {
        castKatalogBezeichnungToWABezeichnung: function (oKatalogBezeichnung) {
            if (!oKatalogBezeichnung.id || !oKatalogBezeichnung.bezeichnung) {
                Log.error("Invalid parameter oKatalogBezeichnung; field id or bezeichnung is missing");
                return null;
            }
            return {
                id: oKatalogBezeichnung.id,
                bezeichnung: oKatalogBezeichnung.bezeichnung
            };
        }
    };
});