sap.ui.define([], function () {
  "use strict";

  // TODO: TODO-Marker + Jira-Ticket für Backend-Validierung diesbzgl.

  // Preference States
  const GESAMTKOSTEN = "Gesamtkosten";
  const TEILKOSTEN = "Teilkosten";
  const NONE = "Keine";

  return {

    getPreferenceValues: function () {
      return {
        GESAMTKOSTEN,
        TEILKOSTEN,
        NONE
      };
    },

    getEmptyWeiterbildungsangebotKosten: function () {
      return {
        teilkostenbetrag: null, teilkostendauer: null,
          Zeitlaenge: {id: null, wert: null, einheit: 1},
          gesamtkostenbetrag: null, anmerkungen: null,
          link: null,
          kostenwaehrung: 20 // €
      };
    },

    adaptLoadedWAData: function (oWeiterbildungsangebotKosten) {
      if (!oWeiterbildungsangebotKosten) {
        return this.getEmptyWeiterbildungsangebotKosten();
      }
      if (!oWeiterbildungsangebotKosten.link) {
        oWeiterbildungsangebotKosten.link = this.getEmptyWeiterbildungsangebotKosten().link;
      }
      return oWeiterbildungsangebotKosten;
    },


    _calculateGesamtkostenValue: function (vTeilkosten, vTeilkostendauer) {
      if (vTeilkosten !== "" && vTeilkostendauer !== "") {
        return vTeilkosten * vTeilkostendauer;
      } else {
        return 0;
      }
    },

    validateTeilkosten: function (oTeilkostenbetrag, oTeilkostendauer) {
      return (oTeilkostenbetrag.getValue() && oTeilkostendauer.getValue() || !oTeilkostenbetrag.getValue() && !oTeilkostendauer.getValue());
    },
    validateGesamtkosten: function (oGesamtkostenbetrag, oKostenlos) {
      return (parseFloat(oGesamtkostenbetrag.getValue()) > 0 || oKostenlos.getSelected());
    },


    getKostenState: function (vTeilkostenbetrag = null, vTeilkostendauer = null, vGesamtkostenbetrag = null, bKostenlos= false, vPreference = NONE) {
      const oKostenState = {
        teilkosten: {
          enabled: !bKostenlos,
          value: vTeilkostenbetrag
        },
        gesamtkosten: {
          enabled: !bKostenlos,
          value: ""
        },
        zeitdauer: {
          enabled: !bKostenlos
        },
        teilkostendauer: {
          enabled: !bKostenlos,
          value: vTeilkostendauer
        },
        kostenlos: bKostenlos
      };
      if (bKostenlos) {
        oKostenState.teilkosten.value = null;
        oKostenState.teilkostendauer.value = null;
        oKostenState.gesamtkosten.value = null;
      } else {
        if (vPreference === GESAMTKOSTEN && vGesamtkostenbetrag !== "") {
          oKostenState.gesamtkosten.value = vGesamtkostenbetrag;
          oKostenState.teilkosten.value = null;
          oKostenState.teilkostendauer.value = null;
          oKostenState.teilkosten.enabled = false;
          oKostenState.teilkostendauer.enabled = false;
          oKostenState.zeitdauer.enabled = false;
        } else if (vPreference === TEILKOSTEN) {
          oKostenState.gesamtkosten.value = this._calculateGesamtkostenValue(vTeilkostenbetrag, vTeilkostendauer);
          oKostenState.gesamtkosten.enabled = false;
        }
      }
      return oKostenState;
    }

  };
});
