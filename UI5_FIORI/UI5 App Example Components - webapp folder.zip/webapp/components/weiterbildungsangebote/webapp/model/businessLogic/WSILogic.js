sap.ui.define([
  "sap/ui/base/Object",
  "sap/ui/core/message/Message"
], function (BaseObject, Message) {
  "use strict";

  /**
   * ID for the validation message of incomplete selection of Wissensgruppe and Wissensbereich
   * @type {string}
   */
  const sWissensfelderAuswahlErrorId = "wissensfelder-incomplete-id";
  /**
   * ID for the validation message of an invalid selection of RIASEC values
   * @type {string}
   */
  const sWissenstestRIASECErrorId = "wissenstest-incomplete-id";
  /**
   * Keys for the RIASEC properties in the JSON object - needed to iterate over the object
   * @type {string[]}
   */
  const aKategorieKeys = ["r", "i", "a", "s", "e", "c"];

  /**
   * String representations for hollandcodeverwendung for structured use in the client
   * @type {object}
   */
  const codeTypes = {
    WIT_CODE: "WITCode",
    WIT_CODE_AND_INDIVIDUAL_CODE: "WITCodeAndIndividualCode",
    INDIVIDUAL_CODE: "IndividualCode"
  };

  /**
   * Method to generate a base selection instance for the combo boxes
   * @param aBereiche
   * @return {{wissensbereiche: *[], bereich: null, id: null, gruppeState: string, gruppe: null, bereichState: string}}
   * @private
   */
  const _createAuswahlObject = (aBereiche) => {
    return {
      id: null,
      gruppeState: "None",
      gruppe: null,
      bereich: null,
      bereichState: "None",
      wissensbereiche: aBereiche || []
    };
  };

  const _createInteressenstest = () => {
    return {
      hollandcodeverwendung: codeTypes.WIT_CODE,
      coder: null,
      rSelectable: true,
      rSelected: false,
      codei: null,
      iSelectable: true,
      iSelected: false,
      codea: null,
      aSelectable: true,
      aSelected: false,
      codes: null,
      sSelectable: true,
      sSelected: false,
      codee: null,
      eSelectable: true,
      eSelected: false,
      codec: null,
      cSelectable: true,
      cSelected: false
    };
  };

  /**
   * Method to generate the root object for Eingabeformular 11
   * @return {{wissensfeldzuordnungen: *[], interessenstest: {eSelected: boolean, codes: null, coder: null, eSelectable: boolean, hollandcodeverwendung: string, sSelectable: boolean, cSelected: boolean, cSelectable: boolean, iSelectable: boolean, sSelected: boolean, codec: null, aSelected: boolean, rSelectable: boolean, codea: null, rSelected: boolean, iSelected: boolean, codei: null, aSelectable: boolean, codee: null}, schwerpunkte: [{de: string}]}}
   * @private
   */
  const _createModelRootObject = () => {
    return {
      wissensfeldzuordnungen: [],
      schwerpunkte: [{de: ""}],
      interessenstest: _createInteressenstest()
    };
  };

  /**
   * The _formularFields variable for the formular reset functionality of the EingabeformularBaseController
   * @type {{wissensfeldzuordnungen: *[], interessenstest: {eSelected: boolean, codes: null, coder: null, eSelectable: boolean, hollandcodeverwendung: string, sSelectable: boolean, cSelected: boolean, cSelectable: boolean, iSelectable: boolean, sSelected: boolean, codec: null, aSelected: boolean, rSelectable: boolean, codea: null, rSelected: boolean, iSelected: boolean, codei: null, aSelectable: boolean, codee: null}, schwerpunkte: {de: string}[]}}
   * @private
   */
  const _formularFields = _createModelRootObject();

  return BaseObject.extend("de.hrk.hochweit.components.Weiterbildungsangebote.model.businessLogic.WSILogic", {

    /**
     * Method to apply the data obtained from the backend to the current model state
     * @param oWeiterbildungsangebot the Weiterbildungsangebot JSON structure from the backend
     * @private
     */
    _applyWeiterbildungsangebot: function (oWeiterbildungsangebot) {
      _formularFields.interessenstest = Object.assign({}, _createInteressenstest(), oWeiterbildungsangebot.interessenstest);
      let iSelectedCount = 0;
      // apply selected status according to initialize technical attribute
      this.getRIASECKeys().forEach(sCategory => {
        const oInteressenstest = _formularFields.interessenstest;
        const bCategorySelected = !!oInteressenstest["code" + sCategory];
        oInteressenstest[sCategory + "Selected"] = bCategorySelected;
        if (bCategorySelected) {
          iSelectedCount++;
        }
      });
      // Apply selection status
      this.getRIASECKeys().forEach(sCategory => {
        const oInteressenstest = _formularFields.interessenstest;
        oInteressenstest[sCategory + "Selectable"] = iSelectedCount < 3 || oInteressenstest[sCategory + "Selected"];
      });
      _formularFields.schwerpunkte = oWeiterbildungsangebot.schwerpunkte || [];
      if (oWeiterbildungsangebot.wissensfeldzuordnungen && oWeiterbildungsangebot.wissensfeldzuordnungen.length) {
        _formularFields.wissensfeldzuordnungen = oWeiterbildungsangebot.wissensfeldzuordnungen.map(oZuordnung => {
          const oKatalogGruppe = this.findGruppe(oZuordnung.gruppe);
          const oTemplate = _createAuswahlObject(this.wissensbereiche);
          oTemplate.id = oZuordnung.id || null;
          oTemplate.gruppe =  oKatalogGruppe ? oKatalogGruppe.id : null;
          oTemplate.bereich = oZuordnung.bereich;
          return [oTemplate];
        }).reduce((acc, arr) => {
          acc.push(...arr);
          return acc;
        });
      } else {
        _formularFields.wissensfeldzuordnungen = [_createAuswahlObject(this.wissensbereiche)];
      }
    },

    /**
     * Method to adapt the internal state of this WSILogic instance to the data given as parameter
     * @param oWeiterbildungsangebot the Weiterbildungsangebot JSON structure
     * @param data the Katalog data for Wissensgruppen
     * @param oResourceBundle instance of the current resource bundle
     */
    adaptData: function (oWeiterbildungsangebot, data, oResourceBundle) {
      this.wissensbereiche = data.reduce((acc, oGruppe) => {
        acc.push(...oGruppe.Wissensbereich);
        return acc;
      }, []);
      this.wissensgruppen = [...data.map(oGruppe => {
        return {
          ...oGruppe};
      })];
      this._applyWeiterbildungsangebot(oWeiterbildungsangebot);
      this._resourceBundle = oResourceBundle;
    },

    /**
     * Method to apply the state of this WSILogic instance to the given model
     * @param oModel the instance of the model to apply the state to
     */
    applyToModel: function (oModel) {
      oModel.setProperty("/wissensfeldzuordnungen", _formularFields.wissensfeldzuordnungen);
      oModel.firePropertyChange({
        reason: sap.ui.model.ChangeReason.Change,
        path: "/wissensfeldzuordnungen"
      });
      oModel.setProperty("/schwerpunkte", _formularFields.schwerpunkte);
      oModel.firePropertyChange({
        reason: sap.ui.model.ChangeReason.Change,
        path: "/schwerpunkte"
      });
      oModel.setProperty("/interessenstest", _formularFields.interessenstest);
      oModel.firePropertyChange({
        reason: sap.ui.model.ChangeReason.Change,
        path: "/interessenstest"
      });
    },

    sanitizeModelData: function (oWeiterbildungsangebot) {
      // remove wissensgruppen specific technical attributes
      const aSanitizedWissensfeldzuordnungen = oWeiterbildungsangebot.wissensfeldzuordnungen
        .filter(oWissensfeldzuordnung => !!oWissensfeldzuordnung.gruppe && !!oWissensfeldzuordnung.bereich)
        .map(oWissensfeldzuordnung => {
          return {
            id: oWissensfeldzuordnung.id,
            gruppe: parseInt(oWissensfeldzuordnung.gruppe, 10),
            bereich: parseInt(oWissensfeldzuordnung.bereich, 10)
          };
        });
      // schwerpunkte do not have any technical attributes
      const aSanizitedSchwerpunkte = oWeiterbildungsangebot.schwerpunkte.map(oSchwerpunkt => {
        return {
          de: oSchwerpunkt.de,
        };
      });
      // remove interessenstest specific technical attributes
      const oInteressenstest = oWeiterbildungsangebot.interessenstest;
      const oSanitizedInteressenstest = {
        hollandcodeverwendung: oInteressenstest.hollandcodeverwendung
      };
      this.getRIASECKeys().reduce((oResult, sCategory) => {
        const sKey = "code" + sCategory;
        oResult[sKey] = oInteressenstest[sKey];
        return oResult;
      }, oSanitizedInteressenstest);

      return {
        wissensfeldzuordnungen: aSanitizedWissensfeldzuordnungen,
        schwerpunkte: aSanizitedSchwerpunkte,
        interessenstest: oSanitizedInteressenstest
      };
    },

    /**
     * Getter for the formular fields
     * @return {{wissensfeldzuordnungen: *[], interessenstest: {eSelected: boolean, codes: null, coder: null, eSelectable: boolean, hollandcodeverwendung: string, sSelectable: boolean, cSelected: boolean, cSelectable: boolean, iSelectable: boolean, sSelected: boolean, codec: null, aSelected: boolean, rSelectable: boolean, codea: null, rSelected: boolean, iSelected: boolean, codei: null, aSelectable: boolean, codee: null}, schwerpunkte: {de: string}[]}}
     */
    getFormularFields: function () {
      return _formularFields;
    },

    getCodeTypes: function () {
      return codeTypes;
    },

    /**
     * Method to create a new selection object - needed for the add functionality of the corresponding Feldliste in the UI
     * @return {{wissensbereiche: *[], bereich: null, id: null, gruppeState: string, gruppe: null, bereichState: string}}
     */
     createNewWissensfeldzuordnung: function () {
      return _createAuswahlObject(this.wissensbereiche);
    },

    /**
     * Method to create a new Schwerpunkt object - needed for the add functionality of the corresponding Feldliste in the UI
     * @return {{de: string}}
     */
    createNewSchwerpunkt: function () {
      return {
        de: ""
      };
    },

    /**
     * Convenience method to generate a validation error message
     * @return {*}
     */
     createZuordnungError: function () {
      return new Message({
        id: sWissensfelderAuswahlErrorId,
        type: "Error",
        message: this._resourceBundle.getText("wsi.wissensfelder.unvollstaendigeAuswahl.title"),
        description: this._resourceBundle.getText("wsi.wissensfelder.unvollstaendigeAuswahl.description"),
        additionalText: this._resourceBundle.getText("wsi.wissensfelder.unvollstaendigeAuswahl.subtitle")
      });
    },

    /**
     * Convenience method to generate a validation error message
     * @return {*}
     */
    createRIASECError: function () {
      return new Message({
        id: sWissenstestRIASECErrorId,
        type: "Error",
        message: this._resourceBundle.getText("wsi.interessentest.ungueltigeAuswahl.title"),
        description: this._resourceBundle.getText("wsi.interessentest.ungueltigeAuswahl.description"),
        additionalText: this._resourceBundle.getText("wsi.interessentest.ungueltigeAuswahl.subtitle")
      });
    },


    /**
     * Getter for the RIASEC keys
     * @return {string[]}
     */
    getRIASECKeys: function () {
      return aKategorieKeys;
    },

    /**
     * Getter for the current Katalog data of Wissensgruppen
     * @return {*|*[]}
     */
    getWissensgruppen: function () {
      return this.wissensgruppen;
    },

    /**
     * Getter for the current Katalog data of Wissensbereiche
     * @return {*}
     */
    getWissensbereiche: function () {
      return this.wissensbereiche;
    },

    /**
     * Helper method to find a Wissensgruppe instance for a given id
     * @param sGruppeId the id of the Wissensgruppe to search for
     * @return {T}
     */
    findGruppe: function (sGruppeId) {
      return this.wissensgruppen.find(oGruppe => oGruppe.id === sGruppeId);
    },

    /**
     * Helper method to find the corresponding Wissensgruppe for a selected Wissensbereich
     * @param iBereichsId
     * @return {T|null}
     */
    findGruppeForBereich: function (iBereichsId) {
      return this.wissensgruppen
        .filter(oGruppe => !!oGruppe.id)
        .find(oGruppe => oGruppe.Wissensbereich.findIndex(oWissensbereich => oWissensbereich.id === iBereichsId) !== -1) || null;
    }
  });
});
