sap.ui.define([
], function () {
  "use strict";

  return {
    createSpaetereAngebotszeitraumEntry: function () {
      return {
        id: null,
        fristentyp: "SpaetererAngebotszeitraum",
        anmerkungen: null,
        zeitraum: {
          von: null,
          bis: null
        },
      };
    },

    validateVonAndBis: function (dVon, dBis) {
      if (!dBis || !dVon || (dVon > dBis)) {
        return "Error";
      } else {
          return "None";
      }
    },

    validateRequiredBis: function (dVon, dBis) {
      if (!dBis) {
        return "Error";
      } else if (!dVon) {
          return "None";
      } else if (dVon > dBis){
          return "Error";
      } else {
          return "None";
      }
    },

    setFristenTyp: function (){
      for (var i = 0; i <= 3; i++) {
        var sPathFristentyp = "this.getModel().oData.fristSpaetereAngebotszeitraeume["+i+"]";
        sPathFristentyp.setValue(fristentyp, "SpaetererAngebotszeitraum");
      }
    }
  };
});
