sap.ui.define([
], function () {
  "use strict";


  return {
    createNewAnsprechpartner: function () {
      return {
        kontaktpersonen: [],
        kontaktstelle: {
          id: null,
          kontaktstellentyp: {
            bezeichnung: ""
          },
          adresse: {
            strasseoderpostfach: "",
            plz: null,
            ort: ""
          },
          email: "",
          telefon: ""
        }
      };
    },

    adaptKontaktauswahl: function (kontaktauswahl) {
      if (kontaktauswahl.kontaktpersonen) {
        kontaktauswahl.kontaktpersonen = kontaktauswahl.kontaktpersonen.map(kontaktperson => {
          const adaptedPerson = Object.assign({}, kontaktperson);
          if (adaptedPerson.id !== null && adaptedPerson.id !== undefined) {
            adaptedPerson.id = adaptedPerson.id.toString();
          }
          return adaptedPerson;
        });
      }
    },

    formatKontaktpersonenQuickinfo: function (aWAKontaktpersonen, aKatalogKontaktpersonen) {
      if (!aWAKontaktpersonen || aWAKontaktpersonen.length === 0) {
        return "";
      }

      // get info from katalog data, WAKontaktperson may only include an id
      const firstKontaktperson = aKatalogKontaktpersonen.find(person => { return person.id == aWAKontaktpersonen[0].id; });

      if (firstKontaktperson) {
        return `${firstKontaktperson.vorname} ${firstKontaktperson.nachname} ${firstKontaktperson.email} ${firstKontaktperson.telefon}`;
      } else {
        return "";
      }
    }
  };
});
