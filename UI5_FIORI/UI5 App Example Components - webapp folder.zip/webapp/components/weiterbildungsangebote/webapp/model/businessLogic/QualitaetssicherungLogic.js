sap.ui.define([
    "sap/ui/base/ManagedObject",
    "de/hrk/hochweit/components/Weiterbildungsangebote/model/businessLogic/QualitaetssicherungLogic"
], function (
    ManagedObject
) {
    "use strict";

    const _createZertifikat = (nextId) => {
        return {
            id: nextId,
            qszertifikat: {
                id: nextId,
                bezeichnung: {
                    de: ""
                }
            },
            qseinrichtung: {
                id: nextId,
                bezeichnung: {
                    de: ""
                }
            }
        };
    };

    const _createbUnbekanntesZertifikat = (nextId) => {
        return {
            id: nextId,
            zertifikat: "",
            einrichtung: ""
        };
    };

    return ManagedObject.extend("de.hrk.hochweit.components.Weiterbildungsangebote.model.businessLogic.QualitaetssicherungLogic", {
        createNewGruppe: function (bUnbekanntesZertifikat, nextId) {
            if (bUnbekanntesZertifikat) {
                return _createbUnbekanntesZertifikat(nextId);
            } else {
                return _createZertifikat(nextId);
            }
        }
    });
});