sap.ui.define([
  "de/hrk/hochweit/components/Weiterbildungsangebote/model/businessLogic/KontaktUndAnsprechpartnerLogic",
], function (KontaktUndAnsprechpartnerLogic) {
  "use strict";


  return {
    validateVonAndBis: function (dVon, dBis) {
      if (dVon > dBis) {
        return "Error";
      } else {
        return "None";
      }
    },
    checkVisibilityOfPauschaleAnrechnungHochschule: function (selection){
      switch (selection) {
        case "1": return true;
        case "2": return false;
        case "3":
        case "4": return true;
        default: return false;
      }
    },
    checkVisibilityOfPauschaleAnrechnungPraktisch: function (selection){
      switch (selection) {
        case "1": return false;
        case "2":
        case "3":
        case "4": return true;
        default: return false;
      }
    },
    checkVisibilityOfNoAnrechnungsvoraussetzungstypInfoText: function (selection){
      switch (selection) {
        case "1":
        case "2":
        case "3":
        case "4": return false;
        default: return true;
      }
    },

    adaptLoadedWAData: function (oAnerkennungUndAnrechnung) {
      if (!oAnerkennungUndAnrechnung) {
        return {
          anrechnungwebsite: this.createNewAnrechnungwebsiteLink(),
          individuelleanrechnungwebsite: this.createNewIndividuelleAnrechnungwebsiteLink(),
          bildungstraeger: [this.createNewBildungstraegerKooperation()],
          praktischeerfahrungen: [this.createNewPraktischeErfahrung()]
        };
      }
      return oAnerkennungUndAnrechnung;
    },

    createNewPraktischeErfahrung: function () {
      return {
        erfahrungstyp: {
          id: null,
          bezeichnung: {
            de: "",
          }
        },
        erfahrungsdauerwert: 0,
        erfahrungsdauereinheit: null,
        bereich: ""
      };
    },

    createNewBildungstraegerKooperation: function () {
      return {
        id: null,
        beginn: null,
        ende: null,
        Bildungstraeger: {
          id: null,
          bezeichnung: "",
          plz: "",
          ort: "",
          vordefinierterbildungstraeger: false
        }
      };
    },

    createNewAnsprechpartnerList: function () {
      return [KontaktUndAnsprechpartnerLogic.createNewAnsprechpartner()];
    }

  };
});
