sap.ui.define([
    "sap/ui/base/Object"
], function (BaseObject) {
    "use strict";

    return BaseObject.extend("de.hrk.hochweit.components.Weiterbildungsangebote.model.businessLogic.UserLogic", {

        constructor: function (oUser) {
            this.oUser = Object.assign({}, oUser);
        },

        canDeleteAngebotsbezeichnung: function () {
            return this._requireAllPermissions("w_angebb_delete");
        },

        canMarkAngebotsbezeichnungForDeletion: function () {
            return this._requireAllPermissions("w_angebb_mark_deleted");
        },

        canEditAngebotsbezeichnung: function () {
            return this._requireAllPermissions("w_angebb_edit");
        },

        isAdmin: function () {
            return this._requireAnyRole("admin", "fach_admin", "tech_admin");
        },

        _requireAllPermissions: function (...permissionNames) {
            if (!this.oUser) {
                return false;
            }
            return permissionNames.every(element => this.oUser.permissions.includes(element));
        },

        _requireAnyRole: function (...roleNames) {
            if (!this.oUser) {
                return false;
            }
            return roleNames.includes(this.oUser.role);
        }
    });
});
