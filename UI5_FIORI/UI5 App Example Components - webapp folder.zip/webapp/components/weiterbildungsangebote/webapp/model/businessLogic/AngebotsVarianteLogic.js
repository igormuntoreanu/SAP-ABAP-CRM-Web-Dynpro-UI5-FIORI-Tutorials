sap.ui.define([
    "sap/ui/base/Object",
    "sap/ui/model/Filter"
], function (BaseObject, Filter) {
    "use strict";

    // TODO: TODO-Marker + Jira-Ticket für Backend-Validierung diesbzgl.

    return BaseObject.extend("de.hrk.hochweit.components.Weiterbildungsangebote.model.businessLogic.AngebotsVarianteLogic", {

        angebotsVarianten: {},
        constructor: function (oAngebotsVarianten) {
            this.angebotsVarianten = Object.values(oAngebotsVarianten);
        },

        getAbschluesseState: function (iAngebotsTypId) {
            return {
                enabled: !!iAngebotsTypId,
                filter: iAngebotsTypId ? this._getAvailableAbschluesseFilter(iAngebotsTypId) : null
            };
        },

        getMinECTS: function (iAngebotsTypId, iAbschlussId) {
            const oAngebotsvariante =  this.angebotsVarianten.find(oItem => {
                return (oItem.angebotstyp === iAngebotsTypId && oItem.abschluss === iAbschlussId);
            });
            if (oAngebotsvariante && oAngebotsvariante.minects) {
                return oAngebotsvariante.minects;
            }
            return 0;
        },

        _getAvailableAbschluesseFilter: function (iAngebotsTypId) {
            return new Filter({
                path: "id",
                test: (sValue) => { return this._getAbschluesseForAngebotstyp(iAngebotsTypId).includes(sValue); }
            });
        },

        _getAbschluesseForAngebotstyp: function (iAngebotsTypId) {
            return this.angebotsVarianten
            .filter((oItem) => { return oItem.angebotstyp === iAngebotsTypId; })
            .map((oItem) => { return oItem.abschluss; });
        }
    });
});