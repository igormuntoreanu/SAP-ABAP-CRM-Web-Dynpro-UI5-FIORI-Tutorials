sap.ui.define([], function () {
    "use strict";

    return {
       /**
       * Function to remove unwanted decimal places
       * @param {string} sValue - Number that needs to be truncated
       * @param {number} iDecimalPlaces - Amount of decimal places that should stay
       * @param {string} sDelimiterSymbol - Delimiter / Decimal separator that is used
       * @returns the value as float without the unwanted decimal places
       * */
        truncateDecimalPlaces: function(sValue, iDecimalPlaces, sDelimiterSymbol) {
            let iDelimiterPosition = sValue.indexOf(sDelimiterSymbol) + 1;
            const iDecimalPlacesAmount = !iDelimiterPosition ? 0 : sValue.length - iDelimiterPosition;

            if (iDecimalPlacesAmount > iDecimalPlaces) {
              const sTruncatedValue = sValue.substring(0, sValue.length - 1);
              return {tooManyDecimalPlaces: true, value: parseFloat(sTruncatedValue.replace(",", "."))};
            }
            return {tooManyDecimalPlaces: false, value: parseFloat(sValue.replace(",", "."))};
          }
    };
});