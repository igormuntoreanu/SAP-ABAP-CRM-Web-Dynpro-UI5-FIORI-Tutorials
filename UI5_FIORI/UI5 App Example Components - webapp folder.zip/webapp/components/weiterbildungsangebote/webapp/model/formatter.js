sap.ui.define([
	"sap/ui/core/SortOrder"
], function (
	SortOrder
) {
	"use strict";

	var _getI18nResourceBundle = function (uiElement) {
		var component = uiElement.getOwnerComponent();
		var i18nModel;
		if (!component) {
			return null;
		}
		i18nModel = component.getModel("i18n");
		if (!i18nModel) {
			return null;
		}
		return i18nModel.getResourceBundle();
	};

	var Formatter = {

		i18nResourceBundle: _getI18nResourceBundle,


		formatFilterbar: function (sText, sLabel) {
			if (sLabel === "" || sLabel === "\"\"") {
				return sText + " " + Formatter.i18nResourceBundle(this).getText("filterbar.nofilter");
			}
			else {
				return sText + " " + sLabel;
			}
		},

		formatDataSourceImg: function (sIstHSKImportiert) {
			const bIstHSKimportiert = (sIstHSKImportiert === 'true');
			if (bIstHSKimportiert) {
				return "resources/img/hsk.ico";
			}
			else {
				return "resources/img/favicon.ico";
			}
		},

		formatEditorialStatus: function (sStatus) {
			switch (sStatus) {
				case "Freigegeben":
					return "sap-icon://circle-task";
				case "In Bearbeitung":
					return "sap-icon://circle-task-2";
				case "FreigabeErforderlich":
					return "sap-icon://order-status";
				case "Gelöscht":
					return "sap-icon://delete";
				default:
					return;
			}
		},

		formatBoolean: function (bBoolean) {
			if (bBoolean) {
				return Formatter.i18nResourceBundle(this).getText("common.yes");
			}
			return Formatter.i18nResourceBundle(this).getText("common.no");
		},

		formatSortingIndicator: function (sSortingColumn, sSortingDirection, sColumn) {
			if (sSortingColumn !== sColumn) {
				return SortOrder.None;
			}
			return sSortingDirection;
		},

		formatObjectArrayToString: function (aArray, sAttribute, sLanguage){
			if (aArray){
				if (aArray[0]){
			// Check if array and attribute exist
					if (aArray[0][sAttribute]){
						let sAttributeString = "";
						for (const item of aArray){
							if (sLanguage){
								sAttributeString += item[sAttribute][sLanguage] + ", ";
							}
							else {
								sAttributeString += item[sAttribute] + ", ";
							}
						}
						// return formatted string and remove comma at the end
						return sAttributeString.substring(0, sAttributeString.length - 2);
					}
				}
			}
			return "";
		},

		formatDateAsText: function (sDate) {
			if (!sDate) {
				return Formatter.i18nResourceBundle(this).getText("common.noValueGiven");
			}
			return sDate; // TODO: possibly needs conversion into proper format; consider using sap.ui.model.type.Date
		},

		formatHeaderAngebotEdit: function (oBezeichnung, sId) {
			if (oBezeichnung) {
				const oLogin = this.getModel("login").getData();
				const bezeichnungDe = (oBezeichnung.bezeichnung && oBezeichnung.bezeichnung.de) ? `${oBezeichnung.bezeichnung.de} ` : "";
				const sIdAddendum = (sId && ["admin", "fach_admin", "tech_admin"].includes(oLogin.role)) ? `(${sId})` : "";
				return  bezeichnungDe + sIdAddendum;
			}
		},

		formatHeaderAngebotNew: function (oBezeichnung) {
			const sNewAngebot = Formatter.i18nResourceBundle(this).getText("angbeoteDetailNew.header.newAngebot");
			if (oBezeichnung && oBezeichnung.bezeichnung) {
				const bezeichnungDe = (oBezeichnung.bezeichnung.de) ? `${oBezeichnung.bezeichnung.de} ` : "";
				const sNewAngebotAddendum = `(${sNewAngebot})`;
				return bezeichnungDe + sNewAngebotAddendum;
			}
			return sNewAngebot;
		},

    // The HSK editor can only be contacted, if
    // * The user has the appropriate permission, and
    // * The current Weiterbildungsangebot is imported from HSK
		formatCheckContactHsk: function (Permissions, isthskimportiert = false) {
		  return Permissions && Permissions.includes("contact_hk_editor") && isthskimportiert;
    }
	};

	return Formatter;

});
