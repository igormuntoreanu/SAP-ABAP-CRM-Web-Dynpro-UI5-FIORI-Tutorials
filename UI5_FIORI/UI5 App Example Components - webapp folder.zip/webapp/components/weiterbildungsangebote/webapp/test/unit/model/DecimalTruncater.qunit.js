sap.ui.define([
    "de/hrk/hochweit/components/Weiterbildungsangebote/model/DecimalTruncater"
], function(DecimalTruncater) {
    "use strict";

    QUnit.test("Verify correct truncation of unwanted decimal place", function (assert) {
        assert.strictEqual(DecimalTruncater.truncateDecimalPlaces("12,345", 2, ","), {"tooManyDecimalPlaces": true, "value": 12.34 },
                                                                                     "Comma: Truncated three decimal places to two");
        assert.strictEqual(DecimalTruncater.truncateDecimalPlaces("12.345", 2, "."), {"tooManyDecimalPlaces": true, "value": 12.34 },
                                                                                      "Dot: Truncated three decimal places to two");
    });

    QUnit.test("Verify already correct values are not truncated", function (assert) {
        assert.strictEqual(DecimalTruncater.truncateDecimalPlaces("12,34", 2, ","), {"tooManyDecimalPlaces": false, "value": 12.34 },
                                                                                     "Comma: Keep all decimal places");
        assert.strictEqual(DecimalTruncater.truncateDecimalPlaces("12.34", 2, "."), {"tooManyDecimalPlaces": false, "value": 12.34 },
                                                                                     "Dot: Keep all decimal places");
        assert.strictEqual(DecimalTruncater.truncateDecimalPlaces("12", 2, ","), {"tooManyDecimalPlaces": false, "value": 12 },
                                                                                  "No decimal place: return number");
    });

});