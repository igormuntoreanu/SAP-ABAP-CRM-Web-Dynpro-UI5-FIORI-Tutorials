sap.ui.define([
    "de/hrk/hochweit/components/Weiterbildungsangebote/model/businessLogic/AngebotsVarianteLogic"
], function(AngebotsVarianteLogic) {
    "use strict";

    const aAngebotsVarianten = [
        {id: 1, minects: 42, angebotstyp: 1, abschluss: 1, __typename: "AngebotsVarianteType"},
        {id: 2, minects: 43, angebotstyp: 2, abschluss: 2, __typename: "AngebotsVarianteType"},
        {id: 3, minects: 44, angebotstyp: 2, abschluss: 3, __typename: "AngebotsVarianteType"}
    ];

    QUnit.module("Angebotsvariante BusinessLogic", {
        beforeEach: function () {
            this.angebotsVarianteLogic = new AngebotsVarianteLogic(aAngebotsVarianten);
        },
        afterEach: function () {
            this.angebotsVarianteLogic.destroy();
        }
    });

    QUnit.test("Verify correct abschluesseState return values for existing Angebotsvariante", function (assert) {
        const abschluesseState = this.angebotsVarianteLogic.getAbschluesseState(1);
        assert.ok(abschluesseState.enabled, "Returned enabled for existing Angebotsvariante");
        assert.strictEqual(abschluesseState.filter.sPath, "id", "Returned Filter obect with set path");
        assert.strictEqual(typeof abschluesseState.filter.fnTest, "function", "Returned Filter obect with test function");
    });


    QUnit.test("Verify correct abschluesseState return values for non-existing Angebotsvariante", function (assert) {
        const abschluesseState = this.angebotsVarianteLogic.getAbschluesseState();
        assert.notOk(abschluesseState.enabled, "Returned false for enabled");
        assert.notOk(abschluesseState.filter, "Returned null for filter");
    });

    QUnit.test("Verify correct filtering of possible Abschluesse", function (assert) {
        assert.deepEqual(this.angebotsVarianteLogic._getAbschluesseForAngebotstyp(2), [2, 3], "Returned an array with correctly filterd AbschlussIds for existing AngebotsVariante");
        assert.deepEqual(this.angebotsVarianteLogic._getAbschluesseForAngebotstyp(3), [], "Returned an empty array for non-existing Angebotsvariante");
    });

    QUnit.test("Verify correct minECTS return values", function (assert) {
        let expected = 42;
        assert.strictEqual(this.angebotsVarianteLogic.getMinECTS(1, 1), expected, `Returned expected minECTS value for existing Angebotsvariante: ${expected}`);
        expected = 0;
        assert.strictEqual(this.angebotsVarianteLogic.getMinECTS(2, 1), expected, `Returned expected minECTS value for non-existing Angebotsvariante: ${expected}`);
    });
});