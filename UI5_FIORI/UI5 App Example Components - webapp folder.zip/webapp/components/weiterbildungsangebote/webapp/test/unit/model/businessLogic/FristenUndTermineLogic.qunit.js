sap.ui.define([
  "de/hrk/hochweit/components/Weiterbildungsangebote/model/businessLogic/FristenUndTermineLogic"
], function(FristenUndTermineLogic) {
    "use strict";

    QUnit.test("Verify dateBis later than dateVon", function (assert) {
      const date1 = new Date ("2021-02-23T00:00:00.000Z");
      const date2 = new Date ("2021-02-25T00:00:00.000Z");
      const dateEmpty = null;
      assert.strictEqual(FristenUndTermineLogic.validateVonAndBis(date1, date2), "None", "DateVon liegt vor DateBis");
      assert.strictEqual(FristenUndTermineLogic.validateVonAndBis(date2, date1), "Error", "DateVon liegt nach DateBis");
      assert.strictEqual(FristenUndTermineLogic.validateVonAndBis(dateEmpty, date1), "None", "Es gibt kein DateBis also valide");
      assert.strictEqual(FristenUndTermineLogic.validateVonAndBis(date2, dateEmpty), "None", "Es gibt kein DateVon also valide");
    });

});
