sap.ui.define([
    "./model/businessLogic/AngebotsvarianteLogic.qunit",
    "./model/businessLogic/GesamtkostenLogic.qunit",
    "./model/businessLogic/FristenUndTermineLogic.qunit",
    "./model/DecimalTruncater.qunit"
]);
