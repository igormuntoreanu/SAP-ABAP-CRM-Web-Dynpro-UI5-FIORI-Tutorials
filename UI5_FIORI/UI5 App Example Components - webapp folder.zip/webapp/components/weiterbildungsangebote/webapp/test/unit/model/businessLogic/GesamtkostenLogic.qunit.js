sap.ui.define([
  "de/hrk/hochweit/components/Weiterbildungsangebote/model/businessLogic/GesamtkostenLogic"
], function(GesamtkostenLogic) {
  "use strict";

  QUnit.test("Verify initial kostenState when no values are provided", function (assert) {
    const expected = {
      teilkosten: {
        enabled: true,
        value: null
      },
      gesamtkosten: {
        enabled: true,
        value: 0
      },
      zeitdauer: {
        enabled: true
      },
      teilkostendauer: {
        enabled: true,
        value: null
      },
      kostenlos: false
    };
    assert.deepEqual(GesamtkostenLogic.getKostenState(undefined, undefined, undefined, undefined, undefined), expected, "Did match the expected result when no values are provided");
  });

  QUnit.test("Verify correct kostenState when Teilkosten are partly set", function (assert) {
    const expected = {
      teilkosten: {
        enabled: true,
        value: 191
      },
      gesamtkosten: {
        enabled: true,
        value: 0
      },
      zeitdauer: {
        enabled: true
      },
      teilkostendauer: {
        enabled: true,
        value: null
      },
      kostenlos: false
    };
    assert.deepEqual(GesamtkostenLogic.getKostenState(191, null, null, false, GesamtkostenLogic.getPreferenceValues().NONE), expected, "Did match the expected result when only Teilkostenbetrag was set");

    expected.teilkosten.value = null;
    expected.teilkostendauer.value = 7;
    assert.deepEqual(GesamtkostenLogic.getKostenState(null, 7, null, false, GesamtkostenLogic.getPreferenceValues().NONE), expected, "Did match the expected result when only Teilkostendauer was set");
  });

  QUnit.test("Verify correct kostenState when Teilkosten are fully set", function (assert) {
    const expected = {
      teilkosten: {
        enabled: true,
        value: 191
      },
      gesamtkosten: {
        enabled: false,
        value: 1337
      },
      zeitdauer: {
        enabled: true
      },
      teilkostendauer: {
        enabled: true,
        value: 7
      },
      kostenlos: false
    };
    assert.deepEqual(GesamtkostenLogic.getKostenState(191, 7, null, false, GesamtkostenLogic.getPreferenceValues().TEILKOSTEN), expected, "Did match the expected result when Teilkostenbetrag, Teilkostendauer and preference to Teilkosten were set");
  });

  QUnit.test("Verify correct kostenState when Gesamtkosten are set", function (assert) {
    const expected = {
      teilkosten: {
        enabled: false,
        value: null
      },
      gesamtkosten: {
        enabled: true,
        value: 42
      },
      zeitdauer: {
        enabled: false
      },
      teilkostendauer: {
        enabled: false,
        value: null
      },
      kostenlos: false
    };
    assert.deepEqual(GesamtkostenLogic.getKostenState(null, null, 42, false, GesamtkostenLogic.getPreferenceValues().GESAMTKOSTEN), expected, "Did match the expected result when Gesamtkostenbetrag and preference to Gesamtkosten were set");
  });

  QUnit.test("Verify correct kostenState when kostenlos is set", function (assert) {
    const expected = {
      teilkosten: {
        enabled: false,
        value: null
      },
      gesamtkosten: {
        enabled: false,
        value: null
      },
      zeitdauer: {
        enabled: false
      },
      teilkostendauer: {
        enabled: false,
        value: null
      },
      kostenlos: true
    };
    assert.deepEqual(GesamtkostenLogic.getKostenState(null, null, null, true, GesamtkostenLogic.getPreferenceValues().NONE), expected, "Did match the expected result when kostenlos was set and no other values were provided");
    assert.deepEqual(GesamtkostenLogic.getKostenState(191, 7, 42, true, GesamtkostenLogic.getPreferenceValues().NONE), expected, "Did match the expected result when kostenlos was set and other values were provided");
  });


  QUnit.test("Verify correct calculation of gesamtkostenbetrag", function (assert) {
    assert.strictEqual(GesamtkostenLogic._calculateGesamtkostenValue(191, 7), 1337, "Did match the expected result when both values were provided");
    assert.strictEqual(GesamtkostenLogic._calculateGesamtkostenValue(191, null), 0, "Did match the expected result when not all values were provided");
    assert.strictEqual(GesamtkostenLogic._calculateGesamtkostenValue(null, 7), 0, "Did match the expected result when not all values were provided");
    assert.strictEqual(GesamtkostenLogic._calculateGesamtkostenValue(191, ""), 0, "Did match the expected result when not all values were provided");
    assert.strictEqual(GesamtkostenLogic._calculateGesamtkostenValue("", 7), 0, "Did match the expected result when not all values were provided");
  });

});
