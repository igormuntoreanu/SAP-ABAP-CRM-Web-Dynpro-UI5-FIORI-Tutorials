sap.ui.define([
  "sap/ui/test/opaQunit",
  "de/hrk/hochweit/components/Weiterbildungsangebote/test/integration/pages/Main"
], function (opaTest) {
  "use strict";

  opaTest("should show the FCL for navigation", function (Given, When, Then) {

    // Arrangements
    Given.iStartMyApp();

    // Assertions
    Then.onTheMainPage.iShouldSeePageCount();

    // Cleanup
    Then.iTeardownMyApp();
  });

});
