/*global QUnit*/

sap.ui.define([
	"sap/ui/test/opaQunit",
	"./pages/AngeboteList"
], function (opaTest) {
	"use strict";

	QUnit.module("AngeboteList");

	opaTest("Should see the master list and its searchfield", function (Given, When, Then) {
		// Arrangements
		Given.iStartMyApp();

		// Assertions
		Then.onTheMasterPage.iShouldSeeTheList().
			and.iShouldSeeTheSearchField();

	});

	opaTest("Should pick a sorting column with the correct sortdirection after table header click", function (Given, When, Then) {

		// Assertions
		Then.onTheMasterPage.iClickOnSort("Ascending").
			and.iClickOnSort("Descending");

		// Cleanup
		Then.iTeardownMyApp();
	});

});