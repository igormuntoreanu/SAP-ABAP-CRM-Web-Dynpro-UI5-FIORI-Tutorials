sap.ui.define([
  "sap/ui/test/Opa5"
], function(Opa5) {
  "use strict";

  return Opa5.extend("de.hrk.hochweit.components.Weiterbildungsangebote.test.integration.arrangements.Startup", {

    iStartMyApp: function (sHash, iTimeout) {
      this.iStartMyUIComponent({
        componentConfig: {
          name: "de.hrk.hochweit.components.Weiterbildungsangebote",
          async: true,
          manifest: true
        },
        hash: sHash,
        timeout: iTimeout
      });
    }

  });
});
