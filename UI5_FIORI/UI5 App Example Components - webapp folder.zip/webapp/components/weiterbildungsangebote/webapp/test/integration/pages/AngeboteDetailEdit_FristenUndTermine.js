sap.ui.require([
  "sap/ui/test/Opa5"
], function (Opa5) {
  "use strict";

  const sViewName = "de.hrk.hochweit.components.Weiterbildungsangebote.view.eingabeformular3.FristenUndTermine";

  Opa5.createPageObjects({
    onTheFristenUndTerminePage: {

      assertions: {

        iShouldSeeTheFristenUndTermineFormularabschnitt: function () {
          return this.waitFor({
            id: "fristenUndTermineAbschnitt",
            viewName: sViewName,
            controlType: "hrk.formular.FormularAbschnitt",
            success: function () {
              Opa5.assert.ok(true, "The Formularabschnitt Fristen und Termine appears");
            },
            errorMessage: "Formularabschnitt Fristen und Termine does not appear"
          });
        },

        iShouldSeeTheAngebotszeitraumFeldgruppeAndControls: function () {
          return this.waitFor({
            id: "angebotsZeitraum",
            controlType: "hrk.formular.Feldgruppe",
            viewName: sViewName,
            success: function () {
              Opa5.assert.ok(true, "The Feldgruppe Angebotszeitraum appears");
              return this.waitFor({
                id: "angebotsZeitraumVon",
                controlType: "sap.m.DatePicker",
                viewName: sViewName,
                success: function () {
                  Opa5.assert.ok(true, "The DatePickerControl Angebotszeitraum von appears");
                  return this.waitFor({
                    id: "angebotsZeitraumZwischentext",
                    controlType: "sap.m.Text",
                    viewName: sViewName,
                    success: function () {
                      Opa5.assert.ok(true, "The Text angebotsZeitraumZwischentext appears");
                      return this.waitFor({
                        id: "angebotsZeitraumBis",
                        controlType: "sap.m.DatePicker",
                        viewName: sViewName,
                        success: function () {
                          Opa5.assert.ok(true, "The DatePickerControl AngebotszeitraumBis appears");
                          return this.waitFor({
                            id: "angebotsZeitraumAnmerkung",
                            controlType: "sap.m.TextArea",
                            viewName: sViewName,
                            success: function () {
                              Opa5.assert.ok(true, "The TextArea angebotsZeitraumAnmerkung appears");
                            }
                          });
                        }
                      });
                    },
                  });
                },
              });
            }.bind(this),
            errorMessage: "Feldgruppe angebotsZeitraum does not appear"
          });
        },

        iShouldSeeTheAnmeldefristFeldgruppeAndControls: function () {
          return this.waitFor({
            id: "anmeldefrist",
            controlType: "hrk.formular.Feldgruppe",
            viewName: sViewName,
            success: function () {
              Opa5.assert.ok(true, "The Feldgruppe Anmeldefrist appears");
              return this.waitFor({
                id: "anmeldefristVon",
                controlType: "sap.m.DatePicker",
                viewName: sViewName,
                success: function () {
                  Opa5.assert.ok(true, "The DatePickerControl Anmeldefrist von appears");
                  return this.waitFor({
                    id: "angebotsZeitraumZwischentext",
                    controlType: "sap.m.Text",
                    viewName: sViewName,
                    success: function () {
                      Opa5.assert.ok(true, "The Text angebotsZeitraumZwischentext appears");
                      return this.waitFor({
                        id: "anmeldefristBis",
                        controlType: "sap.m.DatePicker",
                        viewName: sViewName,
                        success: function () {
                          Opa5.assert.ok(true, "The DatePickerControl anmeldefristBis appears");
                          return this.waitFor({
                            id: "anmeldefristAnmerkung",
                            controlType: "sap.m.TextArea",
                            viewName: sViewName,
                            success: function () {
                              Opa5.assert.ok(true, "The TextArea anmeldefristAnmerkung appears");
                            }
                          });
                        }
                      });
                    },
                  });
                },
              });
            }.bind(this),
            errorMessage: "Feldgruppe does not appear"
          });
        },

        iShouldSeeTheSpaetereAngebotszeitraeumeFeldgruppeAndControls: function () {
          return this.waitFor({
            id: "spaetereAngebotszeitraeumeListe",
            controlType: "hrk.formular.Feldliste",
            viewName: sViewName,
            success: function () {
              Opa5.assert.ok(true, "The Feldliste SpaetereAngebotszeitraeume appears");
            }
          });
            errorMessage: "Feldliste SpaetereAngebotszeitraeume does not appear";

        },

      }

    }
  });

});
