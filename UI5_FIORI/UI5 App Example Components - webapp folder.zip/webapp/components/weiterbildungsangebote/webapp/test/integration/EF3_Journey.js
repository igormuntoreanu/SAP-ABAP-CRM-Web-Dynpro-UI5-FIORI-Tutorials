sap.ui.define([
  "sap/ui/test/opaQunit",
  "de/hrk/hochweit/components/Weiterbildungsangebote/test/integration/pages/AngeboteDetailEdit_FristenUndTermine",
  "de/hrk/hochweit/components/Weiterbildungsangebote/test/integration/pages/AngeboteDetailEditPage"
], function (opaTest) {
  "use strict";

  QUnit.module("Eingabeformular 3");

  opaTest("should show the Fristen und Termine section and all relevant controls", function (Given, When, Then) {

    // Arrangements
    Given.iStartMyApp("1/edit", 90);

    // Assertions
    When.onTheAngeboteDetailEditPage.iPressTheFristenUndTermineAnchorBar();
    Then.onTheFristenUndTerminePage.iShouldSeeTheFristenUndTermineFormularabschnitt()
      .and.iShouldSeeTheAngebotszeitraumFeldgruppeAndControls()
      .and.iShouldSeeTheAnmeldefristFeldgruppeAndControls()
      .and.iShouldSeeTheSpaetereAngebotszeitraeumeFeldgruppeAndControls();

    // Cleanup
    Then.iTeardownMyApp();
  });

});
