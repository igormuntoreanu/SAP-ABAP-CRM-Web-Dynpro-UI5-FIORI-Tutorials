sap.ui.define([
  "sap/ui/test/Opa5",
  "de/hrk/hochweit/components/Weiterbildungsangebote/test/integration/arrangements/Startup",
  "de/hrk/hochweit/components/Weiterbildungsangebote/test/integration/BasicJourney",
  "de/hrk/hochweit/components/Weiterbildungsangebote/test/integration/AngeboteListJourney",
  "de/hrk/hochweit/components/Weiterbildungsangebote/test/integration/EF1_Journey",
  "de/hrk/hochweit/components/Weiterbildungsangebote/test/integration/EF3_Journey",
  "de/hrk/hochweit/components/Weiterbildungsangebote/test/integration/EF7_Journey"
], function(Opa5, Startup) {
  "use strict";

  Opa5.extendConfig({
    arrangements: new Startup(),
    autoWait: true,
    pollingInterval: 1,
    asyncPolling: true
  });

});
