sap.ui.require([
  "sap/ui/test/Opa5",
  "sap/ui/test/actions/Press"
], function (Opa5, Press) {
  "use strict";

  var sViewName = "de.hrk.hochweit.components.Weiterbildungsangebote.view.AngeboteList";
  var sListId = "masterTable";

  Opa5.createPageObjects({
    onTheMasterPage: {

      assertions: {

		iShouldSeeTheList: function () {
			return this.waitFor({
				id: sListId,
				viewName: sViewName,
				success: function (oList) {
					Opa5.assert.ok(oList, "Found the object List");
				},
				errorMessage: "Can't see the master list."
			});
		},

		iShouldSeeTheSearchField: function() {
			return this.waitFor({
			id: "searchField",
			controlType: "sap.m.SearchField",
			viewName: sViewName,
			success: function() {
				Opa5.assert.ok(true, "The searchfield appears");
			},
			errorMessage: "Can't see the searchfield."
			});
		},

		iClickOnSort: function (sortDirection) {
			return this.waitFor({
				id: "sortByAngebotstypButton",
				controlType: "sap.m.Link",
				viewName: sViewName,
				actions: new Press(),
				success: function (oSortKey) {
					Opa5.assert.ok(true, "The table header button was clicked");

					const oSorting = oSortKey.getParent().getModel("masterView").getProperty("/sorting");

					if (oSorting.column === "angebotstyp" && oSorting.direction === sortDirection) {
						Opa5.assert.ok(true, "The sorting column is picked");
					}
					else {
						Opa5.assert.errorMessage("Did not find a sorting column.");
					}
				},
				errorMessage: "Did not find the table header button"
			});
		},

      }

    }
  });

});
