sap.ui.require([
  "sap/ui/test/Opa5",
  "sap/ui/test/actions/Press"
], function (Opa5, Press) {
  "use strict";

  var sViewName = "de.hrk.hochweit.components.Weiterbildungsangebote.view.AngeboteDetailEdit";


  Opa5.createPageObjects({
    onTheAngeboteDetailEditPage: {

      actions: {

        iPressTheFristenUndTermineAnchorBar: function() {
          return this.waitFor({
            ancestor: {id: "detailPage-anchBar", viewName: sViewName},
            controlType: "sap.m.Button",
            properties: {text: "Fristen und Termine"},
            actions: new Press(),
            errorMessage: "Could not press FristenUndTermine"
          });
        }
      }

    }
  });

});
