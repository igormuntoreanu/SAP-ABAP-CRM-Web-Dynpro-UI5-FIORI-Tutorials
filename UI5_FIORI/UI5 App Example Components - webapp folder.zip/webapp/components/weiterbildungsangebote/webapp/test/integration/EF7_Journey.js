sap.ui.define([
  "sap/ui/test/opaQunit",
  "de/hrk/hochweit/components/Weiterbildungsangebote/test/integration/pages/AngeboteDetailEdit_AnerkennungUndAnrechnung"
], function (opaTest) {
  "use strict";

  QUnit.module("Einfabeformular 1");

  opaTest("should show the Allgemeine Informationen section and all relevant controls", function (Given, When, Then) {

    // Arrangements
    Given.iStartMyApp("1/edit");

    // Assertions
    When.onTheAngeboteDetailEditPage.iPressTheAnerkennungUndAnrechnungAnchorBar();
    Then.onTheAnerkennungUndAnrechnungPage.iShouldSeeTheAnerkennungUndAbrechnungFormularabschnitt()
      .and.iShouldSeeTheAnerkennungFormularabschnitt()
      .and.iShouldSeeTheAnerkennungAnsprechpartnerUebernehmenFeldgruppeAndControl()
      .and.iShouldSeeTheAnrechnungFormularabschnitt()
      .and.iShouldSeeTheAnrechnungsvoraussetzungFeldgruppeAndControls()
      .and.iShouldSeeTheAnrechnungsvoraussetzungCheckboxFeldgruppeAndControls()
      .and.iShouldSeeTheAnrechnungAnsprechpartnerAbschnittFormularabschnitt()
      .and.iShouldSeeTheIndividuelleAnrechnungAbschnittFormularabschnitt()
      .and.iShouldSeeTheIndividuelleAnrechnungLinkFeldgruppeAndControls()
      .and.iShouldSeeThePauschaleAnrechnungAbschnittFormularabschnitt()
      .and.iShouldSeeThePauschaleAnrechnungLinkFeldgruppeAndControls()
      .and.iShouldSeeThePauschaleAnrechnungAuflagenAbschnittFormularabschnitt()
      .and.iShouldSeeThePauschaleAnrechnungHochschulberechtigungFeldgruppeAndControls()
      .and.iShouldSeeThePauschaleAnrechnungPraktischeErfahrungenListeFeldliste()
      .and.iShouldSeeThePauschaleAnrechnungmaxECTSFeldgruppeAndControls()
      .and.iShouldSeeThePauschaleAnrechnungKooperationAbschnittFormularabschnitt()
      .and.iShouldSeeThePauschaleAnrechnungBildungstraegerListeFeldliste();

    // Cleanup
    Then.iTeardownMyApp();
  });

});
