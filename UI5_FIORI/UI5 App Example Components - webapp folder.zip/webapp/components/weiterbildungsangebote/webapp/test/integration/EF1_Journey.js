sap.ui.define([
  "sap/ui/test/opaQunit",
  "de/hrk/hochweit/components/Weiterbildungsangebote/test/integration/pages/AngeboteDetailEdit_AllgemeineInformationen"
], function (opaTest) {
  "use strict";

  QUnit.module("Einfabeformular 1");

  opaTest("should show the Allgemeine Informationen section and all relevant controls", function (Given, When, Then) {

    // Arrangements
    Given.iStartMyApp("1/edit");

    // Assertions
    Then.onTheAllgemeineInformationenPage.iShouldSeeTheAllgemeineInformationenFormularabschnitt().
    and.iShouldSeeTheAngebotsbezeichnungFeldgruppeAndControls().
    and.iShouldSeeTheAngebotstypFeldgruppeAndControls().
    and.iShouldSeeTheAbschlussFeldgruppeAndControls().
    and.iShouldSeeTheMaxECTSFeldgruppeAndControls().
    and.iShouldSeeTheHauptunterrichtsspracheFeldgruppeAndControls().
    and.iShouldSeeTheGesamtkostenFormularabschnitt().
    and.iShouldSeeTheTeilkostenFeldgruppeAndControls().
    and.iShouldSeeTheTeilkostenDauerEinzelkostenFeldgruppeAndControls().
    and.iShouldSeeTheTeilkostenDauerInputFeldgruppeAndControls().
    and.iShouldSeeTheTeilkostenDauerGesamtkostenFeldgruppeAndControls().
    and.iShouldSeeTheGesamtostenbetragFeldgruppeAndControls().
    and.iShouldSeeTheLinkEditorFeldgruppeAndControls().
    and.iShouldSeeTheAnmerkungenFeldgruppeAndControls();

  });

  opaTest("should show the Gesamtkosten section and all relevant controls", function (Given, When, Then) {
    Then.onTheAllgemeineInformationenPage.iShouldSeeTheGesamtkostenFormularabschnitt();

    // Cleanup
    Then.iTeardownMyApp();
  });

});
