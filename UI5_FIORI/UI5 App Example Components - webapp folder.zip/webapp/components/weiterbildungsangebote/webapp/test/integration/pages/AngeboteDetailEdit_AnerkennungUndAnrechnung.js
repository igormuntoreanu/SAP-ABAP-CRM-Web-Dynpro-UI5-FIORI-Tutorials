sap.ui.require([
  "sap/ui/test/Opa5"
], function (Opa5) {
  "use strict";

  const sViewName = "de.hrk.hochweit.components.Weiterbildungsangebote.view.eingabeformular7.AnerkennungUndAnrechnung";

  // function fnCheckFeldgruppeAndSingleControl (sFeldgruppeId, sControlId) {
  //   return this.waitFor({
  //     id: sFeldgruppeId,
  //     controlType: "hrk.formular.Feldgruppe",
  //     viewName: sViewName,
  //    success: function () {
  //       Opa5.assert.ok(true, `The Feldgruppe ${sFeldgruppeId} appears`);
  //       return this.waitFor({
  //         id: sControlId,
  //         viewName: sViewName,
  //         success: function() {
  //           Opa5.assert.ok(true, `The Control ${sControlId} appears`);
  //         },
  //         errorMessage: `Control ${sControlId} does not appear`
  //       });
  //     }.bind(this),
  //     errorMessage: `Feldgruppe ${sFeldgruppeId} does not appear`
  //   });
  // }

  Opa5.createPageObjects({
    onTheAnerkennungUndAnrechnungPage: {

      assertions: {

        iShouldSeeTheAnerkennungUndAbrechnungFormularabschnitt: function () {
          return this.waitFor({
            id: "anerkennungUndAnrechnungAbschnitt",
            viewName: sViewName,
            success: function () {
              Opa5.assert.ok(true, "The Formularabschnitt Anerkennung und Anrechnung appears");
            },
            errorMessage: "Formularabschnitt Anerkennung und Anrechnung does not appear"
          });
        },

        iShouldSeeTheAnerkennungFormularabschnitt: function () {
          return this.waitFor({
            id: "anerkennungAbschnitt",
            viewName: sViewName,
            success: function () {
              Opa5.assert.ok(true, "The Formularabschnitt Anerkennung und Anrechnung appears");
            },
            errorMessage: "Formularabschnitt Anerkennung und Anrechnung does not appear"
          });
        },

        iShouldSeeTheAnerkennungAnsprechpartnerUebernehmenFeldgruppeAndControl: function () {
          return this.waitFor({
            id: "anerkennungAnsprechpartnerUebernehmen",
            controlType: "hrk.formular.Feldgruppe",
            viewName: sViewName,
            success: function () {
              Opa5.assert.ok(true, "The Feldgruppe anerkennungAnsprechpartnerUebernehmen appears");
              return this.waitFor({
                id: "anerkennungAnsprechpartnerUebernehmenInput",
                viewName: sViewName,
                success: function () {
                  Opa5.assert.ok(true, "The Checkbox anerkennungAnsprechpartnerUebernehmenInput appears");
                },
                errorMessage: "Checkbox anerkennungAnsprechpartnerUebernehmenInput does not appear"
              });
            }.bind(this),
            errorMessage: "Feldgruppe anerkennungAnsprechpartnerUebernehmen does not appear"
          });
          // fnCheckFeldgruppeAndSingleControl.call(this, "angebotsbezeichnung", "angebotsbezeichnungSelection");
        },

        iShouldSeeTheAnrechnungFormularabschnitt: function () {
          return this.waitFor({
            id: "anerkennungAbschnitt",
            viewName: sViewName,
            success: function () {
              Opa5.assert.ok(true, "The Formularabschnitt Anerkennung und Anrechnung appears");
            },
            errorMessage: "Formularabschnitt Anerkennung und Anrechnung does not appear"
          });
        },

        iShouldSeeTheAnrechnungsvoraussetzungFeldgruppeAndControls: function () {
          return this.waitFor({
            id: "anrechnungsvoraussetzung",
            controlType: "hrk.formular.Feldgruppe",
            viewName: sViewName,
            success: function () {
              Opa5.assert.ok(true, "The Feldgruppe anrechnungsvoraussetzung appears");
              return this.waitFor({
                id: "anrechnungsvoraussetzungSelection",
                viewName: sViewName,
                success: function () {
                  Opa5.assert.ok(true, "The ComboBox anrechnungsvoraussetzungSelection appears");
                },
                errorMessage: "ComboBox anrechnungsvoraussetzungSelection does not appear"
              });
            }.bind(this),
            errorMessage: "Feldgruppe anrechnungsvoraussetzung does not appear"
          });
          // fnCheckFeldgruppeAndSingleControl.call(this, "angebotsbezeichnung", "angebotsbezeichnungSelection");
        },

        iShouldSeeTheAnrechnungsvoraussetzungCheckboxFeldgruppeAndControls: function () {
          return this.waitFor({
            id: "anrechnungsvoraussetzungCheckbox",
            controlType: "hrk.formular.Feldgruppe",
            viewName: sViewName,
            success: function () {
              Opa5.assert.ok(true, "The Feldgruppe anrechnungsvoraussetzungCheckbox appears");
              return this.waitFor({
                id: "anrechnungsvoraussetzungInput",
                viewName: sViewName,
                success: function () {
                  Opa5.assert.ok(true, "The Checkbox anrechnungsvoraussetzungInput appears");
                },
                errorMessage: "Checkbox anrechnungsvoraussetzungInput does not appear"
              });
            }.bind(this),
            errorMessage: "Feldgruppe anrechnungsvoraussetzungCheckbox does not appear"
          });
          // fnCheckFeldgruppeAndSingleControl.call(this, "angebotsbezeichnung", "angebotsbezeichnungSelection");
        },

        iShouldSeeTheAnrechnungAnsprechpartnerAbschnittFormularabschnitt: function () {
          return this.waitFor({
            id: "anrechnungAnsprechpartnerAbschnitt",
            viewName: sViewName,
            success: function () {
              Opa5.assert.ok(true, "The Formularabschnitt anrechnungAnsprechpartnerAbschnitt appears");
            },
            errorMessage: "Formularabschnitt anrechnungAnsprechpartnerAbschnitt does not appear"
          });
        },

        iShouldSeeTheIndividuelleAnrechnungAbschnittFormularabschnitt: function () {
          return this.waitFor({
            id: "individuelleAnrechnungAbschnitt",
            viewName: sViewName,
            success: function () {
              Opa5.assert.ok(true, "The Formularabschnitt individuelleAnrechnungAbschnitt appears");
            },
            errorMessage: "Formularabschnitt individuelleAnrechnungAbschnitt does not appear"
          });
        },

        iShouldSeeTheIndividuelleAnrechnungLinkFeldgruppeAndControls: function () {
          return this.waitFor({
            id: "individuelleAnrechnungLink",
            controlType: "hrk.formular.Feldgruppe",
            viewName: sViewName,
            success: function () {
              Opa5.assert.ok(true, "The Feldgruppe individuelleAnrechnungLink appears");
            },
            errorMessage: "Checkbox anrechnungsvoraussetzungInput does not appear"
          });
        },

        iShouldSeeThePauschaleAnrechnungAbschnittFormularabschnitt: function () {
          return this.waitFor({
            id: "pauschaleAnrechnungAbschnitt",
            viewName: sViewName,
            success: function () {
              Opa5.assert.ok(true, "The Formularabschnitt pauschaleAnrechnungAbschnitt appears");
            },
            errorMessage: "Formularabschnitt pauschaleAnrechnungAbschnitt does not appear"
          });
        },

        iShouldSeeThePauschaleAnrechnungLinkFeldgruppeAndControls: function () {
          return this.waitFor({
            id: "pauschaleAnrechnungLink",
            controlType: "hrk.formular.Feldgruppe",
            viewName: sViewName,
            success: function () {
              Opa5.assert.ok(true, "The Feldgruppe pauschaleAnrechnungLink appears");
            },
            errorMessage: "Checkbox pauschaleAnrechnungLink does not appear"
          });
        },

        iShouldSeeThePauschaleAnrechnungAuflagenAbschnittFormularabschnitt: function () {
          return this.waitFor({
            id: "pauschaleAnrechnungAuflagenAbschnitt",
            viewName: sViewName,
            success: function () {
              Opa5.assert.ok(true, "The Formularabschnitt pauschaleAnrechnungAuflagenAbschnitt appears");
            },
            errorMessage: "Formularabschnitt pauschaleAnrechnungAuflagenAbschnitt does not appear"
          });
        },

        iShouldSeeThePauschaleAnrechnungHochschulberechtigungFeldgruppeAndControls: function () {
          return this.waitFor({
            id: "pauschaleAnrechnungHochschulberechtigung",
            controlType: "hrk.formular.Feldgruppe",
            viewName: sViewName,
            success: function () {
              Opa5.assert.ok(true, "The Feldgruppe pauschaleAnrechnungHochschulberechtigung appears");
              return this.waitFor({
                id: "pauschaleAnrechnungHochschulberechtigungInput1",
                viewName: sViewName,
                success: function () {
                  Opa5.assert.ok(true, "The Checkbox pauschaleAnrechnungHochschulberechtigungInput1 appears");
                  return this.waitFor({
                    id: "pauschaleAnrechnungHochschulberechtigungInput2",
                    viewName: sViewName,
                    success: function () {
                      Opa5.assert.ok(true, "The Checkbox pauschaleAnrechnungHochschulberechtigungInput2 appears");
                      return this.waitFor({
                        id: "pauschaleAnrechnungHochschulberechtigungInput3",
                        viewName: sViewName,
                        success: function () {
                          Opa5.assert.ok(true, "The Checkbox pauschaleAnrechnungHochschulberechtigungInput3 appears");
                        }
                      });
                    },
                  });
                },
              });
            }.bind(this),
            errorMessage: "Feldgruppe pauschaleAnrechnungHochschulberechtigung does not appear"
          });
          // fnCheckFeldgruppeAndSingleControl.call(this, "angebotsbezeichnung", "angebotsbezeichnungSelection");
        },

        iShouldSeeThePauschaleAnrechnungPraktischeErfahrungenListeFeldliste: function () {
          return this.waitFor({
            id: "pauschaleAnrechnungPraktischeErfahrungenListe",
            controlType: "hrk.formular.Feldliste",
            viewName: sViewName,
            success: function () {
              Opa5.assert.ok(true, "The Feldliste anrechnungsvoraussetzungCheckbox appears");
            },
                errorMessage: "Feldliste pauschaleAnrechnungPraktischeErfahrungenListe does not appear"
          });
        },

        iShouldSeeThePauschaleAnrechnungmaxECTSFeldgruppeAndControls: function () {
          return this.waitFor({
            id: "pauschaleAnrechnungMaxECTS",
            controlType: "hrk.formular.Feldgruppe",
            viewName: sViewName,
            success: function () {
              Opa5.assert.ok(true, "The Feldgruppe pauschaleAnrechnungMaxECTS appears");
              return this.waitFor({
                id: "pauschaleAnrechnungMaxETCSInput",
                viewName: sViewName,
                success: function () {
                  Opa5.assert.ok(true, "The Checkbox pauschaleAnrechnungMaxETCSInput appears");
                },
                errorMessage: "Checkbox pauschaleAnrechnungMaxETCSInput does not appear"
              });
            }.bind(this),
            errorMessage: "Feldgruppe pauschaleAnrechnungmaxECTS does not appear"
          });
          // fnCheckFeldgruppeAndSingleControl.call(this, "angebotsbezeichnung", "angebotsbezeichnungSelection");
        },

        iShouldSeeThePauschaleAnrechnungKooperationAbschnittFormularabschnitt: function () {
          return this.waitFor({
            id: "pauschaleAnrechnungKooperationAbschnitt",
            viewName: sViewName,
            success: function () {
              Opa5.assert.ok(true, "The Formularabschnitt pauschaleAnrechnungKooperationAbschnitt appears");
            },
            errorMessage: "Formularabschnitt pauschaleAnrechnungKooperationAbschnitt does not appear"
          });
        },

        iShouldSeeThePauschaleAnrechnungBildungstraegerListeFeldliste: function () {
          return this.waitFor({
            id: "pauschaleAnrechnungBildungstraegerListe",
            controlType: "hrk.formular.Feldliste",
            viewName: sViewName,
            success: function () {
              Opa5.assert.ok(true, "The Feldliste pauschaleAnrechnungBildungstraegerListe appears");
            },
            errorMessage: "Feldliste pauschaleAnrechnungBildungstraegerListe does not appear"
          });
        },
      },
    }
    });

});
