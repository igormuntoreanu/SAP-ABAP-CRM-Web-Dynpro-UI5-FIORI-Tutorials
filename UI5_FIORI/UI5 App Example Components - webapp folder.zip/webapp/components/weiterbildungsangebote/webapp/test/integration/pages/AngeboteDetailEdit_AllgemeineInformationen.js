sap.ui.require([
  "sap/ui/test/Opa5"
], function (Opa5) {
  "use strict";

  const sViewName = "de.hrk.hochweit.components.Weiterbildungsangebote.view.eingabeformular1.AllgemeineInformationen";

  // function fnCheckFeldgruppeAndSingleControl (sFeldgruppeId, sControlId) {
  //   return this.waitFor({
  //     id: sFeldgruppeId,
  //     controlType: "hrk.formular.Feldgruppe",
  //     viewName: sViewName,
  //    success: function () {
  //       Opa5.assert.ok(true, `The Feldgruppe ${sFeldgruppeId} appears`);
  //       return this.waitFor({
  //         id: sControlId,
  //         viewName: sViewName,
  //         success: function() {
  //           Opa5.assert.ok(true, `The Control ${sControlId} appears`);
  //         },
  //         errorMessage: `Control ${sControlId} does not appear`
  //       });
  //     }.bind(this),
  //     errorMessage: `Feldgruppe ${sFeldgruppeId} does not appear`
  //   });
  // }

  Opa5.createPageObjects({
    onTheAllgemeineInformationenPage: {

      assertions: {

        iShouldSeeTheAllgemeineInformationenFormularabschnitt: function() {
          return this.waitFor({
            id: "allgemeineInformationenAbschnitt",
            viewName: sViewName,
           success: function() {
              Opa5.assert.ok(true, "The Formularabschnitt Allgemeine Informationen appears");
            },
            errorMessage: "Formularabschnitt Allgemeine Informationen does not appear"
          });
        },

        iShouldSeeTheAngebotsbezeichnungFeldgruppeAndControls: function() {
          return this.waitFor({
            id: "angebotsbezeichnung",
            controlType: "hrk.formular.Feldgruppe",
            viewName: sViewName,
           success: function() {
              Opa5.assert.ok(true, "The Feldgruppe angebotsbezeichnung appears");
              return this.waitFor({
                id: "angebotsbezeichnungSelection",
                viewName: sViewName,
                success: function() {
                  Opa5.assert.ok(true, "The Control angebotsbezeichnungSelection appears");
                },
                errorMessage: "Control angebotsbezeichnungSelection does not appear"
              });
            }.bind(this),
            errorMessage: "Feldgruppe does not appear"
          });
          // fnCheckFeldgruppeAndSingleControl.call(this, "angebotsbezeichnung", "angebotsbezeichnungSelection");
        },

        iShouldSeeTheAngebotstypFeldgruppeAndControls: function() {
          return this.waitFor({
            id: "angebotstyp",
            controlType: "hrk.formular.Feldgruppe",
            viewName: sViewName,
           success: function() {
              Opa5.assert.ok(true, "The Feldgruppe angebotstyp appears");
              return this.waitFor({
                id: "angebotstypSelection",
                viewName: sViewName,
                success: function() {
                  Opa5.assert.ok(true, "The Control angebotstypSelection appears");
                },
                errorMessage: "Control angebotsbezeichnungSelection does not appear"
              });
            }.bind(this),
            errorMessage: "Feldgruppe angebotstyp does not appear"
          });
          // fnCheckFeldgruppeAndSingleControl.call(this, "angebotstyp", "angebotstypSelection");
        },

        iShouldSeeTheAbschlussFeldgruppeAndControls: function() {
          return this.waitFor({
            id: "abschluss",
            controlType: "hrk.formular.Feldgruppe",
            viewName: sViewName,
           success: function() {
              Opa5.assert.ok(true, "The Feldgruppe abschluss appears");
              return this.waitFor({
                id: "abschlussSelection",
                viewName: sViewName,
                success: function() {
                  Opa5.assert.ok(true, "The Control abschlussSelection appears");
                },
                errorMessage: "Control abschlussSelection does not appear"
              });
            }.bind(this),
            errorMessage: "Feldgruppe abschluss does not appear"
          });
        },

        iShouldSeeTheMaxECTSFeldgruppeAndControls: function() {
          return this.waitFor({
            id: "maxECTS",
            controlType: "hrk.formular.Feldgruppe",
            viewName: sViewName,
           success: function() {
              Opa5.assert.ok(true, "The Feldgruppe maxECTS appears");
              return this.waitFor({
                id: "maxETCSInput",
                viewName: sViewName,
                success: function() {
                  Opa5.assert.ok(true, "The Control maxETCSInput appears");
                },
                errorMessage: "Control maxETCSInput does not appear"
              });
            }.bind(this),
            errorMessage: "Feldgruppe maxECTS does not appear"
          });
        },

        iShouldSeeTheHauptunterrichtsspracheFeldgruppeAndControls: function() {
          return this.waitFor({
            id: "hauptunterrichtssprache",
            controlType: "hrk.formular.Feldgruppe",
            viewName: sViewName,
           success: function() {
              Opa5.assert.ok(true, "The Feldgruppe hauptunterrichtssprache appears");
              return this.waitFor({
                id: "hauptunterrichtsspracheSelection",
                viewName: sViewName,
                success: function() {
                  Opa5.assert.ok(true, "The Control hauptunterrichtsspracheSelection appears");
                },
                errorMessage: "Control hauptunterrichtsspracheSelection does not appear"
              });
            }.bind(this),
            errorMessage: "Feldgruppe hauptunterrichtssprache does not appear"
          });
        },

        iShouldSeeTheGesamtkostenFormularabschnitt: function() {
          return this.waitFor({
            id: "gesamtkostenAbschnitt",
            viewName: sViewName,
           success: function() {
              Opa5.assert.ok(true, "The Formularabschnitt Gesamtkosten appears");
            },
            errorMessage: "Formularabschnitt Gesamtkosten does not appear"
          });
        },

        iShouldSeeTheTeilkostenFeldgruppeAndControls: function() {
          return this.waitFor({
            id: "teilkostenbetrag",
            controlType: "hrk.formular.Feldgruppe",
            viewName: sViewName,
            success: function() {
              Opa5.assert.ok(true, "The Feldgruppe teilkostenbetrag appears");
              return this.waitFor({
                id: "teilkostenbetragInput",
                viewName: sViewName,
                success: function() {
                  Opa5.assert.ok(true, "The Control teilkostenbetragInput appears");
                },
                errorMessage: "Control teilkostenbetragInput does not appear"
              });
            }.bind(this),
            errorMessage: "Feldgruppe teilkostenbetrag does not appear"
          });
        },

        iShouldSeeTheTeilkostenDauerEinzelkostenFeldgruppeAndControls: function() {
          return this.waitFor({
            id: "teilkostenbetrag",
            controlType: "hrk.formular.Feldgruppe",
            viewName: sViewName,
            success: function() {
              Opa5.assert.ok(true, "The Feldgruppe teilkostenbetrag appears");
              return this.waitFor({
                id: "teilkostenDauerEinzelkostenSelection",
                viewName: sViewName,
                success: function() {
                  Opa5.assert.ok(true, "The Control teilkostenDauerEinzelkostenSelection appears");
                },
                errorMessage: "Control teilkostenDauerEinzelkostenSelection does not appear"
              });
            }.bind(this),
            errorMessage: "Feldgruppe teilkostenbetrag does not appear"
          });
        },

        iShouldSeeTheTeilkostenDauerInputFeldgruppeAndControls: function() {
          return this.waitFor({
            id: "teilkostenbetrag",
            controlType: "hrk.formular.Feldgruppe",
            viewName: sViewName,
            success: function() {
              Opa5.assert.ok(true, "The Feldgruppe teilkostenbetrag appears");
              return this.waitFor({
                id: "teilkostendauerInput",
                viewName: sViewName,
                success: function() {
                  Opa5.assert.ok(true, "The Control teilkostendauerInput appears");
                },
                errorMessage: "Control teilkostendauerInput does not appear"
              });
            }.bind(this),
            errorMessage: "Feldgruppe teilkostenbetrag does not appear"
          });
        },

        iShouldSeeTheTeilkostenDauerGesamtkostenFeldgruppeAndControls: function() {
          return this.waitFor({
            id: "teilkostenbetrag",
            controlType: "hrk.formular.Feldgruppe",
            viewName: sViewName,
            success: function() {
              Opa5.assert.ok(true, "The Feldgruppe teilkostenbetrag appears");
              return this.waitFor({
                id: "teilkostenDauerGesamtkostenSelection",
                viewName: sViewName,
                success: function() {
                  Opa5.assert.ok(true, "The Control teilkostenDauerGesamtkostenSelection appears");
                },
                errorMessage: "Control teilkostenDauerGesamtkostenSelection does not appear"
              });
            }.bind(this),
            errorMessage: "Feldgruppe teilkostenbetrag does not appear"
          });
        },

        iShouldSeeTheGesamtostenbetragFeldgruppeAndControls: function() {
          return this.waitFor({
            id: "gesamtkosten",
            controlType: "hrk.formular.Feldgruppe",
            viewName: sViewName,
            success: function() {
              Opa5.assert.ok(true, "The Feldgruppe gesamtkosten appears");
              return this.waitFor({
                id: "gesamtkostenbetragInput",
                viewName: sViewName,
                success: function() {
                  Opa5.assert.ok(true, "The Control gesamtkostenbetragInput appears");
                },
                errorMessage: "Control gesamtkostenbetragInput does not appear"
              });
            }.bind(this),
            errorMessage: "Feldgruppe gesamtkosten does not appear"
          });
        },

        iShouldSeeTheLinkEditorFeldgruppeAndControls: function() {
          return this.waitFor({
            id: "kostenaufstellungInformationen",
            viewName: sViewName,
            success: function() {
              Opa5.assert.ok(true, "The Formularabschnitt KostenaufstellungInformationen appears");
            },
            errorMessage: "Formularabschnitt KostenaufstellungInformationen does not appear"
          });
        },

        iShouldSeeTheAnmerkungenFeldgruppeAndControls: function() {
          return this.waitFor({
            id: "gesamtkostenAnmerkungen",
            controlType: "hrk.formular.Feldgruppe",
            viewName: sViewName,
            success: function() {
              Opa5.assert.ok(true, "The Feldgruppe gesamtkostenAnmerkungen appears");
              return this.waitFor({
                id: "gesamtkostenAnmerkungenInput",
                viewName: sViewName,
                success: function() {
                  Opa5.assert.ok(true, "The Control gesamtkostenAnmerkungenInput appears");
                },
                errorMessage: "Control gesamtkostenAnmerkungenInput does not appear"
              });
            }.bind(this),
            errorMessage: "Feldgruppe gesamtkostenAnmerkungen does not appear"
          });
        },
      }

    }
  });

});
