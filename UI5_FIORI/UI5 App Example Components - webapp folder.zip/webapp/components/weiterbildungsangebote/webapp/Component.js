sap.ui.define([
  "sap/ui/core/UIComponent",
  "sap/ui/Device",
  "de/hrk/hochweit/components/Weiterbildungsangebote/model/models",
  "de/hrk/hochweit/components/Weiterbildungsangebote/controller/ListSelector",
  "sap/ui/core/IconPool",
  "apollo/client/service/ApolloService",
  "sap/base/Log"
], function(UIComponent, Device, models, ListSelector, IconPool, ApolloService, Log) {
  "use strict";

  return UIComponent.extend("de.hrk.hochweit.components.Weiterbildungsangebote.Component", {

    metadata: {
      manifest: "json",
      events: {
        notifyPendingChanges: {
          parameters: {
            componentName: {type: "string"}
          }
        },
        notifyNoPendingChanges: {
          parameters: {
            componentName: {type: "string"}
          }
        }
      },
      properties: {}
    },

    /**
     * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
     * @public
     * @override
     */
    init: function() {

      this.oListSelector = new ListSelector();

      // call the base component's init function
      UIComponent.prototype.init.apply(this, arguments);

      this._registerCustomResources();

      // enable routing
      this.getRouter().initialize();

      // set the device model
      this.setModel(models.createDeviceModel(), "device");

       /**
       * Sample initialization of Apollo service
       */
      this._apolloService = new ApolloService(
        this.getMetadata().getManifestEntry("/sap.app/dataSources/graphql/uri"),
        this.getMetadata().getManifestEntry("/sap.app/dataSources/graphql/ws"),
        true /* disable refresh */
      );

      sap.ui.getCore().getEventBus().subscribe("rootComponent", "discardChanges", this._discardAllChanges, this);
    },

     /**
     * Make ApolloService available for controllers
     */
    getApolloService: function () {
      return this._apolloService;
    },

    declarePendingChanges: function () {
      this.getModel("state").setProperty("/hasPendingChanges", true);
      this.fireNotifyPendingChanges({
        componentName: this.getMetadata().getComponentName()
      });
    },
    liftPendingChanges: function () {
      this.getModel("state").setProperty("/hasPendingChanges", false);
      this.fireNotifyNoPendingChanges({
        componentName: this.getMetadata().getComponentName()
      });
    },

    _discardAllChanges: function (channelId, eventId, oPayload) {
      const sComponentName = this.getMetadata().getComponentName();
      Log.debug(`Event ${eventId} (channel ${channelId}) was caught by ${sComponentName}`);
      if (oPayload.componentName === sComponentName) {
        this.getModel("state").setProperty("/hasPendingChanges", false);
      }
    },

    _registerCustomResources: function () {
      if (this.getComponentData() && this.getComponentData().standalone) {
        IconPool.registerFont({
          collectionName: "huw-icons",
          fontFamily: "huw-icons",
          fontURI: sap.ui.require.toUrl("hrk/icons/font"),
          lazy: true,
        });
        IconPool.registerFont({
          collectionName: "SAP-icons-TNT",
          fontFamily: "SAP-icons-TNT",
          fontURI: sap.ui.require.toUrl("sap/tnt/themes/base/fonts"),
          lazy: true
        });
      }
    },

     /**
     * Cleanup ApolloService instance on Component's end
     */
    exit: function () {
      this.oListSelector.destroy();
      // UIComponent.prototype.destroy.apply(this, arguments);
      if (this._apolloService) {
        this._apolloService.destroy();
      }
    },

    /**
			 * This method can be called to determine whether the sapUiSizeCompact or sapUiSizeCozy
			 * design mode class should be set, which influences the size appearance of some controls.
			 * @public
			 * @return {string} css class, either 'sapUiSizeCompact' or 'sapUiSizeCozy' - or an empty string if no css class should be set
			 */
			getContentDensityClass: function () {
				if (this._sContentDensityClass === undefined) {
					// check whether FLP has already set the content density class; do nothing in this case
					if (jQuery(document.body).hasClass("sapUiSizeCozy") || jQuery(document.body).hasClass("sapUiSizeCompact")) {
						this._sContentDensityClass = "";
					} else if (!Device.support.touch) { // apply "compact" mode if touch is not supported
						this._sContentDensityClass = "sapUiSizeCompact";
					} else {
						// "cozy" in case of touch support; default for most sap.m controls, but needed for desktop-first controls like sap.ui.table.Table
						this._sContentDensityClass = "sapUiSizeCozy";
					}
				}
				return this._sContentDensityClass;
      }
  });
});
