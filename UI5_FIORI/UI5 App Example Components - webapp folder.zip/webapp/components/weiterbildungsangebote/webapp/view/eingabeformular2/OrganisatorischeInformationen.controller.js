sap.ui.define(
  [
    "de/hrk/hochweit/components/Weiterbildungsangebote/controller/EingabeformularBaseController",
    "sap/ui/model/json/JSONModel",
    "de/hrk/hochweit/components/Weiterbildungsangebote/service/KatalogService",
    "de/hrk/hochweit/components/Weiterbildungsangebote/model/businessLogic/OrganisatorischeInformationenLogic",
    "sap/ui/core/ValueState",
    "de/hrk/hochweit/components/Weiterbildungsangebote/validation/type/Integer",
    "de/hrk/hochweit/components/Weiterbildungsangebote/validation/type/ComboBoxSelection",
    "de/hrk/hochweit/components/Weiterbildungsangebote/validation/type/String"
  ],
  function (EingabeformularBaseController, JSONModel, KatalogService, OrganisatorischeInformationenLogic, ValueState) {
    "use strict";

	const _formularFields = OrganisatorischeInformationenLogic.getEmptyOrganisatorischeInformationen();

    return EingabeformularBaseController.extend(
      "de.hrk.hochweit.components.Weiterbildungsangebote.view.eingabeformular2.OrganisatorischeInformationen",
      {
        onInit: function () {
          EingabeformularBaseController.prototype.onInit.call(this);
          this.formularReset = Object.assign({}, this.formularReset, {ME: "eingabeformular2" });
          this.formularFields = _formularFields;

          this.setModel(new JSONModel({}), "katalog");
          this._loadCatalogData();

          this.byId("digitaleLernUndLehrformateListe").attachValidationSuccess(oEvent => oEvent.getSource().removeStyleClass("hrk-control-fehler"));
        },

        _loadCatalogData: function () {
          KatalogService.getVeranstaltungsformate(this._apolloService).then(
            function (data) {
              this.getView()
                .getModel("katalog")
                .setProperty("/veranstaltungsformate", data);
            }.bind(this)
          );

          KatalogService.getLehrUndLernformate(this._apolloService).then(
            function (data) {
              this.getView()
                .getModel("katalog")
                .setProperty("/lehrUndLernformate", data);
            }.bind(this)
          );
          KatalogService.getEinheitenZeitdauer(this._apolloService).then(
            function (data) {
              // since "Einheiten" is an optional attribute, insert an artificial item representing "no selection" with id=null
              const emptyItem = { id: "", bezeichnungplural: { de: "" } };
              data.unshift(emptyItem);
              this.getView().getModel("katalog").setProperty("/einheitenZeitdauer", data);
            }.bind(this)
          );
        },

        onAfterRendering: function () {
          this.getModel().setProperty("/LehrUndLernEinheiten", this.formularFields.LehrUndLernEinheiten);
          this.getModel().firePropertyChange({
            reason: sap.ui.model.ChangeReason.Change,
            path: "/LehrUndLernEinheiten"
          });
        },

        addLehrUndLernEinheit: function () {
          const aLehrUndLernEinheiten = this.getModel().getProperty("/LehrUndLernEinheiten") || [];
          aLehrUndLernEinheiten.push(OrganisatorischeInformationenLogic.createLehrUndLernEinheitenEntry());
          this.getModel().setProperty("/LehrUndLernEinheiten", aLehrUndLernEinheiten);
        },

        _isPropertyPathRelevantForValidation: function (sPath) {
          const viewPaths = ["/veranstaltungsformenIDs", "/LehrUndLernEinheiten", "/praesenzanteiloertlich", "/praesenzanteilzeitlich", "/anmerkunglehrundlerneinheiten",
            "/zielgruppen", "/Zeitbereich/von", "/Zeitbereich/bis", "/Zeitbereich/einheit", "/zeitaufwandvon", "/zeitaufwandbis", "/zeitaufwandeinheit"];
          return viewPaths.map((result, pathElement) => result || pathElement.indexOf(sPath) !== -1, false);
        },

        _onValidationRequested: function () {
          if (!this.getModel("viewState").getProperty("/isShown")) { return; } // ignore event in case the embedding view is not currently displayed
          const bValidationSuccess = this._validateFields();
          this.getEventBus().publish(this.eventRegistry.eingabeformulare.channel, this.eventRegistry.eingabeformulare.events.reportValidationResult, { reporter: this.formularReset.ME, result: bValidationSuccess });
        },

        _validateFields: function () {
          let bValidationSuccess = true;
          let iMaxAnmerkungenInputLength = this.byId("anmerkungenInput").getMaxLength();
          let iMaxZielgruppenInputLength = this.byId("zielgruppenInput").getMaxLength();

          bValidationSuccess &= this._validateVeranstaltungsformatSelection();
          // validation of praesenzanteiloertlich not required as bound to slider providing always a value
          bValidationSuccess &= this._validateLehrUndLernEinheiten();
          bValidationSuccess &= this._validateFieldValue(this.byId("anmerkungenInput"), "value", "string", this.translate("organisatorischeInformationen.validation.maximale.textlaenge", [this.translate("organisatorischeInformationen.validation.anmerkungen.lehrUndLernformate"), iMaxAnmerkungenInputLength]));
          bValidationSuccess &= this._validateFieldValue(this.byId("zielgruppenInput"), "value", "string", this.translate("organisatorischeInformationen.validation.maximale.textlaenge", [this.translate("organisatorischeInformationen.validation.anmerkungen.zielgruppen"), iMaxZielgruppenInputLength]));
          bValidationSuccess &= this._validateFieldValue(this.byId("angebotsDauer2"), "value", "int", this.translate("organisatorischeInformationen.validation.angebotsdauer.obergrenze.erforderlich"));
          bValidationSuccess &= this._validateFieldValue(this.byId("angebotsDauer3"), "selectedKey", "int", this.translate("organisatorischeInformationen.validation.angebotsdauer.zeiteinheit.erforderlich"));

          return !!bValidationSuccess;
        },

        _validateVeranstaltungsformatSelection: function () {
          const oMultiCombo = this.byId("veranstaltungsformatSelection");
          const aSelectionKeys = this.getModel().getProperty("/veranstaltungsformenIDs");
          if (!aSelectionKeys || !aSelectionKeys.length) {
            const errorText = this.getBundle().getText("organisatorischeInformationen.validation.veranstaltungsFormat.message");
            oMultiCombo.fireValidationError({
              element: oMultiCombo,
              message: errorText
            }, false, true); // bAllowPreventDefault, bEnableEventBubbling
            oMultiCombo.setValueState(ValueState.Error);
            oMultiCombo.setValueStateText(errorText);
            return false;
          }
          oMultiCombo.fireValidationSuccess({
            element: oMultiCombo
          }, false, true); // bAllowPreventDefault, bEnableEventBubbling
          oMultiCombo.setValueState(ValueState.None);
          oMultiCombo.setValueStateText("");
          return true;
        },

        _validateLehrUndLernEinheiten: function () {
          const aLehrUndLernEinheiten = this.getModel().getProperty("/LehrUndLernEinheiten");
          const oLehrUndLernEinheitenListe = this.byId("digitaleLernUndLehrformateListe");
          if (!aLehrUndLernEinheiten || !aLehrUndLernEinheiten.length) {
            oLehrUndLernEinheitenListe.addStyleClass("hrk-control-fehler");
            oLehrUndLernEinheitenListe.fireValidationError({
              element: oLehrUndLernEinheitenListe,
              message: this.getBundle().getText("organisatorischeInformationen.validation.lehrUndLerneinheit.required.message")
            }, false, true);
            return false;
          }
          const iErrorCount = aLehrUndLernEinheiten.map((oLehrUndLernEinheit, iIndex) => {
              const bError = !oLehrUndLernEinheit.lehrundlernformat || !(oLehrUndLernEinheit.asynchron || oLehrUndLernEinheit.synchron || oLehrUndLernEinheit.praesenz);
              if (bError) {
                oLehrUndLernEinheitenListe.getZeilen()[iIndex].getParent().addStyleClass("hrk-control-fehler"); // FIXME: We use the parent control because we cannot assign the css class to the list item (possible because no DomRef is returned for the list item; remove getParent() once a solution to this is found)
              } else {
                oLehrUndLernEinheitenListe.getZeilen()[iIndex].getParent().removeStyleClass("hrk-control-fehler");
              }
              return bError;
            })
            .filter(bError => bError).length;
          if (iErrorCount) {
            oLehrUndLernEinheitenListe.fireValidationError({
              element: oLehrUndLernEinheitenListe,
              message: this.getBundle().getText("organisatorischeInformationen.validation.lehrUndLerneinheit.content.message")
            }, false, true);
            return false;
          }
          oLehrUndLernEinheitenListe.fireValidationSuccess({
            element: oLehrUndLernEinheitenListe
          }, false, true); // bAllowPreventDefault, bEnableEventBubbling
          return true;
        }
      }
    );
  }
);
