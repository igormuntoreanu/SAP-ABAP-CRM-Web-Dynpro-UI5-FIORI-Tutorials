sap.ui.define(
  [
    "de/hrk/hochweit/components/Weiterbildungsangebote/controller/EingabeformularBaseController",
    "sap/ui/model/json/JSONModel",
    "de/hrk/hochweit/components/Weiterbildungsangebote/service/KatalogService",
    "de/hrk/hochweit/components/Weiterbildungsangebote/model/businessLogic/WSILogic",
    "de/hrk/hochweit/components/Weiterbildungsangebote/model/businessLogic/UserLogic"
  ],
  function (EingabeformularBaseController, JSONModel, KatalogService, WSILogic, UserLogic) {
    "use strict";

    return EingabeformularBaseController.extend(
      "de.hrk.hochweit.components.Weiterbildungsangebote.view.eingabeformular11.WSI",
      {

        onInit: function () {
          EingabeformularBaseController.prototype.onInit.call(this);
          this.formularReset = Object.assign({}, this.formularReset, {ME: "eingabeformular11" });
          this._messages = [];

          this._userLogic = new UserLogic(this.getOwnerComponent().getModel("login").getProperty("/"));
          this._wsiLogic = new WSILogic();
          this._codeType = this._wsiLogic.getCodeTypes();

          this.getView().setModel(new JSONModel({
            wissensgruppen: [],
            wissensbereiche: []
          }), "katalog");

          this.getView().setModel(new JSONModel({
            codeType: this._codeType
          }), "logic");

          this.getView().setModel(new JSONModel({
            isAdmin: this._userLogic.isAdmin()
          }), "user");

          this._onWALoaded();
        },

        _onWALoaded: function () {
          this._loadKatalogData();
          this._updateVisibilities();
        },

        _loadKatalogData: function () {
          const oKatalogModel = this.getView().getModel("katalog");
          return KatalogService.getWissensgruppen(this._apolloService).then(data => {
            this._wsiLogic.adaptData(this.getModel().getProperty("/"), data, this.getBundle());
            this.formularFields = this._wsiLogic.getFormularFields();
            oKatalogModel.setProperty("/wissensgruppen", this._wsiLogic.getWissensgruppen());
            oKatalogModel.setProperty("/wissensbereiche", this._wsiLogic.getWissensbereiche());
            this._wsiLogic.applyToModel(this.getModel());
          });
        },

        _updateVisibilities: function () {
          this.getModel("user").updateBindings(true);
        },

        _updateRIASECSelection: function () {
          const oModel = this.getView().getModel();
          const oInteressentest = oModel.getProperty("/interessenstest");
          const iSelectedCount = this._wsiLogic.getRIASECKeys().filter(sCategory => oInteressentest[sCategory + "Selected"]).length;
          const bMaxSelected = iSelectedCount >= 3;
          this._wsiLogic.getRIASECKeys().forEach(sCategory => {
            const bKeySelected = oInteressentest[sCategory + "Selected"];
            oModel.setProperty("/interessenstest/" + sCategory + "Selectable", !(bMaxSelected && !bKeySelected));
          });
        },

        _getWITCode: function () {
          const oInteressentest = this.getView().getModel().getProperty("/interessenstest");
          return this._wsiLogic.getRIASECKeys()
            .filter(sCategory => !!oInteressentest["code" + sCategory])
            .reduce((result, sCategory) => {
              return result + sCategory.toUpperCase() + oInteressentest["code" + sCategory];
            }, "");
        },

        checkUserRoles: function (aRoles) {
          const sUserRole = this.getOwnerComponent().getModel("app").getProperty("/user/role");
          return aRoles.indexOf(sUserRole) !== -1;
        },

        formatHinweisText: function (sHollandCodeVerwendung) {
          if (!this.getModel() || !this.getModel().getProperty("/interessenstest")) {
            return "";
          }
          const sWITCode = this._getWITCode();
          let key;
          switch (sHollandCodeVerwendung) {
            case this._codeType.INDIVIDUAL_CODE:
              key = "wsi.interessentest.gruppe.zusatztext.individuellerCode";
              break;
            case this._codeType.WIT_CODE_AND_INDIVIDUAL_CODE:
              key = "wsi.interessentest.gruppe.zusatztext.WITundIndividuell";
              break;
            default:
              return "";
          }
          return this.getBundle().getText(key, [sWITCode]);
        },

        handleInteressenToggle: function (sCategory) {
          const oModel = this.getView().getModel();
          const sCategoryPath = "/interessenstest/" + sCategory + "Selected";
          const bSelection = oModel.getProperty(sCategoryPath);
          if (bSelection) {
            oModel.setProperty("/interessenstest/code" + sCategory, null);
            const oToggleButton = this.byId(sCategory + "Button");
            if (oToggleButton) {
              oToggleButton.setSelectedButton("None");
            }
          }
          this._updateRIASECSelection();
        },

        handleCodeSelect: function (sVerwendung, oEvent) {
          // exclude deselect events
          if (!oEvent.getParameter("selected")) {
            return;
          }
          const oModel = this.getView().getModel();
          oModel.setProperty("/interessenstest/hollandcodeverwendung", sVerwendung);
          if (sVerwendung === this._codeType.WIT_CODE) {
            this._wsiLogic.getRIASECKeys().forEach(sCategory => {
              oModel.setProperty("/interessenstest/code" + sCategory, null);
              oModel.setProperty("/interessenstest/" + sCategory + "Selected", false);
              oModel.setProperty("/interessenstest/" + sCategory + "Selectable", true);
            });
          }
        },

        handleGruppenSelectionChange: function (oEvent) {
          const oContext = oEvent.getSource().getBindingContext();
          const oModel = this.getView().getModel();
          const oKatalogModel = this.getView().getModel("katalog");
          const sPath = oContext.getPath();
          const oGruppenAuswahl = oEvent.getParameter("selectedItem");
          if (!oGruppenAuswahl) {
            oModel.setProperty(sPath + "/wissensbereiche", oKatalogModel.getProperty("/wissensbereiche"));
          } else {
            const iGruppenId = parseInt(oGruppenAuswahl.getKey(), 10);
            const oGruppe = oKatalogModel.getProperty("/wissensgruppen").find(oElement => oElement.id === iGruppenId);
            oModel.setProperty(sPath + "/wissensbereiche", oGruppe.Wissensbereich);
          }
          oModel.setProperty(sPath + "/gruppeState", "None");
          oModel.setProperty(sPath + "/bereich", null);
        },

        handleBereichSelectionChange: function (oEvent) {
          const oContext = oEvent.getSource().getBindingContext();
          const oModel = this.getView().getModel();
          const sPath = oContext.getPath();
          const vGruppenId = oModel.getProperty(sPath + "/gruppe");
          const oBereichsAuswahl = oEvent.getParameter("selectedItem");
          oModel.setProperty(sPath + "/bereichState", "None");
          oModel.setProperty(sPath + "/gruppeState", "None");
          if (vGruppenId || !oBereichsAuswahl) {
            return;
          }
          const oGruppe = this._wsiLogic.findGruppeForBereich(parseInt(oBereichsAuswahl.getKey(), 10));
          oModel.setProperty(sPath + "/gruppe", oGruppe.id);
          oModel.setProperty(sPath + "/wissensbereiche", oGruppe.Wissensbereich);
          oEvent.getSource().close();
        },

        addWissenfeldzuordnung: function () {
          const oModel = this.getView().getModel();
          const aWissensfeldzuordnungen = oModel.getProperty("/wissensfeldzuordnungen");
          aWissensfeldzuordnungen.push(this._wsiLogic.createNewWissensfeldzuordnung());
          oModel.setProperty("/wissensfeldzuordnungen", aWissensfeldzuordnungen);
          oModel.firePropertyChange({
            reason: sap.ui.model.ChangeReason.Change,
            path: "/wissensfeldzuordnungen"
          });
        },

        addSchwerpunkt: function () {
          const oModel = this.getView().getModel();
          const aSchwerpunkte = oModel.getProperty("/schwerpunkte");
          aSchwerpunkte.push(this._wsiLogic.createNewSchwerpunkt());
          oModel.setProperty("/schwerpunkte", aSchwerpunkte);
          oModel.firePropertyChange({
            reason: sap.ui.model.ChangeReason.Change,
            path: "/schwerpunkte"
          });
        },

        _onValidationRequested: function () {
          if (!this.getModel("viewState").getProperty("/isShown")) { return; } // ignore event in case the embedding view is not currently displayed
          const bValidationSuccess = this._validateFields();
          this.getEventBus().publish(this.eventRegistry.eingabeformulare.channel, this.eventRegistry.eingabeformulare.events.reportValidationResult, { reporter: this.formularReset.ME, result: bValidationSuccess });
        },

        _clearMessagesOfThisForm: function () {
          this._messageManager.removeMessages(this._messages);
        },

        _validateFields: function () {
          this._clearMessagesOfThisForm();
          this._messages = [
            ...this._validateWissensfeldzuordnungen(),
            ...this.validateInteressen()
          ];
          this._messageManager.addMessages(this._messages);

          const bSchwerpunkteValid = this._validator.validate(this.byId("schwerpunktGruppe"));

          return this._messages.length === 0 && bSchwerpunkteValid;
        },

        _validateWissensfeldzuordnungen: function () {
          const oModel = this.getView().getModel();
          if (!oModel) {
            return [];
          }
          const aZuordnungen = oModel.getProperty("/wissensfeldzuordnungen") || [];
          let bZuordnungenComplete = true;
          aZuordnungen.forEach((oAuswahl, index) => {
            const bGruppeError = !oAuswahl.gruppe;
            const bBereichError = !oAuswahl.bereich;

            oModel.setProperty("/wissensfeldzuordnungen/" + index + "/gruppeState", bGruppeError ? "Error" : "None");
            oModel.setProperty("/wissensfeldzuordnungen/" + index + "/bereichState", bBereichError ? "Error" : "None");
            bZuordnungenComplete &= !(bGruppeError || bBereichError);
          });
          if (bZuordnungenComplete) {
            return [];
          }
          return [this._wsiLogic.createZuordnungError()];
        },

        validateInteressen: function () {
          const oModel = this.getView().getModel();
          if (!oModel) {
            return [];
          }
          const sHollandcodeverwendung = oModel.getProperty("/interessenstest/hollandcodeverwendung");
          if (sHollandcodeverwendung === this._codeType.WIT_CODE) {
            return [];
          }
          const oCategories = oModel.getProperty("/interessenstest");
          this._wsiLogic.getRIASECKeys().forEach(sCategory => {
            const oGrid = this.byId(sCategory + "Category");
            oGrid.removeStyleClass("hrk-control-fehler");
          });
          const aSelectedCategories = this._wsiLogic.getRIASECKeys().filter(sCategory => oCategories[sCategory + "Selected"]);
          let i, j;
          let bInvalidCombination = false;
          for (i = 0; i < aSelectedCategories.length; i++) {
            const sCategoryI = aSelectedCategories[i];
            const iSelectionI = parseInt(oCategories["code" + sCategoryI], 10);
            for (j = i + 1; j < aSelectedCategories.length; j++) {
              const sCategoryJ = aSelectedCategories[j];
              const iSelectionJ = parseInt(oCategories["code" + sCategoryJ], 10);
              if (iSelectionI && iSelectionI === iSelectionJ) {
                bInvalidCombination = true;
                const oGrid1 = this.byId(sCategoryI + "Category");
                const oGrid2 = this.byId(sCategoryJ + "Category");
                if (!oGrid1.hasStyleClass("hrk-control-fehler")) {
                  oGrid1.addStyleClass("hrk-control-fehler");
                }
                if (!oGrid2.hasStyleClass("hrk-control-fehler")) {
                  oGrid2.addStyleClass("hrk-control-fehler");
                }
              }
            }
          }
          if (!bInvalidCombination) {
            return [];
          }
          return [this._wsiLogic.createRIASECError()];
        }
      }
    );
  }
);
