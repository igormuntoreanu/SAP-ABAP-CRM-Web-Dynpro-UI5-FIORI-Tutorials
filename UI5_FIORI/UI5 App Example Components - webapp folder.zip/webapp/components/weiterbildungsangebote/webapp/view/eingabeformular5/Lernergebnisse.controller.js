sap.ui.define(
  [
    "de/hrk/hochweit/components/Weiterbildungsangebote/controller/EingabeformularBaseController"
  ],
  function (EingabeformularBaseController) {
    "use strict";

    const _formularFields = {
      lernergebnisse: ""
    };

    return EingabeformularBaseController.extend(
      "de.hrk.hochweit.components.Weiterbildungsangebote.view.eingabeformular5.Lernergebnisse",
      {
        onInit: function () {
          EingabeformularBaseController.prototype.onInit.call(this);
          this.formularReset = Object.assign({}, this.formularReset, {ME: "eingabeformular5"});
          this.formularFields = _formularFields;
        },

        _isPropertyPathRelevantForValidation: function (sPropertyPath) {
          return sPropertyPath && sPropertyPath.endsWith("/lernergebnisse");
        }
      }
    );
  }
);
