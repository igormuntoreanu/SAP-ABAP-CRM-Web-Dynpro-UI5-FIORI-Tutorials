sap.ui.define(
  [
    "de/hrk/hochweit/components/Weiterbildungsangebote/controller/EingabeformularBaseController",
    "sap/ui/model/json/JSONModel",
    "de/hrk/hochweit/components/Weiterbildungsangebote/model/businessLogic/KontaktUndAnsprechpartnerLogic",
    "sap/m/Dialog",
    "sap/m/DialogType",
    "sap/m/Button",
    "sap/m/List",
    "sap/m/StandardListItem"
  ],
  function (EingabeformularBaseController, JSONModel, KontaktUndAnsprechpartnerLogic, Dialog, DialogType, Button, List, StandardListItem) {
    "use strict";
    return EingabeformularBaseController.extend(
      "de.hrk.hochweit.components.Weiterbildungsangebote.view.eingabeformular10.KontaktUndAnsprechpartner",
      {
        onInit: function () {
          EingabeformularBaseController.prototype.onInit.call(this);

          // HOWI-767
          this.byId("anrechnungsAnsprechpartnerListe").getAddButton().setEnabled(false);
        },

        onPersonendatenAnzeigenPress: function () {
          if (!this.oResizableDialog) {
            this.oResizableDialog = new Dialog({
              title: "{i18n>angeboteDetailEdit.KontaktUndAnsprechpartnerDialogTitle}",
              contentWidth: "550px",
              contentHeight: "300px",
              resizable: true,
              content: new List({
                items: {
                  path: "",
                  template: new StandardListItem({
                    title: "{kontaktpersonen/0/vorname} {kontaktpersonen/0/nachname}", // FIXME: do not hard-code person id(s)
                    description: "{kontaktpersonen/0/email} {kontaktpersonen/0/telefon}"
                  })
                }
              }),
              endButton: new Button({
                text: "{i18n>angeboteDetailEdit.KontaktUndAnsprechpartnerButtonClose}",
                type:"Ghost",
                press: function () {
                  this.oResizableDialog.close();
                }.bind(this)
              })
            });

            //to get access to the controller's model
            this.getView().addDependent(this.oResizableDialog);
          }

          this.oResizableDialog.open();
        },

        addAnsprechpartner: function (oEvent) {
          const oModel = this.getView().getModel();
          const oCtx = oEvent.getSource().getBindingContext();
          const aAnsprechpartner = oModel.getProperty(oCtx.getPath());
          aAnsprechpartner.push(KontaktUndAnsprechpartnerLogic.createNewAnsprechpartner());
          oModel.setProperty(oCtx.getPath(), aAnsprechpartner);
          oModel.firePropertyChange({
            reason: sap.ui.model.ChangeReason.Change,
            path: ""
          });
        },

        onFormatKontaktpersonenIds: function (aKontaktpersonen) {
          if (!aKontaktpersonen) {
            return [];
          }
          return aKontaktpersonen
          .filter((person => { return !!person.id; }))
          .map((person) => {return person.id.toString(); });
        },

        onKontaktstelleSelectionChange: function (oEvent) {
          const oSelectedItem = oEvent.getParameter("selectedItem");
          const oCtx = oEvent.getSource().getBindingContext();
          const sPath = oCtx.getPath() + "/kontaktstelle";
          const oSelectedKontaktstelle = oSelectedItem ? this.getModel("katalog").getProperty("/kontaktstellen").find(kontaktstelle => { return kontaktstelle.id == oSelectedItem.getKey(); }) : KontaktUndAnsprechpartnerLogic.createNewAnsprechpartner().kontaktstelle;
          this.getModel().setProperty(sPath, oSelectedKontaktstelle);
        },

        onKontaktpersonenChange: function (oEvent, aKontaktpersonen) {
          const oChangedPerson = oEvent.getParameter("changedItem");
          const sChangedPersonKey = oChangedPerson.getKey();
          const bSelected = oEvent.getParameter("selected");

          const aWAKontaktpersonen = [].concat(aKontaktpersonen);

          if (bSelected) {
            if (!aWAKontaktpersonen.find((person) => { return person.id == sChangedPersonKey})) {
              aWAKontaktpersonen.push({id: sChangedPersonKey});
            }
          } else {
            if (aWAKontaktpersonen.find((person) => { return person.id == sChangedPersonKey})) {
              aWAKontaktpersonen.splice(aWAKontaktpersonen.findIndex((person) => { return person.id == sChangedPersonKey}), 1);
            }
          }
          const oCtx = oEvent.getSource().getBindingContext();
          const sKontaktpersonenPath =  oCtx.getPath() + "/kontaktpersonen";

          this.getModel().setProperty(sKontaktpersonenPath, aWAKontaktpersonen);

          // this.getModel().firePropertyChange({
          //   reason: sap.ui.model.ChangeReason.Change,
          //   path: "kontaktpersonen",
          //   context: oCtx,
          //   value: aWAKontaktpersonen
          // }); // TODO: won't work, maybe due to wrong path - check if doable to avoid calling updateBindings
          this.getModel().updateBindings(true);
        },

        formatKontaktpersonenQuickinfo: KontaktUndAnsprechpartnerLogic.formatKontaktpersonenQuickinfo

      }
    );
  }
);
