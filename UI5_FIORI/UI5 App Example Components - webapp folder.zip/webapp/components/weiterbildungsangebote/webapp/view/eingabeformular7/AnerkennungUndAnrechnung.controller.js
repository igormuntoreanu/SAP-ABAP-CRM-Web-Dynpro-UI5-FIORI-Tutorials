sap.ui.define(
  [
    "de/hrk/hochweit/components/Weiterbildungsangebote/controller/EingabeformularBaseController",
    "sap/ui/model/json/JSONModel",
    "sap/ui/model/BindingMode",
    "de/hrk/hochweit/components/Weiterbildungsangebote/service/KatalogService",
    "de/hrk/hochweit/components/Weiterbildungsangebote/model/businessLogic/AnerkennungUndAnrechnungLogic",
    "de/hrk/hochweit/components/Weiterbildungsangebote/model/businessLogic/UserLogic",
    "sap/ui/core/ValueState",
    "sap/ui/core/message/Message",
    "de/hrk/hochweit/components/Weiterbildungsangebote/validation/type/ComboBoxSelection"
  ],
  function (EingabeformularBaseController, JSONModel, BindingMode, KatalogService, AnerkennungUndAnrechnungLogic, UserLogic, ValueState, Message) {
    "use strict";

    const _formularFields = {
      anrechnungsansprechpartner: [{
        kontaktpersonen: [],
        kontaktstelle: {
          id: null,
          kontaktstellentyp: {
            bezeichnung: ""
          },
          adresse: {
            strasseoderpostfach: "",
            plz: null,
            ort: ""
          },
          email: "",
          telefon: ""
        }
      }],
      ansprechpartnerfueranerkennungausanrechnung: false,
      voraussetzunganrechnungstyp: {},
      anerkennungwebsiteausanrechnunguebernehmen: null,
      einstufungspruefunginhoeheressemestermoeglich: false,
      anerkennungsansprechpartner: [],
      individuelleanrechnungwebsite: {},
      anrechnungwebsite: {},
      hochschulzugangsberechtigung: [],
      praktischeerfahrungen: [],
      maxanrechenbareects: {},
      BildungstraegerKooperation: []
    };

    return EingabeformularBaseController.extend(
      "de.hrk.hochweit.components.Weiterbildungsangebote.view.eingabeformular7.AnerkennungUndAnrechnung",
      {
        onInit: function () {
          EingabeformularBaseController.prototype.onInit.call(this);
          this.formularReset = Object.assign({}, this.formularReset, {ME: "eingabeformular7" });
          this.formularFields = _formularFields;
          this._messages = [];
          this.MESSAGE_ANRECHNUNGSVORAUSSETZUNGEN_MISSING = new Message({
            id: "weiterbildungsangebot.anrechnungsvoraussetzung.missing",
            type: "Error",
            message: this.getBundle().getText("anerkennungAnrechnung.anrechnungsvoraussetzung.missing.title"),
            description: this.getBundle().getText("anerkennungAnrechnung.anrechnungsvoraussetzung.missing.description"),
            additionalText: this.getBundle().getText("anerkennungAnrechnung.anrechnungsvoraussetzung.missing.subtitle")
          });

          //set model to handle visibility of Pauschale Anrechnung
          this.setModel(new JSONModel({
            logic: {
              hochschule: {
                enabled: true
              },
              praktisch: {
                  enabled: true
              },
              noAnrechnungsvoraussetzungstypInfoText: {
                enabled: true
              },
              einstufungFachsemester: {
                enabled: false
              }
            }
          }), "visibility");

          this.getView().setModel(new JSONModel({
            kontaktstellen: [],
            kontaktpersonen: [],
            anrechnungsvoraussetzungstypen: [],
            hochschulzugangsberechtigung: [],
            praktischeErfahrungTypen: [],
            einheitenZeitdauerFormular: [],
            bildungstraeger: []
          }), "katalog");
          this.getModel("katalog").setDefaultBindingMode(BindingMode.OneWay);

          this._userLogic = new UserLogic(this.getOwnerComponent().getModel("login").getProperty("/"));

          this._onWALoaded();

          this.byId("pauschaleAnrechnungPraktischeErfahrungenListe").attachValidationSuccess(oEvent => oEvent.getSource().removeStyleClass("hrk-control-fehler"));
          this.byId("pauschaleAnrechnungBildungstraegerListe").attachValidationSuccess(oEvent => oEvent.getSource().removeStyleClass("hrk-control-fehler"));
        },


        _onWALoaded: function (){
          this._loadCatalogData().then(() => {
            //Bind data from anrechnungsAnsprechpartner for EF 10
            this.byId("anrechnungsAnsprechpartner").bindElement({path: "/anrechnungsansprechpartner"});
            //Bind data from anerkennungsAnsprechpartner for EF 10
            this.byId("anerkennungsAnsprechpartner").bindElement({path: "/anerkennungsansprechpartner"});
            this.updateVisibilityAnrechnung();
          });
        },

        _onValidationRequested: function () {
          if (!this.getModel("viewState").getProperty("/isShown")) { return; } // ignore event in case the embedding view is not currently displayed
          const bValidationSuccess = this._validateFields();
          this.getEventBus().publish(this.eventRegistry.eingabeformulare.channel, this.eventRegistry.eingabeformulare.events.reportValidationResult, { reporter: this.formularReset.ME, result: bValidationSuccess });
        },

        _clearMessagesOfThisForm: function () {
          this._messageManager.removeMessages(this._messages);
          this._messages = [];
        },

        _validateFields: function () {
          let success = true;
          this._clearMessagesOfThisForm();

          //Anrechnungsvoraussetzungen
          const anrechungsvoraussetzungenCombo = this.byId("anrechnungsvoraussetzungSelection");
          if (anrechungsvoraussetzungenCombo) {
            // reset all error states of this form
            anrechungsvoraussetzungenCombo.setValueState(ValueState.None);
            anrechungsvoraussetzungenCombo.setValueStateText("");
            const selectedKey = anrechungsvoraussetzungenCombo.getSelectedKey();
            if (!selectedKey) {
              success = false;
              anrechungsvoraussetzungenCombo.setValueState(ValueState.Error);
              anrechungsvoraussetzungenCombo.setValueStateText(this.getBundle().getText("anerkennungAnrechnung.anrechnungsvoraussetzung.missing.description"));
              this._messages.push(this.MESSAGE_ANRECHNUNGSVORAUSSETZUNGEN_MISSING);
              this._messageManager.addMessages(this.MESSAGE_ANRECHNUNGSVORAUSSETZUNGEN_MISSING);
            }
          }

          //Praktische Erfahrungen
          const oPraktischeErfahrungenListe = this.byId("pauschaleAnrechnungPraktischeErfahrungenListe");
          const iPraktischeErfahrungenErrorCount = oPraktischeErfahrungenListe.getZeilen().map((oPraktischeErfahrung) => {
            const oPraktischeErfahrungCtx = oPraktischeErfahrung.getBindingContext();
            return ( !oPraktischeErfahrungCtx.getProperty("erfahrungstyp/id")
              || (!oPraktischeErfahrungCtx.getProperty("erfahrungsdauerwert") && oPraktischeErfahrungCtx.getProperty("erfahrungsdauerwert") !== 0)
              || !oPraktischeErfahrungCtx.getProperty("erfahrungsdauereinheit")
            );
          })
          .filter(bError => bError).length;
          if (iPraktischeErfahrungenErrorCount) {
            oPraktischeErfahrungenListe.addStyleClass("hrk-control-fehler");
            oPraktischeErfahrungenListe.fireValidationError({
              element: oPraktischeErfahrungenListe,
              message: this.translate("anerkennungAnrechnung.anrechnungPraktischeErfahrung.validation.missingValues.message")
            }, false, true);
            success = false;
          } else {
            oPraktischeErfahrungenListe.fireValidationSuccess({
              element: oPraktischeErfahrungenListe
            }, false, true); // bAllowPreventDefault, bEnableEventBubbling
          }

          //Bildungsträger
          const oBildungstraegerListe = this.byId("pauschaleAnrechnungBildungstraegerListe");
          const iBildungstraegerErrorCount = oBildungstraegerListe.getZeilen().map((oBildungstraeger) => {
            const oBildungstraegerCtx = oBildungstraeger.getBindingContext();
            return (!oBildungstraegerCtx.getProperty("Bildungstraeger/bezeichnung") || !oBildungstraegerCtx.getProperty("beginn"));
          })
          .filter(bError => bError).length;
          if (iBildungstraegerErrorCount) {
            oBildungstraegerListe.addStyleClass("hrk-control-fehler");
            oBildungstraegerListe.fireValidationError({
              element: oBildungstraegerListe,
              message: this.translate("anerkennungAnrechnung.anrechnungBildungstraeger.validation.missingValues.message")
            }, false, true);
            success = false;
          } else {
            oBildungstraegerListe.fireValidationSuccess({
              element: oBildungstraegerListe
            }, false, true); // bAllowPreventDefault, bEnableEventBubbling
          }

          return success;
        },

        _loadCatalogData: function () {
          const oKatalogModel = this.getView().getModel("katalog");

          const oModel = this.getModel();

          let hochschuleId = 1; // FIXME: remove hard-coded default once timing-issue (see above) is resolved
          if (oModel) {
            const oWAHochschule = oModel.getProperty("/hochschule");
            hochschuleId = oWAHochschule.id;
          }

          const promiseKontaktstellen = KatalogService.getKontaktstellen(this._apolloService, hochschuleId).then(
            function (data) {
              oKatalogModel.setProperty("/kontaktstellen", data.kontaktstellen);
            }.bind(this)
          );

          const promiseKontaktpersonen = KatalogService.getKontaktpersonen(this._apolloService, hochschuleId).then(
            function (data) {
              oKatalogModel.setProperty("/kontaktpersonen", data.kontaktpersonen);
            }.bind(this)
          );

          const promiseAnrechnungsvoraussetzungstypen = KatalogService.getAnrechnungsvoraussetzungstypen(this._apolloService).then(
            function (data) {
              oKatalogModel.setProperty("/anrechnungsvoraussetzungstypen", data);
            }.bind(this)
          );

          const promiseHochschulzugangsberechtigungen = KatalogService.getHochschulzugangsberechtigungen(this._apolloService).then(
            function (data) {
              oKatalogModel.setProperty("/hochschulzugangsberechtigungen", data);
            }.bind(this)
          );

          const promisePraktischeErfahrungTypen = KatalogService.getPraktischeErfahrungTypen(this._apolloService).then(
            function (data) {
              oKatalogModel.setProperty("/praktischeErfahrungTypen", data);
            }.bind(this)
          );

          const promiseEinheitenZeitdauerFormular = KatalogService.getEinheitenZeitdauerFormular(this._apolloService).then(
            function (data) {
              oKatalogModel.setProperty("/einheitenZeitdauerFormular", data);
            }.bind(this)
          );

          const promiseBildungstraeger = KatalogService.getBildungstraeger(this._apolloService).then(
            function (data) {
              oKatalogModel.setProperty("/bildungstraeger", data);
            }.bind(this)
          );

          return Promise.all([promiseKontaktstellen, promiseKontaktpersonen, promiseAnrechnungsvoraussetzungstypen, promiseHochschulzugangsberechtigungen, promisePraktischeErfahrungTypen, promiseEinheitenZeitdauerFormular, promiseBildungstraeger]);
        },

        onBildungstraegerAngebotsZeitraumChange: function (oEvent, bSetBildungstraegerAngebotsZeitraumBisInitial) {
          const oCtx = oEvent.getSource().getBindingContext();
          this.getModel().setProperty(oCtx.getPath()+"/valueState", AnerkennungUndAnrechnungLogic.validateVonAndBis(oCtx.getProperty("beginn"), oCtx.getProperty("ende")));
          if (bSetBildungstraegerAngebotsZeitraumBisInitial) {
            sap.ui.getCore().byId(oEvent.getSource().getPairedWith()).setInitialFocusedDateValue(oEvent.getSource().getDateValue());
          }
        },

        // TODO: Check what this function does and what it should do!
        onBildungstraegerSelectionChange: function (oEvent) {
          const oCtx = oEvent.getSource().getBindingContext();
          this.getModel().setProperty(oCtx.getPath("beginn"), null);
          this.getModel().setProperty(oCtx.getPath("ende"), null);
        },

        onChangeIndividuelleanrechnungwebsite: function(oEvent) {
          this.getModel().setProperty("/individuelleanrechnungwebsite", oEvent.getParameter("value"));
        },

        onChangeanrechnungwebsite: function(oEvent) {
          this.getModel().setProperty("/anrechnungwebsite", oEvent.getParameter("value"));
        },

        updateVisibilityAnrechnung: function (){
         var selection = this.byId("anrechnungsvoraussetzungSelection").getSelectedKey();
         this.getModel("visibility").setProperty("/logic/hochschule/enabled", AnerkennungUndAnrechnungLogic.checkVisibilityOfPauschaleAnrechnungHochschule(selection));
         this.getModel("visibility").setProperty("/logic/praktisch/enabled", AnerkennungUndAnrechnungLogic.checkVisibilityOfPauschaleAnrechnungPraktisch(selection));
         this.getModel("visibility").setProperty("/logic/noAnrechnungsvoraussetzungstypInfoText/enabled", AnerkennungUndAnrechnungLogic.checkVisibilityOfNoAnrechnungsvoraussetzungstypInfoText(selection));
         this.getModel("visibility").setProperty("/logic/einstufungFachsemester/enabled", this._userLogic.isAdmin());
        },

        onSelectHochschulzugangsberechtigung: function (oEvent, iId) {
          if (!iId) return;
          const sPath = "/hochschulzugangsberechtigung";
          const aHochschulzugangsberechtigung = this.getModel().getProperty(sPath);
          const bSelected = oEvent.getParameter("selected");
          if (bSelected) {
            if (!aHochschulzugangsberechtigung.includes(iId)) {
              aHochschulzugangsberechtigung.push(iId);
              this.getModel().setProperty(sPath, aHochschulzugangsberechtigung);
            }
          } else {
            if (aHochschulzugangsberechtigung.includes(iId)) {
              aHochschulzugangsberechtigung.splice(aHochschulzugangsberechtigung.indexOf(iId), 1);
              this.getModel().setProperty(sPath, aHochschulzugangsberechtigung);
            }
          }
        },

        addPraktischeErfahrungen: function () {
          const oModel = this.getView().getModel();
          const aPraktischeErfahrungen = oModel.getProperty("/praktischeerfahrungen");
          aPraktischeErfahrungen.push(AnerkennungUndAnrechnungLogic.createNewPraktischeErfahrung());
          oModel.setProperty("/praktischeerfahrungen", aPraktischeErfahrungen);
          oModel.firePropertyChange({
            reason: sap.ui.model.ChangeReason.Change,
            path: "/praktischeerfahrungen"
          });
        },

        addBildungstraeger: function () {
          const oModel = this.getView().getModel();
          const aBildungstraeger = oModel.getProperty("/BildungstraegerKooperation");
          aBildungstraeger.push(AnerkennungUndAnrechnungLogic.createNewBildungstraegerKooperation());
          oModel.setProperty("/BildungstraegerKooperation", aBildungstraeger);
          oModel.firePropertyChange({
            reason: sap.ui.model.ChangeReason.Change,
            path: "/BildungstraegerKooperation"
          });
        },

        onChangeAnsprechpartnerUebernehmen: function (event) {
          var selection = event.getSource().getSelected();
          if (selection) {
            this.getModel().setProperty("/anrechnungsansprechpartner", this.getModel().getProperty("/anerkennungsansprechpartner"));
          } else {
            this.getModel().setProperty("/anrechnungsansprechpartner", AnerkennungUndAnrechnungLogic.createNewAnsprechpartnerList());
          }
          this.getModel().firePropertyChange({
            reason: sap.ui.model.ChangeReason.Change,
            path: "/anrechnungsansprechpartner"
          });
        }

      }
    );
  }
);
