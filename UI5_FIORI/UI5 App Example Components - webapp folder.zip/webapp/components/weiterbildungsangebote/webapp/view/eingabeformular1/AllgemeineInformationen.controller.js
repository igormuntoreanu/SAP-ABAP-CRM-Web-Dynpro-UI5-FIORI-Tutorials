sap.ui.define(
  [
    "de/hrk/hochweit/components/Weiterbildungsangebote/controller/EingabeformularBaseController",
    "sap/ui/model/json/JSONModel",
    "de/hrk/hochweit/components/Weiterbildungsangebote/service/KatalogService",
    "de/hrk/hochweit/components/Weiterbildungsangebote/model/businessLogic/AngebotsBezeichnungLogic",
    "de/hrk/hochweit/components/Weiterbildungsangebote/model/businessLogic/AngebotsVarianteLogic",
    "de/hrk/hochweit/components/Weiterbildungsangebote/model/businessLogic/GesamtkostenLogic",
    "de/hrk/hochweit/components/Weiterbildungsangebote/model/DecimalTruncater",
    "sap/ui/core/ValueState",
    "de/hrk/hochweit/components/Weiterbildungsangebote/validation/type/ComboBoxSelection",
    "de/hrk/hochweit/components/Weiterbildungsangebote/validation/type/Integer",
    "de/hrk/hochweit/components/Weiterbildungsangebote/validation/type/HrkKostenDecimal"
  ],
  function (EingabeformularBaseController, JSONModel, KatalogService, AngebotsBezeichnungLogic, AngebotsVarianteLogic, GesamtkostenLogic, DecimalTruncater, ValueState) {
    "use strict";

    const _formularFields = {
      bezeichnung: ["/bezeichnung"],
      angebotstyp: ["/angebotstyp"],
      abschluss: ["/abschluss"],
      maxects: ["/maxects"],
      hauptunterichtssprache: ["/hauptunterichtssprache"],
      WeiterbildungsangebotKosten: [
        "/Weiterbildungsangebotkosten/teilkostenbetrag",
        "/WeiterbildungsangebotKosten/Zeitlaenge/wert",
        "/WeiterbildungsangebotKosten/gesamtkostenbetrag"
      ]
    };

    // Preference values for GesamtkostenLogic
    const GESAMTKOSTEN = GesamtkostenLogic.getPreferenceValues().GESAMTKOSTEN;
    const TEILKOSTEN = GesamtkostenLogic.getPreferenceValues().TEILKOSTEN;
    const NONE = GesamtkostenLogic.getPreferenceValues().NONE;

    return EingabeformularBaseController.extend(
      "de.hrk.hochweit.components.Weiterbildungsangebote.view.eingabeformular1.AllgemeineInformationen",
      {
        onInit: function () {
          EingabeformularBaseController.prototype.onInit.call(this);
          this.formularReset = Object.assign({}, this.formularReset, {ME: "eingabeformular1" });
          this.formularFields = _formularFields;

          this.setModel(new JSONModel({
            logic: {
              abschluesse: {
                enabled: true,
                filter: []
              },
              kosten: {
                teilkosten: {
                  enabled: true
                },
                gesamtkosten: {
                  enabled: true
                },
                zeitdauer: {
                  enabled: true
                },
                teilkostendauer: {
                  enabled: true
                },
                kostenlos: false
              }
            }
          }), "katalog"); // TODO: refactor into own model "logic", don't use the "katalog" model for this

          this.getOwnerComponent().getEventBus().subscribe(
            this.eventRegistry.eingabeformulare.channel,
            this.eventRegistry.eingabeformulare.events.newWeiterbildungsangebotInHochschulkontext,
            this._onReceiveHochschulkontext,
            this
          );

          this._angebotsVarianteLogic = null;
          this._abschluesseSelection = this.byId("abschlussSelection");
          this._maxECTSInput = this.byId("maxETCSInput");
        },

        _loadCatalogData: function (hochschulId) {
          const bezeichnungenPromise = KatalogService.getAngebotsbezeichnungen(this._apolloService, hochschulId).then(
            function (data) {
              this.getView()
                .getModel("katalog")
                .setProperty("/angebotsbezeichnungen", data);
            }.bind(this)
          );

          const angebotstypenPromise = KatalogService.getAngebotsTypen(this._apolloService).then(
            function (data) {
              this.getView()
                .getModel("katalog")
                .setProperty("/angebotsTypen", data);
            }.bind(this)
          );

          const sprachenPromise = KatalogService.getSprachen(this._apolloService).then(
            function (data) {
              this.getView().getModel("katalog").setProperty("/sprachen", data);
            }.bind(this)
          );

          const abschluessePromise = KatalogService.getAbschluesse(this._apolloService).then(
            function (data) {
              this.getView().getModel("katalog").setProperty("/abschluesse", data);
            }.bind(this)
          );

          const angebotsvariantenPromise = KatalogService.getAngebotsvarianten(this._apolloService).then(
            function (data) {
              this._angebotsVarianteLogic = new AngebotsVarianteLogic(data);
            }.bind(this)
          );

          const einheitenZeitdauerPromise = KatalogService.getEinheitenZeitdauer(this._apolloService).then(
            function (data) {
              this.getView().getModel("katalog").setProperty("/einheitenZeitdauer", data);
            }.bind(this)
          );
          return Promise.all([bezeichnungenPromise, angebotstypenPromise, sprachenPromise, abschluessePromise, angebotsvariantenPromise, einheitenZeitdauerPromise]);
        },

        _onReceiveHochschulkontext: function(channel, eventId, { hochschulId }) {
          this._loadCatalogData(hochschulId);
        },

        _getHochschuleFromKontext: function () {
          const hochschule = this.getModel().getProperty("/hochschule");
          return hochschule && hochschule.id;
        },

        _onWALoaded: function () {
          this._loadCatalogData(this._getHochschuleFromKontext()).then(() => {
            this.getModel().refresh(true);
            // Adjust value of Bezeichnung Combobox so that a value can still be displayed if Bezeichnung has already been marked for deletion.
            // In this case the Bezeichnung will not be contained in the values loaded from the Katalogtabelle, therefore the combobox
            // would be empty. This fix displays the correct bezeichnung, but doesn't allow it to be selected from the Combobox any more.
            // For all other cases (non-marked-for-deletion) this just overwrites the value with the one which is there anyway, so it doesn't hurt.
            const bezeichnungCombo = this.getView().byId("angebotsbezeichnungSelection");
            if (bezeichnungCombo) {
              const bezeichnung = this.getModel().getProperty("/bezeichnung/bezeichnung/de");
              bezeichnungCombo.setValue(bezeichnung);
            }

            //update initial UI state
            this._updateAvailableAbschluesse(this.getModel().getProperty("/angebotstyp/id"));
            this._updateMinECTSConstraint(this.getModel().getProperty("/angebotstyp/id"), this.getModel().getProperty("/abschluss/id"));
          });
          const bIsWAKostenlos = this.getModel().getProperty("/WeiterbildungsangebotKosten/gesamtkostenbetrag") === null;

          let preference = NONE;
          // data fetching from model is redundant because we do not know what values to expect from a freshly loaded WA
          const vTeilkostenbetrag = this.getModel().getProperty("/WeiterbildungsangebotKosten/teilkostenbetrag");
          const vTeilkostendauer = this.getModel().getProperty("/WeiterbildungsangebotKosten/Zeitlaenge/wert");
          const vGesamtkostenbetrag = this.getModel().getProperty("/WeiterbildungsangebotKosten/gesamtkostenbetrag");
          if (vGesamtkostenbetrag) {
            preference = GESAMTKOSTEN;
          }
          if (vTeilkostenbetrag && vTeilkostendauer) {
            preference = TEILKOSTEN;
          }

          this._updateKostenStateNoValidate(bIsWAKostenlos, preference);
        },

        onTeilkostenLiveChange: function (oEvent, sTeilkostenbetragFieldValue) {
          let oTeilkostenbetragTruncated, fTeilkostenValue;
            // Case: decimal separator is "." (Dot)
            if (!sTeilkostenbetragFieldValue.includes(",") && sTeilkostenbetragFieldValue.includes(".")) {
              oTeilkostenbetragTruncated = DecimalTruncater.truncateDecimalPlaces(sTeilkostenbetragFieldValue, 2, ".");
            }
            // Case: decimal separator is "," (Comma)
            else {
              oTeilkostenbetragTruncated = DecimalTruncater.truncateDecimalPlaces(sTeilkostenbetragFieldValue, 2, ",");
            }

            // Change the value instantly if there are too many decimal places
            if (oTeilkostenbetragTruncated.tooManyDecimalPlaces) {
              this.getModel().setProperty("/WeiterbildungsangebotKosten/teilkostenbetrag", oTeilkostenbetragTruncated.value);
              this.getModel().refresh(true);
              fTeilkostenValue = oTeilkostenbetragTruncated.value;
            }
            else {
              // Transform the decimal-string to a float
              fTeilkostenValue = parseFloat(sTeilkostenbetragFieldValue.replace(",", "."));
            }

            // Save the current fieldValue in the model to access the variable in the elements onfocusout event
            oEvent.getSource().getModel().setProperty("/WeiterbildungsangebotKosten/teilkostenbetragTrueValue", fTeilkostenValue);

            // If the input is structured like "14.6" and the input field looses its focus, the
            // value of the inputfield should be overwritten with the user input
            if (sTeilkostenbetragFieldValue.match("\\d+[.]\\d{1}")) {
              const oElement = oEvent.getSource();
              function focusoutOnce(fn) {
                function oneTimeHandler(event) {
                  oElement.removeEventDelegate({
                    onfocusout: oneTimeHandler
                  });
                  fn(event);
                }
                oElement.addEventDelegate({
                  onfocusout: oneTimeHandler
                });
              }
              focusoutOnce(function() {
                const teilkostenbetragTrueValue = oElement.getModel().getProperty("/WeiterbildungsangebotKosten/teilkostenbetragTrueValue");
                oElement.setValue(teilkostenbetragTrueValue.toString().replace(".", ","));
              });
            }
            // If the input is structured like "123.00" or "1.23" the model needs to be refreshed
            // or else the Input-field formats it into a completly different number after the cursor is clicked elsewhere
            if (sTeilkostenbetragFieldValue.match("\\d+[.]\\d{2}")) {
              this.getModel().setProperty("/WeiterbildungsangebotKosten/teilkostenbetrag", fTeilkostenValue);
              this.getModel().refresh(true);
            }
        },

        onTeilkostenChange: function (teilkostenbetragFieldValue, teilkostenbetragModelValue, teilkostendauerFieldValue, teilkostendauerModelValue) {
          const vTeilkostenbetrag = teilkostenbetragFieldValue !== "" ? teilkostenbetragModelValue : null;
          const vTeilkostendauer = teilkostendauerFieldValue !== "" ? teilkostendauerModelValue : null;
          let sPreference = NONE;
          if (vTeilkostenbetrag !== "" && vTeilkostenbetrag !== null && vTeilkostendauer !== "" && vTeilkostendauer !== null) {
            sPreference = TEILKOSTEN;
          }
          this._updateKostenState(false, sPreference, vTeilkostenbetrag, vTeilkostendauer);
        },

        onToggleKostenlos: function (oEvent) {
          var bKostenlos = oEvent.getParameter("selected");
          this._updateKostenState(bKostenlos);
        },

        onGesamtkostenbetragLiveChange: function (oEvent, sGesamtkostenbetragFieldValue) {
          let oGesamtkostenbetragTruncated, fGesamtkostenValue;
            // Case: decimal separator is "." (Dot)
            if (!sGesamtkostenbetragFieldValue.includes(",") && sGesamtkostenbetragFieldValue.includes(".")) {
              oGesamtkostenbetragTruncated = DecimalTruncater.truncateDecimalPlaces(sGesamtkostenbetragFieldValue, 2, ".");
            }
            // Case: decimal separator is "," (Comma)
            else {
              oGesamtkostenbetragTruncated = DecimalTruncater.truncateDecimalPlaces(sGesamtkostenbetragFieldValue, 2, ",");
            }

            // Change the value instantly if there are too many decimal places
            if (oGesamtkostenbetragTruncated.tooManyDecimalPlaces) {
              this.getModel().setProperty("/WeiterbildungsangebotKosten/gesamtkostenbetrag", oGesamtkostenbetragTruncated.value);
              this.getModel().refresh(true);
              fGesamtkostenValue = oGesamtkostenbetragTruncated.value;
            }
            else {
              // Transform the decimal-string to a float
              fGesamtkostenValue = parseFloat(sGesamtkostenbetragFieldValue.replace(",", "."));
              fGesamtkostenValue = isNaN(fGesamtkostenValue) ? undefined : fGesamtkostenValue;
            }

            // Save the current fieldValue in the model to access the variable in the elements onfocusout event
            oEvent.getSource().getModel().setProperty("/WeiterbildungsangebotKosten/gesamtkostenbetragTrueValue", fGesamtkostenValue);

            // If the input is structured like "14.6" and the input field looses its focus, the
            // value of the inputfield should be overwritten with the user input
            if (sGesamtkostenbetragFieldValue.match("\\d+[.]\\d{1}")) {
              const oElement = oEvent.getSource();
              function focusoutOnce(fn) {
                function oneTimeHandler(event) {
                  oElement.removeEventDelegate({
                    onfocusout: oneTimeHandler
                  });
                  fn(event);
                }
                oElement.addEventDelegate({
                  onfocusout: oneTimeHandler
                });
              }
              focusoutOnce(function() {
                const fGesamtkostenbetragTrueValue = oElement.getModel().getProperty("/WeiterbildungsangebotKosten/gesamtkostenbetragTrueValue");
                if (fGesamtkostenbetragTrueValue) {
                  oElement.setValue(fGesamtkostenbetragTrueValue.toString().replace(".", ","));
                }
              });
            }
            // If the input is structured like "123.00" or "1.23" the model needs to be refreshed
            if (sGesamtkostenbetragFieldValue.match("\\d+[.]\\d{2}")) {
              this.getModel().setProperty("/WeiterbildungsangebotKosten/gesamtkostenbetrag", fGesamtkostenValue);
              this.getModel().refresh(true);
            }
        },

        onGesamtkostenbetragChange: function (gesamtkostenbetragFieldValue, gesamtkostenbetragModelValue) {
          const vGesamtkostenbetrag = gesamtkostenbetragFieldValue !== "" ? gesamtkostenbetragModelValue : null;
          const sPreference = (vGesamtkostenbetrag !== "" && vGesamtkostenbetrag !== null) ? GESAMTKOSTEN : NONE;
          this._updateKostenState(false, sPreference, null, null, vGesamtkostenbetrag);
        },

        _updateKostenStateNoValidate: function (bKostenlos = false, sPreference = NONE, fTeilkostenbetrag = null, iTeilkostendauer = null, fGesamtkostenbetrag = null) {
          const vTeilkostenbetrag = fTeilkostenbetrag || this.getModel().getProperty("/WeiterbildungsangebotKosten/teilkostenbetrag");
          const vTeilkostendauer = iTeilkostendauer || this.getModel().getProperty("/WeiterbildungsangebotKosten/Zeitlaenge/wert");
          const vGesamtkostenbetrag = fGesamtkostenbetrag || this.getModel().getProperty("/WeiterbildungsangebotKosten/gesamtkostenbetrag");

          const oKostenState = GesamtkostenLogic.getKostenState(vTeilkostenbetrag, vTeilkostendauer, vGesamtkostenbetrag, bKostenlos, sPreference);

          this.getModel("katalog").setProperty("/logic/kosten", oKostenState);
          this.getModel().setProperty("/WeiterbildungsangebotKosten/teilkostenbetrag", oKostenState.teilkosten.value);
          this.getModel().setProperty("/WeiterbildungsangebotKosten/Zeitlaenge/wert", oKostenState.teilkostendauer.value);
          this.getModel().setProperty("/WeiterbildungsangebotKosten/gesamtkostenbetrag", oKostenState.gesamtkosten.value);

        },

        _updateKostenState: function () {
          this._updateKostenStateNoValidate(...arguments);
          this._validateKostenFields();
        },

        onValidateAngebotsbezeichnung: function () {
          this._validateFieldValue(this.byId("angebotsbezeichnungSelection"), "selectedKey", "string");
        },

        onValidateAngebotstyp: function () {
          this._validateFieldValue(this.byId("angebotstypSelection"), "selectedKey", "string");
        },

        onValidateAbschluss: function () {
          this._validateFieldValue(this.byId("abschlussSelection"), "selectedKey", "string");
        },

        onValidateMaxECTS: function () {
          this._validateFieldValue(this._maxECTSInput, "value", "string");
        },



        onAngebotsTypSelectionChange: function (oEvent) {
          let sAngebotsTypId = null;
          const oItem = oEvent.getParameter("selectedItem");
          if (oItem && oItem.getKey) {
            sAngebotsTypId = oItem.getKey();
          }
          this._updateAvailableAbschluesse(sAngebotsTypId, true);
          this._updateMinECTSConstraint(sAngebotsTypId, this.getModel().getProperty("/abschluss/id"));
        },

        onAbschlussSelectionChange: function (oEvent) {
          const oItem = oEvent.getParameter("selectedItem");
          let sAbschlussTypId = null;
          if (oItem && oItem.getKey) {
            sAbschlussTypId = oItem.getKey();
          }
          this._updateMinECTSConstraint(this.getModel().getProperty("/angebotstyp/id"), sAbschlussTypId);
        },

        onChangeLink: function(oEvent) {
          this.getModel().setProperty("/WeiterbildungsangebotKosten/link", oEvent.getParameter("value"));
        },

        onAngebotsbezeichnungSelected: function (iTitleId) {
          const oKatalogBezeichnung = this.getModel("katalog").getProperty("/angebotsbezeichnungen").find(angebotsbezeichnung => { return angebotsbezeichnung.id === iTitleId; });
          if (oKatalogBezeichnung) {
            this.getModel().setProperty("/bezeichnung", AngebotsBezeichnungLogic.castKatalogBezeichnungToWABezeichnung(oKatalogBezeichnung));
          }
        },

        _updateAvailableAbschluesse: function (sAngebotsTypId, bUnsetValue) {
          const oAbschluesseState = this._angebotsVarianteLogic.getAbschluesseState(parseInt(sAngebotsTypId, 10));
          this.getModel("katalog").setProperty("/logic/abschluesse", oAbschluesseState);
          this._abschluesseSelection.getBinding("items").filter(oAbschluesseState.filter);
          if (bUnsetValue) {
            this.getModel().setProperty("/abschluss/id", null);
          }
        },


        _updateMinECTSConstraint: function (sAngebotsTypId, sAbschlussId) {
          if (this._angebotsVarianteLogic) {
            const iMinECTS = this._angebotsVarianteLogic.getMinECTS(parseInt(sAngebotsTypId, 10), parseInt(sAbschlussId, 10));
            const oConstraints = this._maxECTSInput.getBinding("value").getType().oConstraints;
            oConstraints.minimum = iMinECTS;
            this._maxECTSInput.getBinding("value").getType().setConstraints(oConstraints);
          }
        },

        onAngebotsbezeichnungVerwaltenPress: function () {
          this._getAngebotsbezeichnungenVerwaltenDialog()
          .then((oView) => {
            oView.getController().openDialog();
          });
        },

        _getAngebotsbezeichnungenVerwaltenDialog: function () {
          return new Promise((resolve) => {
             if (this._AngebotsbezeichnungenVerwaltenDialog) {
              resolve(this._AngebotsbezeichnungenVerwaltenDialog);
            } else {
              sap.ui.require([
                "sap/ui/core/mvc/XMLView"
              ], function (XMLView) {
                const fnCreateView = () => XMLView.create({ viewName: "de.hrk.hochweit.components.Weiterbildungsangebote.view.eingabeformular1.AngebotsbezeichnungenVerwalten"});
                this.getOwnerComponent().runAsOwner(fnCreateView)
                .then((oView) => {
                  this._AngebotsbezeichnungenVerwaltenDialog = oView;
                  this.getView().addDependent(oView);
                  resolve(oView);
                });
              }.bind(this));
            }
          });
        },

        _onValidationRequested: function () {
          if (!this.getModel("viewState").getProperty("/isShown")) { return; } // ignore event in case the embedding view is not currently displayed
          const bValidationSuccess = this._validateFields();
          this.getEventBus().publish(this.eventRegistry.eingabeformulare.channel, this.eventRegistry.eingabeformulare.events.reportValidationResult, { reporter: this.formularReset.ME, result: bValidationSuccess });
        },

        _validateFields: function () {
          let bValidationSuccess = true;
          bValidationSuccess &= this._validateFieldValue(this.byId("angebotsbezeichnungSelection"), "selectedKey", "string");
          bValidationSuccess &= this._validateFieldValue(this.byId("angebotstypSelection"), "selectedKey", "string");
          bValidationSuccess &= this._validateFieldValue(this.byId("abschlussSelection"), "selectedKey", "string");
          bValidationSuccess &= this._validateFieldValue(this._maxECTSInput, "value", "string");
          bValidationSuccess &= this._validateKostenFields();
          return !!bValidationSuccess;
        },

        _validateKostenFields: function () {
          const oTeilkostenbetrag = this.byId("teilkostenbetragInput");
          const oTeilkostendauer = this.byId("teilkostendauerInput");
          const oGesamtkostenbetrag = this.byId("gesamtkostenbetragInput");
          const oKostenlos = this.byId("kostenlosSelection");

          oTeilkostenbetrag.setValueState(ValueState.None);
          oTeilkostenbetrag.setValueStateText("");
          oTeilkostenbetrag.fireValidationSuccess({element: oTeilkostenbetrag});
          oTeilkostendauer.setValueState(ValueState.None);
          oTeilkostendauer.setValueStateText("");
          oGesamtkostenbetrag.setValueState(ValueState.None);
          oGesamtkostenbetrag.setValueStateText("");
          oGesamtkostenbetrag.fireValidationSuccess({element: oGesamtkostenbetrag});

          if (!GesamtkostenLogic.validateTeilkosten(oTeilkostenbetrag, oTeilkostendauer)) {
            oTeilkostenbetrag.setValueState(ValueState.Error);
            oTeilkostenbetrag.setValueStateText(this.getBundle().getText("angeboteDetailEdit.validation.teilkostenIncomplete"));
            oTeilkostenbetrag.fireValidationError({
              element: oTeilkostenbetrag,
              message: this.getBundle().getText("angeboteDetailEdit.validation.teilkostenIncomplete")
            });
            oTeilkostendauer.setValueState(ValueState.Error);
            oTeilkostendauer.setValueStateText(this.getBundle().getText("angeboteDetailEdit.validation.teilkostenIncomplete"));
            return false;
          }

          if (!GesamtkostenLogic.validateGesamtkosten(oGesamtkostenbetrag, oKostenlos)) {
            oGesamtkostenbetrag.setValueState(ValueState.Error);
            oGesamtkostenbetrag.setValueStateText(this.getBundle().getText("angeboteDetailEdit.validation.gesamtkostenInconsistent"));
            oGesamtkostenbetrag.fireValidationError({
              element: oGesamtkostenbetrag,
              message: this.getBundle().getText("angeboteDetailEdit.validation.gesamtkostenInconsistent")
            });
            return false;
          }
          return true;
        },

        /**
         * Checks whether or not the provided property path is part of a relevant (for validation) binding of EF1
         * @param {string} sPropertyPath the property path to check
         * @returns {boolean}
         */
        _isPropertyPathRelevantForValidation: function (sPropertyPath) {
          return [].concat(Object.values(_formularFields)).includes(sPropertyPath);
        }

    });
  });
