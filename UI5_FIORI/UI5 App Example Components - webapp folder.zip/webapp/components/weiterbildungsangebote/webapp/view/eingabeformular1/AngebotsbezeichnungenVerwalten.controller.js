sap.ui.define(
  [
    "de/hrk/hochweit/components/Weiterbildungsangebote/controller/BaseController",
    "sap/ui/model/json/JSONModel",
    "de/hrk/hochweit/components/Weiterbildungsangebote/service/KatalogService",
    "de/hrk/hochweit/components/Weiterbildungsangebote/view/eingabeformular1/fragments/AngebotsbezeichnungVerwaltenListItemFactory",
    "de/hrk/hochweit/components/Weiterbildungsangebote/model/businessLogic/UserLogic",
    "sap/m/MessageToast",
    "sap/m/PlacementType",
    "sap/base/Log",
    "sap/m/MessageBox",
  ],
  function (
    Controller, JSONModel, KatalogService, AngebotsbezeichnungVerwaltenListItemFactory, UserLogic, MessageToast, PlacementType, Log, MessageBox
  ) {
    "use strict";

    return Controller.extend("de.hrk.hochweit.components.Weiterbildungsangebote.view.eingabeformular1.AngebotsbezeichnungenVerwalten", {
        onInit: function () {
            this._oDialog = this.byId("angebotsbezeichnungenVerwaltenDialog");
            this.setModel(new JSONModel({
              editing: false
            }), "local");
            this._apolloService = this.getOwnerComponent().getApolloService();
            this._userLogic = new UserLogic(this.getOwnerComponent().getModel("login").getProperty("/"));
        },

        openDialog: function () {
            if (!this._oDialog.getEscapeHandler()) {
              this._oDialog.setEscapeHandler(this.onEscapeDialog.bind(this));
            }
            this._oDialog.open();
        },

        onCloseDialog: function () {
          this._oDialog.close();
        },

        onEscapeDialog: function (oEscapePromise) {
          if (this.getModel("local").getProperty("/editing")) {
            oEscapePromise.reject();
          } else {
            oEscapePromise.resolve();
          }
        },

        getEnglishNameVisible: function() {
          return this._userLogic.isAdmin();
        },

        /**
         * Factory function for Table entries; delegates to dedicated factory module
         * @param {*} sId Control id as passed to factory
         * @param {*} oContext Control context as passed to factory
         * @returns void
         */
        createAngebotsBezeichnungListItem: function (sId, oContext) {
            return AngebotsbezeichnungVerwaltenListItemFactory.createAngebotsBezeichnungListItem(this, sId, oContext);
        },

        /**
         * Start editing an entry
         * @param {*} oEvent sap.m.Button.press
         */
        onEditItem: function (oEvent) {
          this._setItemEditing(oEvent.getSource().getBindingContext("katalog"), true);
        },

        /**
         * Cancel editing an entry
         * @param {*} oEvent sap.m.Button.press
         */
        onCancelEditing: function (oEvent) {
          const oCtx = oEvent.getSource().getBindingContext("katalog");
          this._setItemEditing(oCtx, false);
          if (oCtx.getProperty("isNewItem")) {
            this._deleteLocalItem(oCtx);
          } else {
            this._refreshTable(true);
          }

        },

        /**
         * Save a newly created item
         * @param {*} oEvent sap.m.Button.press
         */
        onSaveItem: async function (oEvent) {
          const oCtx = oEvent.getSource().getBindingContext("katalog");
          let result;
          if (oCtx.getProperty("isNewItem")) {
            try {
              result = await KatalogService.createAngebotsbezeichnung(this._apolloService, oCtx.getProperty(""));
              this._showCreated(result.data.createAngebotsbezeichnung);
              this._setItemEditing(oCtx, false);
              this._refreshTable(true);
            } catch (error) {
              if (error.message === "GraphQL error: Cannot have duplicate values for bezeichnung") { // TODO: improve error "identification"
                this._handleDuplicateNameError(error);
              }
            }
          } else {
            try {
              result = await KatalogService.updateAngebotsbezeichnung(this._apolloService, oCtx.getProperty(""));
              this._showUpdated(result.data.updateAngebotsbezeichnung);
              this._setItemEditing(oCtx, false);
              this._refreshTable(true);
              // update angebotsbzeichnung in the header in case the currently selected angebotszezeichnung was changed
              if (oCtx.getProperty("id") === this.getModel().getProperty("/bezeichnung/id")) {
                this._publishAngebotsbezeichnungUpdated(oCtx.getObject());
              }
            } catch (error) {
              if (error.message === "GraphQL error: Cannot have duplicate values for bezeichnung") { // TODO: improve error "identification"
                this._handleDuplicateNameError(error);
              }
            }
          }
        },

        _handleDuplicateNameError: function (oError) {
          Log.error(oError.message + "\n" + oError.stack);
          const oInputDE = this.byId("input-de");
          const oInputEN = this.byId("input-en");
          if (oInputDE) {
            oInputDE.setValueState("Error");
            oInputDE.setValueStateText(this.getBundle().getText("angebotsbezeichnungen.message.DuplicateEntryForAngebotsbezeichnung"));
          }
          if (oInputEN) {
            oInputEN.setValueState("Error");
            oInputEN.setValueStateText(this.getBundle().getText("angebotsbezeichnungen.message.DuplicateEntryForAngebotsbezeichnung"));
          }
        },

        onResetItem: function () { /* TODO */},

        /**
         * Handler for deleting a single Angebotsbezeichnung via its table entry
         * @param {*} oEvent sap.m.Button.press
         */
        onDeleteItem: function (oEvent) {
          const oCtx = oEvent.getSource().getBindingContext("katalog");
          const fnDelete = () => {
            KatalogService.deleteAngebotsbezeichnung(this._apolloService, oCtx.getProperty(""))
            .then((result) => {
              this._setGlobalEditing(false);
              this._refreshTable(true);
              this._showDeleted(result.data.deleteAngebotsbezeichnung);
            });
          };

          this._promptAndExecute(
            oEvent.getSource(),
            PlacementType.HorizontalPreferredLeft,
            this.promptType.CONFIRM,
            this.getBundle().getText("angebotsbezeichnungen.table.prompt.deleteItem"),
            this.getBundle().getText("common.delete"),
            fnDelete
          );
        },

        /**
         * Handler for deleting multiple selected Angebotsbezeichnungen
         * @param {*} oEvent sap.m.Button.press
         */
        onDeleteSelectedAngebotsbezeichnungen: function (oEvent) {
          const aContexts = this.byId("angebotsBezeichnungen").getSelectedContexts();
          const aUsage = aContexts.filter((f) => f.getProperty("istInBenutzungVon") > 0);

          if (aUsage.length === 0) {
            const aIds = aContexts.map(ctx => ctx.getProperty("id"));
            const fnDeleteMultiple = () => {
              KatalogService.deleteAngebotsbezeichnungen(this._apolloService, {ids: aIds})
                .then((result) => {
                  this._setGlobalEditing(false);
                  this.byId("angebotsBezeichnungen").removeSelections(true);
                  this._refreshTable(true);
                  this._showDeletedMultiple(result.data.deleteAngebotsbezeichnungen);
                });
            };
            this._promptAndExecute(
              oEvent.getSource(),
              PlacementType.VerticalPreferredTop,
              this.promptType.CONFIRM,
              this.getBundle().getText("angebotsbezeichnungen.table.prompt.deleteSelectedItems"),
              this.getBundle().getText("common.delete"),
              fnDeleteMultiple
            );
          } else {
            MessageBox.error(this.getBundle().getText("messageBox.onDeleteSelectedAngebotsbezeichnungen"));
          }
        },

        onTableEntrySelectionChange: function (oEvent) {
          this.getModel("local").setProperty("/selectedItemsCount", oEvent.getSource().getSelectedItems().length);
        },

        onAddAngebotsbezeichnung: function () {
          const hochschulId = this.getModel().getProperty("/hochschule/id");
          this.getModel("katalog").getProperty("/angebotsbezeichnungen").push(this._getNewModelEntry(hochschulId));
          this._setGlobalEditing(true);
          this._refreshTable();
        },

        _setItemEditing(oCtx, bEditing) {
          oCtx.getObject().editing = bEditing;
          this._setGlobalEditing(bEditing);
        },

        _setGlobalEditing(bEditing) {
          this.getModel("local").setProperty("/editing", bEditing);
          this._refreshTable();
           if (bEditing) {
            setTimeout(() => {
              this.byId("input-de").focus();
            }, 50);
          }
        },

        _refreshTable: async function(bServerside = false) {
          if (bServerside) {
            this.byId("angebotsBezeichnungen").setBusy(true);
            const data = await KatalogService.getAngebotsbezeichnungen(this._apolloService);
            this.getModel("katalog").setProperty("/angebotsbezeichnungen", data);
            this.byId("angebotsBezeichnungen").setBusy(false);
          }
          this.byId("angebotsBezeichnungen").getBinding("items").refresh(true);
        },

        /**
         * Deletes an Angebotsbezeichnung in the client model
         * @param {*} oCtx
         */
         _deleteLocalItem: function (oCtx) {
          const sPath = oCtx.getPath();
            const oModel = oCtx.getModel();
            const sRootPath = sPath.substring(0, sPath.lastIndexOf("/"));
            const nIndex = parseInt(sPath.substring(sPath.lastIndexOf("/") + 1), 10);
            const aData = oModel.getProperty(sRootPath);
            aData.splice(nIndex, 1);
            oModel.setProperty(sRootPath, aData);
            oModel.firePropertyChange({
              reason: sap.ui.model.ChangeReason.Change,
              path: sRootPath
            });
        },

        /**
         * Creates an empty JSON context for a new Angebotsbezeichnung
         * @returns {JSON}
         */
        _getNewModelEntry: function (hochschulId) {
          return {
            bezeichnung: { de: null, en: null},
            isthskimportiert: false,
            istzumloeschenvorgesehen: false,
            istInBenutzungVon: 0,
            editing: true,
            isNewItem: true,
            hochschule: {
              id: hochschulId
            }
          };
        },

        _showCreated: function (oCreatedAngebotsbezeichnung) {
          MessageToast.show(this.getBundle().getText("angebotsbezeichnungen.message.AngebotsbezeichnungAdded", [oCreatedAngebotsbezeichnung.bezeichnung.de]));
        },
        _showUpdated: function (oUpdatedAngebotsbezeichnung) {
          MessageToast.show(this.getBundle().getText("angebotsbezeichnungen.message.AngebotsbezeichnungUpdated", [oUpdatedAngebotsbezeichnung.bezeichnung.de]));
        },
        _showDeleted: function (oDeletedAngebotsbezeichnung) {
          MessageToast.show(this.getBundle().getText("angebotsbezeichnungen.message.AngebotsbezeichnungDeleted", [oDeletedAngebotsbezeichnung.bezeichnung.de]));
        },
        _showDeletedMultiple: function (iDeletedAngebotsbezeichnungenCount) {
          MessageToast.show(this.getBundle().getText("angebotsbezeichnungen.message.MultipleAngebotsbezeichnungDeleted", [iDeletedAngebotsbezeichnungenCount]));
        },

        _publishAngebotsbezeichnungUpdated: function (oUpdatedAngebotsbezeichnung) {
          const oPayload = { angebotsbezeichnung: { id: oUpdatedAngebotsbezeichnung.id, bezeichnung: oUpdatedAngebotsbezeichnung.bezeichnung} };
          this.getEventBus().publish(this.eventRegistry.eingabeformulare.channel, this.eventRegistry.eingabeformulare.events.angebotsbezeichnungUpdated, oPayload);
        }

    });
});
