sap.ui.define(
  [
    "sap/m/ColumnListItem",
    "sap/m/Input",
    "sap/m/Text",
    "sap/m/HBox",
    "sap/ui/core/Icon",
    "sap/m/Button",
    "sap/m/ButtonType",
    "sap/m/FlexRendertype",
    "sap/m/FlexJustifyContent",
    "sap/m/FlexAlignItems"
  ],
  function (
    ColumnListItem,
    Input,
    Text,
    HBox,
    Icon,
    Button,
    ButtonType,
    FlexRendertype,
    FlexJustifyContent,
    FlexAlignItems
  ) {
    "use strict";

    return {
      createAngebotsBezeichnungListItem: function (oController, sId, oContext) {

        const sGermanNamePath = "katalog>bezeichnung/de";
        const sEnglishNamePath = "katalog>bezeichnung/en";

        const oGermanName = oContext.getProperty("editing")
          ? new Input({ value: { path: sGermanNamePath }, id: oController.createId("input-de") })
          : new Text({ text: { path: sGermanNamePath } });

        const oEnglishName = oContext.getProperty("editing")
          ? new Input({ value: { path: sEnglishNamePath }, id: oController.createId("input-en") })
          : new Text({ text: { path: sEnglishNamePath } });

        const oUsage = new Text({ text: { path: "katalog>istInBenutzungVon" } });

        let aButtons = [];
        if (oContext.getProperty("editing")) {
          aButtons = [
            new Button({
              icon: "sap-icon://cancel",
              type: ButtonType.Transparent,
              tooltip: {
                path: "i18n>angebotsbezeichnungen.table.tooltip.cancelEditing",
              },
              press: [oController.onCancelEditing, oController],
            }),
            new Button({
              icon: "sap-icon://save",
              type: ButtonType.Transparent,
              tooltip: {
                path: "i18n>angebotsbezeichnungen.table.tooltip.saveItem",
              },
              press: [oController.onSaveItem, oController],
            })
          ];
        } else {
          aButtons = [
            new Button({
              icon: "sap-icon://edit",
              type: ButtonType.Transparent,
              tooltip: {
                path: "i18n>angebotsbezeichnungen.table.tooltip.editItem",
              },
              enabled: !oController.getModel("local").getProperty("/editing"),
              visible: oController._userLogic.canEditAngebotsbezeichnung(),
              press: [oController.onEditItem, oController],
            }),
            new Button({
              icon: "sap-icon://reset",
              type: ButtonType.Transparent,
              tooltip: {
                path: "i18n>angebotsbezeichnungen.table.tooltip.resetItem",
              },
              enabled: !oController.getModel("local").getProperty("/editing"),
              visible: (oContext.getProperty("istzumloeschenvorgesehen") && oController._userLogic.canDeleteAngebotsbezeichnung()),
              press: [oController.onResetItem, oController],
            }),
            new Icon({
              src: "sap-icon://error",
              tooltip: {
                path: "i18n>angebotsbezeichnungen.table.tooltip.itemMarkedForDeletion",
              },
              visible: (oContext.getProperty("istzumloeschenvorgesehen") && oController._userLogic.canDeleteAngebotsbezeichnung()),
            }),
            new Button({
              icon: "sap-icon://delete",
              type: ButtonType.Transparent,
              tooltip: {
                path: (oController._userLogic.canDeleteAngebotsbezeichnung() ? "i18n>angebotsbezeichnungen.table.tooltip.deleteItem" : "i18n>angebotsbezeichnungen.table.tooltip.markItemForDeletion"),
              },
              enabled: !oController.getModel("local").getProperty("/editing"),
              visible: (oContext.getProperty("istInBenutzungVon") === 0 && (oController._userLogic.canDeleteAngebotsbezeichnung() || oController._userLogic.canMarkAngebotsbezeichnungForDeletion())),
              press: [oController.onDeleteItem, oController],
            }),
          ];
        }

        const oActions = new HBox({
          renderType: FlexRendertype.Bare,
          justifyContent: FlexJustifyContent.End,
          alignItems: FlexAlignItems.Center,
          items: aButtons,
        });


        return new ColumnListItem(sId, {
          cells: [oGermanName, oEnglishName, oUsage, oActions],
        });
      },
    };
  }
);
