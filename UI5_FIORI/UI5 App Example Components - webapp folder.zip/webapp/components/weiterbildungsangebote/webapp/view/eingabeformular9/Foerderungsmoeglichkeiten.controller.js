sap.ui.define(
  [
    "de/hrk/hochweit/components/Weiterbildungsangebote/controller/EingabeformularBaseController",
    "sap/ui/model/json/JSONModel",
    "de/hrk/hochweit/components/Weiterbildungsangebote/service/KatalogService",
    "de/hrk/hochweit/components/Weiterbildungsangebote/model/businessLogic/FoerderungsmoeglichkeitenLogic",
  ],
  function (EingabeformularBaseController, JSONModel, KatalogService, FoerderungsmoeglichkeitenLogic) {
    "use strict";

    const _formularFields = {
      foerdermoeglichkeitenIDs: [],
      sonstigeFoerdermoeglichkeiten: []
    };

    return EingabeformularBaseController.extend(
      "de.hrk.hochweit.components.Weiterbildungsangebote.view.eingabeformular9.Foerderungsmoeglichkeiten",
      {
        onInit: function () {
          EingabeformularBaseController.prototype.onInit.call(this);
          this.formularReset = Object.assign({}, this.formularReset, {ME: "eingabeformular9"});
          this.formularFields = _formularFields;
          this.setModel(new JSONModel({}), "katalog");
          this._loadCatalogData();
        },

        _loadCatalogData: function () {
          KatalogService.getFoerdermoeglichkeiten(this._apolloService).then(
            function (data) {
              this.getView()
                .getModel("katalog")
                .setProperty("/foerdermoeglichkeiten", data);
            }.bind(this)
          );
        },

        addSonstigeFoerdermoeglichkeit: function () {
          const oModel = this.getView().getModel();
          const aSonstigeFoerdermoeglichkeiten = oModel.getProperty("/sonstigeFoerdermoeglichkeiten") || [];
          aSonstigeFoerdermoeglichkeiten.push(FoerderungsmoeglichkeitenLogic.createNewSonstigeFoerdermoeglichkeit());
          oModel.setProperty("/sonstigeFoerdermoeglichkeiten", aSonstigeFoerdermoeglichkeiten);
          oModel.firePropertyChange({
            reason: sap.ui.model.ChangeReason.Change,
            path: "/sonstigeFoerdermoeglichkeiten"
          });
        },

        onSelectFoerdermoeglichkeit: function (oEvent, iId) {
          if (!iId) return;
          const sPath = "/foerdermoeglichkeitenIDs";
          const aFoerdermoeglichkeit = this.getModel().getProperty(sPath);
          const bSelected = oEvent.getParameter("selected");
          if (bSelected) {
            if (!aFoerdermoeglichkeit.includes(iId)) {
              aFoerdermoeglichkeit.push(iId);
              this.getModel().setProperty(sPath, aFoerdermoeglichkeit);
            }
          } else {
            if (aFoerdermoeglichkeit.includes(iId)) {
              aFoerdermoeglichkeit.splice(aFoerdermoeglichkeit.indexOf(iId), 1);
              this.getModel().setProperty(sPath, aFoerdermoeglichkeit);
            }
          }
        },
      }
    );
  }
);
