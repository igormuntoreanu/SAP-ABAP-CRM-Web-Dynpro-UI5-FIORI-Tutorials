sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/json/JSONModel",
    "de/hrk/hochweit/components/Weiterbildungsangebote/model/businessLogic/QualitaetssicherungLogic",
    "de/hrk/hochweit/components/Weiterbildungsangebote/service/QualitaetssicherungService",
    "sap/base/Log"
], function (
    Controller,
    JSONModel,
    QualitaetssicherungLogic,
    QsService,
    Log
) {
    "use strict";

    return Controller.extend("de.hrk.hochweit.components.Weiterbildungsangebote.view.eingabeformular8.Qualitaetssicherung", {
        onInit: function () {

            this._apolloService = this.getOwnerComponent().getApolloService();
            this._QualitaetssicherungLogic = new QualitaetssicherungLogic();
            this._loadQSData();
        },
        addZertifikatgruppe: function () {
            const oModel = this.getView().getModel();
            let aGruppen = oModel.getProperty("/qsverifiziertezertifikate");
            aGruppen.push(this._QualitaetssicherungLogic.createNewGruppe(false, aGruppen.length + 1));
            oModel.setProperty("/qsverifiziertezertifikate", aGruppen);
            oModel.firePropertyChange({
                reason: sap.ui.model.ChangeReason.Change,
                path: "/qsverifiziertezertifikate"
            });
        },
        addUnbekannteZertifikatgruppe: function () {
            const oModel = this.getView().getModel();
            const aGruppen = oModel.getProperty("/qsunbekanntezertifikate");
            // True = Unbekanntezertifikat / aGruppen.length = next ID
            aGruppen.push(this._QualitaetssicherungLogic.createNewGruppe(true, aGruppen.length + 1));
            oModel.setProperty("/qsunbekanntezertifikate", aGruppen);
            oModel.firePropertyChange({
                reason: sap.ui.model.ChangeReason.Change,
                path: "/qsunbekanntezertifikate"
            });
        },
        _loadQSData: function () {

            const sId = this.getOwnerComponent().getModel().getData().id;

            QsService.getQsTypen(this._apolloService).then(
                function (data) {
                    this.getView().setModel(new JSONModel(data.qstypen), "QSTypen"); // FIXME: einheitliche Benennung für Modell "katalog"
                }.bind(this))
                .catch(oError => {
                    Log.error(oError.message + "\n" + oError.stack);
                });

            QsService.getQualitaetssicherung(this._apolloService, sId).then(
                function (data) {
                    let zertifikate = {
                        qsverifiziertezertifikate: [],
                        qsunbekanntezertifikate: []
                    };
                    if (data) {
                        // Mark the checkbox according to the DB data
                        const qsTypen = this.getView().getModel("QSTypen").getData();
                        qsTypen.forEach(function (line) {
                            if (line.id === data.qualitaetssicherung.qstypen.id) {
                                line.selected = true;
                            } else {
                                line.selected = false;
                            }
                        });
                        this.getView().getModel("QSTypen").setData(qsTypen);
                        zertifikate.qsverifiziertezertifikate = data.qualitaetssicherung.qsverifiziertezertifikate;
                        zertifikate.qsunbekanntezertifikate = data.qualitaetssicherung.qsunbekanntezertifikate;
                    }
                    // Fill the DropDown Values for the Verifiziert- und Unbekanntezertifikate
                    // FIXME: darf nicht das Default-Model überschreiben -> Default-Model enthält WA-Daten! Katalogdaten in Modell "katalog"
                    this.getView().setModel(new JSONModel(zertifikate));
                }.bind(this))
                .catch(oError => {
                    Log.error(oError.message + "\n" + oError.stack);
                });
        }
    });
});