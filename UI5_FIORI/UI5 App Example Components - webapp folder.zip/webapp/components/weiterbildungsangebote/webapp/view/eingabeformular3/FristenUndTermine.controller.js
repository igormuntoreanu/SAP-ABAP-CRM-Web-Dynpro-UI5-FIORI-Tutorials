sap.ui.define(
  [
    "de/hrk/hochweit/components/Weiterbildungsangebote/controller/EingabeformularBaseController",
    "sap/ui/model/json/JSONModel",
    "sap/ui/core/message/Message",
    "de/hrk/hochweit/components/Weiterbildungsangebote/model/businessLogic/FristenUndTermineLogic",
    "de/hrk/hochweit/components/Weiterbildungsangebote/validation/type/Date"
  ],
  function (EingabeformularBaseController, JSONModel, Message, FristenUndTermineLogic) {
    "use strict";

    const _formularFields = {
      fristAngebotszeitraum: {},
      fristAnmeldefrist: {
        zeitraum: {}
      },
      fristSpaetereAngebotszeitraeume: []
    };

    return EingabeformularBaseController.extend(
      "de.hrk.hochweit.components.Weiterbildungsangebote.view.eingabeformular3.FristenUndTermine",
      {
        onInit: function () {
          EingabeformularBaseController.prototype.onInit.call(this);
          this.formularReset = Object.assign({}, this.formularReset, {ME: "eingabeformular3"});
          this.formularFields = _formularFields;
          this._messages = [];
          this.MESSAGE_ANGEBOT_BEGINN_NACH_ENDE = new Message({
            type: "Error",
            message: this.getBundle().getText("fristenUndTermine.angebotzeitraum.beginnvorende.message"),
            description: this.getBundle().getText("fristenUndTermine.angebotzeitraum.beginnvorende.text")
          });
          this.MESSAGE_ANMELDEFRIST_BEGINN_NACH_ENDE = new Message({
            type: "Error",
            message: this.getBundle().getText("fristenUndTermine.frist.title"),
            description: this.getBundle().getText("fristenUndTermine.missing.description")
          });
        },

        //TODO: Current workaround: check why this method doesn't work in onInit (getModel -> undefined). AFTER BETA
        onAfterRendering: function () {
          this.getModel().setProperty("/fristSpaetereAngebotszeitraeume", this.formularFields.fristSpaetereAngebotszeitraeume);
          this.getModel().firePropertyChange({
            reason: sap.ui.model.ChangeReason.Change,
            path: "/fristSpaetereAngebotszeitraeume"
          });
        },

        onAngebotsZeitraumChange: function (oEvent, bSetAngebotszeitraumBisInitial) {
//          var angebotsZeitraumVon = this.byId("angebotsZeitraumVon").getDateValue();
//          var angebotsZeitraumBis = this.byId("angebotsZeitraumBis").getDateValue();
//          this.getModel().setProperty("/fristAngebotszeitraum/valueState", FristenUndTermineLogic.validateVonAndBis(angebotsZeitraumVon, angebotsZeitraumBis));
          if (bSetAngebotszeitraumBisInitial) {
            sap.ui.getCore().byId(oEvent.getSource().getPairedWith()).setInitialFocusedDateValue(oEvent.getSource().getDateValue());
         }
        },

        onAnmeldeFristChange: function (oEvent, bSetAnmeldeFristBisInitial) {
// Controlling the ValueState via model conflicts w/ setting the ValueState during form validation. We need to come up with a solution
// that will prevent any settings for ValueState to cancel each other out.
//          var anmeldeFristVon = this.byId("anmeldefristVon").getDateValue();
//          var anmeldeFristBis = this.byId("anmeldefristBis").getDateValue();
//          this.getModel().setProperty("/fristAnmeldefrist/valueState", FristenUndTermineLogic.validateRequiredBis(anmeldeFristVon, anmeldeFristBis));

          if (bSetAnmeldeFristBisInitial) {
           sap.ui.getCore().byId(oEvent.getSource().getPairedWith()).setInitialFocusedDateValue(oEvent.getSource().getDateValue());
          }
        },

        onSpaetereZeitraeumeChange: function (oEvent, bSetSpaetereAngebotszeitraumBisInitial) {
          const oCtx = oEvent.getSource().getBindingContext();
          this.getModel().setProperty(oCtx.getPath()+"/valueState", FristenUndTermineLogic.validateVonAndBis(oCtx.getProperty("zeitraum/von"), oCtx.getProperty("zeitraum/bis")));
          if (bSetSpaetereAngebotszeitraumBisInitial) {
            sap.ui.getCore().byId(oEvent.getSource().getPairedWith()).setInitialFocusedDateValue(oEvent.getSource().getDateValue());
          }
        },

        addSpaeterenAngebotszeitraum: function () {
          const aSpaetereZeitraeume = this.getModel().getProperty("/fristSpaetereAngebotszeitraeume") || [];
          aSpaetereZeitraeume.push(FristenUndTermineLogic.createSpaetereAngebotszeitraumEntry());
          this.getModel().setProperty("/fristSpaetereAngebotszeitraeume", aSpaetereZeitraeume);
          this.getModel().firePropertyChange({
            reason: sap.ui.model.ChangeReason.Change,
            path: "/fristSpaetereAngebotszeitraeume"
          });
        },

        _clearMessagesOfThisForm: function () {
          this._messageManager.removeMessages(this._messages);
          this._messages = [];
        },

        _onValidationRequested: function () {
          if (!this.getModel("viewState").getProperty("/isShown")) { return; } // ignore event in case the embedding view is not currently displayed
          const bValidationSuccess = this._validateFields();
          this.getEventBus().publish(this.eventRegistry.eingabeformulare.channel, this.eventRegistry.eingabeformulare.events.reportValidationResult, { reporter: this.formularReset.ME, result: bValidationSuccess });
        },

        _validateFields: function () {
          let bValidationSuccess;

          let oAngebotVon = this.byId("angebotsZeitraumVon");
          let oAngebotBis = this.byId("angebotsZeitraumBis");
          let oAnmeldefristVon = this.byId("angebotsZeitraumBis");  // not a mandatory field
          let oAnmeldefristBis = this.byId("anmeldefristBis");

          bValidationSuccess = this._validateFieldValue(oAngebotVon, "value", "string", this.translate("fristenUndTermine.frist.angebotszeitraum.von.missing"));
          bValidationSuccess &= this._validateFieldValue(oAngebotBis, "value", "string", this.translate("fristenUndTermine.frist.angebotszeitraum.bis.missing"));
          if (bValidationSuccess && oAngebotVon.getDateValue() > oAngebotBis.getDateValue()) {
            this._messages.push(this.MESSAGE_ANGEBOT_BEGINN_NACH_ENDE);
            this._messageManager.addMessages(this.MESSAGE_ANGEBOT_BEGINN_NACH_ENDE);
            return false;
          }
          bValidationSuccess &= this._validateFieldValue(oAnmeldefristBis, "value", "string", this.translate("fristenUndTermine.frist.anmeldefrist.bis.missing"));
          if (bValidationSuccess && oAnmeldefristVon.getDateValue() > oAngebotBis.getDateValue()) {
            this._messages.push(this.MESSAGE_ANMELDEFRIST_BEGINN_NACH_ENDE);
            this._messageManager.addMessages(this.MESSAGE_ANMELDEFRIST_BEGINN_NACH_ENDE);
            return false;
          }
          return !!bValidationSuccess;
        }
      }
    );
  }
);
