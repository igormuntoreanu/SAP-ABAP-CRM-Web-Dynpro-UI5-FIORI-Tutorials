sap.ui.define([
    "sap/ui/model/type/Date",
	"sap/ui/model/ValidateException"
], function( BaseDate, ValidateException ) {
	"use strict";

	return BaseDate.extend("de.hrk.hochweit.components.Weiterbildungsangebote.validation.type.Date", {
		constructor: function (oFormatOptions, oConstraints) {
			if (!oFormatOptions) {
			    oFormatOptions = {};
			}
			if (!oFormatOptions.source) {
			    oFormatOptions.source = {pattern: 'yyyy-MM-dd'};
			}
			if (!oFormatOptions.pattern) {
			    oFormatOptions.pattern = 'dd.MM.yyyy';
			}

			BaseDate.call(this, oFormatOptions, oConstraints);
		},

        formatValue: function (oValue, sInternalType) {
		    if (this.oFormatOptions.nullAsMinusInfinity && !oValue) {
		        return "-\u221e";
            }
		    if (this.oFormatOptions.nullAsInfinity && !oValue) {
		        return "\u221e";
            }

            return BaseDate.prototype.formatValue.call(this, oValue, sInternalType);
        },

		parseValue: function(oValue, sInternalType) {
            if (oValue === "") {
                return null;
            }
            // Wir übersetzen -inf / inf wieder zurück zu null, damit format/parse invers sind!
            if (this.oFormatOptions.nullAsMinusInfinity && oValue === "-\u221e") {
                return null;
            }
            if (this.oFormatOptions.nullAsInfinity && oValue === "\u221e") {
                return null;
            }

            return BaseDate.prototype.parseValue.call(this, oValue, sInternalType);
        },

      /**
       * Extension of the base types validateValue function. The {constraints} can be provided with an additional 'required' attribute which is checked when validation is performed.
       * The {formatOptions} can be provided with a 'customError' (String) parameter. This *must* be an i18n key. If provided, the custom error message is provided instead of the library default.
       * If the {formatOptions} are provided with a 'customErrorPrefixOnly' (Boolean) parameter, the library default message is prefixed with the 'customError' parameter.
       * @param {*} oValue the value to be passed
       */
        validateValue: function(oValue) {
            try {
                BaseDate.prototype.validateValue.call(this, oValue);
              } catch (exception) {
                if (exception instanceof ValidateException && this.oFormatOptions.customErrorPrefixOnly) {
                  this._throwCustomValidateException(new ValidateException(), this.oFormatOptions);
                } else {
                  throw exception;
                }
              }

            var bRequired = this.oConstraints.required === true;
            var bOnlyPast = this.oConstraints.onlyPast === true;

            // see: https://github.com/SAP/openui5/blob/master/src/sap.ui.core/src/sap/ui/model/type/Date.js
            // convert date into date object to compare
            if (this.oInputFormat && this.oFormatOptions.source.pattern !== "timestamp") {
                oValue = this.oInputFormat.parse(oValue);
            }

            if (bRequired && !oValue) {
                this._throwCustomValidateException(new ValidateException(), this.oFormatOptions);
            }

            if (bOnlyPast && oValue > new Date()) {
                this._throwCustomValidateException(new ValidateException(""), this.oFormatOptions);
            }
        },

        _throwCustomValidateException: function (oException, oFormatOptions) {
            if (oFormatOptions.customError) {
              const sComponentId = oFormatOptions.customErrorComponentId || "Weiterbildungsangebote"; // NOTE: if this type is to be reused in other components, the component id must be passed as an additional parameter
              const oBundle = sap.ui.getCore().getComponent(sComponentId).getModel("i18n").getResourceBundle();
              const sCustomError = oBundle.getText(oFormatOptions.customError);
    
              if (oFormatOptions.customErrorPrefixOnly) {
                const oLibraryBundle = sap.ui.getCore().getLibraryResourceBundle();
                const sMessage = oLibraryBundle.getText(this.sName + ".Invalid");
                oException.message = `${sCustomError} ${sMessage}`;
                throw oException;
              } else {
                oException.message = sCustomError;
                throw oException;
              }
            } else {
              const oBundle = sap.ui.getCore().getLibraryResourceBundle();
              const sMessage = oBundle.getText(this.sName + ".Invalid");
              oException.message = sMessage;
              throw oException;
            }
          }
	});
});