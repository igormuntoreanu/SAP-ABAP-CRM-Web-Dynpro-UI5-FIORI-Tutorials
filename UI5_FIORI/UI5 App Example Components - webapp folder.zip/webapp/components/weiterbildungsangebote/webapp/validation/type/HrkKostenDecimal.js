sap.ui.define([
  "sap/ui/model/odata/type/Decimal",
  "sap/ui/model/ValidateException"
], function ( BaseDecimal, ValidateException ) {
  "use strict";

  const oDefaultFormatOptions = {
    minFractionDigits: 2,
    maxFractionDigits: 2,
    maxIntegerDigits: 5,
    emptyString: null
  };

  const oDefaultConstraints = {
    precision: 7,
    scale: 2
  };

  return BaseDecimal.extend("de.hrk.hochweit.components.Weiterbildungsangebote.validation.type.HrkKostenDecimal", {

    constructor: function (oFormatOptions, oConstraints) {
      BaseDecimal.call(this, this.setDefaultOptions(oFormatOptions), this.setDefaultConstraints(oConstraints));
    },

    formatValue: function (oValue, sInternalType) {
      return BaseDecimal.prototype.formatValue.call(this, oValue, sInternalType);
    },

    parseValue: function (oValue, sInternalType) {
      if (oValue === "" || !oValue) {
        return null;
      }
      oValue = this.adaptParsedValue(oValue);
      return BaseDecimal.prototype.parseValue.call(this, oValue, sInternalType);
    },

    /**
     * Extension of the base types validateValue function. The {constraints} can be provided with an additional 'required' attribute which is checked when validation is performed.
     * The {formatOptions} can be provided with a 'customError' (String) parameter. This *must* be an i18n key. If provided, the custom error message is provided instead of the library default.
     * If the {formatOptions} are provided with a 'customErrorPrefixOnly' (Boolean) parameter, the library default message is prefixed with the 'customError' parameter.
     * @param {*} oValue the value to be passed
     */
    validateValue: function (oValue) {
      try {
        BaseDecimal.prototype.validateValue.call(this, oValue);
      } catch (exception) {
        if (exception instanceof ValidateException && this.oFormatOptions.customErrorPrefixOnly) {
          this._throwCustomValidateException(new ValidateException(), this.oFormatOptions);
        } else {
          throw exception;
        }
      }

      var bRequired = this.oConstraints.required;
      var bValueExists = oValue !== null && oValue !== undefined;

      if (bRequired && !bValueExists) {
        this._throwCustomValidateException(new ValidateException(), this.oFormatOptions);
      }
    },

    _throwCustomValidateException: function (oException, oFormatOptions) {
      if (oFormatOptions.customError) {
        const sComponentId = oFormatOptions.customErrorComponentId || "Weiterbildungsangebote"; // NOTE: if this type is to be reused in other components, the component id must be passed as an additional parameter
        const oBundle = sap.ui.getCore().getComponent(sComponentId).getModel("i18n").getResourceBundle();
        const sCustomError = oBundle.getText(oFormatOptions.customError);

        if (oFormatOptions.customErrorPrefixOnly) {
          const oLibraryBundle = sap.ui.getCore().getLibraryResourceBundle();
          const sMessage = oLibraryBundle.getText(this.sName + ".Invalid");
          oException.message = `${sCustomError} ${sMessage}`;
          throw oException;
        } else {
          oException.message = sCustomError;
          throw oException;
        }
      } else {
        const oBundle = sap.ui.getCore().getLibraryResourceBundle();
        const sMessage = oBundle.getText(this.sName + ".Invalid");
        oException.message = sMessage;
        throw oException;
      }
    },

    setDefaultOptions: function (oFormatOptions) {
      return Object.assign({}, oDefaultFormatOptions, oFormatOptions);
    },

    setDefaultConstraints: function (oConstraints) {
      return Object.assign({}, oDefaultConstraints, oConstraints);
    },

    adaptParsedValue: function (oValue) {
      if (!oValue) {
        return oValue;
      }
      return oValue.replaceAll(".", ",");
    }
  });

});
