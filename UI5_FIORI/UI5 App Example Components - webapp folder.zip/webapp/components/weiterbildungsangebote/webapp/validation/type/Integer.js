sap.ui.define([
    "sap/ui/model/type/Integer",
    "sap/ui/model/ValidateException"
], function ( BaseInteger, ValidateException ) {
    "use strict";

    return BaseInteger.extend("de.hrk.hochweit.components.Weiterbildungsangebote.validation.type.Integer", {
        constructor: function (oFormatOptions, oConstraints) {
            BaseInteger.call(this, oFormatOptions, oConstraints);
        },

        formatValue: function (oValue, sInternalType) {
            if (this.oFormatOptions.nullAsMinusInfinity && !oValue) {
                return "-\u221e";
            }
            if (this.oFormatOptions.nullAsInfinity && !oValue) {
                return "\u221e";
            }

            return BaseInteger.prototype.formatValue.call(this, oValue, sInternalType);
        },

        parseValue: function (oValue, sInternalType) {
            if (oValue === "") {
                return null;
            }

            return BaseInteger.prototype.parseValue.call(this, oValue, sInternalType);
        },

        /**
         * Extension of the base types validateValue function. The {constraints} can be provided with an additional 'required' attribute which is checked when validation is performed.
         * The {formatOptions} can be provided with a 'customError' (String) parameter. This *must* be an i18n key. If provided, the custom error message is provided instead of the library default.
         * If the {formatOptions} are provided with a 'customErrorPrefixOnly' (Boolean) parameter, the library default message is prefixed with the 'customError' parameter.
         * @param {*} oValue the value to be passed
         */
        validateValue: function (oValue) {
            try {
                BaseInteger.prototype.validateValue.call(this, oValue);
              } catch (exception) {
                if (exception instanceof ValidateException && this.oFormatOptions.customErrorPrefixOnly) {
                  this._throwCustomValidateException(new ValidateException(), this.oFormatOptions);
                } else {
                  throw exception;
                }
              }

            var bRequired = this.oConstraints.required === true ? true : false;
            var bValueExists = oValue !== null && oValue !== undefined;

            if (bRequired && !bValueExists) {
                this._throwCustomValidateException(new ValidateException(), this.oFormatOptions);
            }
        },

        _throwCustomValidateException: function (oException, oFormatOptions) {
            if (oFormatOptions.customError) {
              const sComponentId = oFormatOptions.customErrorComponentId || "Weiterbildungsangebote"; // NOTE: if this type is to be reused in other components, the component id must be passed as an additional parameter
              const oBundle = sap.ui.getCore().getComponent(sComponentId).getModel("i18n").getResourceBundle();
              const sCustomError = oBundle.getText(oFormatOptions.customError);
    
              if (oFormatOptions.customErrorPrefixOnly) {
                const oLibraryBundle = sap.ui.getCore().getLibraryResourceBundle();
                const sMessage = oLibraryBundle.getText(this.sName + ".Invalid");
                oException.message = `${sCustomError} ${sMessage}`;
                throw oException;
              } else {
                oException.message = sCustomError;
                throw oException;
              }
            } else {
              const oBundle = sap.ui.getCore().getLibraryResourceBundle();
              const sMessage = oBundle.getText(this.sName + ".Invalid");
              oException.message = sMessage;
              throw oException;
            }
          }
    });

});