sap.ui.define([
    "sap/ui/model/type/String",
    "sap/ui/model/ValidateException"
], function ( BaseString, ValidateException ) {
    "use strict";

    /**
     * sap/ui/model/type/String with following extensions:
     *
     * FormatOptions:
     * - nullString: string - converts null to "nullString" and vice versa
     *
     * Constraints:
     * - required: boolean - requires the value to be truthy
     */
    return BaseString.extend("de.hrk.hochweit.components.Weiterbildungsangebote.validation.type.String", {

        constructor: function (oFormatOptions, oConstraints) {
            BaseString.call(this, oFormatOptions, oConstraints);
        },

        /**
         * Extension of the base types validateValue function. The {constraints} can be provided with an additional 'required' attribute which is checked when validation is performed.
         * The {formatOptions} can be provided with a 'customError' (String) parameter. This *must* be an i18n key. If provided, the custom error message is provided instead of the library default.
         * If the {formatOptions} are provided with a 'customErrorPrefixOnly' (Boolean) parameter, the library default message is prefixed with the 'customError' parameter.
         * @param {*} oValue the value to be passed
         */
        validateValue: function (oValue) {
            try {
                BaseString.prototype.validateValue.call(this, oValue);
              } catch (exception) {
                if (exception instanceof ValidateException && this.oFormatOptions.customErrorPrefixOnly) {
                  this._throwCustomValidateException(new ValidateException(), this.oFormatOptions);
                } else {
                  throw exception;
                }
              }

            const bRequired = this.oConstraints.required === true;
            if (bRequired && !oValue) {
                this._throwCustomValidateException(new ValidateException(), this.oFormatOptions);
            }
        },

        _throwCustomValidateException: function (oException, oFormatOptions) {
            if (oFormatOptions.customError) {
              const sComponentId = oFormatOptions.customErrorComponentId || "Weiterbildungsangebote"; // NOTE: if this type is to be reused in other components, the component id must be passed as an additional parameter
              const oBundle = sap.ui.getCore().getComponent(sComponentId).getModel("i18n").getResourceBundle();
              const sCustomError = oBundle.getText(oFormatOptions.customError);
    
              if (oFormatOptions.customErrorPrefixOnly) {
                const oLibraryBundle = sap.ui.getCore().getLibraryResourceBundle();
                const sMessage = oLibraryBundle.getText(this.sName + ".Invalid");
                oException.message = `${sCustomError} ${sMessage}`;
                throw oException;
              } else {
                oException.message = sCustomError;
                throw oException;
              }
            } else {
              const oBundle = sap.ui.getCore().getLibraryResourceBundle();
              const sMessage = oBundle.getText(this.sName + ".Invalid");
              oException.message = sMessage;
              throw oException;
            }
          },

        formatValue: function (sValue, sInternalType) {
            const nullString = this.oFormatOptions.nullString;
            if (nullString !== undefined && sValue === null) {
                sValue = nullString;
            }
            return BaseString.prototype.formatValue.call(this, sValue, sInternalType);
        },

        parseValue: function (oValue, sInternalType) {
            let sResult = BaseString.prototype.parseValue.call(this, oValue, sInternalType);
            const nullString = this.oFormatOptions.nullString;
            if (nullString !== undefined && sResult === nullString) {
                sResult = null;
            }
            return sResult;
        }
    });
});
