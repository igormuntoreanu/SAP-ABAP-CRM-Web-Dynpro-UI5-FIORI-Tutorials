sap.ui.define([
  "sap/base/Log"
], function (
  Log
) {
  "use strict";

  function buildPathReferencesForBinding(oBinding) {
    let refs = [];
    if (oBinding instanceof sap.ui.model.CompositeBinding) {
      oBinding.getBindings().forEach(oSubBinding => {
        refs = refs.concat(buildPathReferencesForBinding(oSubBinding));
      });
    } else if (oBinding.oModel) {
      // Check for existing model via field to avoid a warning log when calling .getModel(). ("Model doesn't exist..")
      const sModelId = oBinding.getModel().getId();
      const sContextPath = oBinding.getContext() ? (oBinding.getContext().getPath() + "/") : "";
      const sOwnPath = oBinding.getPath();
      const sRef = sModelId + ">" + sContextPath + sOwnPath;
      refs.push(sRef);
    }
    return refs;
  }

  function buildPathReferenceForContext(oContext) {
    return oContext.getModel().getId() + ">" + oContext.getPath();
  }

  function translateBackendToPathRef(sBackendReference, oBackendMappingConfig) {
    if (sBackendReference) {
      // Prefixes absteigend nach Länge sortieren
      const aBackendPrefixes = Object.keys(oBackendMappingConfig)
        .sort((a, b) => -(a.length - b.length));
      for (let sBackendPrefix of aBackendPrefixes) {
        try {
          const sRelativePath = getRelativePathOfBackendReference(sBackendReference, sBackendPrefix);
          if (sRelativePath !== null) {
            const oContext = oBackendMappingConfig[sBackendPrefix];
            return buildPathReference(oContext, sRelativePath);
          }
        } catch (error) {
          Log.error(`Fehler beim Verarbeiten der oBackendMappingConfig[${sBackendPrefix}]:`);
          Log.error(error);
        }
      }
      Log.trace(`Kein Mapping für die Fehler-Referenz ${sBackendReference} gefunden!`);
    }
    return null;
  }

  function getRelativePathOfBackendReference(sBackendReference, sBackendPrefix) {
    const sPrefixSlash = getPathWithAddedSeparator(sBackendPrefix);
    if (sBackendReference.startsWith(sPrefixSlash)) {
      return sBackendReference.substring(sPrefixSlash.length);
    }
    return null;
  }

  function buildPathReference(oContext, sRelativePath) {
    // oContext könnte ein "Context-Supplier" sein
    if (oContext instanceof Function) {
      oContext = oContext();
    }
    const sContextPathRef = buildPathReferenceForContext(oContext);
    if (!sRelativePath) {
      return sContextPathRef;
    }
    return getPathWithAddedSeparator(sContextPathRef) + sRelativePath;
  }

  function getPathWithAddedSeparator(sPath) {
    return sPath.endsWith("/") ? sPath : (sPath + "/");
  }

  return {
    /**
     * Generates a unique path reference using a given property binding. The unique uses the following structure
     *      MODELID>/path/to/property
     * Usually, there is a reference except for composite bindings which are built up of several bindings.
     *
     * @param {sap.ui.model.Binding} oBinding
     * @return {Array<string>} - path references, if the binding has a model
     */
    buildPathReferencesForBinding,

    /**
     * Generate a path reference out of a context. The reference uses the following structure
     *      MODELID>/path/to/property
     *
     * @param {sap.ui.model.Context} oContext
     * @return {string} - the path reference
     */
    buildPathReferenceForContext,

    /**
     * Generate a backend error reference to a path reference
     *
     * The longest prefix according to the given backendReference is chosen using the provided BackendMappingConfig
     * The corresponding context (or the result of the context function) is translated into a path reference. This reference is then
     * concatenated with the rest of the backend reference and returned.
     *
     * Example:
     * - oBackendMappingConfig: {"model>/": oModel1.getContext("/"), "model>/property1": () => oModel2.getContext("/zub")}
     * - sBackendReference: model>/property1/path/x
     * --> "MODEL2ID>/zub/path/x" (MODEL2ID = oModel2.getId())
     *
     * @param {string} sBackendReference
     * @param {object} oBackendMappingConfig - Map: sBackendPrefix -> {sap.ui.model.Context|Function}
     * @return {string|null} - the translated path reference; null, if the map does not contain any matching prefix
     */
    translateBackendToPathRef
  };
});
