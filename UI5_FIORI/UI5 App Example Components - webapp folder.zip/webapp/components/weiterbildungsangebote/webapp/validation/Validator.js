sap.ui.define([
    "sap/ui/core/ValueState",
    "sap/ui/model/ParseException",
    "sap/ui/model/ValidateException",
    "./ModelReferenceUtil",
    "sap/base/Log"
], function (
    ValueState,
	ParseException,
	ValidateException,
	ModelReferenceUtil,
	Log
) {
    "use strict";

    /**
     * Recursively validates the given oMainControl and any aggregations (i.e. child controls) it may have.
     *
     * @param {Element} oMainControl
     *          - The control or element to be validated. It needs a getVisible() function that returns true.
     * @return {boolean} - true, if the oMainControl and its aggregation are valid
     */
    function validate(oMainControl) {
        attachValueStateValidationHandler(oMainControl);
        return _check(oMainControl,
                oCurrControl => _validateControl(oCurrControl));
    }

    /**
     * Recursively traverses the given oMainControl and any aggregations (i.e. child controls) it may have
     * and marks all controls that have an entry in the oErrorMap for their binding.
     *
     * @param {Element} oMainControl
     *          - The control or element to be checked. It needs a getVisible() function that returns true.
     * @param {map} oErrorMap (optional)
     *          - error map with PathReference as key and message-string as value.
     * @return {boolean} - true, if the oMainControl and its aggregation don't have errors
     */
    function markControls(oMainControl, oErrorMap) {
        attachValueStateValidationHandler(oMainControl);
        // sap.ui.getCore().getMessageManager().removeAllMessages();
        return _check(oMainControl,
                oCurrControl => _markControls(oCurrControl, oErrorMap));
    }

    /**
     * Recursively traverses the given oControl and any aggregations (i.e. child controls) it may have.
     *
     * @param {Element} oControl - The control or element to be validated.
     * @param {function} fCheckControl - Function for checking individual controls (oControl=>boolean>).
     */
    function _check(oControl, fCheckControl) {
        var valid = true;

        // only validate controls and elements which have a 'visible' property
        // and are visible controls (invisible controls make no sense checking)
        if (oControl instanceof sap.ui.core.Element
            && oControl.getVisible && oControl.getVisible()) {      // in this UI5 version (1.60.*) Element doesn't have getVisible()!
            // Validate the control itself.
            if (!fCheckControl(oControl)) {
                valid = false;

            } else {
                // follow all aggregations, only if this control is still valid
                for (var sAggregationName in oControl.mAggregations) {
                    var oAggregation = oControl.getAggregation(sAggregationName);
                    valid &= _checkAggregation(oAggregation, fCheckControl);
                }
            }
        }

        return !!valid;
    }

    /**
     * Validation function for a single control.
     * Calls the validate() function on the control if available,
     * then the parseValue() and validateValue() function on the type.
     *
     * @param oControl
     * @return {boolean}
     * @private
     */
    function _validateControl(oControl) {
        if (oControl.validate) {
            try {
                oControl.validate();
            } catch (oException) {
                // catch any parse/validation errors
                if (oException instanceof ValidateException) {
                    oControl.fireValidationError({
                        element: oControl,
                        exception: oException,
                        message: oException.message
                    }, false, true); // bAllowPreventDefault, bEnableEventBubbling
                } else {
                    Log.error(oException);
                }
                return false;
            }
        }

        var editable = _isControlEditable(oControl);

        // check control for any properties worth validating
        for (var sPropertyName in oControl.mProperties) {
            var oControlBinding = oControl.getBinding(sPropertyName);
            if (!oControlBinding) {
                continue;
            }

            var oType;
            var oValue;
            try {
                // check if a data type exists (which may have validation constraints)
                oType = oControlBinding.getType();
                if (editable && oType) {
                    // Read current value directly from control, not from binding.
                    oValue = oControl.getProperty(sPropertyName);
                    // Try validating this value (by parsing and validating on the type).
                    // This may trigger a ParseException or ValidateException.
                    var oInternalValue = oType.parseValue(oValue, oControlBinding.sInternalType);
                    oType.validateValue(oInternalValue);
                }

            } catch (oException) {
                // catch any parse/validation errors

                // Instead of setting value state manually to error which causes inconsistent behavior from standard
                // on-change validation (e.g. error state set by on-demand validation is not reset during on-change validation),
                // we now fire a parse or validation error just like ManagedObject#updateModelProperty does
                // (unfortunately this method is private so we won't call it directly even though it works - like:
                //      oControl.updateModelProperty(oValidateProperty, oValue, oValue);
                // )!

                if (oException instanceof ParseException) {
                    oControl.fireParseError({
                        element: oControl,
                        property: sPropertyName,
                        type: oType,
                        newValue: oValue,
                        oldValue: oValue,
                        exception: oException,
                        message: oException.message
                    }, false, true); // bAllowPreventDefault, bEnableEventBubbling
                } else if (oException instanceof ValidateException) {
                    oControl.fireValidationError({
                        element: oControl,
                        property: sPropertyName,
                        type: oType,
                        newValue: oValue,
                        oldValue: oValue,
                        exception: oException,
                        message: oException.message
                    }, false, true); // bAllowPreventDefault, bEnableEventBubbling
                } else {
                    Log.error(oException);
                }
                return false;
            }
        }

        oControl.fireValidationSuccess({
            element: oControl
        }, false, true); // bAllowPreventDefault, bEnableEventBubbling
        return true;
    }

    /**
     * Marks errors in the oErrorMap for a single control.
     *
     * @param oControl
     * @param oErrorMap
     * @return {boolean}
     * @private
     */
    function _markControls(oControl, oErrorMap) {
        // check control for any properties worth validating
        for (var sPropertyName in oControl.mProperties) {
            var oControlBinding = oControl.getBinding(sPropertyName);
            if (!oControlBinding) {
                continue;
            }

            // Check if there are any errors for this binding in oErrorMap.
            var aModelReferences = ModelReferenceUtil.buildPathReferencesForBinding(oControlBinding);
            for (var sModelReference of aModelReferences) {
                var sErrorText = oErrorMap[sModelReference];
                if (sErrorText) {
                    oControl.fireValidationError({
                        element: oControl,
                        message: sErrorText
                    }, false, true); // bAllowPreventDefault, bEnableEventBubbling
                    return false;
                }
            }
        }

        oControl.fireValidationSuccess({
            element: oControl
        }, false, true); // bAllowPreventDefault, bEnableEventBubbling
        return true;
    }

    function _isControlEditable(oControl) {
        try {
            return oControl.getProperty("editable");
        } catch (ex) { /* ignore */
            return true;
        }
    }

    function _checkAggregation(oAggregation, fCheckControl) {
        var valid = true;
        if (oAggregation instanceof Array) {
            // generally, aggregations are of type Array
            oAggregation.forEach(function (oControl) {
                valid &= _check(oControl, fCheckControl);
            });
        } else if (oAggregation) {
            // ...however, with sap.ui.layout.form.Form, it is a single object *sigh*
            // Operator &= is important because we want to continue validation even if invalid (so we don't use &&)!
            valid &= _check(oAggregation, fCheckControl);
        }
        return valid;
    }

    function attachValueStateValidationHandler(oControl) {
        if (oControl._validationHandlerAttached) {
            return;
        }

        function setValueState(oSource, sValueState, sValueStateText) {
            if (oSource.setValueState) {
                oSource.setValueState(sValueState);
            }
            if (oSource.setValueStateText) {
                oSource.setValueStateText(sValueStateText);
            }
        }

        oControl.attachParseError(function (oEvent) {
            setValueState(oEvent.getSource(), ValueState.Error, oEvent.getParameter("message"));
        });
        oControl.attachValidationError(function (oEvent) {
            setValueState(oEvent.getSource(), ValueState.Error, oEvent.getParameter("message"));
        });
        oControl.attachValidationSuccess(function (oEvent) {
            setValueState(oEvent.getSource(), ValueState.None, null);
        });
        oControl._validationHandlerAttached = true;
    }

    return {
        /**
         * Recursively validates the given oMainControl and any aggregations (i.e. child controls) it may have.
         *
         * @param {Element} oMainControl
         *          - The control or element to be validated. It needs a getVisible() function that returns true.
         * @return {boolean} - true, if the oMainControl and its aggregation are valid
         */
        validate: validate,

        /**
         * Recursively traverses the given oMainControl and any aggregations (i.e. child controls) it may have
         * and marks all controls that have an entry in the oErrorMap for their binding.
         *
         * @param {Element} oMainControl
         *          - The control or element to be checked. It needs a getVisible() function that returns true.
         * @param {map} oErrorMap (optional)
         *          - error map with PathReference as key and message-string as value.
         * @return {boolean} - true, if the oMainControl and its aggregation don't have errors
         */
        markControls: markControls,

        /**
         * Attaches default validation handlers to the control (i.e. attachParseError, attachValidationError, attachValidationSuccess).
         * If the *source* control of the event has a setValueState() and setValueStateText() function, these will be called.
         * This function makes sure to only attach validation handlers once by setting a flag _validationHandlerAttached on the control.
         * As validation events are propagated up the "UI5 DOM", normally it's enough to call this function only on one parent control.
         * validate() and markControls() implicitly call attachValueStateValidationHandler().
         *
         * @param oControl
         */
        attachValueStateValidationHandler: attachValueStateValidationHandler
    };
});
