sap.ui.define([
  "sap/ui/core/mvc/Controller",
  "sap/ui/core/routing/History",
  "sap/ui/core/UIComponent",
  "de/hrk/hochweit/components/Weiterbildungsangebote/model/formatter",
  "de/hrk/hochweit/components/Weiterbildungsangebote/controller/Events",
  "sap/m/PlacementType",
  "sap/m/MessageBox",
  "de/hrk/hochweit/components/Weiterbildungsangebote/validation/Validator",
  "hrk/webcomponents/lib/bundle" // Notwendiger Import für die Verwendung von Webcomponent aus der libary hrk.webcomponents
], function(Controller,
	History,
	UIComponent,
	formatter,
	Events,
	PlacementType,
  MessageBox,
  Validator
) {
  "use strict";

  return Controller.extend("de.hrk.hochweit.components.Weiterbildungsangebote.controller.BaseController", {


    /* =========================================================== */
    /* constants and enums                                         */
    /* =========================================================== */

    promptType: {
      CONFIRM: "Confirm",
      CANCEL: "Cancel"
    },

    formularReset: {
      ALL: "All"
    },

    /**
     * Make the formatter available to all derived controllers
     */
    formatter: formatter,

    /**
     * Make the event registry available to all derived controllers
     */
    eventRegistry: Events,

    /**
     * Convenience method for getting the view model by name in every controller of the application.
     * @public
     * @param {string} sName the model name
     * @returns {sap.ui.model.Model} the model instance
     */
    getModel: function(sName) {
      return this.getView().getModel(sName);
    },

    /**
     * Convenience method for setting the view model in every controller of the application.
     * @public
     * @param {sap.ui.model.Model} oModel the model instance
     * @param {string} sName the model name
     * @returns {sap.ui.mvc.View} the view instance
     */
    setModel: function(oModel, sName) {
      return this.getView().setModel(oModel, sName);
    },

    /**
     * Convenience method for getting the resource bundle.
     * @public
     * @returns {sap.ui.model.resource.ResourceModel} the resourceModel of the component
     */
    getBundle: function() {
      return this.getOwnerComponent().getModel("i18n").getResourceBundle();
    },

    /**
     * Method for navigation to specific view
     * @public
     * @param {string} psTarget Parameter containing the string for the target navigation
     * @param {mapping} pmParameters? Parameters for navigation
     * @param {boolean} pbReplace? Defines if the hash should be replaced (no browser history entry) or set (browser history entry)
     */
    navTo: function(psTarget, pmParameters, pbReplace) {
      this.getRouter().navTo(psTarget, pmParameters, pbReplace);
    },

    /**
     * Shortcut getter for the component event bus
     * @public
     * @returns {sap.ui.core.EventBus} the component's event bus
     */
    getEventBus: function () {
      return this.getOwnerComponent().getEventBus();
    },

    onNavigate: function (oEvent, sTarget) {
       const oNav = { target: sTarget, parameters: {}, replace: true };
       sap.ui.getCore().getEventBus().publish("rootComponent", "navTo", oNav);
    },

    /**
     * Shortcut getter for the component router
     * @public
     * @returns {sap.f.routing.Router} the component's router
     */
    getRouter: function() {
      return UIComponent.getRouterFor(this);
    },

    /**
     * Standard navBack function to navigate to the appliations previous history or the main page if no history is available
     * @public
     */
    onNavBack: function() {
      var sPreviousHash = History.getInstance().getPreviousHash();

      if (sPreviousHash !== undefined) {
        window.history.back();
      } else {
        this.getRouter().navTo("dashboard", {}, true /*no history*/ );
      }
    },

    /**
     * For navigating from subcomponent to dashboard e.g. via breadcrumb with confirmation popup
     * @public
     */
    onNavToDashboard: function(oEvent) {
      // TODO: only prompt when changes were made
      let fnConfirm = function () {
        this.onNavigate(oEvent, "dashboard");
        }.bind(this);
      this._promptAndExecute(
        oEvent.getSource(),
        "top",
        this.promptType.CANCEL,
        this.getResourceBundle().getText("angeboteDetailEdit.edit.cancel.prompt.text"),
        this.getResourceBundle().getText("angeboteDetailEdit.edit.cancel.action.confirm"),
        fnConfirm.bind(this)
        );
      },

      onNavToAngeboteList: function(oEvent) {
        this.onCancel(oEvent);
      },

      onCancel: function (oEvent) {
        // TODO: only prompt when changes were made
        let fnOnCancelConfirmed = function () {
          this.navTo("list");
          this.getOwnerComponent().liftPendingChanges();
        }.bind(this);
        this._promptAndExecute(
          oEvent.getSource(),
          "top",
          this.promptType.CANCEL,
          this.getResourceBundle().getText("angeboteDetailEdit.edit.cancel.prompt.text"),
          this.getResourceBundle().getText("angeboteDetailEdit.edit.cancel.action.confirm"),
          fnOnCancelConfirmed.bind(this)
        );
      },

    /**
      * Convenience method for getting the resource bundle.
      * @public
      * @returns {sap.ui.model.resource.ResourceModel} the resourceModel of the component
      */
    getResourceBundle: function () {
      return this.getOwnerComponent().getModel("i18n").getResourceBundle();
    },

    /**
     * Callback for optional translation of the bindingPath provided by the backend to the corresponding frontend binding path
     * @param sServerPath
     * @return {*}
     */
    translateValidationPath: function (sServerPath) {
      if (!sServerPath) {
        return sServerPath;
      }
      return sServerPath.replaceAll("[", "/").replaceAll("]", "/").replaceAll("//", "/");
    },

    /**
     * Callback for optional provision of a specific model name for the binding paths provided by the backend
     * @return {*}
     */
    getModelId: function () {
      return this.getModel().getId();
    },

    /**
     * Method to reset the message manager and the value state of the
     */
    resetErrorMessages: function () {
      sap.ui.getCore().getMessageManager().removeAllMessages();
      Validator.markControls(this.getView(), {});
    },

    /**
     * Method to handle errors on save
     * @param error the error object which occurred during save
     */
    onSaveFailed: function (error) {
      if (error.validationErrors) {
        let oErrorMap = {};
        error.validationErrors.forEach(oValidationError => {
          const sPath = this.getModelId() + this.translateValidationPath(oValidationError.bindingPath);
          oErrorMap[sPath] = this.getBundle().getText(oValidationError.code);
        });
        this.getEventBus().publish(this.eventRegistry.eingabeformulare.channel, this.eventRegistry.eingabeformulare.events.handleServerValidation, oErrorMap);
      }
      MessageBox.error(this.getBundle().getText("messageBox.onSave.weiterbildungsangebot"));
    },

    translate: function (sKey, ...parameter) {
      return this.getBundle().getText(sKey, ...parameter);
    },

    /**
     * Shorthand method for displaying a Popover with a configurable text and a Accept/Reject button.
     * The passed function is executed when the button is pressed.
     * @private
     * @param {Object} oObjectToOpenBy The control by which the popover is to open
     * @param {string} sPosition The relative position in which the popover should open @see sap.m.PlacementType
     * @param {string} sPromptType The type of prompt to be displayed. Choose between "Confirm" and "Cancel"
     * @param {string} sTitle The popover title
     * @param {string} sButtonText The button text
     * @param {function} fnToExecute The function to be executed when the prompt is confirmed
     */
    _promptAndExecute: function (oObjectToOpenBy, sPosition, sPromptType, sTitle, sButtonText, fnToExecute) {
      let sPlacement = sPosition === PlacementType[sPosition] ?  sPosition : PlacementType.PreferredTopOrFlip;
      switch (sPosition) {
        case "bottom": sPlacement = PlacementType.PreferredBottomOrFlip; break;
        default: break;
      }
      let sButtonType = sPromptType === this.promptType.CONFIRM ? "Accept" : "Reject";

      sap.ui.require(["sap/m/Popover", "sap/m/Button"], function (Popover, Button) {
        var oPopover = new Popover({
          placement: sPlacement,
          title: sTitle,
          content: [
            new Button({
              text: sButtonText,
              type: sButtonType,
              width: "100%",
              press: function () {
                fnToExecute.apply(this);
                oPopover.close();
              }
            })
          ]
        });
        oPopover.attachAfterClose(function () {
          oPopover.destroy();
        }, this);
        oPopover.openBy(oObjectToOpenBy);
      }.bind(this));
    }
  });

});
