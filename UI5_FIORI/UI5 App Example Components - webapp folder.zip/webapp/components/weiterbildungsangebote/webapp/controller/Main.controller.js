sap.ui.define([
  "de/hrk/hochweit/components/Weiterbildungsangebote/controller/BaseController",
  "sap/ui/model/json/JSONModel"
], function (BaseController, JSONModel) {
  "use strict";

  return BaseController.extend("de.hrk.hochweit.components.Weiterbildungsangebote.controller.Main", {

    onInit: function () {
      // Set language/locale to german
      sap.ui.getCore().getConfiguration().applySettings({
        language: "de"
      });

      var oViewModel;

      oViewModel = new JSONModel({
        busy: false,
        delay: 0,
        layout: "OneColumn",
        previousLayout: "",
        actionButtonsInfo: {
          midColumn: {
            fullScreen: false
          }
        }
      });
      this.setModel(oViewModel, "appView");

      // apply content density mode to root view
      this.getView().addStyleClass(this.getOwnerComponent().getContentDensityClass());
    }

  });
}
);
