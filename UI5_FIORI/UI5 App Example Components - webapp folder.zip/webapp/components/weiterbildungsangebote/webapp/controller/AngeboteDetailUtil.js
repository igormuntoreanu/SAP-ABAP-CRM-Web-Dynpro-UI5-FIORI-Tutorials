sap.ui.define([
    "sap/ui/base/Object",
    "sap/base/Log"
], function(
    BaseObject,
	Log
) {
	"use strict";

	return BaseObject.extend("de.hrk.hochweit.components.Weiterbildungsangebote.controller.AngeboteDetailUtil", {

        constructor: function (oController) {
            this._oController = oController;
        },

        requestFormValidations: function () {
			return new Promise (resolve => {
				const mReportedValidations = {
					eingabeformular1: { reported: false, result: undefined },
					eingabeformular2: { reported: false, result: undefined },
					eingabeformular3: { reported: false, result: undefined },
					eingabeformular7: { reported: false, result: undefined },
					eingabeformular11: { reported: false, result: undefined }
				};

				const fnUpdateResult = (channelId, eventId, payload) => {
					Log.debug(`Validation: ${payload.reporter} reported in via ${eventId} (channel ${channelId})`);
					mReportedValidations[payload.reporter].reported = true;
					mReportedValidations[payload.reporter].result = payload.result;

					// continue waiting for reponses when not all forms have reported back
					if (Object.values(mReportedValidations).find(form => { return form.reported === false; })) {
						return;
					}

					//unsubscribe before resolving the final validation result
					this._oController.getEventBus().unsubscribe(
						this._oController.eventRegistry.eingabeformulare.channel,
						this._oController.eventRegistry.eingabeformulare.events.reportValidationResult,
						fnUpdateResult,
						this._oController
					);
					resolve(Object.values(mReportedValidations).every(form => { return form.result === true; }));
				};

				this._oController.getEventBus().subscribe(
					this._oController.eventRegistry.eingabeformulare.channel,
					this._oController.eventRegistry.eingabeformulare.events.reportValidationResult,
					fnUpdateResult,
					this._oController
				);
				this._oController.getEventBus().publish(this._oController.eventRegistry.eingabeformulare.channel, this._oController.eventRegistry.eingabeformulare.events.triggerValidation);
			});
		},

	});
});
