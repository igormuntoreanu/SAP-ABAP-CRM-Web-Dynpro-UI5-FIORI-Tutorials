sap.ui.define([
    "de/hrk/hochweit/components/Weiterbildungsangebote/controller/BaseController",
    "sap/ui/model/json/JSONModel",
    "de/hrk/hochweit/components/Weiterbildungsangebote/service/KatalogService",
    "de/hrk/hochweit/components/Weiterbildungsangebote/service/AngeboteService",
    "de/hrk/hochweit/components/Weiterbildungsangebote/service/HochschulService",
    "sap/m/MessageToast",
    "sap/m/MessageBox",
    "sap/ui/core/Fragment",
    "de/hrk/hochweit/components/Weiterbildungsangebote/model/businessLogic/UserLogic",
    "sap/base/Log",
    "sap/m/PlacementType",
	"de/hrk/hochweit/components/Weiterbildungsangebote/controller/AngeboteDetailUtil"
  ], function (
  BaseController, JSONModel, KatalogService, AngeboteService, HochschulService, MessageToast, MessageBox, Fragment, UserLogic, Log, PlacementType, AngeboteDetailUtil
  ) {
    "use strict";

	return BaseController.extend("de.hrk.hochweit.components.Weiterbildungsangebote.controller.AngeboteDetailNew", {


		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		onInit: function () {
			// Model used to manipulate control states. The chosen values make sure,
			// detail page is busy indication immediately so there is no break in
			// between the busy indication for loading the view's meta data
			var oViewModel = new JSONModel({
				busy: false,
				delay: 0,
				refreshButtonIcon: "sap-icon://refresh",
				refreshButtonType: "Transparent"
			});

			this.setModel(new JSONModel(), "katalog");
			this.setModel(oViewModel, "local");
			this.setModel(new JSONModel(), "viewState");
			this.setModel(sap.ui.getCore().getMessageManager().getMessageModel(), "message");

      this._apolloService = this.getOwnerComponent().getApolloService();
			this.getView().setModel(new JSONModel());

			this._angeboteDetailUtil = new AngeboteDetailUtil(this);

			this.getRouter().getRoute("newAngebot").attachPatternMatched(this._onNewWeiterbildungsangebot, this);

			this.getEventBus().subscribe(this.eventRegistry.eingabeformulare.channel, this.eventRegistry.eingabeformulare.events.angebotsbezeichnungUpdated, this._onAngebotsbezeichnungUpdated, this);

			this.getView().addEventDelegate({onBeforeShow: () => { this.getModel("viewState").setProperty("/isShown", true); }});
			this.getView().addEventDelegate({onBeforeHide: () => { this.getModel("viewState").setProperty("/isShown", false); }});
		},

		/* =========================================================== */
		/* event handlers                                              */
		/* =========================================================== */

    onSave: function () {
		this.resetErrorMessages();
		this._angeboteDetailUtil.requestFormValidations().then(bSuccess => {
			if (bSuccess) {
				AngeboteService.createNewWeiterbildungsangebot(this._apolloService, this.getView().getModel().getData())
				.then(function (data) {
					this.showCreated(data.bezeichnung, {closeOnBrowserNavigation: false});
					this.navTo("editAngebot", {
						weiterbildungsangebotId: data.id
					});
					this.getOwnerComponent().liftPendingChanges();
				}.bind(this))
				.catch(this.onSaveFailed.bind(this));
			}
		});
    },

	onResetFormular: function (oEvent, sFormular) {
		const oPayload = { formularReset: sFormular || this.formularReset.ALL };

		let fnConfirmReset = () => {
			oPayload.originalData = AngeboteService.getEmptyWA(this._hochschulId);
			this.getOwnerComponent().getEventBus().publish(
				this.eventRegistry.eingabeformulare.channel,
				this.eventRegistry.eingabeformulare.events.resetFormular,
				oPayload
			);
		};

		this._promptAndExecute(
		  oEvent.getSource(),
		  PlacementType.HorizontalPreferredLeft,
		  this.promptType.CANCEL,
		  this.getResourceBundle().getText("angeboteDetailEdit.action.reset.prompt.text", [
			oPayload.formularReset === this.formularReset.ALL ?
			  this.getResourceBundle().getText("angeboteDetailEdit.action.reset.prompt.allForms") :
			  this.getResourceBundle().getText("angeboteDetailEdit.action.reset.prompt.singleForm")
		  ]),
		  this.getResourceBundle().getText("angeboteDetailEdit.action.reset.prompt.confirm"),
		  fnConfirmReset);
	  },

	/* =========================================================== */
	/* begin: internal methods                                     */
	/* =========================================================== */

	/**
	 * Binds the view to the object path and expands the aggregated line items.
	 * @function
	 * @param {sap.ui.base.Event} oEvent pattern match event in route 'object'
	 * @private
	 */
	_onNewWeiterbildungsangebot: function () {
		// Clear any old messages
		sap.ui.getCore().getMessageManager().removeAllMessages();

		//Set Focus to Header
		this.oObjectPageLayout = this.getView().byId("newAngebotPage");
		this.oTargetSection = this.getView().byId("AllgemeineInformationen");
		this.oObjectPageLayout.setSelectedSection(this.oTargetSection);

		//reset default model data without hochschulId at first
		this.getModel().setData(AngeboteService.getEmptyWA());

		this.getModel("appView").setProperty("/layout", "MidColumnFullScreen");
		this.getModel("local").setProperty("/refreshButtonIcon", "sap-icon://refresh");
		this.getModel("local").setProperty("/refreshButtonType", "Transparent");
		this._userLogic = new UserLogic(this.getModel("login").getProperty("/"));

		this._getHochschulIdForNewWeiterbildungsangebot().then(hochschulId => {
			if (typeof hochschulId === "string") {
				hochschulId = parseInt(hochschulId, 10);
			}
			this._hochschulId = hochschulId;
			this._fireHochschulkontextSelected(hochschulId);
			const oWeiterbildungsangebot = AngeboteService.getEmptyWA(hochschulId);
			this.getModel().setData(oWeiterbildungsangebot);
			this.getOwnerComponent().declarePendingChanges(); // TODO: only call when there are actual unsaved changes
			this.getOwnerComponent().getEventBus().publish(this.eventRegistry.eingabeformulare.channel, this.eventRegistry.eingabeformulare.events.weiterbildungsangebotLoaded);
		}).catch(err => {
			Log.error(err);
			this.getOwnerComponent().liftPendingChanges();
			this.navTo("list");
		});

		KatalogService.getRedaktionsstatuses(this._apolloService).then((data)=> {
			this.getModel("katalog").setProperty("/redaktionsstatuses", data);
		});
	},

    _fireHochschulkontextSelected: function (hochschulId) {
      this.getOwnerComponent().getEventBus().publish(
        this.eventRegistry.eingabeformulare.channel,
        this.eventRegistry.eingabeformulare.events.newWeiterbildungsangebotInHochschulkontext,
        { hochschulId }
      );
    },

    _getHochschulIdForNewWeiterbildungsangebot: function () {
		  return new Promise(resolve => {
		    if (this._userLogic.isAdmin()) {
		      return this._openHochschulkontextSelectDialog().then(resolve);
        }

        const hochschulIdOfUser = this._getOwnHochschulId();
        if (hochschulIdOfUser) {
          return resolve(hochschulIdOfUser);
        }

		throw new Error("Invalid hochschulId. Creation form for Weiterbildungsangebot was not opened because neither did the attempting user successfully select a hochschulKontext nor did they have an own hochschulId");
      });
    },

    _openHochschulkontextSelectDialog: function () {
		  return new Promise((resolve, reject) => {
        const sDialogId = "hochschulkontextSelectDialog";
        const sModelnameForDialog = "hsKontext";
        HochschulService.getHochschulen(this._apolloService).then(data => this.setModel(new JSONModel({
          hochschulen: data,
          selectedKontext: null
        }), sModelnameForDialog)).then(() => {
          // create custom "controller" with functions
          return {
            onCloseDialog: () => {
              this.byId(sDialogId).close();
              this.navTo("list");
              reject();
              this.byId(sDialogId).destroy(true);
            },
            onConfirmSelection: () => {
              this.byId(sDialogId).close();
              // pass selection in dialog to router target
              resolve(this.getModel(sModelnameForDialog).getProperty("/selectedKontext"));
              this.byId(sDialogId).destroy(true);
            }
          };
        }).then(oController => Fragment.load({ // load dialog fragment
          id: this.getView().getId(),
          name: "de.hrk.hochweit.components.Weiterbildungsangebote.view.fragments.HochschulkontextSelectDialog",
          controller: oController,
          type: "XML"
        })).then(oDialog => {
          this.getView().addDependent(oDialog);
          oDialog.addStyleClass(this.getOwnerComponent().getContentDensityClass());
          oDialog.open();
        });
      });
    },

    _getOwnHochschulId: function () {
      const user = this.getModel("login");
      return user && user.getProperty("/user/hochschulId") || null;
    },

    /**
		 * Binds the view to the object path. Makes sure that detail view displays
		 * a busy indicator while data for the corresponding element binding is loaded.
		 * @function
		 * @param {string} sObjectPath path to the object to be bound to the view.
		 * @private
		 */
		_bindView: function (sObjectPath) {
			var self = this;
			// Set busy indicator during view binding
			var oViewModel = this.getModel("local");

			// If the view was not bound yet its not busy, only if the binding requests data it is set to busy again
			oViewModel.setProperty("/busy", false);

			this.getView().bindElement({
				path: sObjectPath,
				events: {
					change: this._onBindingChange.bind(this),
					dataRequested: function () {
						oViewModel.setProperty("/busy", true);
					},
					dataReceived: function (oEvent) {
						oViewModel.setProperty("/busy", false);
						self._refreshActionStates(oEvent.getSource().getBoundContext());
					}
				}
			});

		},

		_onBindingChange: function () {
			var oView = this.getView(),
				oElementBinding = oView.getElementBinding();
			// No data for the binding
			if (!oElementBinding.getBoundContext()) {
				this.getRouter().getTargets().display("detailObjectNotFound");
				// if object could not be found, the selection in the master list
				// does not make sense anymore.
				this.getOwnerComponent().oListSelector.clearMasterListSelection();
				return;
			}

			var sPath = oElementBinding.getPath();

			this.getOwnerComponent().oListSelector.selectAListItem(sPath);

		},

		/**
		 * Handler for adjusting the angebotsbezeichnung if it was updated for the currently edited (new) WA
		 */
		_onAngebotsbezeichnungUpdated: function (eventId, channelId, oData) {
			if (!oData || !oData.angebotsbezeichnung) { return; }
			Log.debug(`Event ${eventId} (channel ${channelId}) was caught by ${this.getView().getId()}`);
			this.getModel().setProperty("/bezeichnung", oData.angebotsbezeichnung);
		},

		showCreated: function (oCreatedWeiterbildungsangebot, oDisplayOptions) {
			MessageToast.show(this.getBundle().getText("angbeoteDetailNew.message.AngebotCreated", [oCreatedWeiterbildungsangebot.bezeichnung.de]), oDisplayOptions);
		}
	});
}
);
