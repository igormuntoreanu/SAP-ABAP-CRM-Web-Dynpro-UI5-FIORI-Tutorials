sap.ui.define([], function () {
    "use strict";
    return {
        // <fachlicher name>: {
        //     channel: "app.<name>",
        //     events: {
        //         <eventname>: "app.<name>.<eventname>",
        //         ...
        //     }
        // }
        eingabeformulare: {
            channel: "weiterbildungsangebote.eingabeformulare",
            events: {
                triggerValidation: "weiterbildungsangebote.eingabeformulare.triggerValidation",
                resetFormular: "weiterbildungsangebote.eingabeformulare.resetFormular",
                weiterbildungsangebotLoaded: "weiterbildungsangebote.eingabeformulare.weiterbildungsangebotLoaded",
                weiterbildungsangebotSaved: "weiterbildungsangebote.eingabeformulare.weiterbildungsangebotSaved",
                newWeiterbildungsangebotInHochschulkontext: "weiterbildungsangebote.eingabeformulare.newWeiterbildungsangebotInHochschulkontext",
                angebotsbezeichnungUpdated: "weiterbildungsangebote.eingabeformulare.angebotsbezeichnungUpdated",
                handleServerValidation: "weiterbildungsangebote.eingabeformulare.handleServerValidation",
                reportValidationResult: "weiterbildungsangebote.eingabeformulare.reportValidationResult"
            }
        }
    };
});
