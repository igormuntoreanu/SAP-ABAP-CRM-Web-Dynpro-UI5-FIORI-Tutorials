sap.ui.define([
	"de/hrk/hochweit/components/Weiterbildungsangebote/controller/BaseController",
	"de/hrk/hochweit/components/Weiterbildungsangebote/model/formatter",
	"sap/ui/model/json/JSONModel",
	"sap/ui/Device",
	"de/hrk/hochweit/components/Weiterbildungsangebote/service/AngeboteService",
	"sap/ui/core/SortOrder",
	"sap/m/PlacementType",
	"de/hrk/hochweit/components/Weiterbildungsangebote/model/businessLogic/UserLogic",
	"sap/base/Log"
  ], function(
	BaseController,
	formatter,
	JSONModel,
	Device,
	AngeboteService,
	SortOrder,
	PlacementType,
  	UserLogic,
	Log
) {
	"use strict";

	return BaseController.extend("de.hrk.hochweit.components.Weiterbildungsangebote.controller.AngeboteList", {


		formatter: formatter,
		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		/**
		 * Called when the master list controller is instantiated. It sets up the event handling for
		 * the master/detail communication and other lifecycle tasks.
		 * @public
		 */
		onInit: function () {
			// Control state model
			var oList = this.byId("masterTable"),
				oViewModel = this._createViewModel(),
				// Put down master list's original value for busy indicator delay,
				// so it can be restored later on. Busy handling on the master list is
				// taken care of by the master list itself.
				iOriginalBusyDelay = oList.getBusyIndicatorDelay();

			this._oList = oList;
			// keeps the filter and search state
			this._oListFilterState = {
				aFilter: [],
				aSearch: []
			};

			this.setModel(oViewModel, "masterView");
			// Make sure, busy indication is showing immediately so there is no
			// break after the busy indication for loading the view's meta data is
			// ended (see promise 'oWhenMetadataIsLoaded' in AppController)
			oList.attachEventOnce("updateFinished", function () {
				// Restore original busy indicator delay for the list
				oViewModel.setProperty("/delay", iOriginalBusyDelay);
			});

			// If window/screen height is too big, adapt growingThreshold to reenable growingScrollToLoad
			if (window.innerHeight > 700 && window.innerHeight <= 1400) {
				//GrowingThreshold of table gets doubled (9 => 18)
				this._oList.setProperty("growingThreshold", this._oList.getProperty("growingThreshold") * 2 );
			}
			else if (window.innerHeight > 1400) {
				//GrowingThreshold of table gets tripled (9 => 27)
				this._oList.setProperty("growingThreshold", this._oList.getProperty("growingThreshold") * 3 );
			}

			// Defines number of entries that is fetched when the table grows
			oViewModel.setProperty("/growingThreshold", this._oList.getProperty("growingThreshold") + 1);

			oViewModel.setProperty("/lastHeaderSortKey", undefined);
			oViewModel.setProperty("/lastHeaderDescending", true);

			// this needs to happen every time, if it does not happen timely then the bound master list is not set.
			this.getView().addEventDelegate({
				onBeforeFirstShow: function () {
					this.getOwnerComponent().oListSelector.setBoundMasterList(oList);
				}.bind(this)
			});

			this._apolloService = this.getOwnerComponent().getApolloService();
			this.listmodel = new JSONModel();
			this.getView().setModel(this.listmodel);

			// Get role of logged in user
			const oLogin = this.getOwnerComponent().getModel("login").getProperty("/");
			this._userLogic = new UserLogic(oLogin);

			//TODO: Handle the case of missing userrole (failed login)
			if (oLogin && oLogin.role) {
				this._setListVisibility(oLogin.role, oLogin.permissions);
			}
			//Set to lowest role if role could not be fetched
			else {
				this._setListVisibility("hsb", []);
			}

			this.getRouter().getRoute("list").attachPatternMatched(this._onMasterMatched, this);
			this.getRouter().getRoute("editAngebot").attachPatternMatched(this._onCollapsedMatched, this);
			this.getRouter().attachBypassed(this.onBypassed, this);

			this.getEventBus().subscribe(this.eventRegistry.eingabeformulare.channel, this.eventRegistry.eingabeformulare.events.angebotsbezeichnungUpdated, this._onAngebotsbezeichnungUpdated, this);
			this.getEventBus().subscribe(this.eventRegistry.eingabeformulare.channel, this.eventRegistry.eingabeformulare.events.weiterbildungsangebotSaved, this._onWASaved, this);
		},

		/* =========================================================== */
		/* event handlers                                              */
		/* =========================================================== */

		onUpdateStarted: function(oEvent){
			const sUserrole = this.getModel("masterView").getProperty("/visibility/userrole");

			// Check if the table is growing
			if (oEvent.getParameter("reason") === ("Growing")){
				AngeboteService.getAllWA(this._apolloService,
										  {"skip": this._paginatingCursor, "take": this.getModel("masterView").getProperty("/growingThreshold")},
										  this.listmodel.getProperty("/searchterm"),
										  this.listmodel.getProperty("/sorting"),
										  sUserrole)
				.then(function(data){
					// Add new response to already loaded data
					this.listmodel.setProperty("/weiterbildungsangebote",
					this.listmodel.getProperty("/weiterbildungsangebote").concat(data));
				}.bind(this));

				// Update Cursor
				this._paginatingCursor += this.getModel("masterView").getProperty("/growingThreshold");
			}
		},

		/**
		 * After list data is available, this handler method updates the
		 * master list counter
		 * @param {sap.ui.base.Event} oEvent the update finished event
		 * @public
		 */
		onUpdateFinished: function (oEvent) {
			// update the master list object counter after new data is loaded - was total, is now actual
			this._updateListItemCount(oEvent.getParameter("actual"));
		},

		/**
		 * Event handler for the print page button
		 * @public
		 */
		onPrint: function(){
			window.print();
		},

		/**
		 * Event handler for the export list button
		 * @public
		 */
		 onExport: function(exportType){
			var oFilter = this.listmodel.getProperty("/currentfilter");

			switch (exportType) {
				case "csv":
					AngeboteService.exportList(this._apolloService, oFilter, "csv")
					.then(function(data){
						this.onExportFinished(data);
					}.bind(this));
				  	break;
				case "json":
					AngeboteService.exportList(this._apolloService, oFilter, "json")
					.then(function(data){
						this.onExportFinished(data);
					}.bind(this));
				  	break;
				case "xls":
					AngeboteService.exportList(this._apolloService, oFilter, "xls")
					.then(function(data){
						this.onExportFinished(data);
					}.bind(this));
					break;
				case "xml":
					AngeboteService.exportList(this._apolloService, oFilter, "xml")
					.then(function(data){
						this.onExportFinished(data);
					}.bind(this));
				  	break;
				default:
					break;
			  }
		},

		/**
		 * Event handler for the receiving of an exportfile
		 * @param oData the returned exportfile
		 */
		onExportFinished: function(oData){
			var link = document.createElement("a");
			link.setAttribute("href", encodeURI(oData.content));
			link.setAttribute("download", oData.name);
			document.body.appendChild(link);
			link.click();
		},

		/**
		 * Event handler for the master search field. Applies current
		 * filter value and triggers a new search. If the search field's
		 * 'refresh' button has been pressed, no new search is triggered
		 * and the list binding is refresh instead.
		 * @param {sap.ui.base.Event} oEvent the search event
		 * @public
		 */
		onSearch: function (oEvent) {
			var sQuery = oEvent.getParameter("query");
			this.listmodel.setProperty("/searchterm", sQuery);

			//fetch data with the search input as filter
			this._getWeiterbildungsangebote({"skip": 0, "take": this.getModel("masterView").getProperty("/growingThreshold")},
											 sQuery);

			this._paginatingCursor = this.getModel("masterView").getProperty("/growingThreshold");
		},

		/**
		 * Event handler for the list selection event
		 * @param {sap.ui.base.Event} oEvent the list selectionChange event
		 * @public
		 */
		onSelectItem: function (oEvent) {
			var oList = oEvent.getSource(),
			bSelected = oEvent.getParameter("selected");

			// skip navigation when deselecting an item in multi selection mode
			if (!(oList.getMode() === "MultiSelect" && !bSelected)) {
				// get the list item, either from the listItem parameter or from the event's source itself (will depend on the device-dependent mode).
				this._showDetail(oEvent.getParameter("listItem") || oEvent.getSource());
			}
		},

		onNewWeiterbildungsangebot: function (oEvent) {
			const fnNavToNewItem = () => {
				this.navTo('newAngebot');
			};
			if (this.getModel("state").getProperty("/hasPendingChanges")) {
				this._promptAndExecute(
					oEvent.getSource(),
					PlacementType.VerticalPreferredBottom,
					this.promptType.CANCEL,
					this.getResourceBundle().getText("angeboteDetailEdit.edit.cancel.prompt.text"),
					this.getResourceBundle().getText("angeboteDetailEdit.edit.cancel.action.confirm"),
					fnNavToNewItem
			  	);
			} else {
				fnNavToNewItem();
			}
		},

		/**
		 * Event handler for the bypassed event, which is fired when no routing pattern matched.
		 * If there was an object selected in the master list, that selection is removed.
		 * @public
		 */
		onBypassed: function () {
			this._oList.removeSelections(true);
		},

		/**
		 * Event handler for the filter button to open the ViewSettingsDialog.
		 * @param {sap.ui.base.Event} oEvent the button press event
		 * @public
		 */
		onOpenViewSettings: function () {
			if (!this._oViewSettingsDialog) {
				//todo: remove deprecated
				this._oViewSettingsDialog = sap.ui.xmlfragment("de.hrk.hochweit.components.Weiterbildungsangebote.view.fragments.ViewSettingsDialog", this);
				this.getView().addDependent(this._oViewSettingsDialog);
				// forward compact/cozy style into Dialog
				this._oViewSettingsDialog.addStyleClass(this.getOwnerComponent().getContentDensityClass());
			}
			var sDialogTab = "filter";

			this._oViewSettingsDialog.open(sDialogTab);
		},

		/**
		 * Event handler called when ViewSettingsDialog has been confirmed, i.e.
		 * has been closed with 'OK'. In the case, the currently chosen filters, sorters or groupers
		 * are applied to the master list, which can also mean that they
		 * are removed from the master list, in case they are
		 * removed in the ViewSettingsDialog.
		 * @param {sap.ui.base.Event} oEvent the confirm event
		 * @public
		 */
		onConfirmViewSettingsDialog: function (oEvent) {
			var aFilterItems = oEvent.getParameters().filterItems,
				aFilters = [],
				aCaptions = [];
			// update filter state:
			// combine the filter array and the filter string
			aFilterItems.forEach(function (oItem) {
				aFilters.push({"filterName": oItem.getParent().getText(), "filterValue": oItem.getText()});
	         	aCaptions.push(oItem.getParent().getText() + ": " + oItem.getText());
			});
			this._oListFilterState.aFilter = aFilters;
			this._updateFilterBar(aCaptions.join(", "));
			this._applyFilterSearch();
			// expand the master after searching or filtering
			var sLayout = this.getModel("appView").getProperty("/layout");
			if (sLayout !== "OneColumn") {
				this.getModel("appView").setProperty("/layout", "TwoColumnsBeginExpanded");
			}
		},

		onResetViewSettingsDialogFilters: function () {
			this._resetCustomAppointmentDateFilterAndCaptions();
		},
		/**
		 * Event handler for navigating back.
		 * We navigate back in the browser historz
		 * @public
		 */
		onNavBack: function () {
			history.go(-1);
		},

		/**
		 * Sort table by table header.
		 * @param {Object} oEvent from the header
		 */
		onTableHeaderButtonClick: function (sPath) {
			const oViewModel = this.getModel("masterView");
			// Set new sorting column
			const sCurrentSortingColumn = oViewModel.getProperty("/sorting/column");
			const bSortSameColumn = (sCurrentSortingColumn === sPath);
			if (!bSortSameColumn) {
				oViewModel.setProperty("/sorting/column", sPath);
			}

			// Set sortIndicator direction
			var sNewSortingDirection = SortOrder.Ascending;
			const sCurrentSortingDirection = oViewModel.getProperty("/sorting/direction");
			if (bSortSameColumn && sCurrentSortingDirection === SortOrder.Ascending) {
				sNewSortingDirection = SortOrder.Descending;
			}
			oViewModel.setProperty("/sorting/direction", sNewSortingDirection);

			// Change sortOrder value to match prismas sortOrder
			let sortOrder = this.getModel("masterView").getProperty("/sorting/direction");
			if (sortOrder === "Ascending"){
				sortOrder = "asc";
			}
			else {
				sortOrder = "desc";
			}

			this._getWeiterbildungsangebote( {"skip": 0, "take": this.getModel("masterView").getProperty("/growingThreshold")},
										 	  "",
											 {"sortValue": this.getModel("masterView").getProperty("/sorting/column"),
						 					  "sortOrder": sortOrder});
			this.listmodel.setProperty("/sorting", { "sortColumn": sPath, "sortOrder": sNewSortingDirection });
			this._paginatingCursor = oViewModel.getProperty("/growingThreshold");
		},

		/* =========================================================== */
		/* begin: internal methods                                     */
		/* =========================================================== */

		_createViewModel: function () {
			var titlecountIndex = 0;

			return new JSONModel({
				isFilterBarVisible: false,
				filterBarLabel: "",
				delay: 0,
				title: this.getResourceBundle().getText("offerslist.titleCount", [titlecountIndex]),
				noDataText: this.getResourceBundle().getText("offerslist.tableNoDataPlaceholder"),
				groupBy: "None",
				sorting: {
					column: undefined,
					direction: SortOrder.Ascending
				},
				visibility: {
					userrole: "",
          isAdmin: false,
					createNewButtonVisible: false,
					hochschuleVisible: false,
					angebotsbezeichungVisible: false,
					angebotstypVisible: false,
					abschlussVisible: false,
					veranstaltungsformVisible: false,
					standortVisible: false,
					datenherkunftVisible: false,
					redaktionsstatusVisible: false
				}
			});
		},

		_setListVisibility: function(sUserrole, aPermissions){
			this.getModel("masterView").setProperty("/visibility/userrole", sUserrole);

			if (aPermissions.includes("w_create")){
				this.getModel("masterView").setProperty("/visibility/createNewButtonVisible", true);
			}

			switch (sUserrole) {
				case "ops_admin":
				case "tech_admin":
				case "fach_admin":
				case "admin":
					this.getModel("masterView").setProperty("/visibility/hochschuleVisible", true);
				case "power_user":
					this.getModel("masterView").setProperty("/visibility/redaktionsstatusVisible", true);
					this.getModel("masterView").setProperty("/visibility/datenherkunftVisible", true);
				case "hsb":
					this.getModel("masterView").setProperty("/visibility/angebotstypVisible", true);
					this.getModel("masterView").setProperty("/visibility/abschlussVisible", true);
					this.getModel("masterView").setProperty("/visibility/veranstaltungsformVisible", true);
					this.getModel("masterView").setProperty("/visibility/standortVisible", true);
					this.getModel("masterView").setProperty("/visibility/angebotsbezeichungVisible", true);
				default:
			}
			this.getModel("masterView").setProperty("/visibility/isAdmin", this._userLogic.isAdmin());
		},

		_onMasterMatched: function () {
			//Set the layout property of the FCL control to 'OneColumn'
			this.getModel("appView").setProperty("/layout", "OneColumn");

			// load data for list
			this._getWeiterbildungsangebote({"skip": 0, "take": this.getModel("masterView").getProperty("/growingThreshold")});

			this._paginatingCursor = this.getModel("masterView").getProperty("/growingThreshold");

			// remove selections in case we navigate to the list after having selected an entry at some point
			this._oList.removeSelections(true);
		},

		_onCollapsedMatched: function (oEvent) {
			this.weiterbildungsangebotId = parseInt(oEvent.getParameter("arguments").weiterbildungsangebotId, 10);

			// load data for list
			this._getWeiterbildungsangebote({"skip": 0, "take": this.getModel("masterView").getProperty("/growingThreshold")})
			.then(() => {
				this.getOwnerComponent().oListSelector.selectAListItem(this.weiterbildungsangebotId);
			});

			this._paginatingCursor = this.getModel("masterView").getProperty("/growingThreshold");
		},

		/**
		 * Calls getAllWA function of Angebote Service and
		 * resets the listmodel to ensure correct contexts
		 * @param oApolloService this._apolloService,
		 * @param iSkip number of rows to skip
		 * @param iTake number of rows to fetch at once
		 * @param sSearch value to search by
		 * @private
		 */
		_getWeiterbildungsangebote: function(oPagination, sSearch, oSorting){
			//Fill Filter and Sorting with their current values
			sSearch = (sSearch == null || sSearch == "") ? this.listmodel.getProperty("/searchterm") : sSearch;
            oSorting = (oSorting == null) ? this.listmodel.getProperty("/sorting") : oSorting;
			var oFilter = this.listmodel.getProperty("/currentfilter");
			const sUserrole = this.getModel("masterView").getProperty("/visibility/userrole");

			//Reset data to ensure table grows correctly
			this.getView().getModel().setData({});

			//Fetch the data and store it in the model
			return AngeboteService.getAllWA(this._apolloService, oPagination, sSearch, oSorting, sUserrole, oFilter)
				.then(function(data){
					this.listmodel.setProperty("/weiterbildungsangebote", data);
					this._oList.getBinding("items").fireDataReceived({data: {weiterbildungsangebote: data}});
					return Promise.resolve();
				}.bind(this));
		},

		/**
		 * Shows the selected item on the detail page
		 * On phones a additional history entry is created
		 * @param {sap.m.ObjectListItem} oItem selected Item
		 * @private
		 */
		_showDetail: function (oItem) {
			const fnNavToEditItem = () => {
				var bReplace = !Device.system.phone;
				// set the layout property of FCL control to show two columns {@see https://openui5.hana.ondemand.com/#/api/sap.f.LayoutType/properties}
				this.getModel("appView").setProperty("/layout", "TwoColumnsMidExpanded");
				this.getRouter().navTo("editAngebot", {
					weiterbildungsangebotId: oItem.getBindingContext().getProperty("id")
				}, bReplace);
				this.getOwnerComponent().liftPendingChanges();
			};

			if (this.getModel("state").getProperty("/hasPendingChanges")) {
				this._promptAndExecute(
					oItem,
					PlacementType.HorizontalPreferredRight,
					this.promptType.CANCEL,
					this.getResourceBundle().getText("angeboteDetailEdit.edit.cancel.prompt.text"),
					this.getResourceBundle().getText("angeboteDetailEdit.edit.cancel.action.confirm"),
					fnNavToEditItem
			  	);
			} else {
				fnNavToEditItem();
			}
		},

		/**
		 * Sets the item count on the master list header
		 * @param {integer} iTotalItems the total number of items in the list
		 * @private
		 */
		_updateListItemCount: function (iTotalItems) {
			var sTitle;
			// uncommented the isfinal part because it currently is not a performance concern, re-enable if this is evaluated too often
			// if (this._oList.getBinding("items").isLengthFinal()) {
			sTitle = this.getResourceBundle().getText("offerslist.titleCount", [iTotalItems]);
			this.getModel("masterView").setProperty("/title", sTitle);
			// }
		},

		_getFilterForKey: function(sKey) {
			var aFilters = [];
			if (sKey === "HOCHWEIT") {
				aFilters.push({"filterName": "isthskimportiert", "filterValue": "false"});
			} else if (sKey === "HOCHSCHULKOMPASS") {
				aFilters.push({"filterName": "isthskimportiert", "filterValue": "true"});
			}

			return aFilters;
		},

		/**
		 * Internal helper method to apply both filter and search state together on the list binding
		 * @private
		 */
		_applyFilterSearch: function () {
			var aFilters = this._oListFilterState.aSearch.concat(this._oListFilterState.aFilter),
				oViewModel = this.getModel("masterView");

			this._oList.getBinding("items").filter(aFilters, "Application");
			// changes the noDataText of the list in case there are no filter results
			if (aFilters.length !== 0) {
				oViewModel.setProperty("/noDataText", this.getResourceBundle().getText("offerslist.tableNoDataWithFilterPlaceholder"));
			} else if (this._oListFilterState.aSearch.length > 0) {
				// only reset the no data text to default when no new search was triggered
				oViewModel.setProperty("/noDataText", this.getResourceBundle().getText("offerslist.tableNoDataPlaceholder"));
			}

			// Turn Filters into JSON
			const oFilter = {};
			for (const oFilterItem of aFilters) {
				const filterName = oFilterItem.filterName.toLowerCase();
				if (oFilter[filterName]){
					oFilter[filterName] = oFilter[filterName] + "&&" + oFilterItem.filterValue;
				}
				else {
					oFilter[filterName] = oFilterItem.filterValue;
				}
			}

			// Check if Filters is empty
			if (Object.keys(oFilter).length === 0 && oFilter.constructor === Object){
				this.listmodel.setProperty("/currentfilter", null);
			}
			else {
				this.listmodel.setProperty("/currentfilter", oFilter);
			}

			this._getWeiterbildungsangebote({"skip": 0, "take": this.getModel("masterView").getProperty("/growingThreshold")});

		},

		/**
		 * Internal helper method that sets the filter bar visibility property and the label's caption to be shown
		 * @param {string} sFilterBarText the selected filter value
		 * @private
		 */
		_updateFilterBar: function (sFilterBarText) {
			var oViewModel = this.getModel("masterView");
			oViewModel.setProperty("/isFilterBarVisible", (this._oListFilterState.aFilter.length > 0));
			oViewModel.setProperty("/filterBarLabel", this.getResourceBundle().getText("filter.filterText", [sFilterBarText]));
		},

		/**
		 * Handler for adjusting the angebotsbezeichnung if it was updated for the currently edited WA
		 * (Event via sap.ui.core.EventBus)
		 */
		_onAngebotsbezeichnungUpdated: function (eventId, channelId, oData) {
			if (!oData || !oData.angebotsbezeichnung) { return; }
			Log.debug(`Event ${eventId} (channel ${channelId}) was caught by ${this.getView().getId()}`);
			const oSelectedWABezeichnungPath = this.getOwnerComponent().oListSelector.getSelectedItem().getBindingContext().getPath("bezeichnung");
			this.getModel().setProperty(oSelectedWABezeichnungPath, oData.angebotsbezeichnung);
		},

		/**
		 * Handler for successfull save of a WA
		 * (Event via sap.ui.core.EventBus)
		 */
		_onWASaved: function () {
			this._applyFilterSearch();
		}
	});
}
);
