sap.ui.define([
  "de/hrk/hochweit/components/Weiterbildungsangebote/controller/BaseController",
  "sap/ui/model/json/JSONModel",
  "de/hrk/hochweit/components/Weiterbildungsangebote/service/AngeboteService",
  "de/hrk/hochweit/components/Weiterbildungsangebote/service/KatalogService",
  "de/hrk/hochweit/components/Weiterbildungsangebote/model/businessLogic/GesamtkostenLogic",
  "de/hrk/hochweit/components/Weiterbildungsangebote/model/businessLogic/AnerkennungUndAnrechnungLogic",
  "de/hrk/hochweit/components/Weiterbildungsangebote/model/businessLogic/KontaktUndAnsprechpartnerLogic",
  "de/hrk/hochweit/components/Weiterbildungsangebote/model/businessLogic/OrganisatorischeInformationenLogic",
  "sap/m/PlacementType",
	"sap/m/MessageToast",
  "sap/base/Log",
  "de/hrk/hochweit/components/Weiterbildungsangebote/controller/AngeboteDetailUtil"
], function (
  BaseController,
	JSONModel,
	AngeboteService,
	KatalogService,
	GesamtkostenLogic,
	AnerkennungUndAnrechnungLogic,
	KontaktUndAnsprechpartnerLogic,
	OrganisatorischeInformationenLogic,
	PlacementType,
	MessageToast,
	Log,
  AngeboteDetailUtil
) {
  "use strict";

  return BaseController.extend("de.hrk.hochweit.components.Weiterbildungsangebote.controller.AngeboteDetailEdit", {

    /* =========================================================== */
    /* lifecycle methods                                           */
    /* =========================================================== */

    onInit: function () {
      // Model used to manipulate control states. The chosen values make sure,
      // detail page is busy indication immediately so there is no break in
      // between the busy indication for loading the view's meta data
      var oViewModel = new JSONModel({
        busy: false,
        delay: 0,
        refreshButtonIcon: "sap-icon://refresh",
        refreshButtonType: "Transparent"
      });

      this.setModel(oViewModel, "detailView");
      this.setModel(new JSONModel(), "katalog");
      this.setModel(new JSONModel(), "viewState");
      this.setModel(sap.ui.getCore().getMessageManager().getMessageModel(), "message");

      this._apolloService = this.getOwnerComponent().getApolloService();

      // Get role of logged in user
			this._oLogin = this.getOwnerComponent().getModel("login").getProperty("/");

      this._angeboteDetailUtil = new AngeboteDetailUtil(this);

      this.getRouter().getRoute("editAngebot").attachPatternMatched(this._onEditWeiterbildungsangebot, this);

      this.getEventBus().subscribe(this.eventRegistry.eingabeformulare.channel, this.eventRegistry.eingabeformulare.events.angebotsbezeichnungUpdated, this._onAngebotsbezeichnungUpdated, this);

      this.getView().addEventDelegate({onBeforeShow: () => { this.getModel("viewState").setProperty("/isShown", true); }});
			this.getView().addEventDelegate({onBeforeHide: () => { this.getModel("viewState").setProperty("/isShown", false); }});
    },

    /* =========================================================== */
    /* event handlers                                              */
    /* =========================================================== */

    /**
     * Toggle between full and non full screen mode.
     */
    toggleFullScreen: function () {
      this.getModel("appView").setProperty("/layout", "TwoColumnsMidExpanded");

      var bFullScreen = this.getModel("appView").getProperty("/actionButtonsInfo/midColumn/fullScreen");
      this.getModel("appView").setProperty("/actionButtonsInfo/midColumn/fullScreen", !bFullScreen);
      if (!bFullScreen) {
        // store current layout and go full screen
        this.getModel("appView").setProperty("/previousLayout", this.getModel("appView").getProperty("/layout"));
        this.getModel("appView").setProperty("/layout", "MidColumnFullScreen");
      } else {
        // reset to previous layout
        this.getModel("appView").setProperty("/layout", this.getModel("appView").getProperty("/previousLayout"));
      }
    },

    onSave: function () {
      if (this._oLogin.permissions.includes("w_edit")) {
        this.resetErrorMessages();
        this._angeboteDetailUtil.requestFormValidations().then(bSuccess => {
          if (bSuccess) {
            AngeboteService.editWeiterbildungsangebot(this._apolloService, this.getView().getModel().getData())
              .then(data => {
                this.showEdited(data.bezeichnung, {closeOnBrowserNavigation: false});
                this.getOwnerComponent().liftPendingChanges();
                this.getEventBus().publish(this.eventRegistry.eingabeformulare.channel, this.eventRegistry.eingabeformulare.events.weiterbildungsangebotSaved);
              })
              .catch(this.onSaveFailed.bind(this));
          }
        });
      }
    },

    onResetFormular: function (oEvent, sFormular) {
      const oPayload = { formularReset: sFormular || this.formularReset.ALL };
      let fnConfirmReset = () => {
        AngeboteService.getWA(this._apolloService, this.getModel().getProperty("/id"))
          .then(data => {

            oPayload.originalData = this._adaptForLoad(data);
            this.getOwnerComponent().getEventBus().publish(
              this.eventRegistry.eingabeformulare.channel,
              this.eventRegistry.eingabeformulare.events.resetFormular,
              oPayload
            );
          });
      };

      this._promptAndExecute(
        oEvent.getSource(),
        PlacementType.HorizontalPreferredLeft,
        this.promptType.CANCEL,
        this.getResourceBundle().getText("angeboteDetailEdit.action.reset.prompt.text", [
          oPayload.formularReset === this.formularReset.ALL ?
            this.getResourceBundle().getText("angeboteDetailEdit.action.reset.prompt.allForms") :
            this.getResourceBundle().getText("angeboteDetailEdit.action.reset.prompt.singleForm")
        ]),
        this.getResourceBundle().getText("angeboteDetailEdit.action.reset.prompt.confirm"),
        fnConfirmReset);
    },

		/**
		 * Event handler for the export list button
     * exportType = "json" | "pdf" | "xml"
		 * @public
		 */
     onExport: function(exportType){
      AngeboteService.exportDetail(this._apolloService,
                                  this.getModel().getProperty("/id"),
                                  this.getView().getModel().getData(),
                                  exportType)
      .then(function(data){
        this.onExportFinished(data);
      }.bind(this));
		},

		/**
		 * Event handler for the receiving of an exportfile
		 * @param oData the returned exportfile
		 */
		onExportFinished: function(oData){
			var link = document.createElement("a");
			link.setAttribute("href", encodeURI(oData.content));
			link.setAttribute("download", oData.name);
			document.body.appendChild(link);
			link.click();
		},

    onDeleteWeiterbildungsangebot: function (oEvent) {
      let fnConfirmDelete = () => {
        AngeboteService.deleteWeiterbildungsangebot(this._apolloService, this.getModel().getProperty("/id"))
        .then(function (data) {
          this.showDeleted(data.bezeichnung, {closeOnBrowserNavigation: false});
          this.navTo("list");
          this.getOwnerComponent().liftPendingChanges();
        });
      };

      this._promptAndExecute(
        oEvent.getSource(),
        PlacementType.HorizontalPreferredLeft,
        this.promptType.CANCEL,
        this.getResourceBundle().getText("angeboteDetailEdit.action.delete.prompt.text"),
        this.getResourceBundle().getText("angeboteDetailEdit.action.delete.prompt.confirm"),
        fnConfirmDelete);
    },

    /* =========================================================== */
    /* begin: internal methods                                     */
    /* =========================================================== */

    // TODO: Remove this adaptation by harmonizing Object and Input Type for Weiterbildungsangebot and using ONE model for UI and API
    _adaptForLoad(weiterbildungsangebotData) {
      const adaptedData = Object.assign({}, weiterbildungsangebotData);

      // EF 1
      adaptedData.WeiterbildungsangebotKosten = GesamtkostenLogic.adaptLoadedWAData(adaptedData.WeiterbildungsangebotKosten);

      // EF 2
      // cast lehrUndLernEinheitenIDs to strings
      if (weiterbildungsangebotData.veranstaltungsformenIDs && weiterbildungsangebotData.veranstaltungsformenIDs.length) {
        adaptedData.veranstaltungsformenIDs = weiterbildungsangebotData.veranstaltungsformenIDs.map(id => id !== null && id !== undefined ? id.toString(): id);
      }

      const adaptedOrganisatorischeInformationen = OrganisatorischeInformationenLogic.adaptLoadedWAData({
        LehrUndLernEinheiten: adaptedData.LehrUndLernEinheiten,
        Zeitbereich: adaptedData.Zeitbereich
      });
      adaptedData.LehrUndLernEinheiten = adaptedOrganisatorischeInformationen.LehrUndLernEinheiten;
      adaptedData.Zeitbereich = adaptedOrganisatorischeInformationen.Zeitbereich;

      //EF 7
      const adaptedAnerkennungUndAnrechnungData = AnerkennungUndAnrechnungLogic.adaptLoadedWAData({
        anrechnungwebsite: adaptedData.anrechnungwebsite,
        individuelleanrechnungwebsite: adaptedData.individuelleanrechnungwebsite,
        bildungstraeger: adaptedData.bildungstraeger,
        praktischeerfahrungen: adaptedData.praktischeerfahrungen,
      });
      adaptedData.anrechnungwebsite = adaptedAnerkennungUndAnrechnungData.anrechnungwebsite;
      adaptedData.individuelleanrechnungwebsite = adaptedAnerkennungUndAnrechnungData.individuelleanrechnungwebsite;
      adaptedData.bildungstraeger = adaptedAnerkennungUndAnrechnungData.bildungstraeger;
      adaptedData.praktischeerfahrungen = adaptedAnerkennungUndAnrechnungData.praktischeerfahrungen;

      if (adaptedData.anrechnungsansprechpartner) {
        adaptedData.anrechnungsansprechpartner.forEach(KontaktUndAnsprechpartnerLogic.adaptKontaktauswahl);
      }
      if (adaptedData.anerkennungsansprechpartner) {
        adaptedData.anerkennungsansprechpartner.forEach(KontaktUndAnsprechpartnerLogic.adaptKontaktauswahl);
      }

      return adaptedData;
    },

    /**
     * Binds the view to the object path and expands the aggregated line items.
     * @function
     * @param {sap.ui.base.Event} oEvent pattern match event in route 'object'
     * @private
     */
    _onEditWeiterbildungsangebot: function (oEvent) {
      // Clear any old messages
			sap.ui.getCore().getMessageManager().removeAllMessages();

      this.weiterbildungsangebotId = oEvent.getParameter("arguments").weiterbildungsangebotId;
      this.getModel("appView").setProperty("/layout", "TwoColumnsMidExpanded");
      this.getModel("detailView").setProperty("/refreshButtonIcon", "sap-icon://refresh");
      this.getModel("detailView").setProperty("/refreshButtonType", "Transparent");

      AngeboteService.getWA(this._apolloService, this.weiterbildungsangebotId).then(function (data) {
        const adaptedData = this._adaptForLoad(data);
        this.getModel().setData(adaptedData);

        this.getOwnerComponent().declarePendingChanges(); // TODO: only declare when actual changes were made

        this.getOwnerComponent().getEventBus().publish(this.eventRegistry.eingabeformulare.channel, this.eventRegistry.eingabeformulare.events.weiterbildungsangebotLoaded);
      }.bind(this));

      KatalogService.getRedaktionsstatuses(this._apolloService).then(
        (data) => {
          this.getModel("katalog").setProperty("/redaktionsstatuses", data);
        });
      },

      /**
       * Handler for adjusting the angebotsbezeichnung if it was updated for the currently edited WA
       */
      _onAngebotsbezeichnungUpdated: function (eventId, channelId, oData) {
        if (!oData || !oData.angebotsbezeichnung) { return; }
        Log.debug(`Event ${eventId} (channel ${channelId}) was caught by ${this.getView().getId()}`);
        this.getModel().setProperty("/bezeichnung", oData.angebotsbezeichnung);
      },

      showEdited: function (oEditedWeiterbildungsangebot, oDisplayOptions) {
        MessageToast.show(this.getBundle().getText("angbeoteDetailEdit.message.AngebotEdited", [oEditedWeiterbildungsangebot.bezeichnung.de]), oDisplayOptions);
      },

      showDeleted: function (oDeletedWeiterbildungsangebot, oDisplayOptions) {
        MessageToast.show(this.getBundle().getText("angeboteDetailEdit.action.delete.confirmation.message", [oDeletedWeiterbildungsangebot.bezeichnung.de]), oDisplayOptions);
      }
  });
});
