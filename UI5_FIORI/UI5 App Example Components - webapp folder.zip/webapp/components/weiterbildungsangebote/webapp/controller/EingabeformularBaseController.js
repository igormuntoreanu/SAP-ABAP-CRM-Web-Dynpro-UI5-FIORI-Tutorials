sap.ui.define([
  "de/hrk/hochweit/components/Weiterbildungsangebote/controller/BaseController",
  "sap/base/Log",
  "sap/ui/model/ParseException",
  "sap/ui/model/ValidateException",
  "de/hrk/hochweit/components/Weiterbildungsangebote/validation/Validator"
], function (
  BaseController,
	Log,
	ParseException,
	ValidateException,
  Validator) {
  "use strict";

  return BaseController.extend("de.hrk.hochweit.components.Weiterbildungsangebote.controller.EingabeformularBaseController", {

    formularFields: {}, // controllers extending this should define the key-value structure needed for Weiterbildungsangebot data edited by them

    /* =========================================================== */
    /* lifecycle methods                                           */
    /* =========================================================== */

    _validator: Validator,

    onInit: function () {
      this._apolloService = this.getOwnerComponent().getApolloService();

      this._subscribeToEvents();

      this._messages = [];
      this._messageManager = sap.ui.getCore().getMessageManager();
    },

    /**
     * Subscribes each extending controller to common events.
     * Controllers should implement the _onValidationRequested method as needed
     * Controllers must define this.formularReset.ME and fire the resetFormular event with a matching key
     */
    _subscribeToEvents: function() {
      this.getOwnerComponent().getEventBus().subscribe(
        this.eventRegistry.eingabeformulare.channel,
        this.eventRegistry.eingabeformulare.events.triggerValidation,
        this._onValidationRequested,
        this
      );

      this.getOwnerComponent().getEventBus().subscribe(
        this.eventRegistry.eingabeformulare.channel,
        this.eventRegistry.eingabeformulare.events.resetFormular,
        this._resetFormular,
        this);

      this.getOwnerComponent().getEventBus().subscribe(
        this.eventRegistry.eingabeformulare.channel,
        this.eventRegistry.eingabeformulare.events.weiterbildungsangebotLoaded,
        this._onWALoaded,
        this
      );

      this.getOwnerComponent().getEventBus().subscribe(
        this.eventRegistry.eingabeformulare.channel,
        this.eventRegistry.eingabeformulare.events.handleServerValidation,
        this._handleServerValidation,
        this
      );
    },

    /**
     * Used for self-validation after Weiterbildungsangebot data is loaded.
     * Must be implemented by each controller as needed
     */
    _onValidationRequested: function () {
      Log.warning(`Validation request was caught by ${this.getView().getId()} but not implemented`);
    },

    /**
     * Used for self-validation after Weiterbildungsangebot data is loaded.
     * Must be implemented by each controller as needed
     */
    _onWALoaded: function () {
      Log.warning(`WA loaded event was caught by ${this.getView().getId()} but not implemented`);
    },


    /**
     * Reset Eingabeformular of implementing controller
     * @param {string} channelId
     * @param {string} eventId
     * @param {Object} oPayload {
     *  formularReset: Contains the key of the formular that should be reset,
     *  originalData: Contains a JS object literal with the original data to which the indicated formulars should reset
     * }
     * @returns void
     */
    _resetFormular(channelId, eventId, oPayload) {
      if (!oPayload.formularReset ||  ![this.formularReset.ME, this.formularReset.ALL].includes(oPayload.formularReset)) {
        Log.debug(`Event ${eventId} (channel ${channelId}) was caught by ${this.getView().getId()} without formularReset property matching either formularReset.ME or formularReset.ALL`);
        return;
      }
      if (!oPayload.originalData) {
        Log.error(`Event ${eventId} (channel ${channelId}) was caught without originalData property to which to reset to`);
        return;
      }

      Object.keys(this.formularFields).forEach( (key) => {
        // only set properties directly concerning the formular, don't replace the entire model as other formulars might do the same (when resetting all)
        this.getModel().setProperty(`/${key}`,  oPayload.originalData[key]);
      });
      this.getModel().refresh(true);

      // trigger load handler for EF-specific adaptations
      this._onWALoaded();

      Validator.markControls(this.getView(), {});
      this._messageManager.removeMessages(this._messages);
      this._messages = [];
    },

    _validateFieldValue(oField, sBindingName = "value", sInternalType = "string", sErrorMessage) {
      try {
        const oParsedValue = oField.getBinding(sBindingName).getType().parseValue(oField.getProperty(sBindingName), sInternalType);
        oField.getBinding(sBindingName).getType().validateValue(oParsedValue);
        oField.setValueState("None");
        oField.setValueStateText("");
        oField.fireValidationSuccess({
          element: oField
        });
        return true;
      } catch (error) {
        const sTrueMessage = sErrorMessage || error.message;

        if (error instanceof ParseException || error instanceof ValidateException) {
          oField.fireValidationError({
            element: oField,
            message: sTrueMessage
          });
          oField.setValueState("Error");
          oField.setValueStateText(sTrueMessage);
        } else {
          Log.error(`Validation failed for ${oField.getId()} Message: ${error.message}`);
        }
        return false;
      }
    },

    _handleServerValidation: function (sChannelId, sEventId, oErrorMap) {
      let oFilteredMap = {};
      Object.keys(oErrorMap)
        .filter(this._isPropertyPathRelevantForValidation.bind(this))
        .forEach(sRelevantPath => oFilteredMap[sRelevantPath] = oErrorMap[sRelevantPath]);
      if (Object.keys(oFilteredMap).length) {
        Validator.markControls(this.getView(), oFilteredMap);
      }
    },

    /**
     * Method to optimize validation runtime; controller can override this
     * @param sPropertyPath
     * @return {boolean}
     */
    _isPropertyPathRelevantForValidation: function (sPropertyPath) {
      Log.trace("Check for property relevance of " + sPropertyPath + "; override method to implement view-specific checks");
      return true;
    }
  });
}
);
