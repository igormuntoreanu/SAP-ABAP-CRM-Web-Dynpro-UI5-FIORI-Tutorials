# Administrative Funktionen
This component contains a dashboard visualising all administrative functionalities a user can execute.

Each functionality has its own tile on the dashboard. When the clicking one tile, it navigates to another page, where the functionality can be executed. Each page is created as a separate view.


