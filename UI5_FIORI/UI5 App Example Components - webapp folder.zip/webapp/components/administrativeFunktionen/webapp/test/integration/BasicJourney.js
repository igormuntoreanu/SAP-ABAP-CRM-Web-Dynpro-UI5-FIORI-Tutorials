sap.ui.define([
  "sap/ui/test/opaQunit",
  "de/hrk/hochweit/components/AdministrativeFunktionen/test/integration/pages/Dashboard"

], function (opaTest) {
  "use strict";


  opaTest("should show the dashboard", function (Given, When, Then){

    // Arrangements
    Given.iStartMyApp();

    // Assertions
    Then.onTheDashboardPage.iShouldSeeTheDashboard()
      .and.iShouldSeeTheTitleWithI18nKey("dashboard.title.persoenliches")
      .and.iShouldSeeTheTileWithConfig("dashboard.tile.header.persoenlicheKontoeinstellungen", "dashboard.tile.subHeader.sonstiges", "sap-icon://user-settings");

    // Cleanup
    Then.iTeardownMyApp();
  });

});
