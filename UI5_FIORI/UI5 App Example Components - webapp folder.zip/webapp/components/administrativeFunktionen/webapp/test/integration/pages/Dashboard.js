sap.ui.require([
  "sap/ui/test/Opa5"

], function (Opa5) {
  "use strict";

  var sViewName = "de.hrk.hochweit.components.AdministrativeFunktionen.view.Dashboard";
  var sDashboardGroupContainer = "dashboardGroupContainer";


  Opa5.createPageObjects({
    onTheDashboardPage: {
      assertions: {

        iShouldSeeTheDashboard: function () {
          return this.waitFor({
            id: sDashboardGroupContainer,
            viewName: sViewName,
            success: function () {
              Opa5.assert.ok(true, "The dashboard appears");
            },
            errorMessage: "Dashboard does not appear"
          })
        },

        iShouldSeeTheTitleWithI18nKey: function (sKey) {
          return this.waitFor({
            controlType: "sap.m.Title",
            viewName: sViewName,
            i18NText: {
              propertyName: "text",
              key: sKey
            },

            success: function (aTitles) {
             Opa5.assert.strictEqual(1, aTitles.length, `Found exactly 1 title with text ${aTitles[0].getText()}`);
            },
            errorMessage: `No Title "${sKey}" can be seen`
          })
        },

        iShouldSeeTheTileWithConfig: function (sHeaderI18nKey, sSubHeaderI18nKey, sIcon) {
          return this.waitFor({
            controlType: "sap.m.GenericTile",
            viewName: sViewName,
            i18NText: [ {
              propertyName: "header",
              key: sHeaderI18nKey
            },
              {
                propertyName: "subheader",
                key: sSubHeaderI18nKey
              }
            ],

            success: function (aTiles) {
              Opa5.assert.strictEqual(1, aTiles.length, `Found exactly 1 tile.`);
              Opa5.assert.strictEqual(aTiles[0].getModel("i18n").getResourceBundle().getText(sHeaderI18nKey), aTiles[0].getHeader(), `Header matches expectations`);
              Opa5.assert.strictEqual(aTiles[0].getModel("i18n").getResourceBundle().getText(sSubHeaderI18nKey), aTiles[0].getSubheader(), `SubHeader matches expectations`);
              Opa5.assert.strictEqual(sIcon, aTiles[0].getTileContent()[0].getContent().getSrc(), `ImageContent matches expectations`);
            },
            errorMessage: "No tile is found or tile is not configured correctly"
          })
        }

      }

    }
  });

});
