sap.ui.define(["sap/base/strings/formatMessage"], function (formatMsg) {
  "use strict";

  var _getI18nResourceBundle = function (uiElement) {
    var component = uiElement.getOwnerComponent();
    var i18nModel;
    if (!component) {
      return null;
    }
    i18nModel = component.getModel("i18n");
    if (!i18nModel) {
      return null;
    }
    return i18nModel.getResourceBundle();
  };

  var Formatter = {
    i18nResourceBundle: _getI18nResourceBundle,

    _formatMsg: formatMsg,

    formatMessage: function (sPattern, ...aValues) {
      return Formatter._formatMsg(sPattern, aValues);
    },

    getI18nText: function (sKey) {
      return Formatter.i18nResourceBundle(this).getText(sKey);
    },

    formatISOLanguage: function (sLanguage) {
      return Formatter.i18nResourceBundle(this).getText(
        "language." + sLanguage
      );
    },

    formatBoolean: function (bBoolean) {
      if (bBoolean) {
        return Formatter.i18nResourceBundle(this).getText("common.yes");
      }
      return Formatter.i18nResourceBundle(this).getText("common.no");
    },

    formatTileSpaceRequirement: function (sReq) {
      switch (sReq) {
        case "wide": return "TwoByOne";
        case "wide-reduced": return "TwoByHalf";
        case "narrow-reduced": return "OneByHalf";
        case "narrow":
        default: return "OneByOne";
      }
    },
  };

  return Formatter;
});
