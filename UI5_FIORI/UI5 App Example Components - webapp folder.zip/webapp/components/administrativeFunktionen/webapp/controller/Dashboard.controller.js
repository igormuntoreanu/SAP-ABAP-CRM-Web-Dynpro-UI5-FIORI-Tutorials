sap.ui.define([
    "de/hrk/hochweit/components/AdministrativeFunktionen/controller/BaseController",
    "de/hrk/hochweit/components/AdministrativeFunktionen/model/formatter",
  ], function (BaseController, formatter) {
    "use strict";

    return BaseController.extend("de.hrk.hochweit.components.AdministrativeFunktionen.controller.Dashboard", {

      formatter: formatter,

      /* =========================================================== */
      /* lifecycle methods                                           */
      /* =========================================================== */
      onInit: function () {

        this.getRouter().getRoute("dashboard");

        this.getView().addEventDelegate({
          onBeforeFirstShow: () => {
            const oLoginModel = this.getModel("login");
            if (oLoginModel) {
              oLoginModel.updateBindings(true);
            }
          }
        }, this);
      },


      /* =========================================================== */
      /* begin: internal methods                                     */
      /* =========================================================== */
      onTilePress: function (sKey) {
        this.navTo(sKey);
      },

      shouldBeVisible(bAdminRequired, bPoweruserRequired) {
        if (!bAdminRequired && !bPoweruserRequired) {
          return true;
        }
        const loginModel = this.getModel("login");
        if (!loginModel) {
          return false;
        }
        const login = loginModel.getProperty("/");
        if (!login || !login.role) {
          return false;
        }
        if (login.role.includes("admin")) {
          return true;
        }
        return (!bAdminRequired && login.role === "power_user");
      }
    });
  }
);
