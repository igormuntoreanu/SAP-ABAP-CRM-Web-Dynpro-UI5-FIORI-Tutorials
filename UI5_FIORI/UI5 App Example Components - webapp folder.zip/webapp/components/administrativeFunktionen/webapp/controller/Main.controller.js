sap.ui.define([
  "de/hrk/hochweit/components/AdministrativeFunktionen/controller/BaseController",
  "sap/ui/model/json/JSONModel",
  "sap/base/Log"
], function (BaseController, JSONModel, Log) {
  "use strict";

  return BaseController.extend("de.hrk.hochweit.components.AdministrativeFunktionen.controller.Main", {

    onInit: function () {
      // Set language/locale to german // TODO: make configurable
      sap.ui.getCore().getConfiguration().applySettings({
        language: "de"
      });

      var oViewModel;

      oViewModel = new JSONModel({
        busy: false,
        delay: 0
      });
      this.setModel(oViewModel, "appView");

      // apply content density mode to root view
      this.getView().addStyleClass(this.getOwnerComponent().getContentDensityClass());

      this._attachTargetDisplayHandlers();
    },

    _attachTargetDisplayHandlers: function () {
      let oTargets = this.getOwnerComponent().getManifestEntry(
        "/sap.ui5/routing/targets"
      );
      if (!oTargets) {
        Log.error("No targets were defined in application descriptor");
        return;
      }

      for (const [sKey, oTarget] of Object.entries(oTargets)) {
        try {
          if (oTarget.type === "Component") {
            this.getRouter().getTarget(sKey).attachEventOnce("display", this._attachComponentNotificationHandlers, this);
            this.getRouter().getTarget(sKey).attachEvent("display", this._attachComponentNavigationHandler, this);
          }
        } catch (oError) {
          Log.error(oError.message);
        }
      }
    },

    _attachComponentNotificationHandlers: function (oEvent) {
      let oComponentInstance = oEvent
        .getParameter("object")
        .getComponentInstance();
      if (oComponentInstance) {
        try {
          oComponentInstance.attachNotifyPendingChanges(
            this.relayNotifyPendingChanges,
            this
          );
        } catch (oError) {
          Log.error(
            `Event notifyPendingChanges is not defined in component instance ${oComponentInstance
              .getMetadata()
              .getComponentName()}`
          );
        }
        try {
          oComponentInstance.attachNotifyNoPendingChanges(
            this.relayNotifyNoPendingChanges,
            this
          );
        } catch (oError) {
          Log.error(
            `Event notifyNoPendingChanges is not defined in component instance ${oComponentInstance
              .getMetadata()
              .getComponentName()}`
          );
        }
      }
    },

    relayNotifyPendingChanges: function (oEvent) {
      this.getOwnerComponent().fireNotifyPendingChanges({
        componentName: oEvent.getParameter("componentName")
      });
    },
    relayNotifyNoPendingChanges: function (oEvent) {
      this.getOwnerComponent().fireNotifyNoPendingChanges({
        componentName: oEvent.getParameter("componentName")
      });
    },

    /**
     * Registers the component that the app navigated to as the "current" component - enables checking for pending changes from that component
     * @param {*} oEvent the display event of the component route
     */
    _attachComponentNavigationHandler: function (oEvent) {
      let oComponentInstance = oEvent
        .getParameter("object")
        .getComponentInstance();
      if (oComponentInstance) {
        this.getModel("components").setProperty("/", { // the components model should be propagated from the root component
          currentComponent: oComponentInstance.getMetadata().getComponentName(),
        });
      }
    }

  });
}
);
