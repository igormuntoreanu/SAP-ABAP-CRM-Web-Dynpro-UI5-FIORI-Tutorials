sap.ui.define([
  "de/hrk/hochweit/components/AdministrativeFunktionen/controller/BaseController",
], function (BaseController) {
  "use strict";

  return BaseController.extend("de.hrk.hochweit.components.AdministrativeFunktionen.controller.KatalogverwaltungWeiterbildungsangebote", {

    onInit: function () {

      this.getRouter().getRoute("katalogverwaltungWeiterbildungsangebote")
    },

    /* =========================================================== */
    /* begin: internal methods                                     */
    /* =========================================================== */


  });
}
);
