sap.ui.define([], function() {
    "use strict";
    return {
        // <fachlicher name>: {
        //     channel: "app.<name>",
        //     events: {
        //         <eventname>: "app.<name>.<eventname>",
        //         ...
        //     }
        // }
    };
});