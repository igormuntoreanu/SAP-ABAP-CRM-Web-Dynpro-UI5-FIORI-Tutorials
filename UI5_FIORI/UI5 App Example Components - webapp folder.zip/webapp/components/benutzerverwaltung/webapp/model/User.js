sap.ui.define([
	"./BaseEntity"
], function(
	BaseEntity
) {
	"use strict";

	return BaseEntity.extend("de.hrk.hochweit.components.Seitenbaumeditor.model.Login", {
		constructor: function (data) {
			BaseEntity.call(this, data);
		},

		getJSON: function () {
			return {
			};
		}
	});
});