sap.ui.define([
	"sap/ui/base/Object"
], function(
	BaseObject
) {
	"use strict";

	return BaseObject.extend("de.hrk.hochweit.components.Benutzerverwaltung.model.BaseEntity", {
		constructor: function (data) {
			this.copyValues(data);
		},
		copyFieldsToObject: function (aFields) {
			return this.copyFields(this, {}, aFields);
		},
		copyFieldsToThis: function (oFrom, aFields) {
			return this.copyFields(oFrom, this, aFields);
		},
		copyFields: function (oFrom, oTo, aFields) {
			for (var prop in oFrom) {
				if (aFields.find((field) => field === prop)) {
					oTo[prop] = oFrom[prop];
				}
			}
			return oTo;
		},
		copyValues: function (data) {
			if (data) {
				for (var field in data) {
					this[field] = data[field];
				}
			}
		},
		getData: function () {
			var req = jQuery.extend({}, this);
			delete req["model"];
			return req;
		},
		fnMap: function (oObject) {
			var obj = {};
			for (var prop in oObject) {
				if (oObject.hasOwnProperty(prop) && typeof (oObject[prop]) !== "object") {
					obj[prop] = oObject[prop];
				}
			}
			return obj;
		}
	});
});