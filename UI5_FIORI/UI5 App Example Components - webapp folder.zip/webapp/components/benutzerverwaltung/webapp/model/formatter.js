sap.ui.define([
	"sap/ui/core/SortOrder"
], function(
	SortOrder
) {
	"use strict";

	return  {

		formatSortingIndicator: function (sSortingColumn, sSortingDirection, sColumn) {
			if (sSortingColumn !== sColumn) {
				return SortOrder.None;
			}
			return sSortingDirection;
		}
	};

});