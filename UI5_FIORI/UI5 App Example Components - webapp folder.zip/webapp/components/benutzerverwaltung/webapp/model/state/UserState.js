sap.ui.define([
	"./BaseState",
	"../User"
], function (
	BaseState, User
) {
	"use strict";

	return BaseState.extend("de.hrk.hochweit.components.Benutzerverwaltung.model.state.UserState", {
		constructor: function (oService) {
			this.data = {
				User: new User({
					istHrkZugang: false
				}),
				display: true
			};
			this.UserService = oService;
			BaseState.call(this);
		},

		getUser: function (keycloak_id) {
			return this.UserService.getUser(keycloak_id).then((result) => {
				this.data.User = new User(result.data);
				this.data.display = false;
				this.updateModel();
				return this.data.User;
			});
		},

		maintainUser: function (sCreation) {
			if (sCreation) {
				return this.UserService.createUser(this.data.User);
			} else {
				return this.UserService.updateUser(this.data.User);
			};
		},

		resetPassword: function () {
			return this.UserService.resetPassword(this.data.User.id);
		}
	});
});