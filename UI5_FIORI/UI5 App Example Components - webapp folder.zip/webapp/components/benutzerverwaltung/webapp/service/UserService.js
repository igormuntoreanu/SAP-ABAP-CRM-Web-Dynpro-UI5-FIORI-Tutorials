sap.ui.define([
	"./CoreService",
	"apollo/client/thirdparty/apollo",
	"sap/ui/core/SortOrder"
], function (
	CoreService,
	ApolloClient,
	SortOrderCore
) {
	"use strict";

	const { gql } = ApolloClient;

	const GET_USER_HOCHSCHULEN = {
		gql: gql`
		query getUsersHochschulen ($filterTerm: String!) {
			usersHochschulen(filterTerm: $filterTerm) {
				id
				name
				kurzname
			}
		}`,
		queryName: "usersHochschulen"
	};

	const GET_HOCHSCHULEN = {
		gql: gql`
		query getHochschulen {
			hochschulen {
				id
				name
				kurzname
			}
		}`,
		queryName: "hochschulen"
	};

	const GET_USER = {
		gql: gql`
		query GetSingleUser ($keycloak_id: String!) {
			user (keycloak_id: $keycloak_id) {
				id
				keycloak_id
				username
				vorname
				nachname
				hochschulName
				rolle
				vorwahl
				telefonNummer
				emailAdresse
				istHrkZugang
				Hochschule {id name}
			}
		  }`,
		queryName: "user"
	};
	const GET_ALL_USERS = {
		gql: gql`
		query GetAllUsers( $pagination: PaginationInputType!,
						   $searchTerm: String
						   $hochschulId: Float
						   $sortColumn: UserlistSortColumn
						   $sortOrder: SortOrder
		) {
			allUsers( pagination: $pagination,
					  searchTerm: $searchTerm,
					  hochschulId: $hochschulId,
					  sortColumn: $sortColumn,
					  sortOrder: $sortOrder ) {
			  id
			  username
			  vorname
			  nachname
			  initialen
			  rolle
			  is_active
			  is_locked
			  hochschulName
			  istHrkZugang
			  vorwahl
			  telefonNummer
			  emailAdresse
			  activationStatus
			  keycloak_id
			  zustimmungMitPersonenbezogenenDaten
			}
		  }`,
		queryName: "allUsers"
	};

	return CoreService.extend("de.hrk.hochweit.components.Benutzerverwaltung.service.UserService", {

		constructor: function (model, graphQlEndpoint, graphQlWsEndpoint) {
			CoreService.call(this, model, graphQlEndpoint, graphQlWsEndpoint);
		},

		getUser: function (sKeycloakId) {
			return this._apolloService.query({
				query: GET_USER.gql,
				variables: {
					keycloak_id: sKeycloakId
				}
			})
				.then(result => {
					return Promise.resolve({
						data: result.data[GET_USER.queryName]
					});
				});
		},

		getAllUsers: function (sSkip, sTake, sSearch, sHochschulId, sSortColumn, sSortOrder) {
			//Query must contain a value for its variables
			sSearch = (sSearch == null) ? "" : sSearch;
			sHochschulId = (sHochschulId == null) ? "" : sHochschulId;
			sSortColumn = (sSortColumn == null) ? "" : sSortColumn;
			sSortOrder = (sSortOrder == null) ? "" : sSortOrder;

			sHochschulId = parseFloat(sHochschulId);

			if (sSortOrder === SortOrderCore.Ascending) {
				sSortOrder = "asc";
			} else if (sSortOrder === SortOrderCore.Descending) {
				sSortOrder = "desc";
			};

			const oPagination = {
				skip: sSkip,
				take: sTake
			};

			const getData = {
				searchTerm: sSearch,
				hochschulId: sHochschulId,
				pagination: oPagination
			}

			if (!sSortColumn == "") {
				getData.sortColumn = sSortColumn;
				getData.sortOrder = sSortOrder;
			}

			return this._apolloService.query({
				query: GET_ALL_USERS.gql,
				variables: getData
			})
				.then(result => {
					return Promise.resolve({
						data: result.data[GET_ALL_USERS.queryName]
					});
				});
		},

		getHochschulen: function () {
			return this._apolloService.query({
				query: GET_HOCHSCHULEN.gql
			})
				.then(result => {
					return Promise.resolve({
						data: result.data[GET_HOCHSCHULEN.queryName]
					});
				});
		},

		getUsersHochschulen: function (sFilterTerm) {
			sFilterTerm = (sFilterTerm == null) ? "" : sFilterTerm;

			return this._apolloService.query({
				query: GET_USER_HOCHSCHULEN.gql,
				variables: {
					filterTerm: sFilterTerm
				}
			})
				.then(result => {
					return Promise.resolve({
						data: result.data[GET_USER_HOCHSCHULEN.queryName]
					});
				});
		},

		createUser: function (oUser) {

			const CREATE_USER = {
				gql: gql`
				mutation (
							$username: String!,
						  	$vorname: String!,
							$nachname: String!,
							$hochschulId: Int,
							$rolle: String!
							$vorwahl: String!
							$telefonnummer: String!,
							$emailAdresse: Email!
							$istHrkZugang: Boolean
						  )
						{
						 createUser(
							data: {
								username: $username,
								vorname: $vorname,
								nachname: $nachname,
								rolle: $rolle
								hochschulId: $hochschulId,
								vorwahl: $vorwahl,
								telefonnummer: $telefonnummer,
								emailAdresse: $emailAdresse,
								istHrkZugang: $istHrkZugang
							}
							)
						{
							id keycloak_id username vorname nachname hochschulName rolle
							vorwahl telefonNummer emailAdresse istHrkZugang
							Hochschule {id name}
						}
				}`,
			};

			const creationData = {
				username: oUser.username,
				vorname: oUser.vorname,
				nachname: oUser.nachname,
				rolle: oUser.rolle,
				vorwahl: oUser.vorwahl,
				telefonnummer: oUser.telefonNummer,
				emailAdresse: oUser.emailAdresse,
				istHrkZugang: oUser.istHrkZugang
			};

			if (!oUser.rolle.includes("admin")) {
				creationData.hochschulId = parseInt(oUser.hochschulId, 10);
			};

			return this._apolloService.mutate({
				mutation: CREATE_USER.gql,
				variables: creationData
			}).then(result => {
				return Promise.resolve({
					data: result.data.createUser
				});
			});
		},

		updateUser: function (oUser) {
			const UPDATE_USER = {
				gql: gql`
				mutation (
							$id: Int!
							$rolle: String!
							$istHrkZugang: Boolean,
						  	$vorname: String!,
							$nachname: String!,
							$vorwahl: String!
							$telefonnummer: String!,
							$emailAdresse: Email!
						  )
						{
						 updateUser(
							data: {
								id: $id,
								rolle: $rolle,
								istHrkZugang: $istHrkZugang,
								vorname: $vorname,
								nachname: $nachname,
								vorwahl: $vorwahl,
								telefonnummer: $telefonnummer,
								emailAdresse: $emailAdresse
							}
							)
						{
							id keycloak_id username vorname nachname hochschulName rolle
							vorwahl telefonNummer emailAdresse istHrkZugang
							Hochschule {id name}
						}
				}`,
			};

			const updateData = {
				id: oUser.id,
				rolle: oUser.rolle,
				istHrkZugang: oUser.istHrkZugang,
				vorname: oUser.vorname,
				nachname: oUser.nachname,
				vorwahl: oUser.vorwahl,
				telefonnummer: oUser.telefonNummer,
				emailAdresse: oUser.emailAdresse
			};
			return this._apolloService.mutate({
				mutation: UPDATE_USER.gql,
				variables: updateData
			}).then(result => {
				return Promise.resolve({
					data: result.data.updateUser
				});
			});
		},

		resetPassword: function (sId) {
			const RESET_PASSWORD = {
				gql: gql`
				mutation (
							$id: Int!
						  )
						{
						 resetPassword(
								id: $id
							)
						{
							id
						}
				}`,
			};

			const resetPassword = {
				id: sId
			};
			return this._apolloService.mutate({
				mutation: RESET_PASSWORD.gql,
				variables: resetPassword
			}).then(result => {
				return Promise.resolve({
					data: result.data.resetPassword
				});
			});
		},

		deleteUser: function (sId) {

			const DELETE_USER = {
				gql: gql`
				mutation (
							$id: Int!
						  )
						{
						 	deleteUser(
								id: $id
							)
				}`,
			};

			const deleteUser = {
				id: sId
			};
			return this._apolloService.mutate({
				mutation: DELETE_USER.gql,
				variables: deleteUser
			}).then(result => {
				return Promise.resolve({
					data: result.data.deleteUser
				});
			});
		}
	});
});