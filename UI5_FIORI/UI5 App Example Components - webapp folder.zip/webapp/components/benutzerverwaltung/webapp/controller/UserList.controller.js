sap.ui.define([
	"de/hrk/hochweit/components/Benutzerverwaltung/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/SortOrder",
	"sap/m/Dialog",
	"sap/m/DialogType",
	"sap/m/Button",
	"sap/m/ButtonType",
	"sap/m/Text",
	"sap/base/Log",
	"sap/m/PlacementType"
],
	// eslint-disable-next-line no-unused-vars
	function (BaseController,
	JSONModel,
	SortOrder,
	Dialog,
	DialogType,
	Button,
	ButtonType,
	Text,
	Log,
	PlacementType) {
		"use strict";

		return BaseController.extend("de.hrk.hochweit.components.Benutzerverwaltung.controller.UserList", {
			/**
				 * Called when the master list controller is instantiated. It sets up the event handling for the master/detail communication and other lifecycle tasks.
				 * @public
				 */
			onInit: function () {
				// Control state model
				var oList = this.byId("list"),
					oViewModel = this._createViewModel(),
					// Put down master list's original value for busy indicator delay,
					// so it can be restored later on. Busy handling on the master list is
					// taken care of by the master list itself.
					iOriginalBusyDelay = oList.getBusyIndicatorDelay();

				this._oList = oList;
				// keeps the filter and search state
				this._oListFilterState = {
					aFilter: [],
					aSearch: []
				};

				this.setModel(oViewModel, "masterView");
				// Make sure, busy indication is showing immediately so there is no
				// break after the busy indication for loading the view's meta data is
				// ended (see promise 'oWhenMetadataIsLoaded' in AppController)
				oList.attachEventOnce("updateFinished", function () {
					// Restore original busy indicator delay for the list
					oViewModel.setProperty("/delay", iOriginalBusyDelay);
				});

				// Defines number of entries that is fetched when the table grows
				oViewModel.setProperty("/growingThreshold", this._oList.getProperty("growingThreshold") + 1);
				oViewModel.setProperty("/lastHeaderSortKey", undefined);
				oViewModel.setProperty("/lastHeaderDescending", true);

				// this needs to happen every time, if it does not happen timely then the bound master list is not set.
				this.getView().addEventDelegate({
					onBeforeFirstShow: function () {
						this.getOwnerComponent().oListSelector.setBoundMasterList(oList);
					}.bind(this)
				});

				this.listmodel = new JSONModel();
				this.getView().setModel(this.listmodel);

				this.getRouter().getRoute("userList").attachPatternMatched(this._onMasterMatched, this);
				this.getRouter().getRoute("editUser").attachPatternMatched(this._onMasterMatched, this);
				this.getRouter().getRoute("userCreate").attachPatternMatched(this._onMasterMatched, this);
				this.getRouter().attachBypassed(this.onBypassed, this);
				// User Service to execute the queries
				this._userService = this.getOwnerComponent().getService(this.getOwnerComponent().USER);
				// Get User Login Data from the Model, which is inherited from toplevel Component.js
				this._login = this.getOwnerComponent().getModel("login");
				// Get Hochschulen, that are assigned to the Users at the moment
				this._getUserHochschulen();
				// EventBus to update the User and Hochschulen in the UserList after changing and saving something at the User Edit View.
				this.getOwnerComponent().getEventBus().subscribe(
					"benutzerverwaltung",
					"updateUserList",
					this._reloadUsersAfterAdjustments,
					this);

				this.getOwnerComponent().getEventBus().subscribe(
					"benutzerverwaltung",
					"updateHochschuleList",
					this._reloadUsersHochschulen,
					this);
			},

			/* =========================================================== */
			/* event handlers                                              */
			/* =========================================================== */

			onUpdateStarted: function (oEvent) {
				// Check if the table is growing - Infinite Scrolling
				if (oEvent.getParameter("reason") === ("Growing")) {
					this._getUsers(true); //isScrolling
				}
			},
			/**
			 * After list data is available, this handler method updates the
			 * master list counter
			 * @param {sap.ui.base.Event} oEvent the update finished event
			 * @public
			 */
			onUpdateFinished: function (oEvent) {
				// update the master list object counter after new data is loaded
				this._updateListItemCount(oEvent.getParameter("total"));
			},
			/**
			 * Event handler for the list selection event
			 * @param {sap.ui.base.Event} oEvent the list selectionChange event
			 * @public
			 */
			onSelectionChange: function (oEvent) {

				var hasLinesToActivate = false;
				var hasLinesToDeactivate = false;
				var hasLinesToUnlock = false;
				var oItems = oEvent.getSource().getSelectedItems();
				var selectedItems = [];

				if (oItems.length > 1) {
					oItems.forEach((oLine) => {
						const oData = oLine.getBindingContext().getObject();
						if (oData.is_active) {
							hasLinesToDeactivate = true;
						} else {
							hasLinesToActivate = true;
						}
						if (oData.is_locked) {
							hasLinesToUnlock = true;
						}

						selectedItems.push(oData);

					});

					if (hasLinesToActivate) {
						this.getModel("masterView").setProperty("/hasLinesToActivate", true);
					} else {
						this.getModel("masterView").setProperty("/hasLinesToActivate", false);
					};

					if (hasLinesToDeactivate) {
						this.getModel("masterView").setProperty("/hasLinesToDeactivate", true);
					} else {
						this.getModel("masterView").setProperty("/hasLinesToDeactivate", false);
					};

					if (hasLinesToUnlock) {
						this.getModel("masterView").setProperty("/hasLinesToUnlock", true);
					} else {
						this.getModel("masterView").setProperty("/hasLinesToUnlock", false);
					};
					//Add Selected Items to a Model
					this.getView().setModel(new JSONModel(selectedItems), "selectedItems");

					this.getModel("masterView").setProperty("/isFooterVisible", true);
				} else {
					this.getModel("masterView").setProperty("/isFooterVisible", false);
				};
			},

			/**
			 * Event handler for the master search field. Applies current
			 * filter value and triggers a new search.
			 * @param {sap.ui.base.Event} oEvent the search event
			 * @public
			 */
			onSearch: function (oEvent) {
				var sQuery = oEvent.getParameter("query");
				this.getModel("masterView").setProperty("/searchterm", sQuery);
				this._paginatingCursor = 0;
				//fetch data with the search input as filter
				this._getUsers(false); //isScrolling

			},

			/**
			 * Event handler for the bypassed event, which is fired when no routing pattern matched.
			 * If there was an object selected in the master list, that selection is removed.
			 * @public
			 */
			onBypassed: function () {
				this._oList.removeSelections(true);
			},

			/**
			 * Sort table by table header.
			 * @param {Object} oEvent from the header
			 */
			onTableHeaderButtonClick: function (sPath) {
				const oViewModel = this.getModel("masterView");
				// Set new sorting column
				const sCurrentSortingColumn = oViewModel.getProperty("/sorting/column");
				const bSortSameColumn = (sCurrentSortingColumn === sPath);
				if (!bSortSameColumn) {
					oViewModel.setProperty("/sorting/column", sPath);
				}

				// Set sortIndicator direction
				var sNewSortingDirection = SortOrder.Ascending;
				const sCurrentSortingDirection = oViewModel.getProperty("/sorting/direction");
				if (bSortSameColumn && sCurrentSortingDirection === SortOrder.Ascending) {
					sNewSortingDirection = SortOrder.Descending;
				}
				oViewModel.setProperty("/sorting/direction", sNewSortingDirection);

				this._paginatingCursor = 0;

				this._getUsers(false); //isScrolling

				this.listmodel.setProperty("/sorting", { "sortColumn": sPath, "sortOrder": sNewSortingDirection });

			},

			onNewUser: function (oEvent) {
				const fnNavToNewUser = () => {
					this.navTo("userCreate");
				};
				if (this.getModel("state").getProperty("/hasPendingChanges")) {
					this._promptAndExecute(
						oEvent.getSource(),
						PlacementType.VerticalPreferredBottom,
						this.promptType.CANCEL,
						this.getResourceBundle().getText("app.common.pendingChanges.prompt.text"),
						this.getResourceBundle().getText("app.common.confirm.text"),
						fnNavToNewUser
					  );
				} else {
					fnNavToNewUser();
				}
			},

			onEdit: function (sKeycloackId, oEvent) {
				const fnNavToEditUser = () => {
					this.navTo("editUser", {
						userId: sKeycloackId
					});
				};
				if (this.getModel("state").getProperty("/hasPendingChanges")) {
					this._promptAndExecute(
						oEvent.getSource(),
						PlacementType.HorizontalPreferredLeft,
						this.promptType.CANCEL,
						this.getResourceBundle().getText("app.common.pendingChanges.prompt.text"),
						this.getResourceBundle().getText("app.common.confirm.text"),
						fnNavToEditUser
					  );
				} else {
					fnNavToEditUser();
				}
			},

			onHochschuleChange: function () {
				this._paginatingCursor = 0;
				this._getUsers(false); //isScrolling
			},

			onDeleteUser: function (sId, mulipleItems) {
				this.oApproveDialog = new Dialog({
					type: DialogType.Message,
					title: this.getResourceBundle().getText("user.list.message.delete.confirm.title"),
					content: new Text({ text: this.getResourceBundle().getText("user.list.message.delete.confirm") }),
					beginButton: new Button({
						type: ButtonType.Emphasized,
						text: this.getResourceBundle().getText("user.list.message.delete.confirm.button"),
						press: function () {

							if (!mulipleItems) {
								this._deleteUser(sId);
							} else {
								var oItems = this.getView().getModel("selectedItems").getData();
								oItems.forEach((oLine) => {
									this._deleteUser(oLine.id);
								});
							}

							// Update ListView with the new User Data
							this._paginatingCursor = 0;
							this.getOwnerComponent().getEventBus().publish(
								"benutzerverwaltung",
								"updateUserList");
							// Update Hochschule ListView
							this.getOwnerComponent().getEventBus().publish(
								"benutzerverwaltung",
								"updateHochschuleList");

							this.oApproveDialog.close();
						}.bind(this)
					}),
					endButton: new Button({
						text: this.getResourceBundle().getText("user.list.message.delete.cancel.button"),
						press: function () {
							this.oApproveDialog.close();
						}.bind(this)
					})
				});
				this.oApproveDialog.open();
			},

			onDeleteUsers: function () {
				this.onDeleteUser(null, true);
			},

			onNavigate: function (oEvent) {
				const fnOnNavigateConfirmed = () => {
					const oNav = { target: "administrativeFunktionen", parameters: {}, replace: true };
					sap.ui.getCore().getEventBus().publish("rootComponent", "navTo", oNav);
				};

				if (this.getModel("state").getProperty("/hasPendingChanges")) {
					this._promptAndExecute(
						oEvent.getSource(),
						PlacementType.VerticalPreferredBottom,
						this.promptType.CANCEL,
						this.getResourceBundle().getText("app.common.pendingChanges.prompt.text"),
						this.getResourceBundle().getText("app.common.confirm.text"),
						fnOnNavigateConfirmed);
				} else {
					fnOnNavigateConfirmed();
				}
			},


			/* =========================================================== */
			/* begin: internal methods                                     */
			/* =========================================================== */
			_createViewModel: function () {
				return new JSONModel({
					delay: 0,
					title: this.getResourceBundle().getText("app.navigation.breadcrumb.benutzerverwaltung", [0]),
					noDataText: this.getResourceBundle().getText("user.list.NoDataText"),
					isFooterVisible: false,
					hasLinesToUnlock: false,
					hasLinesToActivate: false,
					hasLinesToDeactivate: false,
					sorting: {
						column: undefined,
						direction: SortOrder.Ascending
					}
				});
			},
			_onMasterMatched: function (oEvent) {
				//Set the layout property of the FCL control to 'OneColumn'
				if (oEvent.getParameter("name") === "userList") {
					this.getModel("appView").setProperty("/layout", "OneColumn");
				};

				this._paginatingCursor = 0;
				this._getUsers(false); //isScrolling
			},

			/**
			 * Sets the item count on the master list header
			 * @param {integer} iTotalItems the total number of items in the list
			 * @private
			 */
			_updateListItemCount: function (iTotalItems) {
				var sTitle;
				// only update the counter if the length is final
				if (this._oList.getBinding("items").isLengthFinal()) {
					sTitle = this.getResourceBundle().getText("app.navigation.breadcrumb.benutzerverwaltung", [iTotalItems]);
					this.getModel("masterView").setProperty("/title", sTitle);
				}
			},

			_deleteUser: function (id) {
				this._userService.deleteUser(id)
					.then(function () {
						Log.info(this.getResourceBundle().getText("user.list.message.delete.success") + id);
					}.bind(this))
					.catch(oError => {
						Log.error(this.getResourceBundle().getText("user.list.message.delete.error")); // eslint-disable-line no-console
						Log.error(oError.message + "\n" + oError.stack); // eslint-disable-line no-console
					});
			},

			_getUsers: function (isScrolling) {
				const oViewModel = this.getModel("masterView");
				//Fill Filter and Sorting with their current values
				const sSkip = this._paginatingCursor;
				const sTake = oViewModel.getProperty("/growingThreshold")
				const sSearch = oViewModel.getProperty("/searchterm");
				const sHochschulId = this.getView().byId("selectHoschule").getSelectedKey();
				const sSortColumn = oViewModel.getProperty("/sorting/column");
				const sSortOrder = oViewModel.getProperty("/sorting/direction");

				this._userService.getAllUsers(sSkip, sTake, sSearch, sHochschulId, sSortColumn, sSortOrder)
					.then(function (users) {
						if (!isScrolling) {
							//Reset model to ensure correct Context values and to keep infinite scrolling working
							this.listmodel = new JSONModel();
							this.getView().setModel(this.listmodel);
							this.listmodel.setProperty("/Users", users.data);
							this._paginatingCursor = this.getModel("masterView").getProperty("/growingThreshold");
						} else {
							this.listmodel.setProperty("/Users", this.listmodel.getProperty("/Users").concat(users["data"]));
							this._paginatingCursor += this.getModel("masterView").getProperty("/growingThreshold");
						}
					}.bind(this))
					.catch(oError => {
						Log.error(this.getResourceBundle().getText("user.list.NoDataWithFilterOrSearchText")); // eslint-disable-line no-console
						Log.error(oError.message + "\n" + oError.stack); // eslint-disable-line no-console
					});
			},

			_reloadUsersAfterAdjustments: function () {
				this._paginatingCursor = 0;
				this._getUsers(false); //isScrolling
			},

			_reloadUsersHochschulen: function () {
				this._getUserHochschulen();
			},

			_getUserHochschulen: function (sFilterTerm) {
				var sLogin = this._login.getData();
				// DO the query only for Admins or higher
				if (sLogin.role && sLogin.role.includes("admin")) {
					//Fetch the data and store it in the model
					this._userService.getUsersHochschulen(sFilterTerm)
						.then(function (hochschulen) {
							this.getView().setModel(new JSONModel(hochschulen.data), "userHochschule");
						}.bind(this))
						.catch(oError => {
							Log.error(this.getResourceBundle().getText("user.list.message.fail.load.userhochschulen"));
							Log.error(oError.message + "\n" + oError.stack);
						});
				}
			}
		});
	});
