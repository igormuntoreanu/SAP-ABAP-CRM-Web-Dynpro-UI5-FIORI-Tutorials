sap.ui.define([
	"de/hrk/hochweit/components/Benutzerverwaltung/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/ValueState",
	"sap/ui/core/message/Message",
	"sap/ui/core/MessageType",
	"sap/m/MessagePopover",
	"sap/m/MessageItem",
	"sap/base/Log",
	"sap/m/PlacementType"
], function (
	BaseController,
	JSONModel,
	ValueState,
	Message,
	MessageType,
	MessagePopover,
	MessageItem,
	Log,
	PlacementType
) {
	"use strict";

	return 	BaseController.extend("de.hrk.hochweit.components.Benutzerverwaltung.controller.UserEdit", {

		onInit: function () {

			var oViewModel = this._createViewModel();
			this.setModel(oViewModel, "detailView");

			this.getRouter().getRoute("userCreate").attachPatternMatched(this._onCreateUser, this);
			this.getRouter().getRoute("editUser").attachPatternMatched(this._onEditUser, this);
			// User Service to execute the queries
			this._userService = this.getOwnerComponent().getService(this.getOwnerComponent().USER);
			this._userState = this.getOwnerComponent().getState(this.getOwnerComponent().USER);

			this.setModel(this._userState.getModel());
			//Prepare Message Manager
			this._prepareMessageManager();
			// Get User Login Data from the Model, which is inherited from toplevel Component.js
			this._login = this.getOwnerComponent().getModel("login");
			// Get Hochschulen to display as a Dropdown-list
			this._getHochschulen();
		},

		onCancel: function (oEvent) {
			// Only prompt when changes were made
			const fnOnCancelConfirmed = () => {
				this.getOwnerComponent().liftPendingChanges();
				this.getView().getModel().detachPropertyChange(this._somethingChanged, this);
				this.navTo("userList");
			};
			if (this.getModel("state").getProperty("/hasPendingChanges")) {
				this._promptAndExecute(
					oEvent.getSource(),
					PlacementType.VerticalPreferredTop,
					this.promptType.CANCEL,
					this.getResourceBundle().getText("user.edit.footer.cancel.prompt.text"),
					this.getResourceBundle().getText("user.edit.footer.cancel.action.confirm"),
					fnOnCancelConfirmed);
			} else {
				fnOnCancelConfirmed();
			}
		},

		onSave: function () {

			if (!this._validateInputs()) { // If does not return an error, proceed
				this._userState.maintainUser(this.getModel("detailView").getProperty("/isCreation"))
					.then(function (User) {
						var oUser = this._userState.getModel().getData();
						oUser.User = User.data;
						oUser.User.hochschulId = ((!User.data.Hochschule) ? null : User.data.Hochschule.id);
						this._userState.getModel().setData(oUser);
						// Update ListView with the new User Data
						this.getOwnerComponent().getEventBus().publish(
							"benutzerverwaltung",
							"updateUserList");
						// Update ListView of Hochschulen Data
						this.getOwnerComponent().getEventBus().publish(
							"benutzerverwaltung",
							"updateHochschuleList");

						this._MessageManager.removeAllMessages();
						this.getModel("detailView").setProperty("/hasErrorMessage", false);
						this.getOwnerComponent().liftPendingChanges();

						// Display message after user edition or creation
						this._MessageManager.addMessages(
							new Message({
								message: this.getResourceBundle().getText("user.edit.save.success") + oUser.User.username,
								type: MessageType.Success,
								processor: this.getView().getModel()
							})
						);
						// After Creating an User, set the screen to editing mode.
						if (this.getModel("detailView").getProperty("/isCreation")) {
							this._onEditUserHandleScreen();
						}
						this._onHandleRolleListe(oUser.User.rolle, oUser.User.keycloak_id);
					}.bind(this))
					.catch(oError => {
						this.getModel("detailView").setProperty("/hasErrorMessage", true);
						this._MessageManager.addMessages(
							new Message({
								message: this.getResourceBundle().getText("user.edit.save.error"),
								additionalText: oError.message + "\n" + oError.stack,
								type: MessageType.Error,
								processor: this.getView().getModel()
							})
						);
					});
			}
		},

		toggleFullScreen: function () {
			var bFullScreen = this.getModel("appView").getProperty("/actionButtonsInfo/midColumn/fullScreen");
			this.getModel("appView").setProperty("/actionButtonsInfo/midColumn/fullScreen", !bFullScreen);
			if (!bFullScreen) {
				// store current layout and go full screen
				this.getModel("appView").setProperty("/previousLayout", this.getModel("appView").getProperty("/layout"));
				this.getModel("appView").setProperty("/layout", "MidColumnFullScreen");
			} else {
				// reset to previous layout
				this.getModel("appView").setProperty("/layout", this.getModel("appView").getProperty("/previousLayout"));
			};
		},

		onMessagePopoverPress: function (oEvent) {
			this.oMP.toggle(oEvent.getSource());
		},

		onRoleChange: function () {
			var oUser = this._userState.getModel().getData();
			if (oUser.User.rolle === "hsb" || oUser.User.rolle === "power_user") {
				this.getModel("detailView").setProperty("/isSelectHochschulnameVisible", true);
				this.getModel("detailView").setProperty("/isLabelHochschulnameVisible", true);
			} else { //Admin roles or no role
				this.getModel("detailView").setProperty("/isSelectHochschulnameVisible", false);
				this.getModel("detailView").setProperty("/isLabelHochschulnameVisible", false);
			}
		},

		onPasswordReset: function () {
			this._userState.resetPassword()
				.then(function () {
					this._MessageManager.removeAllMessages();
					this.getModel("detailView").setProperty("/hasErrorMessage", false);
					this._MessageManager.addMessages(
						new Message({
							message: this.getResourceBundle().getText("user.edit.password.success"),
							type: MessageType.Success,
							processor: this.getView().getModel()
						})
					);
				}.bind(this))
				.catch(oError => {
					this._MessageManager.removeAllMessages();
					this.getModel("detailView").setProperty("/hasErrorMessage", true);
					this._MessageManager.addMessages(
						new Message({
							message: this.getResourceBundle().getText("user.edit.password.error"),
							additionalText: oError.message + "\n" + oError.stack,
							type: MessageType.Error,
							processor: this.getView().getModel()
						})
					);
				});
		},

		onNavigate: function (sNavTo, oEvent) {
			if (this.getModel("state").getProperty("/hasPendingChanges")) {
				const fnOnNavigateConfirmed = () => {
					this.getOwnerComponent().liftPendingChanges();
					this.getView().getModel().detachPropertyChange(this._somethingChanged, this);
					this._navigate(sNavTo);
				};

				this._promptAndExecute(
					oEvent.getSource(),
					PlacementType.VerticalPreferredBottom,
					this.promptType.CANCEL,
					this.getResourceBundle().getText("app.common.pendingChanges.prompt.text"),
					this.getResourceBundle().getText("app.common.confirm.text"),
					fnOnNavigateConfirmed);
			} else {
				fnOnNavigateConfirmed();
			}
		},

		_navigate: function (sNavTo) {
			if (sNavTo === "AdministrativeFunktionen") {
				const oNav = { target: "administrativeFunktionen", parameters: {}, replace: true };
				sap.ui.getCore().getEventBus().publish("rootComponent", "navTo", oNav);
			} else if (sNavTo === "Benutzerverwaltung") {
				this.getOwnerComponent().getRouter().navTo("userList", {}, true);
			}
		},

		/* =========================================================== */
		/* begin: internal methods                                     */
		/* =========================================================== */
		_createViewModel: function () {
			return new JSONModel({
				isRolleEnabled: true,
				isInputUsernameEnabled: false,
				isInputHochschulnameEnabled: false,
				isSelectHochschulnameVisible: true,
				isLabelHochschulnameVisible: true,
				isPasswordResetVisible: false,
				isCreation: false, // Creating or Editing
				isSomethingChanged: false,
				hasErrorMessage: false, // Used to change the icon in the footer for the message Popover
				inputRolleState: ValueState.None,
				inputUsernameState: ValueState.None,
				inputHochschuleState: ValueState.None,
				inputVornameState: ValueState.None,
				inputNachnameState: ValueState.None,
				inputTelefonnummerState: ValueState.None,
				inputVorwahlStateState: ValueState.None,
				inputEmailState: ValueState.None,
			});
		},

		_onCreateUser: function () {
			//Rolle Select into UI as Drop Down List
			this._setRollenIntoUi();
			this._clearFields();
			this._resetFieldsStates();
			this.getModel("appView").setProperty("/layout", "TwoColumnsMidExpanded");

			this.getModel("detailView").setProperty("/isCreation", true);
			this.getModel("detailView").setProperty("/isInputUsernameEnabled", true);
			this.getModel("detailView").setProperty("/isRolleEnabled", true);
			this.getModel("detailView").setProperty("/isPasswordResetVisible", false);

			const oLogin = this._login.getData();
			if (oLogin.role === "power_user") {
				var oData = this.getView().getModel().getData();
				oData.User.hochschulId = oLogin.user.hochschulId;
				this.getView().getModel().setData(oData);
				this.getModel("detailView").setProperty("/isInputHochschulnameEnabled", false);
			} else {
				this.getModel("detailView").setProperty("/isInputHochschulnameEnabled", true);
			}
			// Clear the old messages
			this._MessageManager.removeAllMessages();
			this.getView().getModel().attachPropertyChange(this._somethingChanged, this);
		},
		_onEditUser: function (oEvent) {
			//Rolle Select into UI as Drop Down List
			this._setRollenIntoUi();
			this._resetFieldsStates();
			this.getModel("appView").setProperty("/layout", "TwoColumnsMidExpanded");
			this._userState.getUser(oEvent.getParameter("arguments").userId)
				.then(function () {
					this.setModel(this._userState.getModel());
					var oData = this.getView().getModel().getData();
					if (oData.User.rolle.includes("admin")) {
						this.getModel("detailView").setProperty("/isLabelHochschulnameVisible", false);
						this.getModel("detailView").setProperty("/isSelectHochschulnameVisible", false);
					} else {
						this.getModel("detailView").setProperty("/isLabelHochschulnameVisible", true);
						this.getModel("detailView").setProperty("/isSelectHochschulnameVisible", true);
						oData.User.hochschulId = ((!oData.User.Hochschule) ? null : oData.User.Hochschule.id);
					}
					this._onHandleRolleListe(oData.User.rolle, oData.User.keycloak_id);
					this.getView().getModel().setData(oData);
					this.getView().getModel().attachPropertyChange(this._somethingChanged, this);
					this.getOwnerComponent().liftPendingChanges();
					this.getModel("detailView").setProperty("/hasErrorMessage", false);
				}.bind(this))
				.catch(oError => {
					this.getModel("detailView").setProperty("/hasErrorMessage", true);
					Log.error(this.getResourceBundle().getText("user.list.NoDataWithFilterOrSearchText"));
					Log.error(oError.message + "\n" + oError.stack);
				});
			this._onEditUserHandleScreen();
			// Clear the old messages
			this._MessageManager.removeAllMessages();
		},

		_onEditUserHandleScreen: function () {
			this.getModel("detailView").setProperty("/isCreation", false);
			this.getModel("detailView").setProperty("/isInputUsernameEnabled", false);
			this.getModel("detailView").setProperty("/isInputHochschulnameEnabled", false);
			this.getModel("detailView").setProperty("/isPasswordResetVisible", true);
		},

		_onHandleRolleListe: function (actualRolle, keycloakId) {
			// After creating or when editing an User:
			// If the choosen role is admin or higher, it will be possible only to switch/choose one of the admin roles
			// If the choosen role is power_user or hsb, then the possiblity will be only power_user or hsb
			var oRollen = this.getView().getModel("rolles").getData();
			const oLogin = this._login.getData();
			// Do not allow the user to degrate his own role (When navigating from Dashboard)
			if (oLogin.user.keycloakId === keycloakId) {
				oRollen.rolle = [];

				switch (actualRolle) {
					case "power_user":
						var sDescription = this.getResourceBundle().getText("user.edit.footer.rolles.poweruser");
						break;
					case "admin":
						sDescription = this.getResourceBundle().getText("user.edit.footer.rolles.admin");
						break;
					case "fach_admin":
						sDescription = this.getResourceBundle().getText("user.edit.footer.rolles.fadmin");
						break;
					case "tech_admin":
						sDescription = this.getResourceBundle().getText("user.edit.footer.rolles.tadmin");
						break;
					default:
						break;
				};
				const oOwnRole =  { key: actualRolle, description: sDescription };
				oRollen.rolle.push(oOwnRole);
				this.byId("selectRolle").setSelectedItem(actualRolle);
				this.getModel("detailView").setProperty("/isRolleEnabled", false);
			} else {

				if (actualRolle === "power_user" || actualRolle === "hsb") {
					//Do not allow to set Admin and Higher
					oRollen.rolle = oRollen.rolle.filter(line => (line.key === "power_user" || line.key === "hsb"));
				} else {
					//Do not allow to set Power User and Hsb
					oRollen.rolle = oRollen.rolle.filter(line => (line.key === "admin" || line.key === "fach_admin" || line.key === "tech_admin"));
				}

				this.getModel("detailView").setProperty("/isRolleEnabled", true);
			}

			this.getView().getModel("rolles").setData(oRollen);

		},
		_somethingChanged: function () {
			this.getOwnerComponent().declarePendingChanges();
		},

		_clearFields: function () {
			// Empty fields before creation
			var oData = this.getView().getModel().getData();
			var props = Object.getOwnPropertyNames(oData.User);
			for (var i = 0; i < props.length; i++) {
				oData.User[props[i]] = null;
			}
			this.getView().getModel().setData(oData);

			this.getModel("detailView").setProperty("/hasErrorMessage", false);
			this.getOwnerComponent().liftPendingChanges();
		},

		_resetFieldsStates: function () {
			this.getModel("detailView").setProperty("/inputRolleState", ValueState.None);
			this.getModel("detailView").setProperty("/inputUsernameState", ValueState.None);
			this.getModel("detailView").setProperty("/inputVornameState", ValueState.None);
			this.getModel("detailView").setProperty("/inputNachnameState", ValueState.None);
			this.getModel("detailView").setProperty("/inputTelefonnummerState", ValueState.None);
			this.getModel("detailView").setProperty("/inputVorwahlState", ValueState.None);
			this.getModel("detailView").setProperty("/inputEmailState", ValueState.None);
			this.getModel("detailView").setProperty("/inputHochschuleState", ValueState.None);
		},

		_onBindingChange: function () {
			var oView = this.getView(),
				oElementBinding = oView.getElementBinding("");
			if (!oElementBinding.getBoundContext("")) {
				this.getRouter().getTargets().display("NotFound");
			};
		},

		_setRollenIntoUi: function () {
			// TODO: Replace by using getManageableRoles backend call!
			let oRolles = {
				rolle: []
			};
			const oLogin = this._login.getData();
			const oHsb = { key: "hsb", description: this.getResourceBundle().getText("user.edit.footer.rolles.hsb") };
			const oPowerUser = { key: "power_user", description: this.getResourceBundle().getText("user.edit.footer.rolles.poweruser") };
			const oAdmin = { key: "admin", description: this.getResourceBundle().getText("user.edit.footer.rolles.admin") };
			const oFAdmin = { key: "fach_admin", description: this.getResourceBundle().getText("user.edit.footer.rolles.fadmin") };
			const oTAdmin = { key: "tech_admin", description: this.getResourceBundle().getText("user.edit.footer.rolles.tadmin") };

			switch (oLogin.role) {
				case "power_user":
					oRolles.rolle.push(oHsb);
					break;
				case "admin":
					oRolles.rolle.push(oHsb, oPowerUser);
					break;
				case "fach_admin":
					oRolles.rolle.push(oHsb, oPowerUser, oAdmin);
					break;
				case "tech_admin":
					oRolles.rolle.push(oHsb, oPowerUser, oAdmin, oFAdmin, oTAdmin);
					break;
				default:
					break;
			};

			var oModel = new JSONModel(oRolles);
			this.getView().setModel(oModel, "rolles");
		},

		_addMessage: function (sMessage, sDescription, sAdditional, sType) {
			this._MessageManager.addMessages(
				new Message({
					message: sMessage,
					description: sDescription,
					type: sType,
					additionalText: sAdditional,
					processor: this.getView().getModel()
				}));
		},

		_validateInputs: function () {
			//Clear all messages from the Message Manager
			this._MessageManager.removeAllMessages();
			//Validate if required fields were provided
			var oUser = this._userState.getModel().getData().User;
			var oError = false;

			if (!oUser.rolle) {
				this._addMessage(
					this.getResourceBundle().getText("user.edit.validation.required.fields.title"),
					this.getResourceBundle().getText("user.edit.validation.required.fields.rolle"),
					this.getResourceBundle().getText("user.edit.validation.required.fields.rolle"),
					MessageType.Error);

				this.getModel("detailView").setProperty("/inputRolleState", ValueState.Error);
				oError = true;
			} else {
				this.getModel("detailView").setProperty("/inputRolleState", ValueState.None);
			}

			if (!oUser.username) {
				this._addMessage(
					this.getResourceBundle().getText("user.edit.validation.required.fields.title"),
					this.getResourceBundle().getText("user.edit.validation.required.fields.username"),
					this.getResourceBundle().getText("user.edit.validation.required.fields.username"),
					MessageType.Error);

				this.getModel("detailView").setProperty("/inputUsernameState", ValueState.Error);
				oError = true;
			} else {
				this.getModel("detailView").setProperty("/inputUsernameState", ValueState.None);
			}

			if (!oUser.vorname) {
				this._addMessage(
					this.getResourceBundle().getText("user.edit.validation.required.fields.title"),
					this.getResourceBundle().getText("user.edit.validation.required.fields.vorname"),
					this.getResourceBundle().getText("user.edit.validation.required.fields.vorname"),
					MessageType.Error);

				this.getModel("detailView").setProperty("/inputVornameState", ValueState.Error);
				oError = true;
			} else {
				this.getModel("detailView").setProperty("/inputVornameState", ValueState.None);
			}

			if (!oUser.nachname) {
				this._addMessage(
					this.getResourceBundle().getText("user.edit.validation.required.fields.title"),
					this.getResourceBundle().getText("user.edit.validation.required.fields.nachname"),
					this.getResourceBundle().getText("user.edit.validation.required.fields.nachname"),
					MessageType.Error);

				this.getModel("detailView").setProperty("/inputNachnameState", ValueState.Error);
				oError = true;
			} else {
				this.getModel("detailView").setProperty("/inputNachnameState", ValueState.None);
			}

			if (!oUser.telefonNummer) {
				this._addMessage(
					this.getResourceBundle().getText("user.edit.validation.required.fields.title"),
					this.getResourceBundle().getText("user.edit.validation.required.fields.telefonnummer"),
					this.getResourceBundle().getText("user.edit.validation.required.fields.telefonnummer"),
					MessageType.Error);

				this.getModel("detailView").setProperty("/inputTelefonnummerState", ValueState.Error);
				oError = true;
			} else {

				const sTelefonRegex = /^[0-9|-]*$/;
				if (!sTelefonRegex.test(oUser.telefonNummer)) {
					this._addMessage(
						this.getResourceBundle().getText("user.edit.validation.required.fields.title"),
						this.getResourceBundle().getText("user.edit.validation.telefon.wrong.format"),
						this.getResourceBundle().getText("user.edit.validation.telefon.wrong.regex"),
						MessageType.Error);

					oError = true;
					this.getModel("detailView").setProperty("/inputTelefonnummerState", ValueState.Error);

				} else {
					this.getModel("detailView").setProperty("/inputTelefonnummerState", ValueState.None);
				}

			}

			if (!oUser.vorwahl) {
				this._addMessage(
					this.getResourceBundle().getText("user.edit.validation.required.fields.title"),
					this.getResourceBundle().getText("user.edit.validation.required.fields.vorwahl"),
					this.getResourceBundle().getText("user.edit.validation.required.fields.vorwahl"),
					MessageType.Error);

				this.getModel("detailView").setProperty("/inputVorwahlState", ValueState.Error);
				oError = true;
			} else {
				const sVorwahlRegex = /^[0-9]*$/;
				if (!sVorwahlRegex.test(oUser.vorwahl)) {
					this._addMessage(
						this.getResourceBundle().getText("user.edit.validation.required.fields.title"),
						this.getResourceBundle().getText("user.edit.validation.vorwahl.wrong.format"),
						this.getResourceBundle().getText("user.edit.validation.vorwahl.wrong.regex"),
						MessageType.Error);

					oError = true;
					this.getModel("detailView").setProperty("/inputVorwahlState", ValueState.Error);

				} else {
					this.getModel("detailView").setProperty("/inputVorwahlState", ValueState.None);
				}
			}

			if (!oUser.emailAdresse) {
				this._addMessage(
					this.getResourceBundle().getText("user.edit.validation.required.fields.title"),
					this.getResourceBundle().getText("user.edit.validation.required.fields.email"),
					this.getResourceBundle().getText("user.edit.validation.required.fields.email"),
					MessageType.Error);

				this.getModel("detailView").setProperty("/inputEmailState", ValueState.Error);
				oError = true;

			} else { //Validate E-Mail
				const sMailregex = /^\w+[\w-+\.]*\@\w+([-\.]\w+)*\.[a-zA-Z]{2,}$/;
				if (!sMailregex.test(oUser.emailAdresse)) {
					this._addMessage(
						this.getResourceBundle().getText("user.edit.validation.required.fields.title"),
						this.getResourceBundle().getText("user.edit.validation.email.wrong.format"),
						this.getResourceBundle().getText("user.edit.validation.email.wrong.regex"),
						MessageType.Error);

					oError = true;
					this.getModel("detailView").setProperty("/inputEmailState", ValueState.Error);

				} else {
					this.getModel("detailView").setProperty("/inputEmailState", ValueState.None);
				}
			}

			if (!oUser.hochschulId) { //Hochschule only for hsb and power_user
				if (!oUser.rolle || !oUser.rolle.includes("admin")) {
					this._addMessage(
						this.getResourceBundle().getText("user.edit.validation.required.fields.title"),
						this.getResourceBundle().getText("user.edit.validation.required.fields.hochschule"),
						this.getResourceBundle().getText("user.edit.validation.required.fields.hochschule"),
						MessageType.Error);

					this.getModel("detailView").setProperty("/inputHochschuleState", ValueState.Error);
					oError = true;
				}
			} else {
				this.getModel("detailView").setProperty("/inputHochschuleState", ValueState.None);
			}

			if (oError) {
				this.getModel("detailView").setProperty("/hasErrorMessage", true);
			}
			return oError;
		},

		_prepareMessageManager: function () {
			this.oView = this.getView();
			this._MessageManager = sap.ui.getCore().getMessageManager();
			// Clear the old messages
			this._MessageManager.removeAllMessages();

			this._MessageManager.registerObject(this.oView.byId("UserEditSimpleForm"), true);
			this.oView.setModel(this._MessageManager.getMessageModel(), "message");

			var oMessageTemplate = new MessageItem({
				type: "{message>type}",
				title: "{message>message}",
				activeTitle: "{message>active}",
				description: "{message>additionalText}",
				subtitle: "{message>description}",
				counter: "{message>counter}"
			});

			this.oMP = new MessagePopover({
				items: {
					path: "message>/",
					template: oMessageTemplate
				}
			});

			this.byId("messageNotification").addDependent(this.oMP);
		},

		_getHochschulen: function () {
			//Fetch the data and store it in the model
			this._userService.getHochschulen()
				.then(function (hochschulen) {
					this.getView().setModel(new JSONModel(hochschulen.data), "Hochschule");
				}.bind(this))
				.catch(oError => {
					this.getModel("detailView").setProperty("/hasErrorMessage", true);
					this._MessageManager.addMessages(
						new Message({
							message: this.getResourceBundle().getText("user.edit.message.fail.load.hochschulen"),
							additionalText: oError.message + "\n" + oError.stack,
							type: MessageType.Error,
							processor: this.getView().getModel()
						})
					);
				});
		}
	});
});
