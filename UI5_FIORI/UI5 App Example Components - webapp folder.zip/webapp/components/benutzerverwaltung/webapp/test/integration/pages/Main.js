sap.ui.require([
  "sap/ui/test/Opa5"
], function (Opa5) {
  "use strict";

  var sViewName = "de.hrk.hochweit.components.Benutzerverwaltung.view.Main";
  var sAppId = "idAppControl";

  Opa5.createPageObjects({
    onTheMainPage: {

      assertions: {

        iShouldSeePageCount: function() {
          return this.waitFor({
            id: sAppId,
            viewName: sViewName,
           success: function() {
              Opa5.assert.ok(true, "The app appears");
            },
            errorMessage: "App does not appear"
          });
        }
      }

    }
  });

});
