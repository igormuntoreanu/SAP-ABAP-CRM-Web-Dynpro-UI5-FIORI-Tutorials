sap.ui.define([
	"de/hrk/hochweit/components/Seitenbaumeditor/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"hrk/webcomponents/lib/bundle"
], function(
	Controller, JSONModel
) {
	"use strict";

	return Controller.extend("de.hrk.hochweit.components.Seitenbaumeditor.controller.PageEditor", {

		onInit: function () {
			// const sReactImgUrl = sap.ui.require.toUrl("de/hrk/hochweit/components/Seitenbaumeditor/resources/img/1200px-React-icon.svg.png");
			// this.byId("reactAppPlaceholder").setSrc(sReactImgUrl);

			this.getRouter().getRoute("editPage").attachPatternMatched(this._onPatternMatched, this);

			this.setModel(new JSONModel({ editing: false, pageDataExpanded: false }), "local");

			this._PageDataState = this.getOwnerComponent().getState(this.getOwnerComponent().PAGEDATA);
			this.setModel(this._PageDataState.getModel());

			let fileEditorModel = new JSONModel({
        fileServiceUrl: "my-fileServiceUrl",
        width: 200,
        height: 300,
        file: {
          url: "http://localhost",
          description: "my file description",
          language: "english",
          filename: "MyEditedFile",
          originalFilename: "MyFile",
          filetype: "plain/text"
        }
      });
			this.setModel(fileEditorModel, "fileEditor");

			let imageEditorModel = new JSONModel({
        mediaServiceUrl: "my-mediaServiceUrl",
        pixxioApiKey: "my-pixxioApiKey",
        pixxioRefreshToken: "my-pixxioRefreshToken",
        width: 200,
        height: 300
      });
      this.setModel(imageEditorModel, "imageEditor");

      let linkEditorModel = new JSONModel({
        pageServiceUrl: "my-pageServiceUrl",
        fileServiceUrl: "my-fileServiceUrl",
        entityServiceUrl: "my-entityServiceUrl",
        width: 200,
        value: 300
      });
      this.setModel(linkEditorModel, "linkEditor");

      let richTextEditorModel = new JSONModel({
        height: 200,
        width: 300
      });
      this.setModel(richTextEditorModel, "richTextEditor");

      let sliderEditorModel = new JSONModel({
        pageServiceUrl: "my-pageServiceUrl",
        fileServiceUrl: "my-fileServiceUrl",
        entityServiceUrl: "my-entityServiceUrl",
        mediaServiceUrl: "my-mediaServiceUrl",
        apiKey: "my-apiKey",
        refreshKey: "my-refreshKey",
        width: 200,
        value: 300
      });
      this.setModel(sliderEditorModel, "sliderEditor");

      let testimonialEditorModel = new JSONModel({
        pageServiceUrl: "my-pageServiceUrl",
        fileServiceUrl: "my-fileServiceUrl",
        entityServiceUrl: "my-entityServiceUrl",
        mediaServiceUrl: "my-mediaServiceUrl",
        apiKey: "my-apiKey",
        refreshKey: "my-refreshKey",
        width: 200,
        value: 300
      });
      this.setModel(testimonialEditorModel, "testimonialEditor");
		},

		_onPatternMatched: function () {
			//this._PageDataState.getPageData(oEvent.getParameter("arguments").pageId);
		},

		onEditPageData: function () {
			if (!this.getModel("local").getProperty("/pageDataExpanded"))  {
				this._togglePageDataExpanded();
			}
			this.getModel("local").setProperty("/editing", true);
		},

		onSavePageData: function () {
			this._togglePageDataExpanded();
			this.getModel("local").setProperty("/editing", false);
		},

		onToggleExpandPageData: function () {
			this._togglePageDataExpanded();
		},

		_togglePageDataExpanded: function () {
			let bExpanded = !this.getModel("local").getProperty("/pageDataExpanded");
			let oToggleExpandButton = this.byId("btnToggleExpandPageData");
			oToggleExpandButton.setIcon(bExpanded ? "sap-icon://slim-arrow-down" : "sap-icon://slim-arrow-right");
			oToggleExpandButton.setText(bExpanded ? "Seiteninformation verbergen" : "Seiteninformation anzeigen");
			this.getModel("local").setProperty("/pageDataExpanded", bExpanded);
		},

		onTokenUpdate: function (oEvent) {
			//TODO...
			let aAddedTokens = oEvent.getParameter("addedTokens"); //eslint-disable-line
			let aRemovedTokens = oEvent.getParameter("removedTokens"); //eslint-disable-line
		},

		onUpdateContent: function (oEvent) {
			const sContent = oEvent.getParameter("content") || "";
			sap.ui.require(["sap/base/Log"], function (Log) {
				Log.info("Event caught: " + sContent);
			});
		},

		onSavePage: function () {
			// collect page information
			// collect page content
			// save page data
		}
	});
});
