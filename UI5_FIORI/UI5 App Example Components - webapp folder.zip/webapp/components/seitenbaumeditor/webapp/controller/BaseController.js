sap.ui.define([
  "sap/ui/core/mvc/Controller",
  "sap/ui/core/routing/History",
  "sap/ui/core/UIComponent",
  "de/hrk/hochweit/components/Seitenbaumeditor/model/formatter",
  "de/hrk/hochweit/components/Seitenbaumeditor/controller/Events"
], function(Controller, History, UIComponent, formatter, Events) {
  "use strict";

  return Controller.extend("de.hrk.hochweit.components.Seitenbaumeditor.controller.BaseController", {


    promptType: {
      CONFIRM: "Confirm",
      CANCEL: "Cancel"
    },

    /**
     * Make the formatter available to all derived controllers
     */
    formatter: formatter,

    /**
     * Make the event registry available to all derived controllers
     */
    eventRegistry: Events,

    /**
     * Convenience method for getting the view model by name in every controller of the application.
     * @public
     * @param {string} sName the model name
     * @returns {sap.ui.model.Model} the model instance
     */
    getModel: function(sName) {
      return this.getView().getModel(sName);
    },

    /**
     * Convenience method for setting the view model in every controller of the application.
     * @public
     * @param {sap.ui.model.Model} oModel the model instance
     * @param {string} sName the model name
     * @returns {sap.ui.mvc.View} the view instance
     */
    setModel: function(oModel, sName) {
      return this.getView().setModel(oModel, sName);
    },

    /**
     * Convenience method for getting the resource bundle.
     * @public
     * @returns {sap.ui.model.resource.ResourceModel} the resourceModel of the component
     */
    getResourceBundle: function() {
      return this.getOwnerComponent().getModel("i18n").getResourceBundle();
    },

    /**
     * Method for navigation to specific view
     * @public
     * @param {string} psTarget Parameter containing the string for the target navigation
     * @param {mapping} pmParameters? Parameters for navigation
     * @param {boolean} pbReplace? Defines if the hash should be replaced (no browser history entry) or set (browser history entry)
     */
    navTo: function(psTarget, pmParameters, pbReplace) {
      this.getRouter().navTo(psTarget, pmParameters, pbReplace);
    },

    /**
     * Shortcut getter for the component event bus
     * @public
     * @returns {sap.ui.core.EventBus} the component's event bus
     */
    getEventBus: function () {
      return this.getOwnerComponent().getEventBus();
    },

    /**
     * Shortcut getter for the component router
     * @public
     * @returns {sap.f.routing.Router} the component's router
     */
    getRouter: function() {
      return UIComponent.getRouterFor(this);
    },

    /**
     * Standard navBack function to navigate to the appliations previous history or the main page if no history is available
     * @public
     */
    onNavBack: function() {
      var sPreviousHash = History.getInstance().getPreviousHash();

      if (sPreviousHash !== undefined) {
        window.history.back();
      } else {
        this.getRouter().navTo("viewPageTree", {}, true /*no history*/ );
      }
    },

    /**
     * Shorthand method for displaying a Popover with a configurable text and a Accept/Reject button.
     * The passed function is executed when the button is pressed.
     * @private
     * @param {Object} oObjectToOpenBy The control by which the popover is to open
     * @param {string} sPosition The relative position in which the popover should open @see sap.m.PlacementType
     * @param {string} sPromptType The type of prompt to be displayed. Choose between "Confirm" and "Cancel"
     * @param {string} sTitle The popover title
     * @param {string} sButtonText The button text
     * @param {function} fnToExecute The function to be executed when the prompt is confirmed
     */
    _promptAndExecute: function (oObjectToOpenBy, sPosition, sPromptType, sTitle, sButtonText, fnToExecute) {
      let sPlacement = "PreferredTopOrFlip";
      let sButtonType = sPromptType === this.promptType.CONFIRM ? "Accept" : "Reject";
			switch (sPosition) {
				case "bottom": sPlacement = "PreferredBottomOrFlip"; break;
				default: break;
			}

			sap.ui.require(["sap/m/Popover", "sap/m/Button"], function (Popover, Button) {
				var oPopover = new Popover({
					placement: sPlacement,
					title: sTitle,
					content: [
						new Button({
							text: sButtonText,
							type: sButtonType,
							width: "100%",
							press: function () {
								fnToExecute.apply(this);
								oPopover.close();
							}
						})
					]
				});
				oPopover.attachAfterClose(function () {
					oPopover.destroy();
				}, this);
				oPopover.openBy(oObjectToOpenBy);
			}.bind(this));
		},

  });

});
