sap.ui.define([
	"de/hrk/hochweit/components/Seitenbaumeditor/controller/BaseController",
	"sap/ui/model/json/JSONModel"
], function(
	Controller,
	JSONModel
) {
	"use strict";

	return Controller.extend("de.hrk.hochweit.components.Seitenbaumeditor.controller.PageTree", {

		onInit: function () {
			this.setModel(new JSONModel({selectedRowIndices: 0}), "local");
			this._PageDataService = this.getOwnerComponent().getService(this.getOwnerComponent().PAGEDATA);
			this.getRouter().getRoute("viewPageTree").attachPatternMatched(this._onRouteMatched, this);
		},

		_onRouteMatched: function () {
			this._PageDataService.getAllPageData()
			.then (result => {
				this.getModel().setData(this._createPages(result.data));
			});
		},

		onRowSelectionChange: function (oEvent) {
			this.getModel("local").setProperty("/selectedRowIndices", oEvent.getSource().getSelectedIndices().length);
		},

		onEditPage: function (oEvent) {
			var oPageContext = oEvent.getSource().getBindingContext();
			this.navTo("editPage", {pageId: oPageContext.getProperty("id")});
		},


		_createPages: function (aPageData) {
			const aPages = [];
			aPageData.filter(oPage => { // determine root pages
				return oPage.flatData.parentPage.length === 0;
			})
			.forEach(oRootPage => {
				aPages.push(this._createPageAndSubPages(aPageData, oRootPage));
			});
			return { pages: aPages };
		},

		/**
		 * Recursively transform the PageDataContentDto received from the CMS query into the expected tree structure
		 * @param {Array<PageDataContentDto>} aPageData Flat array of all PageDataContentDto
		 * @param {PageDataContentDto} oPageInput The current PageDataContentDto from which to include subpages
		 */
		_createPageAndSubPages: function (aPageData, oPageInput) {
			let oPage = this._PageDataService.refactorGqlFlatData(oPageInput);
			if (oPage.pageData.pages.length > 0) {
				const aSubPages = Object.assign([], oPage.pageData.pages);
				delete oPage.pageData.pages;
				oPage.pages = [];
				aSubPages.forEach(oSubPageReference => {
					const oSubPage = aPageData.find(oPageData => { return oPageData.id === oSubPageReference.id; } );
					oPage.pages.push(this._createPageAndSubPages(aPageData, oSubPage));
				});
			}
			return oPage;
		}
	});
});