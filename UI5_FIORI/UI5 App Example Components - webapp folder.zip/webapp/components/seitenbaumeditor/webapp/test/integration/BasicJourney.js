sap.ui.define([
  "sap/ui/test/opaQunit",
  "de/hrk/hochweit/components/Seitenbaumeditor/test/integration/pages/Main"
], function (opaTest) {
  "use strict";

  opaTest("should show correct number of nested pages", function (Given, When, Then) {

    // Arrangements
    Given.iStartMyApp();

    // Assertions
    Then.onTheMainPage.iShouldSeePageCount(1);

    // Cleanup
    Then.iTeardownMyApp();
  });

});
