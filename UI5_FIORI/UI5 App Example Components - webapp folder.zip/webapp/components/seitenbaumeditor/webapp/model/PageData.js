sap.ui.define([
	"./BaseEntity"
], function(
	BaseEntity
) {
	"use strict";

	return BaseEntity.extend("de.hrk.hochweit.components.Seitenbaumeditor.model.PageData", {
		constructor: function (data) {
			BaseEntity.call(this, data);

			//extract content to root level
			if (this.pageData && this.pageData.content) {
				this.content = this.pageData.content;
				delete this.pageData.content;
			}
		},

		getJSON: function () {
			return {
				title: { de: this.title.de || ""},
				description: { de: this.description.de || ""},
				path: { iv: this.path || ""},
				content: this.content || []
			};
		}
	});
});