sap.ui.define([
	"./BaseState",
	"de/hrk/hochweit/components/Seitenbaumeditor/model/PageData"
], function(
	BaseState, PageData
) {
	"use strict";

	return BaseState.extend("de.hrk.hochweit.components.Seitenbaumeditor.model.state.PageDataState", {
		constructor: function (oService) {
			this.data = {
				PageData: new PageData(),
				display: true
			};
			this.PageDataService = oService;
			BaseState.call(this);
		},

		getPageData: function (id) {
			return this.PageDataService.getPageData(id).then((result) => {
				this.data.PageData = new PageData(result.data);
				this.data.display = true;
				this.updateModel();
				return this.data.PageData;
			});
		},

		newPageData: function () {
			return this.PageDataService.createPageData(this.data.PageData).then((result) => result.data.Id);
		}

	});
});