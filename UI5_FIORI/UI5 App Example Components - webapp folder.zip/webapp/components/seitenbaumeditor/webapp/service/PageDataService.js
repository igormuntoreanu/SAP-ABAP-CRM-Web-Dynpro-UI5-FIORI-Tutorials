sap.ui.define([
	"./CoreService",
	"apollo/client/thirdparty/apollo"
], function (
	CoreService,
	ApolloClient
) {
	"use strict";

	const { gql } = ApolloClient;

	const GET_PAGEDATA = {
		gql: gql`
			query GetSinglePageData ($pageDataId: String!) {
				findPagedataContent(id: $pageDataId)
				{
					id
					createdBy
					created
					flatData {
						title
						path
						tags
						content
					}
				}
			}`,
		queryName: "findPagedataContent"
	};

	// TODO try to get this properly recursed
	const GET_ALL_PAGEDATA = {
		gql: gql`
		query GetAllPageData {
			queryPagedataContents {
				id
				flatData {
				  title
				  path
				  tags
				  lastEditedAt
				  lastEditedBy
				  publishStatus
				  pages {
					id
				  }
				  parentPage {
					id
				  }
				}
			  }
		}`,
		queryName: "queryPagedataContents"
	};

	return CoreService.extend("de.hrk.hochweit.components.Seitenbaumeditor.service.PageDataService", {

		constructor: function (model, graphQlEndpoint, graphQlWsEndpoint) {
			CoreService.call(this, model, graphQlEndpoint, graphQlWsEndpoint);
		},

		getPageData: function (sId) {
			return this._apolloService.query({
				query: GET_PAGEDATA.gql,
				variables: {
					pageDataId: sId
				}
			})
			.then(result => {
				return Promise.resolve({
					data: this.refactorGqlFlatData(result.data[GET_PAGEDATA.queryName])
				});
			})
			.catch(oError => {
				throw new Error(oError.message);
			});
		},

		getAllPageData: function () {
			return this._apolloService.query({
				query: GET_ALL_PAGEDATA.gql
			})
			.then(result => {
				return Promise.resolve({
					data: result.data[GET_ALL_PAGEDATA.queryName]
				});
			})
			.catch(oError => {
				throw new Error(oError.message);
			});
		},

		/**
		 * Transforms the given PageDataContentDto's flatData attribute as given by the GraphQL query into the expected pageData attribute
		 * @param {PageDataContentDto} item
		 */
		refactorGqlFlatData: function (item) {
			if (item.flatData !== item.pageData && item.flatData) {
				Object.defineProperty(item, "pageData",
					Object.getOwnPropertyDescriptor(item, "flatData"));
				delete item["flatData"];
			}
			return item;
		},

	});
});