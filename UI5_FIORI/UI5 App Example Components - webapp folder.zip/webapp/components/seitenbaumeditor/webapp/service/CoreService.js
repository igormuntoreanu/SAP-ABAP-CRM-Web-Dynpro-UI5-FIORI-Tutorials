sap.ui.define([
	"sap/ui/base/Object",
	"apollo/client/service/ApolloService"
], function(
	BaseObject,
	ApolloService
) {
	"use strict";

	const DISABLE_WEBSOCKET_RECONNECT = true;

	return BaseObject.extend("de.hrk.hochweit.components.Seitenbaumeditor.service.CoreService", {
		constructor: function (model, graphQlEndpoint, graphQlWsEndpoint) {
			Object.call(this);
			if (model) {
				this.setModel(model);
			}
			if (graphQlEndpoint) {
				this.setGraphQlEndpoint(graphQlEndpoint);
			}
			if (graphQlWsEndpoint) {
				this.setGraphQlWsEndpoint(graphQlWsEndpoint);
			}
			if (graphQlEndpoint && graphQlWsEndpoint) {
				this._apolloService = new ApolloService(graphQlEndpoint, graphQlWsEndpoint, DISABLE_WEBSOCKET_RECONNECT);
			}
		},
		setModel: function (model) {
			this.model = model;
		},
		setGraphQlEndpoint: function (graphQlEndpoint) {
			this.graphQlEndpoint = graphQlEndpoint;
		},
		setGraphQlWsEndpoint: function (graphQlWsEndpoint) {
			this.graphQlWsEndpoint = graphQlWsEndpoint;
		}
	});
});