sap.ui.define([
    // TODO: import ApolloService
], function() {
    "use strict";

    //define gql-queries

	return {

	};
});