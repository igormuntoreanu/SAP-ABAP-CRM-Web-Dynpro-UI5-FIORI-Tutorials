sap.ui.define([
	"de/hrk/hochweit/components/Hochschulportraits/controller/BaseController",
	"sap/ui/model/json/JSONModel"
], function (Controller, JSONModel) {
	"use strict";

	return Controller.extend("de.hrk.hochweit.components.Hochschulportraits.controller.PortraitDetailEdit", {

	/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		onInit: function () {
			// Model used to manipulate control states. The chosen values make sure,
			// detail page is busy indication immediately so there is no break in
			// between the busy indication for loading the view's meta data
			var oViewModel = new JSONModel({
				busy: false,
				delay: 0,
				lineItemListTitle: this.getResourceBundle().getText("detailLineItemTableHeading")
			});

			this.getRouter().getRoute("editPortrait").attachPatternMatched(this._onObjectMatched, this);

			this.setModel(oViewModel, "detailView");
		},

		/* =========================================================== */
		/* event handlers                                              */
		/* =========================================================== */

		 onNavToDashboard: function(oEvent) {
			// TODO: only show if changes were made
			let fnConfirm = function () {
			  this.onNavigateViaRoot(oEvent, "dashboard");
			}.bind(this);
			this._promptAndExecute(
			  oEvent.getSource(),
			  "top",
			  this.promptType.CANCEL,
			  this.getResourceBundle().getText("detail.edit.cancel.prompt.text"),
			  this.getResourceBundle().getText("detail.edit.cancel.action.confirm"),
			  fnConfirm.bind(this)
			);
		  },

		  onNavToPortraitList: function(oEvent) {
			// TODO: only show if changes were made
			let fnConfirm = function () {
				this.getModel("appView").setProperty("/actionButtonsInfo/midColumn/fullScreen", false);
				this.getOwnerComponent().oListSelector.clearMasterListSelection();
				this.getRouter().navTo("master");
			  }.bind(this);
			  this._promptAndExecute(
				oEvent.getSource(),
				"top",
				this.promptType.CANCEL,
				this.getResourceBundle().getText("detail.edit.cancel.prompt.text"),
				this.getResourceBundle().getText("detail.edit.cancel.action.confirm"),
				fnConfirm.bind(this)
			  );
		  },

		/* =========================================================== */
		/* begin: internal methods                                     */
		/* =========================================================== */

		/**
		 * Binds the view to the object path and expands the aggregated line items.
		 * @function
		 * @param {sap.ui.base.Event} oEvent pattern match event in route 'object'
		 * @private
		 */
		_onObjectMatched: function (oEvent) {
			this.hochschulId =  oEvent.getParameter("arguments").hochschulId;
			this.getModel("appView").setProperty("/layout", "TwoColumnsMidExpanded");
			// this.getModel().metadataLoaded().then( function() {
				var sObjectPath = `/${this.hochschulId - 1}`;
				this._bindView(sObjectPath);
			// }.bind(this));

			// TODO: only call when there are actual unsaved changes
			const fnFirePendingChanges = function () {
				this.getOwnerComponent().fireNotifyPendingChanges();
			}.bind(this);
			setTimeout(fnFirePendingChanges, 200); // We need a slight delay to give the App a chance to register a listener when jumping directly to the edit page
		},

		/**
		 * Binds the view to the object path. Makes sure that detail view displays
		 * a busy indicator while data for the corresponding element binding is loaded.
		 * @function
		 * @param {string} sObjectPath path to the object to be bound to the view.
		 * @private
		 */
		_bindView: function (sObjectPath) {
			// Set busy indicator during view binding
			var oViewModel = this.getModel("detailView");

			// If the view was not bound yet its not busy, only if the binding requests data it is set to busy again
			oViewModel.setProperty("/busy", false);

			this.getView().bindElement({
				path: sObjectPath,
				events: {
					change: this._onBindingChange.bind(this),
					dataRequested: function () {
						oViewModel.setProperty("/busy", true);
					},
					dataReceived: function () {
						oViewModel.setProperty("/busy", false);
					}
				}
			});
		},

		_onBindingChange: function () {
			var oView = this.getView(),
				oElementBinding = oView.getElementBinding();

			// No data for the binding
			if (!oElementBinding.getBoundContext()) {
				this.getRouter().getTargets().display("detailObjectNotFound");
				// if object could not be found, the selection in the master list
				// does not make sense anymore.
				this.getOwnerComponent().oListSelector.clearMasterListSelection();
				return;
			}

			var sPath = oElementBinding.getPath(),
				oResourceBundle = this.getResourceBundle(),
				oObject = oView.getModel().getObject(sPath),
				sObjectId = oObject.HochschulId,
				sObjectName = oObject.Name,
				oViewModel = this.getModel("detailView");

			this.getOwnerComponent().oListSelector.selectAListItem(sPath);

			oViewModel.setProperty("/shareSendEmailSubject",
				oResourceBundle.getText("shareSendEmailObjectSubject", [sObjectId]));
			oViewModel.setProperty("/shareSendEmailMessage",
				oResourceBundle.getText("shareSendEmailObjectMessage", [sObjectName, sObjectId, location.href]));
		},

		/**
		 * Toggle between full and non full screen mode.
		 */
		toggleFullScreen: function () {
			var bFullScreen = this.getModel("appView").getProperty("/actionButtonsInfo/midColumn/fullScreen");
			this.getModel("appView").setProperty("/actionButtonsInfo/midColumn/fullScreen", !bFullScreen);
			if (!bFullScreen) {
				// store current layout and go full screen
				this.getModel("appView").setProperty("/previousLayout", this.getModel("appView").getProperty("/layout"));
				this.getModel("appView").setProperty("/layout", "MidColumnFullScreen");
			} else {
				// reset to previous layout
				this.getModel("appView").setProperty("/layout",  this.getModel("appView").getProperty("/previousLayout"));
			}
		},

		onSave: function () {
			this.navTo("viewPortrait", {hochschulId: this.hochschulId});
			this.getOwnerComponent().fireNotifyNoPendingChanges(); // TODO: only call when entry is actually saved and pending changes are gone
		},

		onCancel: function (oEvent) {
			// TODO: only prompt when changes were made
			let fnOnCancelConfirmed = function () {
				this.navTo("viewPortrait", {hochschulId: this.hochschulId});
				this.getOwnerComponent().fireNotifyNoPendingChanges();
			}.bind(this);
			this._promptAndExecute(
				oEvent.getSource(),
				"top",
				this.promptType.CANCEL,
				this.getResourceBundle().getText("detail.edit.cancel.prompt.text"),
				this.getResourceBundle().getText("detail.edit.cancel.action.confirm"),
				fnOnCancelConfirmed.bind(this)
			);
		}
	});

});