sap.ui.define(
  [
    "sap/ui/core/UIComponent",
    "de/hrk/hochweit/Backend-web/model/models",
    "sap/ui/core/IconPool",
    "apollo/client/thirdparty/apollo",
    "apollo/client/service/ApolloService",
    "sap/base/Log",
    "sap/ui/core/ComponentSupport" // added for self-contained build
  ],
  function (UIComponent, models, IconPool, ApolloClient, ApolloService, Log) {
    "use strict";

    const INVALID_LOGIN = {
      validLoginSession: false,
      permissions: []
    };

    const { gql } = ApolloClient;

    const LOGIN_QUERY = {
      gql: gql`query getLoginState{
        getLoginState {
          validLoginSession,
          user {
            vorname,
            nachname,
            initialen,
            username,
            keycloakId,
            hochschulId
          },
          role,
          permissions
          }
        }`,
      name: "getLoginState"
    };

    const OWN_PROFILE = {
      gql: gql`query ownProfile {
        ownProfile {
          selbst {
          vorname
          nachname
          vorwahl
          telefonNummer
          emailAdresse
          keycloak_id
          Hochschule { kurzname }
          }
        }
      }`,
      name: "ownProfile"
    };

    return UIComponent.extend("de.hrk.hochweit.Backend-web.Component", {
      metadata: {
        manifest: "json",
      },

      /**
       * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
       * @public
       * @override
       */
      init: function () {
        // call the base component's init function
        UIComponent.prototype.init.apply(this, arguments);

        this._registerCustomResources();

        // set title of HTML document
        if (document && document.title !== undefined)
          document.title = this.getModel("i18n")
            .getResourceBundle()
            .getText("appTitle");

        // enable routing
        this.getRouter().initialize();

        // set the device model
        this.setModel(models.createDeviceModel(), "device");

        // set the image model
        const sImgRootPath = sap.ui.require.toUrl("de/hrk/hochweit/Backend-web/resources/img");
        this.setModel(models.createImageModel(sImgRootPath), "img");

        // Sample initialization of Apollo service
        this._apolloService = new ApolloService(
          this.getMetadata().getManifestEntry("/sap.app/dataSources/graphql/uri"),
          this.getMetadata().getManifestEntry("/sap.app/dataSources/graphql/ws"),
          true /* disable refresh */
        );
        this._initializeLogin();
      },

      /**
       * Make ApolloService available for controllers
       */
      getApolloService: function () {
        return this._apolloService;
      },

      _registerCustomResources: function () {
        IconPool.registerFont({
          collectionName: "huw-icons",
          fontFamily: "huw-icons",
          fontURI: sap.ui.require.toUrl("hrk/icons/font"),
          lazy: true,
        });
        IconPool.registerFont({
          collectionName: "SAP-icons-TNT",
          fontFamily: "SAP-icons-TNT",
          fontURI: sap.ui.require.toUrl("sap/tnt/themes/base/fonts"),
          lazy: true
        });
      },

      onWindowBeforeUnload: function (oEvent) {
        let sCurrentComponentName =
          this.getModel("components").getProperty("/currentComponent");
        if (!sCurrentComponentName) {
          return;
        }

        if (
          this.getModel("components").getProperty(
            `/${sCurrentComponentName}/hasPendingChanges`
          )
        ) {
          oEvent.preventDefault();
          oEvent.returnValue = "";
        }
      },

      /**
       * This method can be called to determine whether the sapUiSizeCompact or sapUiSizeCozy
       * design mode class should be set, which influences the size appearance of some controls.
       * @public
       * @return {string} css class, either 'sapUiSizeCompact' or 'sapUiSizeCozy' - or an empty string if no css class should be set
       */
      getContentDensityClass: function () {
        if (this._sContentDensityClass === undefined) {
          // check whether content density class was already set; do nothing in this case
          if (
            document.body.classList.contains("sapUiSizeCozy") ||
            document.body.classList.contains("sapUiSizeCompact")
          ) {
            this._sContentDensityClass = "";
          } else if (!Device.support.touch) {
            // apply "compact" mode if touch is not supported
            this._sContentDensityClass = "sapUiSizeCompact";
          } else {
            // "cozy" in case of touch support; default for most sap.m controls, but needed for desktop-first controls like sap.ui.table.Table
            this._sContentDensityClass = "sapUiSizeCozy";
          }
        }
        return this._sContentDensityClass;
      },

      _initializeLogin: function () {
        const loginModel = this.getModel("login");
        const appModel = this.getModel("app"); // reading login state from the app model is deprecated, we still support it.
        this._apolloService.query({ query: LOGIN_QUERY.gql })
          .then(loginData => {
            const loginState = loginData.data[LOGIN_QUERY.name];
            if (!loginState.validLoginSession) {
              Log.error(`Login not valid: ${JSON.stringify(loginState)}`);
            }
            loginModel.setData(loginState);
            appModel.setProperty("/user", loginState);
          }).catch(error => {
            Log.error(`Error logging in: ${error.message}@${error.stack}`);
            loginModel.setData(INVALID_LOGIN);
            appModel.setProperty("/user", INVALID_LOGIN);
          });
      },

      getOwnProfile: function () {
        return this._apolloService.query({
          query: OWN_PROFILE.gql
        })
          .then(result => {
            return Promise.resolve({
              data: result.data[OWN_PROFILE.name]
            });
          });
      }
    });
  }
);
