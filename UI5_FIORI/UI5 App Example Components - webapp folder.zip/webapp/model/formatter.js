sap.ui.define([
	"sap/base/strings/formatMessage"
], function (formatMsg) {
	"use strict";
	return {
		formatMessage: function(sPattern, ...aValues) {
			return formatMsg(sPattern, aValues);
		}
	};
});
