sap.ui.define([
	"sap/ui/base/Object",
	"sap/base/Log",
	"apollo/client/thirdparty/apollo"
], function (
		BaseObject,
		Log,
		ApolloClient,
) {
	"use strict";
	const {gql} = ApolloClient;

	// the redirect uri needs to be adapted if application is mounted to a different path
	const LOCAL_LOGOUT_REDIRECT_URL = "/oauth2/sign_out?rd=%2Fbackend%2Findex.html";

	const PERFORM_LOGOUT = {
		gql: gql`mutation{logout}`,
		queryName: "doLogout"
	};

	return BaseObject.extend("de.hrk.hochweit.service.LogoutService", {

		/**
		 * Terminates the login session at the authorization server. This is necessary, since terminating the local
		 * session (with the OAuth2-Proxy) would not be enough. It would just mean that the next request is being
		 * redirected to the authorization server, where it would find the valid session and be immediately redirected
		 * back to the application (via the proxy URL) with a new token.
		 * Termination of the login session at the authorization server would also be possible by a redirect to the
		 * logout endpoint of the authorization server. But this would mean that the application would need to be aware
		 * of the authorization server's external URL, which is not desireable. Therefore, we trigger authorization server
		 * logout via the backend.
		 * @returns {Promise<unknown>}
		 */
		terminateSsoSession: function (apolloService) {
			if (!apolloService) {
				Log.error("No apollo service available");
				return Promise.reject("Apollo service unavailable");
			}
			return apolloService.query({
				query: PERFORM_LOGOUT.gql
			});
		},

		getLocalLogoutRedirect: function () {
			return LOCAL_LOGOUT_REDIRECT_URL;
		}
	});
});
