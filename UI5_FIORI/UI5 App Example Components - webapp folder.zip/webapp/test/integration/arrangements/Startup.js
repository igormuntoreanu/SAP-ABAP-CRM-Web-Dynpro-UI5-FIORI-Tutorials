sap.ui.define([
  "sap/ui/test/Opa5"
], function(Opa5) {
  "use strict";

  return Opa5.extend("de.hrk.hochweit.Backend-web.test.integration.arrangements.Startup", {

      iStartMyApp: function (sHash, iTimeout) {
        this.iStartMyUIComponent({
          componentConfig: {
            name: "de.hrk.hochweit.Backend-web",
            id: "container-Backend-web",
            async: true,
            manifest: true
          },
          hash: sHash,
          timeout: iTimeout
        });
      }
  });
});
