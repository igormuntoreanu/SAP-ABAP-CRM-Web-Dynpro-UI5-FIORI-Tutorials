sap.ui.define([
  "sap/ui/test/Opa5",
  "de/hrk/hochweit/Backend-web/test/integration/arrangements/Startup",
  "de/hrk/hochweit/Backend-web/test/integration/BasicJourney"
], function(Opa5, Startup) {
  "use strict";

  Opa5.extendConfig({
    arrangements: new Startup(),
    autoWait:true,
    pollingInterval: 1,
    asyncPolling: true
  });

});
