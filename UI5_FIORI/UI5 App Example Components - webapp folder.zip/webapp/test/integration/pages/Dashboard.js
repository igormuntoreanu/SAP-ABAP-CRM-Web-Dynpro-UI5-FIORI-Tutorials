sap.ui.require([
  "sap/ui/test/Opa5"
], function (Opa5) {
  "use strict";

  var sViewName = "de.hrk.hochweit.Backend-web.view.Dashboard";

  Opa5.createPageObjects({
    onTheDashboardPage: {

      actions: {},
      assertions: {
        iShouldSeeTheDashoard: function () {
          return this.waitFor({
            id: "dashboardGrid",
            viewName: sViewName,
            success: (oDashboardGrid) => {
              Opa5.assert.strictEqual(oDashboardGrid.getMetadata().getName(), "sap.f.GridContainer", "Did find the Dashboard");
            },
            errorMessage: "Did not find the Dashboard"
        });
        }
      }

    }
  });

});
