sap.ui.require([
    "sap/ui/test/Opa5"
], function (Opa5) {
    "use strict";

    var sViewName = "de.hrk.hochweit.Backend-web.view.App";

    Opa5.createPageObjects({
        onTheAppPage: {

            assertions: {

                iShouldSeeTheApp: function () {
                    return this.waitFor({
                        id: "idAppControl",
                        viewName: sViewName,
                        success: function () {
                            Opa5.assert.ok(true, "The app control was found");
                        },
                        errorMessage: "App control was not present"
                    });
                },
                iShouldSeeOnlyOneApp: function () {
                    return this.waitFor({
                        controlType: "sap.m.App",
                        success: function (aApps) {
                            Opa5.assert.strictEqual(aApps.length, 1, "Did find exactly one sap.m.App control");
                        },
                        errorMessage: "Found none or more than one sap.m.App controls - this can lead to display issues"
                    });
                },
                iShouldSeeTheAppHeader: function () {
                    return this.waitFor({
                        id: "appHeader",
                        viewName: sViewName,
                        success: function () {
                            Opa5.assert.ok(true, "The app header was found");
                        },
                        errorMessage: "The app header was not present"
                    });
                },
                iShouldSeeTheAppHeaderhuwLogo: function () {
                    return this.waitFor({
                        id: "huwLogo",
                        viewName: sViewName,
                        success: function () {
                            Opa5.assert.ok(true, "The image 'Logo' was found");
                        },
                        errorMessage: "The image 'Logo' was not present"
                    });
                },
                iShouldSeeTheAppHeaderWeiterbildungsangebote: function () {
                    return this.waitFor({
                        id: "angebote",
                        viewName: sViewName,
                        success: function () {
                            Opa5.assert.ok(true, "The text 'Weiterbildungsangebote' was found");
                        },
                        errorMessage: "The text 'Weiterbildungsangebote' was not present"
                    });
                },
                iShouldSeeTheAppHeaderAngeboteHsk: function () {
                    return this.waitFor({
                        id: "angebote_hsk",
                        viewName: sViewName,
                        success: function () {
                            Opa5.assert.ok(true, "The text 'Studiengänge aus dem Hochschulkompass' was found");
                        },
                        errorMessage: "The text 'Studiengänge aus dem Hochschulkompass' was not present"
                    });
                },
                iShouldSeeTheAppHeaderHochschulportraits: function () {
                    return this.waitFor({
                        id: "hochschulportraits",
                        viewName: sViewName,
                        success: function () {
                            Opa5.assert.ok(true, "The text 'Hochschulporträts' was found");
                        },
                        errorMessage: "The text 'Hochschulporträts' was not present"
                    });
                },
                iShouldSeeTheAppHeaderLinkvalidierung: function () {
                    return this.waitFor({
                        id: "linkvalidierung",
                        viewName: sViewName,
                        success: function () {
                            Opa5.assert.ok(true, "The text 'zu prüfende Links' was found");
                        },
                        errorMessage: "The text 'zu prüfende Links' was not present"
                    });
                },
                iShouldSeeTheAppHeaderAdministration: function () {
                    return this.waitFor({
                        id: "administrativeFunktionen",
                        viewName: sViewName,
                        success: function () {
                            Opa5.assert.ok(true, "The text 'Administration' was found");
                        },
                        errorMessage: "The text 'Administration' was not present"
                    });
                },
                iShouldSeeTheAppHeaderPendingChanges: function () {
                    return this.waitFor({
                        id: "btnPendingChanges",
                        viewName: sViewName,
                        success: function () {
                            Opa5.assert.ok(true, "The button 'Freizugebende Änderungen' was found");
                        },
                        errorMessage: "The button 'Freizugebende Änderungen' was not present"
                    });
                },
                iShouldSeeTheAppHeaderProfile: function () {
                    return this.waitFor({
                        id: "btnProfile",
                        viewName: sViewName,
                        success: function () {
                            Opa5.assert.ok(true, "The button 'Profil' was found");
                        },
                        errorMessage: "The button 'Profil' was not present"
                    });
                },
                iShouldSeeTheAppHeaderLogout: function () {
                    return this.waitFor({
                        id: "btnLogout",
                        viewName: sViewName,
                        success: function () {
                            Opa5.assert.ok(true, "The button 'Logout' was found");
                        },
                        errorMessage: "The button 'Logout' was not present"
                    });
                }
            }

        }
    });

});
