sap.ui.define([
    "sap/ui/test/opaQunit",
    "de/hrk/hochweit/Backend-web/test/integration/pages/App"
], function (opaTest) {
    "use strict";

    opaTest("should display the main App control and no other App controls", function (Given, When, Then) {

        // Arrangements
        Given.iStartMyApp();

        // Assertions
        Then.onTheAppPage.iShouldSeeTheApp();

        // Cleanup
        Then.iTeardownMyApp();
    });

    opaSkip("should display the app header with its content", function (Given, When, Then) {

        // Arrangements
        Given.iStartMyApp();

        // Assertions
        Then.onTheAppPage.iShouldSeeTheAppHeader()
            .and.iShouldSeeTheAppHeaderhuwLogo()
            .and.iShouldSeeTheAppHeaderWeiterbildungsangebote()
            .and.iShouldSeeTheAppHeaderAngeboteHsk()
            .and.iShouldSeeTheAppHeaderHochschulportraits()
            .and.iShouldSeeTheAppHeaderLinkvalidierung()
            .and.iShouldSeeTheAppHeaderAdministration()
            .and.iShouldSeeTheAppHeaderPendingChanges()
            .and.iShouldSeeTheAppHeaderProfile()
            .and.iShouldSeeTheAppHeaderLogout();

        // Cleanup
        Then.iTeardownMyApp();
    });

    opaSkip("should not see an additional App control for component weiterbildungsangebote", function (Given, When, Then) {
        /*FIXME: currently fails due to the autowaiter running into a timeout because of infinitely
        pending module 'https://unpkg.com/react@16/umd/react.production.min.js' (caused by "hrk/webcomponents/lib/bundle" import in weiterbildungsangebote component)
        */
        Given.iStartMyApp("an");
        Then.onTheAppPage.iShouldSeeOnlyOneApp();
    });

});
