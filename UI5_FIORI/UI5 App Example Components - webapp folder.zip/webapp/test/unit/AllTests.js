sap.ui.define([
    "./misc/Dummy.qunit",
    "./misc/Omit.qunit"
]);
