sap.ui.define([
	"de/hrk/hochweit/components/Weiterbildungsangebote/service/AngeboteService"

], function(AngeboteService) {
	"use strict";

//example test
	QUnit.test("omit flat string", function (assert) {
		const oObj = {
			a: "string",
			b: ["one", "two"],
			c: 1,
			d: false,
			e: { }
		};
		const expected = {
			b: ["one", "two"],
			c: 1,
			d: false,
			e: { }
		};
		const withoutA = AngeboteService._omitRecursively(oObj, "a");
		assert.deepEqual(withoutA, expected, "a is deleted");
	});

	QUnit.test("omit flat array", function (assert) {
		const oObj = {
			a: "string",
			b: ["one", "two"],
			c: 1,
			d: false,
			e: { }
		};
		const expected = {
			a: "string",
			c: 1,
			d: false,
			e: { }
		};
		const withoutA = AngeboteService._omitRecursively(oObj, "b");
		assert.deepEqual(withoutA, expected, "b is deleted");
	});

	QUnit.test("omit flat number", function (assert) {
		const oObj = {
			a: "string",
			b: ["one", "two"],
			c: 1,
			d: false,
			e: { }
		};
		const expected = {
			a: "string",
			b: ["one", "two"],
			d: false,
			e: { }
		};
		const withoutA = AngeboteService._omitRecursively(oObj, "c");
		assert.deepEqual(withoutA, expected, "c is deleted");
	});

	QUnit.test("omit flat boolean", function (assert) {
		const oObj = {
			a: "string",
			b: ["one", "two"],
			c: 1,
			d: false,
			e: { }
		};
		const expected = {
			a: "string",
			b: ["one", "two"],
			c: 1,
			e: { }
		};
		const withoutA = AngeboteService._omitRecursively(oObj, "d");
		assert.deepEqual(withoutA, expected, "d is deleted");
	});

	QUnit.test("omit flat empty object", function (assert) {
		const oObj = {
			a: "string",
			b: ["one", "two"],
			c: 1,
			d: false,
			e: { }
		};
		const expected = {
			a: "string",
			b: ["one", "two"],
			c: 1,
			d: false,
		};
		const withoutA = AngeboteService._omitRecursively(oObj, "e");
		assert.deepEqual(withoutA, expected, "e is deleted");
	});


	QUnit.test("omit deep object", function (assert) {
		const oObj = {
			a: "string",
			b: ["one", "two"],
			c: 1,
			d: false,
			e: {
				a: "otherString",
				b: ["one", "two"],
				c: 1,
				d: false,
				e: {
					a: "third string"
				}
			}
		};
		const expected = {
			b: ["one", "two"],
			c: 1,
			d: false,
			e: {
				b: ["one", "two"],
				c: 1,
				d: false,
				e: { }
			}
		};
		const withoutA = AngeboteService._omitRecursively(oObj, "a");
		assert.deepEqual(withoutA, expected, "a is deleted");
	});

	QUnit.test("null", assert => {
		const nullResult = AngeboteService._omitRecursively(null, "any");
		assert.strictEqual(null, nullResult, "null remains null");
	});

	QUnit.test("undefined", assert => {
		const nullResult = AngeboteService._omitRecursively(undefined, "any");
		assert.strictEqual(undefined, nullResult, "undefined remains undefined");
	});

	QUnit.test("Object in array", assert => {
		const oWithArray = {
			array: [
				{
					a: "should go away",
					b: "should stay"
				},
				{
					a: 1
				},
				{
					b: 2
				}
			]
		};
		const purged = AngeboteService._omitRecursively(oWithArray, "a");
		assert.deepEqual(purged, {
			array: [
				{
					b: "should stay"
				},
				{},
				{
					b: 2
				}
			]
		}, "a should go away");
	});

	QUnit.test("simple array", assert => {
		const result = AngeboteService._omitRecursively(["a", "b"], "a");
		assert.deepEqual(result, ["a", "b"], "Should not modify array");
	});

});
