sap.ui.define([], function() {
    "use strict";

//example test
    QUnit.test("verify value and type", function (assert) {
        // implementation
        var vSomeVar = "42";
        assert.strictEqual("42", vSomeVar, "42 and " + vSomeVar + " have the same value and type");
    });
});