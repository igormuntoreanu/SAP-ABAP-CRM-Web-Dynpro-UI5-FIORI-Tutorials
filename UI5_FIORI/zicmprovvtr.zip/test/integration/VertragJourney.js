/*global QUnit*/

sap.ui.define([
	"sap/ui/test/opaQunit",
	"./pages/Vertrag",
	"./pages/Master"
], function (opaTest) {
	"use strict";

	QUnit.module("Vertrag");

	opaTest("Anzeige des Vertrags 50021", function (Given, When, Then) {

		Given.iStartMyApp();

		When.onTheMasterPage.iEnterTextInput_CtrtbuId(50021);
		When.onTheMasterPage.iPressOnTheItem();

		Then.onTheVertragPage.lavvShouldBeDisplayed(3);
		Then.onTheVertragPage.wpvShouldBeDisplayed(true);
		Then.onTheVertragPage.maklerKommShouldBeDisplayed(false);

		Then.iTeardownMyApp();
	});

	opaTest("Anzeige des Vertrags 45038", function (Given, When, Then) {

		Given.iStartMyApp();

		When.onTheMasterPage.iEnterTextInput_CtrtbuId(45038);
		When.onTheMasterPage.iPressOnTheItem();

		Then.onTheVertragPage.maklerKommShouldBeDisplayed(true);
		Then.onTheVertragPage.wpvShouldBeDisplayed(false);
		Then.onTheVertragPage.lavvShouldBeEmpty();
		Then.onTheVertragPage.compareVersionEnabled(false);

		Then.iTeardownMyApp();
	});

	opaTest("Anzeige des Vertrags 50020", function (Given, When, Then) {

		Given.iStartMyApp();

		When.onTheMasterPage.iEnterTextInput_CtrtbuId(50020);
		When.onTheMasterPage.iPressOnTheItem();

		Then.onTheVertragPage.lockScreenShouldBeDisplayed();

		Then.iTeardownMyApp();
	});

	opaTest("Visualisierung von Versionsänderungen", function (Given, When, Then) {

		Given.iStartMyApp();

		When.onTheMasterPage.iEnterTextInput_CtrtbuId(50022);
		When.onTheMasterPage.iPressButton_expertModusBtn();
		When.onTheMasterPage.iEnterTextInput_NameGrp1("Aktueller Vertrag");
		When.onTheMasterPage.iPressOnTheItem();

		When.onTheVertragPage.iPressButtonVersionsvergleich();
		Then.onTheVertragPage.labelValueStateShouldHaveChanged("IntTitle", "Indication03", "IntTitle changed");

		When.onTheVertragPage.iPressButtonVersionsvergleich();
		Then.onTheVertragPage.labelValueStateShouldHaveChanged("IntTitle", "None", null);

		Then.iTeardownMyApp();
	});

	opaTest("Anzeige der Object Page im Editiermodus", function (Given, When, Then) {

		Given.iStartMyApp();

		When.onTheMasterPage.iEnterTextInput_CtrtbuId(50021);
		When.onTheMasterPage.iPressOnTheItem();

		When.onTheVertragPage.iSetEditMode(true);

		Then.onTheVertragPage.busiBeginShouldBeEditable(true);
		Then.onTheVertragPage.lavvToolBarShouldBeDisplayed(true);
		Then.onTheVertragPage.lavvDeleteColumnShouldBeDisplayed(true);
	});

	/*
		Der EditDialog wird nicht berücksichtigt, da vom Vertrag zu Vertragsversionen nicht simultan zum Backend navigiert werden kann
	*/
	opaTest("Anzeige der Object Page nach dem Wechsel vom Editiermodus in den Anzeigemodus", function (Given, When, Then) {

		When.onTheVertragPage.iSetEditMode(false);

		Then.onTheVertragPage.busiBeginShouldBeEditable(false);
		Then.onTheVertragPage.lavvToolBarShouldBeDisplayed(false);
		Then.onTheVertragPage.lavvDeleteColumnShouldBeDisplayed(false);
	});

	/*
		Der Button zum Verlassen des Editiermodus wird nicht getestet, das dieser im Test nicht gerendert wird. 
		Der Button zum Fortführen im Editiermodus wird nicht getestet, da Funktionen ausgelöst werden, die den weiteren Testverlauf stören.
	*/
	opaTest("Anzeige des Timeout-Dialogs bei Inaktivität", function (Given, When, Then) {

		When.onTheVertragPage.iSetEditMode(true);
		When.onTheVertragPage.iSetInactiveTime(4);

		Then.onTheVertragPage.timeoutAfterFiveMinutesShouldBeDisplayed();
	});

	opaTest("Schließen des Timeout-Dialogs bei keiner Nutzerinteraktion", function (Given, When, Then) {

		When.onTheVertragPage.iSetTimeoutCounter();
		Then.onTheVertragPage.timeoutAfterFiveMinutesShouldBeClosed();

		Then.onTheVertragPage.busiBeginShouldBeEditable(false);
		Then.onTheVertragPage.lavvToolBarShouldBeDisplayed(false);
		Then.onTheVertragPage.lavvDeleteColumnShouldBeDisplayed(false);

		Then.iTeardownMyApp();
	});

});