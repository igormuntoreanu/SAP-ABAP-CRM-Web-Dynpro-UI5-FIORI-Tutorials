sap.ui.define([
	"sap/ui/test/Opa5",
	"de/pnw/icm/provisionsvertrag/vtr2/localService/mockserver",
	"sap/ui/model/odata/v2/ODataModel"
], function (Opa5, mockserver, ODataModel) {
	"use strict";

	return Opa5.extend("de.pnw.icm.provisionsvertrag.vtr2.test.integration.arrangements.Startup", {

		/**
		 * Initializes mock server, then starts the app component
		 */
		iStartMyApp: function () {

			this._clearSharedData();

			// configure mock server
			mockserver.init();

			// start the app UI component
			this.iStartMyUIComponent({
				componentConfig: {
					name: "de.pnw.icm.provisionsvertrag.vtr2",
					async: true
				}
			});
		},

		_clearSharedData: function () {
			// clear shared metadata in ODataModel to allow tests for loading the metadata
			ODataModel.mSharedData = {
				server: {},
				service: {},
				meta: {}
			};
		},

		iTeardownMyApp: function () {
			mockserver.stop();
			this.iTeardownMyUIComponent();
		}
	});
});