sap.ui.define([
	"sap/ui/test/Opa5",
	"de/pnw/icm/provisionsvertrag/vtr2/test/integration/arrangements/Startup",
	"./MasterJourney",
	"./navigationJourney",
	"./VertragJourney"
], function (Opa5, Startup) {
	"use strict";

	Opa5.extendConfig({
		arrangements: new Startup(),
		viewNamespace: "de.pnw.icm.provisionsvertrag.vtr2.view.",
		autoWait: true,
		asyncPolling: false
	});
});