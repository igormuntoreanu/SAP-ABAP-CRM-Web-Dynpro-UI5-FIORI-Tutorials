sap.ui.define([
	"sap/ui/test/Opa5",
	"de/pnw/icm/provisionsvertrag/vtr/test/integration/arrangements/Startup",
	"./MasterJourney",
	"./navigationJourney",
	"./VertragJourney"
], function (Opa5, Startup) {
	"use strict";

	Opa5.extendConfig({
		arrangements: new Startup(),
		viewNamespace: "de.pnw.icm.provisionsvertrag.vtr.view.",
		autoWait: true,
		asyncPolling: false
	});
});