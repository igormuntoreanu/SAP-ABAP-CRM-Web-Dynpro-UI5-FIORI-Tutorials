/*global QUnit*/

sap.ui.define([
	"sap/ui/test/opaQunit",
	"./pages/Master"
], function (opaTest) {
	"use strict";

	QUnit.module("Master");

	opaTest("Anzeige der Filter", function (Given, When, Then) {
		// Arrangements
		Given.iStartMyApp();

		// Asserstions
		Then.onTheMasterPage.iDisplayFilterBar();
	});

	opaTest("Darstellung der Verträge mit dem Standard Varianten Management", function (Given, When, Then) {
		// Asserstions
		Then.onTheMasterPage.iDisplayVertragList();
		Then.onTheMasterPage.iTitleShouldDisplayTheTotalOfVertrag();
	});

	opaTest("Suche nach Verträge", function (Given, When, Then) {
		//Actions
		When.onTheMasterPage.iEnterTextInput_CtrtbuId(50021);
		When.onTheMasterPage.iPressButton_expertModusBtn();
		When.onTheMasterPage.iEnterTextInput_Bpext(2);
		When.onTheMasterPage.iEnterTextInput_NameGrp1("m");

		// Asserstions
		Then.onTheMasterPage.iDisplayVertragList();
	});

	opaTest("Suche über Wertehilfe Dialog", function (Given, When, Then) {
		//Actions
		When.onTheMasterPage.iPressButton_SearchDialog("Herkunft");
		When.onTheMasterPage.iSelectRowInSearchDialog("2");

		// Asserstions
		Then.onTheMasterPage.iDisplayVertragList();
	});

	opaTest("Filter zurücksetzen", function (Given, When, Then) {

		// Asserstions
		Then.onTheMasterPage.iResetFilter();
		Then.onTheMasterPage.iDisplayVertragList();
		Then.iTeardownMyApp();
	});

});