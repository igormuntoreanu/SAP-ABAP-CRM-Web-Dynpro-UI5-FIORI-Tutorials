sap.ui.define([
	"sap/ui/test/Opa5",
	"sap/ui/test/actions/Press",
	"sap/ui/test/actions/EnterText",
	"sap/ui/test/matchers/I18NText",
	"sap/ui/test/matchers/Properties",
	"sap/ui/test/matchers/AggregationLengthEquals",
	"sap/ui/test/matchers/AggregationEmpty"
], function (Opa5, Press, EnterText, I18NText, Properties, AggregationLengthEquals, AggregationEmpty) {
	"use strict";

	Opa5.createPageObjects({
		onTheVertragPage: {
			actions: {
				iPressButtonSelectVersion: function () {
					return this.waitFor({
						viewName: "Vertrag",
						id: "idButtonSelectVersion",
						actions: new Press(),
						errorMessage: "Button Versionsdialog nicht gefunden"
					});
				},

				iPressCloseButton: function () {
					return this.waitFor({
						viewName: "Vertrag",
						id: "idButtonClose",
						actions: new Press(),
						errorMessage: "Schließen-Button nicht gefunden"
					});
				},
				iPressOnTheReferenzVertrag: function (sVertragsnummer) {
					return this.waitFor({
						fragmentId: "idFragmentReferenzenShow",
						controlType: "sap.m.Link",
						matchers: new Properties({
							text: sVertragsnummer
						}),
						actions: new Press(),
						errorMessage: "Link Referenzvertrag nicht gefunden"
					});
				},
				iPressButtonVersionsvergleich: function () {
					return this.waitFor({
						viewName: "Vertrag",
						id: "idButtonCompareMode",
						actions: new Press(),
						errorMessage: "Button Versionsvergleich nicht gefunden"
					});
				},
				iSeletVersion: function () {
					return this.waitFor({
						controlType: "sap.m.Dialog",
						matchers: new I18NText({
							propertyName: "title",
							key: "versionFragmentTitle",
							modelName: "i18n"
						}),
						success: function () {
							return this.waitFor({
								searchOpenDialogs: true,
								controlType: "sap.m.CustomListItem",
								actions: new Press(),
								errorMessage: "Versionen wurde nicht gefunden"
							});
						},
						errorMessage: "Versionsdialog wurde nicht angezeigt"
					});
				},
				iSetEditMode: function (bEditMode) {
					return this.waitFor({
						controlType: "sap.ui.core.mvc.View",
						matchers: {
							properties: {
								viewName: "de.pnw.icm.provisionsvertrag.vtr2.view.Vertrag"
							}
						},
						success: function (oView) {
							var oVertragView = oView[0];
							oVertragView.getModel("appView").setProperty("/editMode", bEditMode);
							//kann nicht aufgerufen werden, weil in den Mockdaten nicht simultan zum Backend zu Versionen navigiert werden kann
							// oVertragView.getController().checkEdit(); 
							// oVertragView.getController().navigateToVertrag(
							// 	"PvSucheSet(CacsBusitimeB=datetime'2021-05-18T06%3A55%3A24',Cacstechtime=datetime'2021-05-18T06%3A55%3A24',CtrtbuId='50021')"
							// );
						},
						errorMessage: "Vertrag-View nicht gefunden"
					});
				},
				iSetInactiveTime: function (iInactiveTime) {
					return this.waitFor({
						controlType: "sap.ui.core.mvc.View",
						matchers: {
							properties: {
								viewName: "de.pnw.icm.provisionsvertrag.vtr2.view.Vertrag"
							}
						},
						success: function (oView) {
							oView[0].getController().inactiveTime = iInactiveTime;
							oView[0].getController()._checkInactivity();
						},
						errorMessage: "Vertrag-View nicht gefunden"
					});
				},
				iSetTimeoutCounter: function () {
					return this.waitFor({
						controlType: "sap.ui.core.mvc.View",
						visible: false,
						matchers: {
							properties: {
								viewName: "de.pnw.icm.provisionsvertrag.vtr2.view.Vertrag"
							}
						},
						success: function (oView) {
							oView[0].getController().counter.setMinutes(oView[0].getController().counter.getMinutes() - 2);

						},
						errorMessage: "Vertrag-View nicht gefunden"
					});
				}
			},
			assertions: {
				theObjectPageShouldBeDisplayed: function (sVertragsnummer) {
					return this.waitFor({
						id: "idObjectPageLayoutVertrag",
						viewName: "Vertrag",
						success: function () {
							return this.waitFor({
								viewName: "Vertrag",
								id: "idVertragCtrtbuId",
								success: function (oText) {
									Opa5.assert.strictEqual(oText.getText(), sVertragsnummer, "Vertragsnummer " + sVertragsnummer +
										" wurde im Object Page Header angezeigt");
								},
								errorMessage: "Vertragsnummer " + sVertragsnummer + "wurde im Object Page Header nicht angezeigt"
							});

						},
						errorMessage: "Object Page konnte nicht angezeigt werden"
					});
				},
				wpvShouldBeDisplayed: function (sbool) {
					var sErrorMsg = "Sektion WPV wurde nicht angezeigt",
						sSuccessMsg = "Sektion WPV wurde angezeigt";
					if (!sbool) {
						sSuccessMsg = "Sektion WPV wurde nicht angezeigt";
						sErrorMsg = "Sektion WPV wurde nicht angezeigt";
					}

					return this.waitFor({
						id: "idFragmentWPVShow--idObjectPageSectionWPV",
						visible: sbool,
						success: function () {
							Opa5.assert.ok(true, sSuccessMsg);
						},
						errorMessage: sErrorMsg
					});
				},
				maklerKommShouldBeDisplayed: function (sbool) {
					var sErrorMsg = "Sektion Makler Kommunikation wurde nicht angezeigt",
						sSuccessMsg = "Sektion Makler Kommunikation wurde angezeigt";
					if (!sbool) {
						sSuccessMsg = "Sektion Makler Kommunikation wurde nicht angezeigt";
						sErrorMsg = "Sektion Makler Kommunikation wurde nicht angezeigt";
					}
					return this.waitFor({
						id: "idFragmentKorrespondenzShow--idObjectPageSectionMakler",
						visible: sbool,
						success: function () {
							Opa5.assert.ok(true, sSuccessMsg);
						},
						errorMessage: sErrorMsg
					});
				},
				lavvShouldBeDisplayed: function (iItemLength) {
					return this.waitFor({
						id: "idFragmentLavvShow--lavvList",
						matchers: new AggregationLengthEquals({
							name: "items",
							length: iItemLength
						}),
						success: function () {
							Opa5.assert.ok(true, iItemLength + " LaVv-Einräge wurden angezeigt");
						},
						errorMessage: "LaVv konnte nicht angezeigt werden"
					});
				},
				lavvShouldBeEmpty: function () {
					return this.waitFor({
						id: "idFragmentLavvShow--lavvList",
						matchers: new AggregationEmpty({
							name: "items"
						}),
						success: function () {
							Opa5.assert.ok(true, "LaVv ist leer");
						},
						errorMessage: "LaVv konnte nicht angezeigt werden"
					});
				},
				compareVersionEnabled: function (bool) {
					return this.waitFor({
						viewName: "Vertrag",
						id: "idButtonCompareMode",
						enabled: bool,
						success: function () {
							Opa5.assert.ok(true, "Button Versionsvergleich wid korrekt angezeigt");
						},
						errorMessage: "Button Versionsvergleich wird nicht korrekt angezeigt"
					});
				},
				lockScreenShouldBeDisplayed: function () {
					return this.waitFor({
						id: "idFragmentContentLocked--LockedSection",
						success: function () {
							Opa5.assert.ok(true, "Inhalt wird aufgrund CoC-Sperre nicht angezeigt");
						},
						errorMessage: "Inhalt wird trotz CoC-Sperre angezeigt"
					});
				},
				labelValueStateShouldHaveChanged: function (sField, sValueState, sToolTipText) {
					return this.waitFor({
						id: "idFragmentAllgemeinesShow--idObjectStatusAllgemeines" + sField,
						success: function (oLabelExtended) {
							Opa5.assert.strictEqual(oLabelExtended.getValueState(), sValueState, "Label " + oLabelExtended.getText() +
								" hat den Value State " + sValueState);
							Opa5.assert.strictEqual(oLabelExtended.getTooltip_Text(), sToolTipText, "Tooltip wurde korrekt angezeigt");
						},
						errorMessage: "Label für " + sField + " hat nicht den Value State " + sValueState
					});
				},
				busiBeginShouldBeEditable: function (bVisible) {
					var sErrorMsg = "BusiBegin im Object Page Header ist nicht editierbar",
						sSuccessMsg = "BusiBegin im Object Page Header ist editierbar";
					if (!bVisible) {
						sSuccessMsg = "BusiBegin im Object Page Header ist nicht editierbar";
						sErrorMsg = "BusiBegin im Object Page Header ist editierbar";
					}

					return this.waitFor({
						viewName: "Vertrag",
						id: "idHBoxBusiBeginEditMode",
						visible: bVisible,
						matchers: {
							properties: {
								visible: bVisible
							}
						},
						success: function () {
							Opa5.assert.ok(true, sSuccessMsg);
						},
						errorMessage: sErrorMsg
					});
				},
				lavvToolBarShouldBeDisplayed: function (bVisible) {
					var sErrorMsg = "Toolbar zum Bearbeiten von LaVv wird nicht angezeigt",
						sSuccessMsg = "Toolbar zum Bearbeiten von LaVv wird angezeigt";
					if (!bVisible) {
						sSuccessMsg = "Toolbar zum Bearbeiten von LaVv wird nicht angezeigt";
						sErrorMsg = "Toolbar zum Bearbeiten von LaVv wird angezeigt";
					}
					return this.waitFor({
						id: "idFragmentLavvShow--idToolbarLavvShow",
						visible: bVisible,
						success: function () {
							Opa5.assert.ok(true, sSuccessMsg);
						},
						errorMessage: sErrorMsg
					});
				},
				lavvDeleteColumnShouldBeDisplayed: function (bVisible) {
					var sErrorMsg = "Spalte zum Löschen von LaVv wird nicht angezeigt",
						sSuccessMsg = "Spalte zum Löschen von LaVv wird angezeigt";
					if (!bVisible) {
						sSuccessMsg = "Spalte zum Löschen von LaVv wird nicht angezeigt";
						sErrorMsg = "Spalte zum Löschen von LaVv wird angezeigt";
					}
					return this.waitFor({
						id: "idFragmentLavvShow--idLavvShowColumnDelete",
						visible: bVisible,
						success: function () {
							Opa5.assert.ok(true, sSuccessMsg);
						},
						errorMessage: sErrorMsg
					});
				},
				timeoutAfterFiveMinutesShouldBeDisplayed: function () {
					return this.waitFor({
						timeout: 80, //time out nach 80 Sekunden
						pollingInterval: 1000, //checkt jede Sekunde
						id: "idTimeoutDialog",
						viewName: "Vertrag",
						success: function (oDialog) {
							Opa5.assert.ok(true, "Timeout-Dialog wird nach 5 Minuten Inaktivität angezeigt");
						},
						errorMessage: "Timeout-Dialog nicht gefunden"
					});
				},
				timeoutAfterFiveMinutesShouldBeClosed: function () {
					return this.waitFor({
						id: "idTimeoutDialog",
						viewName: "Vertrag",
						visible: false,
						success: function (oDialog) {
							Opa5.assert.propEqual(oDialog.getVisible(), false, "Timeout-Dialog wird nach 2 Minuten geschlossen");
						},
						errorMessage: "Timeout-Dialog nicht gefunden"
					});
				}
			}
		}
	});
});