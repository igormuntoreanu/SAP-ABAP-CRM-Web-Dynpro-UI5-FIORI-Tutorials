sap.ui.define([
	"sap/ui/test/Opa5",
	"sap/ui/test/actions/Press",
	"sap/ui/test/actions/EnterText",
	"sap/ui/test/matchers/I18NText",
	"sap/ui/test/matchers/Ancestor",
	"sap/ui/test/matchers/Properties"
], function (Opa5, Press, EnterText, I18NText, Ancestor, Properties) {
	"use strict";

	Opa5.createPageObjects({
		onTheMasterPage: {
			actions: {
				iPressButton_expertModusBtn: function () {
					return this.waitFor({
						id: "expertModusBtn",
						viewName: "Master",
						actions: new Press(),
						success: function (aButtons) {
							Opa5.assert.ok(true, "Expert Modus aktiviert");
						},
						errorMessage: "Expert Modus konnte nicht aktiviert werden"
					});
				},
				iEnterTextInput_CtrtbuId: function (iCtrtbuId) {
					return this.waitFor({
						id: "CtrtbuId",
						viewName: "Master",
						actions: new EnterText({
							text: iCtrtbuId
						}),
						success: function () {
							Opa5.assert.ok(true, "Suche nach Provisionsvertrag: " + iCtrtbuId);
						},
						errorMessage: "Filter für Vertragsnummer nicht gefunden"
					});
				},
				iEnterTextInput_Bpext: function (iBpext) {
					return this.waitFor({
						id: "Bpext",
						viewName: "Master",
						actions: new EnterText({
							text: iBpext
						}),
						success: function () {
							Opa5.assert.ok(true, "Suche nach Gebiet: " + iBpext);
						},
						errorMessage: "Filter für Gebiet nicht gefunden"
					});
				},
				iEnterTextInput_NameGrp1: function (sNameGrp1) {
					return this.waitFor({
						id: "NameGrp1",
						viewName: "Master",
						actions: new EnterText({
							text: sNameGrp1
						}),
						success: function () {
							Opa5.assert.ok(true, "Suche nach Nachname: " + sNameGrp1);
						},
						errorMessage: "Filter für Nachname nicht gefunden"
					});
				},
				iPressButton_SearchDialog: function (sMultiInputId) {
					return this.waitFor({
						viewName: "Master",
						controlType: "sap.ui.core.Icon",
						matchers: {
							ancestor: {
								viewName: "Master",
								controlType: "sap.m.MultiInput",
								id: sMultiInputId
							}
						},
						actions: new Press(),
						success: function () {
							Opa5.assert.ok(true, "Wertehilfe-Dialog geöffnet für " + sMultiInputId);
						},
						errorMessage: "Button für den Wertehilfe-Dialog von " + sMultiInputId + " nicht gefunden"
					});
				},
				iSelectRowInSearchDialog: function (sWertehilfe) {
					return this.waitFor({
						viewName: "Master",
						searchOpenDialogs: true,
						controlType: "sap.m.Text",
						matchers: {
							properties: {
								text: sWertehilfe
							},
							ancestor: {
								viewName: "Master",
								searchOpenDialogs: true,
								controlType: "sap.ui.table.Table"
							}
						},
						actions: new Press(),
						success: function () {
							return this.waitFor({
								viewName: "Master",
								searchOpenDialogs: true,
								controlType: "sap.m.Button",
								matchers: new Properties({
									text: "OK"
								}),
								actions: new Press(),
								errorMessage: "Button OK im Wertehilfe-Dialog nicht gefunden"
							});
						},
						errorMessage: "Wertehilfe " + sWertehilfe + " nicht gefunden"
					});
				},
				iPressButton_persoBtn: function () {
					return this.waitFor({
						id: "persoBtn",
						viewName: "Master",
						actions: new Press(),
						errorMessage: "Eine Personalisierung der Tabelle ist nicht möglich"
					});
				},
				iPressOnTheItem: function () {
					return this.waitFor({
						controlType: "sap.m.ColumnListItem",
						viewName: "Master",
						//matcher
						actions: new Press(),
						errorMessage: "Vertrag nicht gefunden"
					});
				}
			},
			assertions: {
				iDisplayFilterBar: function () {
					return this.waitFor({
						id: "idFilterBar",
						viewName: "Master",
						success: function () {
							Opa5.assert.ok(true, "Filter wurden angezeigt");
						},
						errorMessage: "Filter konnten nicht angezeigt werden "
					});
				},
				iResetFilter: function () {
					return this.waitFor({
						id: "idFilterBar",
						viewName: "Master",
						success: function (oControl) {
							oControl.reset();
							Opa5.assert.ok(true, "Filter wurden zurückgesetzt");
						},
						errorMessage: "Filter konnten nicht zurückgesetzt werden "
					});
				},
				iDisplayVertragList: function () {
					return this.waitFor({
						id: "vertragList",
						viewName: "Master",
						controlType: "sap.m.Table",
						success: function (oResult) {
							var iNbr = oResult.getItems().length,
								sMsg = "Es wurde ";
							if (iNbr === 0) {
								sMsg = sMsg + " keinen Vertrag dargestellt";
							} else if (iNbr === 1) {
								sMsg = sMsg + " einen Vertrag dargestellt";
							} else {
								sMsg = sMsg + iNbr + " Verträge dargestellt";
							}
							Opa5.assert.ok(true, sMsg);
						},
						errorMessage: "Verträge konnten nicht angezeigt werden"
					});
				},
				iTitleShouldDisplayTheTotalOfVertrag: function () {
					return this.waitFor({
						id: "vertragList",
						viewName: "Master",
						controlType: "sap.m.Table",
						success: function (oResult) {
							var iNbr = oResult.getItems().length,
								sTitle = "";
							if ((iNbr >= 50) && (iNbr % 50 === 0)) {
								sTitle = "(" + iNbr + "+)";
							} else {
								sTitle = "(" + iNbr + ")";
							}
							this.iCheckTitle(iNbr, sTitle);
						},
						errorMessage: "Table Title does not contain with number of items"
					});
				},
				iCheckTitle: function (iNbr, sTitle) {
					return this.waitFor({
						id: "tableTitle",
						viewName: "Master",
						matchers: new I18NText({
							key: "listTitle",
							propertyName: "text",
							parameters: [sTitle]
						}),
						success: function () {
							Opa5.assert.ok(true, "Table Title contain with number of items: " + iNbr);
						},
						errorMessage: "Table Title does not contain with number of items"
					});
				}
			}
		}
	});
});