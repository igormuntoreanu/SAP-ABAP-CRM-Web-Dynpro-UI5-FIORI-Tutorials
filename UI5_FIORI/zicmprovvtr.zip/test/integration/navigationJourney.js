sap.ui.define([
	"sap/ui/test/opaQunit",
	"de/pnw/icm/provisionsvertrag/vtr/test/integration/pages/Master",
	"de/pnw/icm/provisionsvertrag/vtr/test/integration/pages/Vertrag"
], function (opaTest) {
	"use strict";

	QUnit.module("Navigation");

	opaTest("Anzeige der Object Page wenn ein Vertrag ausgewählt wird", function (Given, When, Then) {

		Given.iStartMyApp();

		When.onTheMasterPage.iEnterTextInput_CtrtbuId(50021);
		When.onTheMasterPage.iPressOnTheItem();

		Then.onTheVertragPage.theObjectPageShouldBeDisplayed("50021");
	});

	opaTest("Anzeige des Referenzvertrags", function (Given, When, Then) {
		When.onTheVertragPage.iPressOnTheReferenzVertrag("50020");

		Then.onTheVertragPage.theObjectPageShouldBeDisplayed("50020");
	});

	opaTest("Anzeige der Ergebnisliste wenn ein Vertrag geschlossen wird", function (Given, When, Then) {

		When.onTheVertragPage.iPressCloseButton();

		Then.onTheMasterPage.iDisplayVertragList();
		Then.iTeardownMyApp();
	});

	opaTest("Vertragsversion über Versionsdialog öffnen", function (Given, When, Then) {

		Given.iStartMyApp();

		When.onTheMasterPage.iEnterTextInput_CtrtbuId(50022);
		When.onTheMasterPage.iPressButton_expertModusBtn();
		When.onTheMasterPage.iEnterTextInput_NameGrp1("Aktueller Vertrag");
		When.onTheMasterPage.iPressOnTheItem();

		When.onTheVertragPage.iPressButtonSelectVersion();

		When.onTheVertragPage.iSeletVersion();

		Then.onTheVertragPage.theObjectPageShouldBeDisplayed("50022");

		Then.iTeardownMyApp();
	});

});