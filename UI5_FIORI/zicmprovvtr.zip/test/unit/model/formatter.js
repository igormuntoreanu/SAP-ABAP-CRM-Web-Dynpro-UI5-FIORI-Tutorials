sap.ui.define([
	"de/pnw/icm/provisionsvertrag/vtr2/model/formatter",
	"de/pnw/icm/provisionsvertrag/vtr2/localService/mockserver"
], function (formatter, mockserver) {
	"use strict";

	mockserver.init();

	QUnit.module("Formatter");

	function checkHighDate(oOptions) {
		// Act
		var sDate = formatter.checkHighDate(oOptions.date);

		// Assert
		oOptions.assert.strictEqual(sDate, oOptions.expected, "Input: " + oOptions.date + "\nOutput: " + sDate);
	}

	QUnit.test("Datum anzeigen, wenn es ungleich 31.12.9999 ist", function (assert) {
		checkHighDate.call(this, {
			assert: assert,
			date: "01.12.2020",
			expected: "01.12.2020"
		});
	});

	QUnit.test("Datum nicht anzeigen, wenn es gleich 31.12.9999 ist", function (assert) {
		checkHighDate.call(this, {
			assert: assert,
			date: "31.12.9999",
			expected: ""
		});
	});

	QUnit.module("Formetierung");

	function formatDezimalWithLocalString(oOptions) {
		// Act
		var sNumber = formatter.formatDezimalWithLocalString(oOptions.number);

		// Assert
		oOptions.assert.strictEqual(sNumber, oOptions.expected, "Input: " + oOptions.number + "\nOutput: " + sNumber);
	}

	QUnit.test("Formatierung in Local String", function (assert) {
		formatDezimalWithLocalString.call(this, {
			assert: assert,
			number: 1.4517,
			expected: "1,45"
		});
	});

	QUnit.test("Dezimale Formatierung", function (assert) {
		formatDezimalWithLocalString.call(this, {
			assert: assert,
			number: 1.4517,
			expected: "1,45"
		});
	});

});