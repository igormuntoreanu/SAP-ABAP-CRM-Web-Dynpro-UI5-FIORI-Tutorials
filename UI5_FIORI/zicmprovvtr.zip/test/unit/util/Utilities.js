sap.ui.define([
	"de/pnw/icm/provisionsvertrag/vtr/util/Utilities",
	"sap/ui/model/json/JSONModel",
	"sap/base/util/isEmptyObject"
], function (Utilities, JSONModel, isEmptyObject) {
	"use strict";

	QUnit.module("Utilities");

	function compareJSON(oOptions) {
		// Act
		var oDiff = Utilities.compareJSONObject(oOptions.previous, oOptions.current);

		var bDiff = isEmptyObject(oDiff);
		// Assert
		oOptions.assert.strictEqual(bDiff, oOptions.expected, oOptions.section + " wurde richtig verglichen");
	}

	function compareTable(oOptions) {
		// Act
		var oDiff = Utilities.getTableDifference(oOptions.previous, oOptions.current);

		// Assert
		oOptions.assert.deepEqual(oDiff, oOptions.expected, oOptions.section + " wurde richtig verglichen");
	}

	QUnit.test("Versionsvergleich für 50021", function (assert) {
		var oModel = new JSONModel(sap.ui.require.toUrl("de/pnw/icm/provisionsvertrag/vtr/test/unit/json/50021.json"));
		assert.ok(true, "Vorherige und aktuelle Verträge holen");

		oModel.attachRequestCompleted(function (oEvent) {
			var oSource = oEvent.getSource();
			var oCurrent50021 = oSource.getProperty("/current") || {},
				oPrevious50021 = oSource.getProperty("/previous") || {},
				oCurrent50021Lavv = {},
				oPrevious50021Lavv = {},
				oCurrent50021APKond = {},
				oPrevious50021APKond = {},
				oCurrent50021VPKond = {},
				oPrevious50021VPKond = {};

			// Allgemeines	
			compareJSON.call(this, {
				assert: assert,
				current: oCurrent50021.Allgemeines || {},
				previous: oPrevious50021.Allgemeines || {},
				section: "Allgemeines",
				expected: false
			});

			// Abrechnung
			compareJSON.call(this, {
				assert: assert,
				current: oCurrent50021.ProvVertrToAbrechnung || {},
				previous: oPrevious50021.ProvVertrToAbrechnung || {},
				section: "Abrechnung",
				expected: true
			});

			// Korrespondenz
			compareJSON.call(this, {
				assert: assert,
				current: oCurrent50021.ProvVertrToKorrespondenz || {},
				previous: oPrevious50021.ProvVertrToKorrespondenz || {},
				section: "Korrespondenz",
				expected: true
			});

			// WPV Stammdaten
			compareJSON.call(this, {
				assert: assert,
				current: oCurrent50021.ProvVertrToWpvStamm || {},
				previous: oPrevious50021.ProvVertrToWpvStamm || {},
				section: "WPV Stammdaten",
				expected: false
			});

			// LaVv
			(oCurrent50021.ToLavv.results || []).forEach(function (item) {
				oCurrent50021Lavv[item.BucagrId] = item;
			});
			(oPrevious50021.ToLavv.results || []).forEach(function (item) {
				oPrevious50021Lavv[item.BucagrId] = item;
			});

			compareTable.call(this, {
				assert: assert,
				current: oCurrent50021Lavv || {},
				previous: oPrevious50021Lavv || {},
				section: "LaVv",
				expected: {
					deleted: 2,
					added: 0
				}
			});

			// WPV AP Provisionen
			(oCurrent50021.ProvVertrToWpvKond.results || []).forEach(function (item) {
				var key = item.Art + item.Sparte + item.Verguetungsart;
				if (item.Verguetungsart === "AP") {
					oCurrent50021APKond[key] = item;
				} else if (item.Verguetungsart === "VP") {
					oCurrent50021VPKond[key] = item;
				}
			});

			// WPV VP Provisionen
			(oPrevious50021.ProvVertrToWpvKond.results || []).forEach(function (item) {
				var key = item.Art + item.Sparte + item.Verguetungsart;
				if (item.Verguetungsart === "AP") {
					oPrevious50021APKond[key] = item;
				} else if (item.Verguetungsart === "VP") {
					oPrevious50021VPKond[key] = item;
				}
			});

			compareTable.call(this, {
				assert: assert,
				current: oCurrent50021APKond || {},
				previous: oPrevious50021APKond || {},
				section: " WPV AP Provisionen",
				expected: {
					deleted: 2,
					added: 3
				}
			});

			compareTable.call(this, {
				assert: assert,
				current: oCurrent50021VPKond || {},
				previous: oPrevious50021VPKond || {},
				section: " WPV VP Provisionen",
				expected: {
					deleted: 2,
					added: 0
				}
			});
		});

	});

	function dateToStr(oOptions) {
		// Act
		var sDate = Utilities.dateToStr(oOptions.oDate);

		// Assert
		oOptions.assert.strictEqual(sDate, oOptions.expected, "Input: " + oOptions.oDate + "\nOutput: " + sDate);
	}

	QUnit.test("Konvertiert ein Date Objekt in einen String dd.MM.YY", function (assert) {
		dateToStr.call(this, {
			assert: assert,
			oDate: new Date(2021, 0, 1),
			expected: "01.01.2020"
		});
	});

	function urlEncodeEmptySpace(oOptions) {
		var sUrl = Utilities.urlEncodeEmptySpace(oOptions.sUrl);

		oOptions.assert.strictEqual(sUrl, oOptions.expected, "Input: " + oOptions.sUrl + "\nOutput: " + sUrl);
	}

	QUnit.test("URL-Encodiert Leerzeichen in %20", function (assert) {
		urlEncodeEmptySpace.call(this, {
			assert: assert,
			sUrl: "CtrtbuId 1",
			expected: "CtrtbuId%201"
		});
	});

	function formatDate(oOptions) {
		// Act
		var sDate = Utilities.formatDate(oOptions.oDate);

		// Assert
		oOptions.assert.strictEqual(sDate, oOptions.expected, "Input: " + oOptions.oDate + "\nOutput: " + sDate);

		return sDate;
	}

	function buildPvSuchePath(oOptions) {
		// Act
		var sPath = Utilities.buildPvSuchePath(oOptions.sCacsBusitimeB, oOptions.sCacstechtime, oOptions.sCtrtbuId);

		// Assert
		oOptions.assert.strictEqual(sPath, oOptions.expected, "Input: " + oOptions.sCacsBusitimeB + ", " + oOptions.sCacstechtime + ", " +
			oOptions.sCtrtbuId +
			"\nOutput: " + sPath);
	}

	QUnit.test("Bildet für die Entität PvSucheSet den Pfad: CacsBusitimeB, Cacstechtime, CtrtbuId ", function (assert) {
		var sCacsBusitimeB = formatDate.call(this, {
			assert: assert,
			oDate: new Date(2021, 5, 28),
			expected: "2021-06-28T00%3A00%3A00"
		});

		var sCacstechtime = formatDate.call(this, {
			assert: assert,
			oDate: new Date(2021, 4, 27, 16, 4, 33),
			expected: "2021-05-27T16%3A04%3A33"
		});

		var sCtrtbuId = "50021";

		buildPvSuchePath.call(this, {
			assert: assert,
			sCacsBusitimeB: sCacsBusitimeB,
			sCacstechtime: sCacstechtime,
			sCtrtbuId: sCtrtbuId,
			expected: "PvSucheSet(CacsBusitimeB=datetime'2021-06-28T00%3A00%3A00',Cacstechtime=datetime'2021-05-27T16%3A04%3A33',CtrtbuId='50021')"
		});

	});
});