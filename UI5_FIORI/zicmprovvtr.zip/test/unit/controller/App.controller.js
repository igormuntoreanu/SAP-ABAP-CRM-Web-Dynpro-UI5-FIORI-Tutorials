sap.ui.define([
	"de/pnw/icm/provisionsvertrag/vtr2/controller/App.controller"
], function (App) {
	"use strict";

	QUnit.module("App Controller");
	QUnit.test("App Controller wurde geladen", function (e) {
		var o = new App();
		var n = o.getMetadata().getName();
		e.ok(n, "de/pnw/icm/provisionsvertrag/vtr.controller.App");
	});
});