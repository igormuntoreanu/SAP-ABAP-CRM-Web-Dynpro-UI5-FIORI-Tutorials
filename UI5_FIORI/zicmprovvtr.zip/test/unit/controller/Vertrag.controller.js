sap.ui.define([
	"de/pnw/icm/provisionsvertrag/vtr/controller/Vertrag.controller"
], function (Vertrag) {
	"use strict";

	QUnit.module("Vertrag Controller");
	QUnit.test("Vertrag Controller wurde geladen", function (e) {
		var vertrag = new Vertrag();
		var name = vertrag.getMetadata().getName();
		e.ok(name, "de/pnw/icm/provisionsvertrag/vtr.controller.Vertrag");
	});
});