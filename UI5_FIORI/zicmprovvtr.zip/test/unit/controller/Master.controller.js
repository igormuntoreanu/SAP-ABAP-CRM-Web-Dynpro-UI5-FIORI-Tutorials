sap.ui.define([
	"de/pnw/icm/provisionsvertrag/vtr/controller/Master.controller"
], function (Master) {
	"use strict";

	QUnit.module("Master Controller");
	QUnit.test("Master Controller wurde geladen", function (e) {
		var master = new Master();
		var name = master.getMetadata().getName();
		e.ok(name, "de/pnw/icm/provisionsvertrag/vtr.controller.Master");
	});
});