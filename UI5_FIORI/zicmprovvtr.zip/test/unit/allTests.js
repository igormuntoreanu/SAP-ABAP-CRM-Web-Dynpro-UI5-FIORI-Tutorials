sap.ui.define([
	"de/pnw/icm/provisionsvertrag/vtr/test/unit/controller/App.controller",
	"de/pnw/icm/provisionsvertrag/vtr/test/unit/controller/Master.controller",
	"de/pnw/icm/provisionsvertrag/vtr/test/unit/controller/Vertrag.controller",
	"de/pnw/icm/provisionsvertrag/vtr/test/unit/model/formatter",
	"de/pnw/icm/provisionsvertrag/vtr/test/unit/util/Utilities"
], function () {
	"use strict";
});