sap.ui.define([], function () {
	"use strict";
	return {
		checkHighDate: function (oDate) {
			if (oDate !== "31.12.9999") {
				return oDate;
			}
			return "";
		},

		/*
			Formatierung Kbtr und KbetrStd für die Dastellung als locale String
			oder einfach als zweistellige dezimalzahlen im Editmodus: 2,3 ist kein Input Type Number (2.3)
		*/
		formatDezimalWithLocalString: function (sDezimal) {

			var dDezimal = parseFloat(sDezimal);
			if (isNaN(dDezimal)) {
				return sDezimal;
			}
			return dDezimal.toLocaleString("de-DE", {
				minimumFractionDigits: 2,
				maximumFractionDigits: 2
			});
		},

		formatDezimal: function (sDezimal) {
			var dDezimal = parseFloat(sDezimal);
			if (isNaN(dDezimal)) {
				return sDezimal;
			}
			return dDezimal.toFixed(2);
		},
		
		/*
			Die Methode dummy kann einem formatter in XML Views mit , formatter: '.formatter.dummy' mitgegeben werden.
			Beispiel:
			<m:Text text="{path: 'vertrag>ProvVertrToAuszahlung/ZKontoauszt', formatter: '.formatter.dummy'}"/>
			Dafür muss der debugger eingeschaltet werden. Der Formatter muss generell in der Zugehörigen js eingebunden sein.
		*/
		dummy: function (sValue) {
			//debugger;
			if (!sValue) {
				return "";
			}
			return sValue.toString();
		}
	};
});