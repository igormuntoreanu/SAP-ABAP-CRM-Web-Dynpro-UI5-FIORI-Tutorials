sap.ui.define([
	"./Utilities",
	"sap/ui/core/Fragment",
	"sap/m/MessageBox",
	"sap/base/util/isEmptyObject",
	"sap/ui/core/format/DateFormat",
	"sap/m/MessageToast"
], function (Utilities, Fragment, MessageBox, isEmptyObject, DateFormat, MessageToast) {
	"use strict";

	return {
		
		checkHighDate: function (oDate) {
			if (oDate !== "31.12.9999") {
				return false;
			}
			return true;
		},

		/*
		Konvertiert ein Date Objekt in einen String dd.MM.YY
		*/
		dateToStr: function (oDate) {
			var dateFormat = DateFormat.getDateInstance({
				pattern: "dd.MM.YYYY"
			});
			return dateFormat.format(oDate);
		},

		/*
		Fehlermeldung anzeigen
		*/
		displayErrorMessageBox: function (sMessage, view) {
			var bCompact = !!view.$().closest(".sapUiSizeCompact").length,
				confirmMsg = sMessage;
			MessageBox.error(
				confirmMsg, {
					actions: [MessageBox.Action.CLOSE],
					styleClass: bCompact ? "sapUiSizeCompact" : "",
					onClose: function (sAction) {
						
					}
				}
			);
		},

		/*
			URL-Encodiert Leerzeichen in %20
		*/
		urlEncodeEmptySpace: function (sStringtoEncode) {
			return sStringtoEncode.replace(" ", "%20");
		},

		/*
			Bildet für die Entität PvSucheSet den Pfad bestehend aus CacsBusitimeB, Cacstechtime, CtrtbuId 
		*/
		buildPvSuchePath: function (sCacsBusitimeB, sCacstechtime, sCtrtbuId) {
			return "PvSucheSet(CacsBusitimeB=datetime'" + sCacsBusitimeB + "',Cacstechtime=datetime'" + sCacstechtime + "',CtrtbuId='" +
				sCtrtbuId + "')";
		},

		/* 
		returns a Date Format yyyy-mm-ddThh%3Amm%3Ass as String
		The Problem is, that any Date needs the Format of ISOString, but if you use the .toISOString Method, the Date
		will be converted to UTC. This Method is independent from any Browser and returns the correct timeformat with local
		timestamp.
		*/
		formatDate: function (date) {
			var returnString = "";
			var year = "" + date.getFullYear(),
				month = "" + (date.getMonth() + 1),
				day = "" + date.getDate();
			if (month.length < 2) {
				month = "0" + month;
			}
			if (day.length < 2) {
				day = "0" + day;
			}
			var hours = "" + (date.getHours()),
				mins = "" + date.getMinutes(),
				secs = "" + date.getSeconds();
			if (hours.length < 2) {
				hours = "0" + hours;
			}
			if (mins.length < 2) {
				mins = "0" + mins;
			}
			if (secs.length < 2) {
				secs = "0" + secs;
			}
			returnString = year + '-' + month + '-' + day + 'T' + hours + "%3A" + mins + "%3A" + secs;
			return returnString;
		},

		/*
			Busy Dialog öffnen		
		*/
		_showBusyDialog: function () {
			if (!Fragment.byId("idBusyFragment", "idBusyDialog")) {
				Fragment.load({
					id: "idBusyFragment",
					name: "de.pnw.icm.provisionsvertrag.vtr.view.fragment.BusyDialog",
					controller: this
				}).then(function (oDialog) {
					oDialog.open();
				});
			} else {
				Fragment.byId("idBusyFragment", "idBusyDialog").open();
			}
		},

		/*
			Promise OData Read
			@param: 
				- oModel: OData Model, 
				- sPath: Path / EntitySet
				- oUrlParameter: Anfrage Parameter als JSON Object
				- aFilter: Filter als Liste
		*/
		promiseODataRead: function (oModel, sPath, oUrlParameter, aFilter) {
			return new Promise(function (resolve, reject) {
				oModel.read("/" + sPath, {
					urlParameters: oUrlParameter,
					filters: aFilter,
					success: function (oCompleteEntry) {
						resolve(oCompleteEntry);
					},
					error: function (oError) {
						reject(oError);
					}
				});
			});
		},

		/*
			Promise OData Create
			@param: 
				- oModel: OData Model, 
				- sPath: Path / EntitySet
				- oData: Daten
		*/
		promiseODataCreate: function (oModel, sPath, oData) {
			return new Promise(function (resolve, reject) {
				oModel.create("/" + sPath, oData, {
					success: function (oCompleteEntry) {
						resolve(oCompleteEntry);
					},
					error: function (oError) {
						reject(oError);
					}
				});
			});
		},

		/*
			Promise OData Update
			@param: 
				- oModel: OData Model, 
				- sPath: Path / EntitySet
				- oData: Daten
		*/
		promiseODataUpdate: function (oModel, sPath, oData) {
			return new Promise(function (resolve, reject) {
				oModel.update("/" + sPath, oData, {
					success: function (oCompleteEntry) {
						resolve(oCompleteEntry);
					},
					error: function (oError) {
						reject(oError);
					}
				});
			});
		},

		/*
			Promise OData Delete
			@param: 
				- oModel: OData Model, 
				- sPath: Path / EntitySet
		*/
		promiseODataDelete: function (oModel, sPath) {
			return new Promise(function (resolve, reject) {
				oModel.remove("/" + sPath, {
					success: function (oCompleteEntry) {
						resolve(oCompleteEntry);
					},
					error: function (oError) {
						reject(oError);
					}
				});
			});
		},

		/*
			zwei JSON Objekte vergleichen und den Unterschied mit oPreviousObject zurück geben
		 */
		compareJSONObject: function (oPreviousObject, oCurrentObject) {
			var result = {};

			if (Object.is(oPreviousObject, oCurrentObject)) {
				return result;
			}

			if (!oPreviousObject || typeof oPreviousObject !== "object") {
				return oPreviousObject;
			}

			var aKey = Object.keys(oPreviousObject || {}).concat(Object.keys(oCurrentObject || {}));
			if (aKey.length === 0 && !Object.is(oPreviousObject, oCurrentObject)) {
				return oPreviousObject;
			}
			aKey.forEach(function (key) {
				if (oCurrentObject[key] instanceof Date && oPreviousObject[key] instanceof Date) {
					if (oCurrentObject[key].getTime() !== oPreviousObject[key].getTime()) {
						result[key] = this.dateToStr(oPreviousObject[key]);
					}
				} else if (oCurrentObject[key] !== oPreviousObject[key] && !Object.is(oPreviousObject[key], oCurrentObject[key])) {
					result[key] = oPreviousObject[key];
				}
				if (typeof oCurrentObject[key] === "object" && typeof oPreviousObject[key] === "object") {
					var value = this.compareJSONObject(oPreviousObject[key], oCurrentObject[key]);
					if (!isEmptyObject(value)) {
						result[key] = value;
					}
				}
			}.bind(this));
			return result;
		},
		/*
			Liefert die Anzahl von gelöschte und hinzugefügte Zeilen
		*/

		getTableDifference: function (oPrevious, oCurrent) {
			var deleted = 0,
				added = 0;
			Object.keys(oPrevious || {}).forEach(function (key) {
				if (!(key in oCurrent)) {
					deleted++;
				}
			});
			Object.keys(oCurrent || {}).forEach(function (key) {
				if (!(key in oPrevious)) {
					added++;
				}
			});
			return {
				deleted: deleted,
				added: added
			};
		},

		/*
			vorherhige fachliche gültige Versione 
		*/

		getPreviousVertrag: function (oVertragModel, sPath, oThis) {
			var oUrlParameters = {
				$expand: "ProvVertrToPartner,ProvVertrToKommMakler,ProvVertrToWpvStamm,ProvVertrToWpvKond,ToLavv,ProvVertrToKorrespondenz"
			};
			return new Promise(function (resolve, reject) {
				this.promiseODataRead(oVertragModel, sPath + "/PvSucheToProvVertr", oUrlParameters, []).then(
					function (oData) { //resolve
						delete oData.__metadata;
						delete oData.ToVersion;
						delete oData.ToStdLavv;
						delete oData.ProvVertrToVermGruppen;
						delete oData.ProvVertrToOrgaStruktur;
						delete oData.ProvVertrToAuszahlungBank;
						delete oData.ProvVertrToAnsprechpartner;
						delete oData.ProVertrToReferenzen;
						delete oData.ProvVertrToPartner;
						delete oData.Notizen;

						var aLaVv = oData.ToLavv.results,
							oLaVv = {};
						aLaVv.forEach(function (oItem) {
							var key = oItem.BucagrId;
							if (key) {
								delete oItem.__metadata;
								oLaVv[key] = oItem;
							}
						});
						oThis.oModel.setProperty("/previousLavv", oLaVv);
						delete oData.ToLavv;
						if (oThis.oModel.getProperty("/showWPV")) {
							delete oData.ProvVertrToWpvStamm.__metadata;
							oThis.oModel.setProperty("/previousWpvStamm", oData.ProvVertrToWpvStamm);
							delete oData.ProvVertrToWpvStamm;

							var aWpvKond = oData.ProvVertrToWpvKond.results,
								oWpvKond = {};

							aWpvKond.forEach(function (oItem) {
								var sArt = oItem.Art,
									sSparte = oItem.Sparte,
									sVerguetungsart = oItem.Verguetungsart;
								var key = sArt + sSparte + sVerguetungsart;
								if (key) {
									delete oItem.__metadata;
									oWpvKond[key] = oItem;
								}
							});
							oThis.oModel.setProperty("/previousWpvKond", oWpvKond);
							delete oData.ProvVertrToWpvKond;
						}

						if (oThis.oModel.getProperty("/showMaklerKomm") && oData.ProvVertrToKommMakler.results) {
							var oMaklerKommFormatted = {};
							oData.ProvVertrToKommMakler.results.forEach(function (oEntity) {
								oMaklerKommFormatted[(oEntity.Artt)] = oEntity.FlgVorh;
							});
							oThis.oModel.setProperty("/previousKommMakler", oMaklerKommFormatted);
							delete oData.ProvVertrToKommMakler;
						}

						delete oData.ProvVertrToKorrespondenz.__metadata;
						oThis.oModel.setProperty("/previousKorrespondenz", oData.ProvVertrToKorrespondenz);
						delete oData.ProvVertrToKorrespondenz;

						oThis.oModel.setProperty("/previousVertrag", oData);
						resolve(oData);
					},
					function (oError) { //reject
						reject(oError);
					}
				);
			}.bind(this));

		},

		geti18nText: function (oI18nModel, sText, aParameter) {
			return oI18nModel.getResourceBundle().getText(sText, aParameter);
		},

		/*
			Zu einer View navigieren
		*/
		navToRoute: function (oRoute, sName, oLayout, sVertragPath, sLeistungPath, sVerguetungPath) {
			oRoute.navTo(sName, {
				layout: oLayout,
				vertragPath: sVertragPath,
				leistungPath: sLeistungPath,
				verguetungPath: sVerguetungPath
			});
		},

		shwoMessageToast: function (sMessage, iDuration, bCloseOnBrowserNavigation) {
			MessageToast.show(sMessage, {
				duration: iDuration, // time till toast fades/decays
				closeOnBrowserNavigation: bCloseOnBrowserNavigation // keep toast shown in spite of routing
			});
		},

		/*
			Überprüfen, ob der Nutzer berechtigt ist das semantische Objekt „ZIcmProvVtr“ mit der Aktion „edit“ zu öffnen
			- Ja: Button "Edit" aktivieren
			- Nein: Button "Edit" inaktivieren
		*/
		checkIfEditable: function () {
			//TODO: Change semanticObject and action before deploying 
			return new Promise(function (resolve, reject) {
				if (sap.ushell && sap.ushell.Container) {
					this.oCrossAppNav = sap.ushell.Container.getService("CrossApplicationNavigation");
					this.oCrossAppNav.isNavigationSupported([{
							target: {
								semanticObject: "Action",
								action: "todefaultapp"
							}
						}])
						.done(function (aResponse) {
							resolve(aResponse[0].supported);
						})
						.fail(function (oError) {
							reject(oError);
						});
				} else {
					reject(false);
				}

			}.bind(this));
		},

		deleteStoredOData: function (model, specific) {
			
			if (specific) {
				$.each(model.oData, function (value, index, array) {
					if (value.includes("AuszahlungSet") || value.includes("BearbSperreSet") ||
						value.includes("KorrespondenzSet") || 
						value.includes("OrgaStrukturSet") || value.includes("PartnerSet") ||
						value.includes("ProvVertVersionSet") || value.includes("ProvVertrSet") ||
						value.includes("AdressenlisteSet") || value.includes("AuszahlungBankSet") ||
						value.includes("KonditionsTabSet") || value.includes("KonditionenSet")
					) {
						delete model.oData[value];
					}
				});
			} else {
				model.oData = {};
			}
			
		}

	};
});