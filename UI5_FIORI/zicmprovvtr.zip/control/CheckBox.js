sap.ui.define([
	"sap/m/CheckBox",
	"de/pnw/icm/provisionsvertrag/vtr2/control/CheckBoxRenderer"
], function (CheckBox, CheckBoxRenderer) {
	"use strict";

	var CheckBox = CheckBox.extend("de.pnw.icm.provisionsvertrag.vtr2.control.CheckBox", {

		renderer: function (oRm, oControl) {
			CheckBoxRenderer.render(oRm, oControl);
		}

	});

	return CheckBox;
});