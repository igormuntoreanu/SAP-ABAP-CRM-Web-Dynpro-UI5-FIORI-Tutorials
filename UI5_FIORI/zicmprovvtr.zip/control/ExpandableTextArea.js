sap.ui.define([
		"sap/m/library",
		"sap/ui/core/Control",
		"sap/ui/core/library",
		"sap/ui/Device",
		"sap/m/Link",
		"sap/m/Text",
		"sap/m/Button",
		"de/pnw/icm/provisionsvertrag/vtr/control/HyphenationSupport",
		"de/pnw/icm/provisionsvertrag/vtr/control/ExpandableTextAreaRenderer",
		"de/pnw/icm/provisionsvertrag/vtr/util/Utilities"
	],
	function (library,
		Control,
		coreLibrary,
		Device,
		Link,
		Text,
		Button,
		HyphenationSupport,
		ExpandableTextAreaRenderer,
		Utilities
	) {
		"use strict";

		// shortcut for sap.ui.core.TextAlign
		var TextAlign = coreLibrary.TextAlign;

		// shortcut for sap.ui.core.TextDirection
		var TextDirection = coreLibrary.TextDirection;

		// shortcut for sap.m.WrappingType
		var WrappingType = library.WrappingType;

		function reduceWhitespace(sText) {
			return sText.replace(/ {2,}/g, ' ').replace(/\t{2,}/g, ' ');
		}

		var ExpandableTextArea = Control.extend("de.pnw.icm.provisionsvertrag.vtr.control.ExpandableTextArea", {
			metadata: {

				interfaces: [
					"sap.ui.core.IFormContent"
				],
				library: "sap.m",
				properties: {

					/**
					 * Determines the text to be displayed.
					 */
					text: {
						type: "string",
						defaultValue: "",
						bindable: "bindable"
					},

					/**
					 * Available options for the text direction are left-to-right (LTR) and right-to-left (RTL)
					 * By default the control inherits the text direction from its parent control.
					 */
					textDirection: {
						type: "sap.ui.core.TextDirection",
						group: "Appearance",
						defaultValue: TextDirection.Inherit
					},

					/**
					 * Defines the type of text wrapping to be used (hyphenated or normal).
					 */
					wrappingType: {
						type: "sap.m.WrappingType",
						group: "Appearance",
						defaultValue: WrappingType.Normal
					},

					/**
					 * Sets the horizontal alignment of the text.
					 */
					textAlign: {
						type: "sap.ui.core.TextAlign",
						group: "Appearance",
						defaultValue: TextAlign.Begin
					},

					/**
					 * Specifies how whitespace and tabs inside the control are handled. If true, whitespace will be preserved by the browser.
					 */
					renderWhitespace: {
						type: "boolean",
						group: "Appearance",
						defaultValue: false
					},

					/**
					 * Specifies the maximum number of characters from the beginning of the text field that are shown initially.
					 */
					maxCharacters: {
						type: "int",
						group: "Appearance",
						defaultValue: 100
					},

					/**
					 * Determines if the text is expanded.
					 * @private
					 */
					expanded: {
						type: "boolean",
						group: "Appearance",
						defaultValue: false,
						visibility: "hidden"
					}
				},
				aggregations: {
					/**
					 * The "More" link.
					 * @private
					 */
					_showMoreLink: {
						type: "sap.m.Link",
						multiple: false,
						visibility: "hidden"
					}
				},

				designtime: "de/pnw/icm/provisionsvertrag/vtr/control/ExpandableTextArea.designtime"
			}
		});

		/**
		 * Gets the text.
		 *
		 * @public
		 * @param {boolean} bNormalize Indication for normalized text.
		 * @returns {string} Text value.
		 */
		ExpandableTextArea.prototype.getText = function (bNormalize) {
			// returns the text value and normalize line-ending character for rendering
			var sText = this.getProperty("text");

			// handle line ending characters for renderer
			if (bNormalize) {
				return sText.replace(/\r\n|\n\r|\r/g, "\n");
			}

			return sText;
		};

		// /**
		//  * Returns the text node container's DOM reference.
		//  * This can be different from <code>getDomRef</code> when inner wrapper is needed.
		//  *
		//  * @protected
		//  * @returns {HTMLElement|null} DOM reference of the text.
		//  */
		ExpandableTextArea.prototype.getTextDomRef = function () {
			if (!this.getVisible()) {
				return null;
			}

			return this.getDomRef("string");
		};

		// /**
		//  * Returns if the text is expandable
		//  *
		//  * @returns {boolean} if the text is expandable
		//  * @private
		//  */
		ExpandableTextArea.prototype._isExpandable = function () {

			var sText = this.getText();
			var sShowMore = this.getModel("i18n").getResourceBundle().getText("showMore");

			if (!this.getRenderWhitespace()) {
				sText = reduceWhitespace(sText);
			}

			return sText.length > this._getMaxCharacters() + sShowMore.length;
		};

		// /**
		//  * Returns the maximum number of initially displayed characters.
		//  *
		//  * @private
		//  */
		ExpandableTextArea.prototype._getMaxCharacters = function () {
			return Math.max(0, this.getMaxCharacters());
		};

		// /**
		//  * Returns the displayed text.
		//  *
		//  * @returns {string} the displayed text
		//  * @private
		//  */
		ExpandableTextArea.prototype._getDisplayedText = function () {

			var sText = this.getText(true);

			if (this.getProperty("expanded") || !this._isExpandable()) {
				return sText;
			}

			if (!this.getRenderWhitespace()) {
				sText = reduceWhitespace(sText);
			}

			return sText.substring(0, this._getMaxCharacters());
		};

		ExpandableTextArea.prototype._getShowMoreLink = function () {
			var showMoreLink = this.getAggregation("_showMoreLink");

			if (!showMoreLink) {
				var sShowMore = this.getModel("i18n").getResourceBundle().getText("showMore");
				var sShowLess = this.getModel("i18n").getResourceBundle().getText("showLess");
				showMoreLink = new Link(this.getId() + "-showMoreLink", {
					text: this.getProperty("expanded") ? sShowLess : sShowMore,
					press: function (oEvent) {
						var bExpanded;

						bExpanded = !this.getProperty("expanded");
						showMoreLink.setText(bExpanded ? sShowLess : sShowMore);
						this.setProperty("expanded", bExpanded);

						// force the re-rendering of the link,
						// so the popover won't flickering,
						// because of text changing
						showMoreLink.rerender();

					}.bind(this)
				});

				this.setAggregation("_showMoreLink", showMoreLink, true);
			}

			return showMoreLink;
		};

		ExpandableTextArea.prototype._onPopoverBeforeClose = function () {
			var sShowMore = this.getModel("i18n").getResourceBundle().getText("showMore");
			this._getShowMoreLink().setText(sShowMore);
		};

		/**
		 * Called when the control is destroyed.
		 */
		ExpandableTextArea.prototype.exit = function () {
			if (this._oPopover) {
				this._oPopover.destroy();
				this._oPopover = null;
			}
		};

		/**
		 * Gets the accessibility information for the text.
		 *
		 * @protected
		 * @returns {object} Accessibility information for the text.
		 * @see sap.ui.core.Control#getAccessibilityInfo
		 */
		ExpandableTextArea.prototype.getAccessibilityInfo = function () {
			return {
				description: this.getText()
			};
		};

		/**
		 * Gets a map of texts which should be hyphenated.
		 *
		 * @private
		 * @returns {Object<string,string>} The texts to be hyphenated.
		 */
		ExpandableTextArea.prototype.getTextsToBeHyphenated = function () {
			return {
				"main": this._getDisplayedText(true)
			};
		};

		/**
		 * Gets the DOM refs where the hyphenated texts should be placed.
		 *
		 * @private
		 * @returns {map|null} The elements in which the hyphenated texts should be placed
		 */
		ExpandableTextArea.prototype.getDomRefsForHyphenatedTexts = function () {
			return {
				"main": this.getTextDomRef()
			};
		};

		// Add hyphenation to ExpandableText functionality
		HyphenationSupport.mixInto(ExpandableTextArea.prototype);

		return ExpandableTextArea;
	});