sap.ui.define([
	"sap/m/Label",
	"sap/ui/core/ValueState",
	"de/pnw/icm/provisionsvertrag/vtr2/control/LabelExtendedRenderer"
], function (Label, ValueState, LabelExtendedRenderer) {
	"use strict";

	var LabelExtended = Label.extend("de.pnw.icm.provisionsvertrag.vtr2.control.LabelExtended", {
		metadata: {
			properties: {
				valueState: {
					type: "string",
					group: "Data",
					defaultValue: ValueState.None
				}
			}
		},
		renderer: function (oRm, oControl) {
			LabelExtendedRenderer.render(oRm, oControl);
		}

	});

	return LabelExtended;

});