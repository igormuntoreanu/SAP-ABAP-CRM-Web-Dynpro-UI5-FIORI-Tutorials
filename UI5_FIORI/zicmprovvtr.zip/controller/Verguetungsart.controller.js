sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/m/ColumnListItem",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/MessageBox",
	"sap/m/TablePersoController",
	"jquery.sap.global",
	"sap/ui/core/Fragment",
	"sap/m/MessageToast",
	"de/pnw/icm/provisionsvertrag/vtr/model/formatter",
	"sap/ui/core/Item",
	"de/pnw/icm/provisionsvertrag/vtr/util/Utilities"
], function (Controller, JSONModel, ColumnListItem, Filter, FilterOperator, MessageBox, TablePersoController, jQuery, Fragment,
	MessageToast, formatter, Item, Utilities) {
	"use strict";

	return Controller.extend("de.pnw.icm.provisionsvertrag.vtr.controller.Verguetungsart", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf de.pnw.icm.provisionsvertrag.vtr.view.Verguetungsart
		 */
		formatter: formatter,

		onInit: function () {
			this.oRouter = this.getOwnerComponent().getRouter();
			this.oModel = this.getOwnerComponent().getModel("appView");
			this.vertragModel = this.getOwnerComponent().getModel("vertrag");
			this.kondtionList = this.byId("konditionList");
			this.i18n = this.getOwnerComponent().getModel("i18n");
			// proceed only if sap.ushell service is available
			if (sap.ushell && sap.ushell.Container && sap.ushell.Container.getService) {
				var oComponent = sap.ui.core.Component.getOwnerComponentFor(this.getView());
				this.oPersonalizationService = sap.ushell.Container.getService("Personalization");
				var oPersId = {
					container: "konditionList", // Any //10.02.2021 alter Name: konditionListPersonalisation
					item: "konditionList" // Table id 
				};
				// define scope 
				var oScope = {
					keyCategory: this.oPersonalizationService.constants.keyCategory.FIXED_KEY,
					writeFrequency: this.oPersonalizationService.constants.writeFrequency.LOW,
					clientStorageAllowed: true
				};
				var oPersonalizer = this.oPersonalizationService.getPersonalizer(oPersId, oScope, oComponent);

				// init and activate controller
				this.oTablepersoService = new TablePersoController({
					table: this.getView().byId("konditionList"),
					persoService: oPersonalizer
				}).activate();

				// get default columns
				this.aDefaultColumns = this.getDefaultColumns();

				this.oPersonalizationService.getContainer("konditionList", oScope, oComponent) //10.02.2021 alter Name: konditionListPersonalisation
					.done(function (oContainer) {
						this.oContainer = oContainer;
						this.oVariantSetAdapter = new sap.ushell.services.Personalization.VariantSetAdapter(this.oContainer);
						// get variant set which is stored in backend
						this.oVariantSet = this.oVariantSetAdapter.getVariantSet("konditionList");
						if (!this.oVariantSet) { //if not in backend, then create one
							this.oVariantSet = this.oVariantSetAdapter.addVariantSet("konditionList");
						}
						var defaultVariantKey = this.oVariantSet.getCurrentVariantKey();
						// array to store the existing variants
						var Variants = [],
							defaultVariantName = null;
						// now get the existing variants from the backend to show as list
						for (var key in this.oVariantSet.getVariantNamesAndKeys()) {
							if (this.oVariantSet.getVariantNamesAndKeys().hasOwnProperty(key)) {
								var oVariantItemObject = {};
								oVariantItemObject.Key = this.oVariantSet.getVariantNamesAndKeys()[key];
								oVariantItemObject.Name = key;
								Variants.push(oVariantItemObject);
								if (this.oVariantSet.getVariantNamesAndKeys()[key] === defaultVariantKey) {
									defaultVariantName = key;
								}
							}
						}

						// Attach to the variant management UI control
						this.oModel.setProperty("/VariantListKond", Variants);
						this.getView().byId("VariantsKond").setModel(this.oModel);
						this.getView().byId("VariantsKond").currentVariantSetModified(false);
						//set default variant, initial select and personalization
						this.getView().byId("VariantsKond").setInitialSelectionKey(defaultVariantKey);
						this.getView().byId("VariantsKond").setDefaultVariantKey(defaultVariantKey);
						this.setSelectedVariantToTable(defaultVariantName);

					}.bind(this));
			}
			this.oRouter.getRoute("verguetung").attachPatternMatched(this._onObjectMatched, this);
		},

		getDefaultColumns: function () {
			var defaultColumns = [];
			if (this.oTablepersoService) {
				var initialTblStateMap = this.oTablepersoService._mInitialTableStateMap;
				var firstKey = Object.keys(initialTblStateMap)[0];
				defaultColumns = initialTblStateMap[firstKey];
			}
			return defaultColumns;
		},

		setVariantList: function () {
			var Variants = [];
			// now get the existing variants from the backend to show as list
			for (var key in this.oVariantSet.getVariantNamesAndKeys()) {
				if (this.oVariantSet.getVariantNamesAndKeys().hasOwnProperty(key)) {
					var oVariantItemObject = {};
					oVariantItemObject.Key = this.oVariantSet.getVariantNamesAndKeys()[key];
					oVariantItemObject.Name = key;
					Variants.push(oVariantItemObject);
				}
			}

			// Attach to the variant management UI control
			this.oModel.setProperty("/VariantListKond", Variants); //Error 10.02.2021
			this.oModel.refresh(); //Error 10.02.2021
		},

		onSaveAs: function (oEvent) {
			var VariantParam = oEvent.getParameters();
			var aColumnsData = this.oTablepersoService._oPersonalizations.aColumns;
			// Check if the variant already exist, else create a new
			this.oVariant = this.oVariantSet.getVariant(VariantParam.key);
			if (!this.oVariant) {
				this.oVariant = this.oVariantSet.addVariant(VariantParam.name);
			}
			if (this.oVariant) {
				// Setzt die Spalten definition von Konditionen
				this.oVariant.setItemValue("konditionList", JSON.stringify(aColumnsData));
				if (VariantParam.def === true) {
					this.oVariantSet.setCurrentVariantKey(this.oVariant.getVariantKey());
				}
				this.oContainer.save();
				this.oContainer.save().done(function () {
					this.setVariantList();
					// Tell the user that the personalization data was saved
					MessageToast.show(VariantParam.name + " " + Utilities.geti18nText(this.i18n, "saved", []));
				}.bind(this));

			}
		},

		onSelect: function (oEvent) {
			var selectedKey = oEvent.getParameter("key");
			for (var i = 0; i < oEvent.getSource().getVariantItems().length; i++) {
				if (oEvent.getSource().getVariantItems()[i].getProperty("key") === selectedKey) {
					var selectedVariant = oEvent.getSource().getVariantItems()[i].getProperty("text");
					break;
				}
			}
			this.setSelectedVariantToTable(selectedVariant);
		},

		/*
			Hole die entsprechenden Konfigs und setzte in der Tabelle
		*/
		setSelectedVariantToTable: function (oSelectedVariant) {
			var aColumns = [];
			if (oSelectedVariant) {
				var oVariant = this.oVariantSet.getVariant(this.oVariantSet.getVariantKeyByName(oSelectedVariant));
				aColumns = JSON.parse(oVariant.getItemValue("konditionList"));
			}
			// default *Standard*
			else {
				aColumns = this.aDefaultColumns;
			}

			this.oldColumns = aColumns.map(function (item) {
				var obj = {};
				obj.id = item.id;
				obj.order = item.order;
				obj.visible = item.visible;
				obj.group = item.group;
				return obj;
			});

			var persData = {
				_persoSchemaVersion: "1.0",
				aColumns: aColumns
			};
			this.oTablepersoService.getPersoService().setPersData(persData);
			this.oTablepersoService.applyPersonalizations();
			this.oContainer.save();
		},

		/*
			Verwahltung von Variants
		*/
		onManage: function (oEvent) {
			var oParameters = oEvent.getParameters();

			// rename variants
			if (oParameters.renamed.length > 0) {
				oParameters.renamed.forEach(function (aRenamed) {
					var sVariant = this.oVariantSet.getVariant(aRenamed.key);
					sVariant.setVariantName(aRenamed.name);
				}.bind(this));
			}

			// default variant changed
			if (oParameters.def !== "*standard*") {
				this.oVariantSet.setCurrentVariantKey(oParameters.def);
			} else {
				this.oVariantSet.setCurrentVariantKey(null);
			}

			// Delete variants
			if (oParameters.deleted.length > 0) {
				oParameters.deleted.forEach(function (aDelete) {
					this.oVariantSet.delVariant(aDelete);
				}.bind(this));
			}

			//Save the Variant Container
			this.oContainer.save();
			this.oContainer.save().done(function () {
				// Tell the user that the personalization data was saved
				MessageToast.show(Utilities.geti18nText(this.i18n, "changed", []));
			}.bind(this));
		},

		/*
				Element im View binden wenn die Route aufgerufen wurde,
				globale Variablen werden auch hier definiert und zugewiesen
				ältere geänderte Konditionen werden abgeholt und wenn vorhanden dargestellt (setChachedKond),
				wenn nicht werden Konditionen im Backend abgeholt (afterObjectMatched)
		
				Im Bearbeitungsmodus wenn das Gültig-Ab gesetzt wurde, wird im kopfdaten angepasst
			*/
		_onObjectMatched: function (oEvent) {
			this._vertragPath = oEvent.getParameter("arguments").vertragPath;
			this._leistungPath = oEvent.getParameter("arguments").leistungPath;
			this._verguetungPath = oEvent.getParameter("arguments").verguetungPath;
			this.changedKondition = [];
			this.oDataResults = {};
			this.filteredOData = {};
			this.indicesOfChangedKonds = {};

			//Set personalization
			//this.setSelectedVariantToTable();

			// prüft, ob Daten im Modell vorhanden

			if (this.vertragModel.getData("/" + this._verguetungPath)) {
				this.isEditMode = this.oModel.getProperty("/editMode");
				this.getView().bindElement({
					path: "/" + this._verguetungPath,
					model: "vertrag"
				});
				var validFromDate = this.oModel.getProperty("/validFromDate");
				if (validFromDate) {
					this.byId("validFromKond").setText(validFromDate.toLocaleDateString());
				}
				var chache = this.oModel.getProperty("/chachedKond");
				
				if (chache) {
					// check if chached Kond match with selected Lavv
					var cachedLavv = chache[this._leistungPath];
					if (cachedLavv) {
						// check if cached Lavv match with seleted Kond
						var cachedKond = cachedLavv[this._verguetungPath];
						if (cachedKond) {
							this.setChachedKond(cachedKond);
						} else {
							this.afterObjectMatched();
						}
					} else {
						this.afterObjectMatched();
					}
				} else {
					this.afterObjectMatched();
				}
				this.oModel.setProperty("/kondHasChanged", false);
			} else {
				this.navigateToView(sap.f.LayoutType.OneColumn, "vertrag");
			}
		},
		/*
			setChachedKond setzt die vorhandene Konditionen in der View
		*/
		setChachedKond: function (oData) {
			this.konditionFilter(oData);
			this._konditionModel = new JSONModel(oData);
			this.getView().byId("konditionList").setModel(this._konditionModel);
			this.setTableTitle(oData.length);
		},
		/*
			Holt die Konditionen in Backend und setzt in der Tabelle
		*/
		afterObjectMatched: function () {
			var oVertragModel = this.getView().getModel("vertrag"),
				tabName = this._verguetungPath.split("Set")[1],
				sPath = this._leistungPath + "/ToKondTab" + tabName + "/ToKond";

			Utilities._showBusyDialog();
			Utilities.promiseODataRead(oVertragModel, sPath, {}, []).then(
				function (oData) { //resolve
					this.konditionFilter(oData.results);
					this._konditionModel = new JSONModel(oData.results);
					this.getView().byId("konditionList").setModel(this._konditionModel); //diese Zeile löscht den Eeintrag der Indiv raus
					this.setTableTitle(oData.results.length);
					Fragment.byId("idBusyFragment", "idBusyDialog").close();
				}.bind(this),
				function (oError) { //reject
					Fragment.byId("idBusyFragment", "idBusyDialog").close();
					Utilities.displayErrorMessageBox(oError.message, this.getView());
				}.bind(this)
			);
		},

		/*
			setzt den Tabellentitel mit dem Anzahl von Datensätzen
		*/
		setTableTitle: function (length) {
			var sTitle = "";
			sTitle = "(" + length + ")";
			var txt = Utilities.geti18nText(this.i18n, "lavv", [sTitle]);
			this.oModel.setProperty("/konditionTitle", txt);
		},

		/*
			Nach oben zurück scrollen
		*/
		onUpdateFinished: function (oEvent) {
			if (this.bFilterChanged) {
				this.byId("ObjectPageVerguetung").getScrollDelegate().scrollTo(0, 0);
				this.bFilterChanged = false;
			}
		},

		/*
			öffnet Variant Management für den Auswahl von Spalten und die Reihenfolge
		*/
		onPersoButtonPressed: function (oEvent) {
			if (this.oTablepersoService) {
				this.oTablepersoService.openDialog();
				var sOldColumns = JSON.stringify(this.oldColumns);
				var that = this;
				this.oTablepersoService.attachPersonalizationsDone(function (oPerso) {
					//that.oTablepersoService.savePersonalizations();
					// set to json model
					var aColumns = oPerso.getSource()._oPersonalizations.aColumns;
					var aNewColumns = aColumns.map(function (item) {
						var obj = {};
						obj.id = item.id;
						obj.order = item.order;
						obj.visible = item.visible;
						obj.group = item.group;
						return obj;
					});
					var sNewColumns = JSON.stringify(aNewColumns);
					// Wurde die Spalten Eingeschaften geändert? Wenn ja zeigt im Variant Titel
					if (sOldColumns !== sNewColumns) {
						that.setVariantTitle();
					}
					that.oModel.setProperty("/konditionList", aColumns);
				});
			}
		},

		setVariantTitle: function () {
			var variant = this.getView().byId("VariantsKond");
			variant.currentVariantSetModified(true);
		},

		/*
			Holt die Elemente der Filter und setzt Filter für verkaufsgruppe und tarifwerk
		*/
		konditionFilter: function (oData) {
			// original oData vorhalten
			this.oDataResults = oData;
			// im filteredOData wird alles gespeichert, was auch tatsächlich angezeigt wird
			this.filteredOData = this.oDataResults;
			var vZweg = this.oModel.getProperty("/vZweg");
			if (vZweg === "L" && oData.length > 0) {
				// set select filter visible
				this.byId("verkaufsgruppe").setVisible(true);
				this.byId("tarifwerk").setVisible(true);
				var verkaufsgruppeArr = [],
					tarifwerkArr = [];
				for (var i in oData) {
					verkaufsgruppeArr.push(oData[i].ZVerkaufsgruppe);
					tarifwerkArr.push(oData[i].ZTarifwerk);
				}

				verkaufsgruppeArr = this.removeDuplicate(verkaufsgruppeArr);
				tarifwerkArr = this.removeDuplicate(tarifwerkArr);

				this.byId("verkaufsgruppe").removeAllItems();
				this.byId("tarifwerk").removeAllItems();

				this.addSelectItem("verkaufsgruppe", 0, "{vertrag>/KonditionenSet/ZVerkaufsgruppe/#@sap:label}");
				this.addSelectItem("tarifwerk", 0, "{vertrag>/KonditionenSet/ZTarifwerk/#@sap:label}");

				verkaufsgruppeArr.sort(); //sortiert die Elemente der Verkaufsgruppe alphabetisch 
				if (verkaufsgruppeArr.indexOf("Leben") !== -1) {
					//if(verkaufsgruppeArr.includes("Leben")){	<----- includes not supported by IE11 + Opera
					var indexOfLeben = verkaufsgruppeArr.indexOf("Leben");
					verkaufsgruppeArr.unshift("Leben");
					verkaufsgruppeArr.splice(indexOfLeben + 1, 1);
				}

				// tarifwerkArr.sort().reverse();
				tarifwerkArr.sort(function (a, b) {
					return b - a; // sortiert die Elemente des Tarifwerks absteigend.
				});

				if (tarifwerkArr.indexOf("V86") !== -1) {
					//if(tarifwerkArr.includes("V86")){		<----- includes not supported by IE11 + Opera
					var indexOfV86 = tarifwerkArr.indexOf("V86");
					tarifwerkArr.splice(indexOfV86, 1);
					tarifwerkArr.push("V86");
				}

				for (var j in verkaufsgruppeArr) {
					this.addSelectItem("verkaufsgruppe", verkaufsgruppeArr[j], verkaufsgruppeArr[j]);
				}

				for (var k in tarifwerkArr) {
					this.addSelectItem("tarifwerk", tarifwerkArr[k], tarifwerkArr[k]);
				}

			} else {
				// hidde select filter
				this.byId("verkaufsgruppe").setVisible(false);
				this.byId("tarifwerk").setVisible(false);
			}
			this.determineCurrentKonwaStd(); //hier wird ermittelt welche Einheit im Individualiseren Dialog benötigt werden
		},
		/*
			Suche nach Duplikaten im Array und lösche sie
		*/
		removeDuplicate: function (array) {
			var unique = {};
			array.forEach(function (i) {
				if (!unique[i]) {
					unique[i] = true;
				}
			});
			return Object.keys(unique);
		},
		/*
			Fügt items in dem Auswahlfeld ein
		*/
		addSelectItem: function (selectId, itemKey, itemText) {
			var item = new Item({
				key: itemKey,
				text: itemText
			});
			this.byId(selectId).addItem(item);
			if (itemKey === 0) {
				this.byId(selectId).setSelectedItem(item);
			}
		},
		/*
			Tabelle wird nach Selektion gefiltert
			TODO: Geht aktuell nicht
		*/
		onSelectChange: function () {
			var aFilter = [],
				gruppe = this.byId("verkaufsgruppe").getSelectedKey(),
				tarifwerk = this.byId("tarifwerk").getSelectedKey();

			if (gruppe !== "0") {
				aFilter.push(new Filter("ZVerkaufsgruppe", FilterOperator.EQ, gruppe));
			}
			if (tarifwerk !== "0") {
				aFilter.push(new Filter("ZTarifwerk", FilterOperator.EQ, tarifwerk));
			}

			// filter binding
			var oBinding = this.byId("konditionList").getBinding("items");
			oBinding.filter(aFilter);

			//update table header
			var len = oBinding.getLength();
			this.setTableTitle(len);
			var i;
			// reset filteredOData
			this.filteredOData = {};
			// in oBinding.aIndices stehen die Indices der angezeigten Konditionen aus dem original OData 
			for (i = 0; i < len; i++) {
				this.filteredOData[i] = this.oDataResults[oBinding.aIndices[i]];
			}
			this.filteredOData.length = len;
			this.indicesOfChangedKonds = oBinding.aIndices;

			this.determineCurrentKonwaStd(); //hier wird ermittelt welche Einheit im Individualiseren Dialog benötigt werden
			this.bFilterChanged = true;
		},

		/*
			Bei einer Individualisierung werden die Daten in this.changedKondition gepush 
			und kondHasChanged auf true im Modell gestzt.
			Vor der Speicherung wird geprüft, ob der Datensatz vorhanden ist, ggf. aktualisiert oder gepusht
		*/

		onKbetrLiveChange: function (oEvent) {
			var itemPath = oEvent.getSource().getParent().getBindingContext().getPath().substr(1);
			this.toBeChangedKond = this._konditionModel.getData()[itemPath];
		},

		onKbetrChange: function (oEvent) {
			var itemPath = oEvent.getSource().getParent().getBindingContext().getPath().substr(1),
				newValue = oEvent.getParameter("newValue");
			// Sonderfall IE: Der IE wandelt die Komma in den Werten nicht direkt in Punkte um. 
			// Chrome usw machen das so schon. Da das Feld vom Type Number ist, versteht es Kommawerte nur mit Punkt.
			// Für alle anderen Browser ist das eh nicht relevant
			newValue = newValue.replace(/,/g, '.');

			var selectedKond = this._konditionModel.getData()[itemPath];
			selectedKond.Kbetr = newValue;
			delete selectedKond.bckgrd;

			if (this.changedKondition.length > 0) {
				var idx = this.changedKondition.indexOf(this.toBeChangedKond);
				if (idx !== -1) {
					this.changedKondition[idx] = selectedKond;
				} else {
					this.changedKondition.push(selectedKond);
				}
			} else {
				this.changedKondition.push(selectedKond);
			}
			this.oModel.setProperty("/kondHasChanged", true);
		},
		
		resetKond: function(){
			
			this.changedKondition = [];
			this.oModel.setProperty("/kondHasChanged", false);
			delete this._konditionModel;
			this.afterObjectMatched();
		}, 
		
		/*
			Am Ende der Individualisierung sollten die neuen und älteren Änderungen zusammengefügt.
			die aktuelle Änderung wird im Objekt "chachedKond" aus dem Modell gesichert und das Ergebnis im "changedKondition"
		*/
		saveKond: function () {
			var obj1 = {},
				obj2 = {},
				oldKond = this.oModel.getProperty("/changedKondition"),
				cacheLavv = this.oModel.getProperty("/chachedKond"),
				cacheObj = {},
				allKond = this.byId("konditionList").getModel().getData();

			if (oldKond) {
				if (oldKond[this._leistungPath]) {
					if (oldKond[this._leistungPath][this._verguetungPath]) {
						if (oldKond[this._leistungPath][this._verguetungPath].ToKond) {
							// wenn vorab alle Konditionen schon individualisiert wurden, darf bei einer Aktualisierung nur die entsprechende Kondition angepasst werden, sonst werden die anderen Individualisierungen überschrieben 
							var i, j;
							for (i = 0; i < oldKond[this._leistungPath][this._verguetungPath].ToKond.length; i++) {
								for (j = 0; j < this.changedKondition.length; j++) {
									if ((oldKond[this._leistungPath][this._verguetungPath].ToKond[i].Knumh === this.changedKondition[j].Knumh) && (oldKond[this._leistungPath]
											[this._verguetungPath].ToKond[i].KnumhStd === this.changedKondition[j].KnumhStd)) {
										oldKond[this._leistungPath][this._verguetungPath].ToKond[i].Kbetr = this.changedKondition[j].Kbetr;
									}
								}
							}
						} else {
							obj1.ToKond = this.changedKondition;
							oldKond[this._leistungPath][this._verguetungPath] = obj1;
						}
					} else {
						obj1.ToKond = this.changedKondition;
						oldKond[this._leistungPath][this._verguetungPath] = obj1;
					}
				} else {
					obj1.ToKond = this.changedKondition;
					obj2[this._verguetungPath] = obj1;
					oldKond[this._leistungPath] = obj2;
				}
			} else {
				oldKond = {};
				obj1.ToKond = this.changedKondition;
				obj2[this._verguetungPath] = obj1;
				oldKond[this._leistungPath] = obj2;

			}
			// Suche nach Vorhandene Cache und Aktualisierung
			if (!cacheLavv) {
				cacheLavv = {};
			}
			if (cacheLavv[this._leistungPath]) {
				cacheLavv[this._leistungPath][this._verguetungPath] = allKond;
			} else {
				cacheObj[this._verguetungPath] = allKond;
				cacheLavv[this._leistungPath] = cacheObj;
			}

			this.oModel.setProperty("/changedKondition", oldKond);
			this.oModel.setProperty("/chachedKond", cacheLavv);
			this.oModel.setProperty("/kondHasChanged", false);
			this.oModel.setProperty("/lavvHasChanged", true);
		},
		/*
			handleFullScreen: 2te Spalten im Vollbildmodus
			handleExitFullScreen: Vollbildmodus verlassen
			handleClose: 2te Spalte schließen, züruck auf dem Vertrag
			beforeNavigateToView: vor der Navigation auf dem Vertrag wird geprüft 
				ob es eine nicht gespeicherte Änderung gibt.
			navigateToView: Navigation zu einer Route
		 */
		handleFullScreen: function () {
			this.oModel.setProperty("/bInFullScreen", true);
			this.oModel.setProperty("/layout", "MidColumnFullScreen");
		},

		handleExitFullScreen: function () {
			this.oModel.setProperty("/bInFullScreen", false);
			this.oModel.setProperty("/layout", "TwoColumnsMidExpanded");
		},

		handleClose: function () {
			if (this.isEditMode && this.byId("alleIndivID")) {
				this.byId("alleIndivID")._lastValue = "";
				this.byId("alleIndivID")._sOldInputValue = null;
				this.byId("alleIndivID")._oTempValue._aContent[0] = "_";
				this.byId("alleIndivID")._oTempValue._aContent[1] = "_";
				this.byId("alleIndivID")._oTempValue._aContent[3] = "_";
				this.byId("alleIndivID")._oTempValue._aContent[4] = "_";
				this.byId("alleIndivID")._bCheckDomValue = true;
			}
			this.beforeNavigateToView(sap.f.LayoutType.OneColumn, "vertrag");
		},

		beforeNavigateToView: function (sNextLayout, sNextView) {

			if (this.oModel.getProperty("/kondHasChanged")) {
				var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length,
					confirmMsg = Utilities.geti18nText(this.i18n, "confirmMsg", []), //this.getView().getModel("i18n").getResourceBundle().getText("confirmMsg"),
					that = this;
				MessageBox.confirm(
					confirmMsg, {
						actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
						styleClass: bCompact ? "sapUiSizeCompact" : "",
						onClose: function (sAction) {
							if (sAction === "OK") {
								that.navigateToView(sNextLayout, sNextView);
							}
						}
					}
				);
			} else {
				this.navigateToView(sNextLayout, sNextView, false);
			}
			this.oModel.setProperty("/bInFullScreen", false);
		},

		navigateToView: function (sNextLayout, sNextView) {
			this.changedKondition = [];
			this.oRouter.navTo(sNextView, {
				layout: sNextLayout,
				vertragPath: this._vertragPath,
				leistungPath: this._leistungPath,
				verguetungPath: this._verguetungPath
			});
			this.oModel.setProperty("/bInFullScreen", false);
		},

		/*
		//this.oModel.setProperty("/hinweisText", <textVariableHierEinfügen>);
		Überschrift und Buttontexte sind der i18n zu entnehmen
		
		Öffnet ein Popup, in dem der Anwender einen Wert eintragen kann. Anschließend werden alle Konditionen der Tabelle auf diesen Wert individualisiert. 
		Dabei werden vorab die Filter berücksichtigt  
		*/
		openIndividualisieren: function () {
			if (!this.byId("alleIndividualisierenDialog")) {
				Fragment.load({
					id: this.getView().getId(),
					name: "de.pnw.icm.provisionsvertrag.vtr.view.fragment.alleIndividualisierenDialog",
					controller: this
				}).then(function (oDialog) {
					oDialog.setModel(this.getView().getModel("vertrag"));
					this.getView().addDependent(oDialog);
					oDialog.open();
				}.bind(this));
				this.defaultMask = this.byId("alleIndivIDProz");
			} else {
				//this.byId("alleIndividualisierenDialog").open();
				this.byId("alleIndividualisierenDialog").destroy();
				this.openIndividualisieren();
			}
		},

		determineCurrentKonwaStd: function () { //hier wird ermittelt welche Einheit im Individualiseren Dialog benötigt werden

			if (!KonwaStdList) {
				var KonwaStdList = [];
			} else {
				KonwaStdList = [];
			}

			var len = this.filteredOData.length;

			for (var i = 0; i < len; i++) { //erzeuge Array nur mit Einheiten der Tabelleneinträge

				var sValue = this.filteredOData[i].KonwaStd,
					bContains = (KonwaStdList.indexOf(sValue) === -1);

				if (bContains) {
					KonwaStdList.push(sValue);
				}
			}

			this.KonwaStdVisibSetting(KonwaStdList);
		},

		KonwaStdVisibSetting: function (KonwaStdList) {
			this.oModel.setProperty("/KonwaStdEURVis", (KonwaStdList.indexOf("EUR") !== -1));
			this.oModel.setProperty("/KonwaStdProzentVis", (KonwaStdList.indexOf("%") !== -1));
			this.oModel.setProperty("/KonwaStdProzentMBVis", (KonwaStdList.indexOf("%MB") !== -1));
			this.oModel.setProperty("/KonwaStdPromilleVis", (KonwaStdList.indexOf("%o") !== -1));
		},

		onZeroAll: function (oEvent) { //Button Methode "Alles nullen" im Dialog
			this.setAlleIndivValues(0); //Felder im Modell füllen
			this.handleValueAll("0"); //Input Mask Felder füllen
			this.handleOkIndiv();
		},
	
		handleValueAll: function (value){
			this.byId("alleIndivIDProz").setValue(value);
			this.byId("alleIndivIDProzMB").setValue(value);
			this.byId("alleIndivIDProm").setValue(value);
			this.byId("alleIndivIDEUR").setValue(value);	
		},
		
		onRemoveAll: function(oEvent){
			this.setAlleIndivValues("");
			this.handleValueAll("");
			this.handleOkIndiv();
		},

		setValuesInInput: function (name, string) { //setzt einen Eintrag in die Input Mask des Individualisieren Dialogs
			this.byId(name)._lastValue = "";
			this.byId(name)._sOldInputValue = null;
			this.byId(name).setValue(string);
			this.byId(name)._bCheckDomValue = true;
		},

		handleDeclineIndiv: function (oEvent) { //regelt was passiert wenn Individualisieren Dialog abgebrochen wird
			this.setAlleIndivValues(null);
			this.byId("alleIndividualisierenDialog").close();
		},

		setAlleIndivValues: function (value) { //setze die Werte im Modell auf übergebenen Wert
			this.oModel.setProperty("/alleIndivValueProz", value);
			this.oModel.setProperty("/alleIndivValueProzMB", value);
			this.oModel.setProperty("/alleIndivValueProm", value);
			this.oModel.setProperty("/alleIndivValueEUR", value);
		},

		/*
			
		 */
		handleOkIndiv: function (oEvent) {
			// Wert nur akzeptieren, wenn tatsächlich ein Wert eingegeben wurde
			if (!(this.oModel.getProperty("/alleIndivValueProz") === null) || !(this.oModel.getProperty("/alleIndivValueProzMB") === null) || !
				(this.oModel.getProperty("/alleIndivValueProm") === null) || !(this.oModel.getProperty("/alleIndivValueEUR") === null)) {
				var KbetrAufbereitetProz = "" + this.oModel.getProperty("/alleIndivValueProz"),
					KbetrAufbereitetProzMB = "" + this.oModel.getProperty("/alleIndivValueProzMB"),
					KbetrAufbereitetProm = "" + this.oModel.getProperty("/alleIndivValueProm"),
					KbetrAufbereitetEUR = "" + this.oModel.getProperty("/alleIndivValueEUR");

				var i;

				for (i = 0; i < this.filteredOData.length; i++) {
					if (this.filteredOData[i].KonwaStd === "%" && !(this.oModel.getProperty("/alleIndivValueProz") === null)) { //wenn Einheit stimmt und Modell nicht initial belegt
						this.filteredOData[i].Kbetr = KbetrAufbereitetProz;
					}

					if (this.filteredOData[i].KonwaStd === "%MB" && !(this.oModel.getProperty("/alleIndivValueProzMB") === null)) { //wenn Einheit stimmt und Modell nicht initial belegt
						this.filteredOData[i].Kbetr = KbetrAufbereitetProzMB;
					}

					if (this.filteredOData[i].KonwaStd === "%o" && !(this.oModel.getProperty("/alleIndivValueProm") === null)) { //wenn Einheit stimmt und Modell nicht initial belegt
						this.filteredOData[i].Kbetr = KbetrAufbereitetProm;
					}

					if (this.filteredOData[i].KonwaStd === "EUR" && !(this.oModel.getProperty("/alleIndivValueEUR") === null)) { //wenn Einheit stimmt und Modell nicht initial belegt
						this.filteredOData[i].Kbetr = KbetrAufbereitetEUR;
					}
					if(this.changedKondition.includes(this.filteredOData[i])){
						this.changedKondition[this.changedKondition.indexOf(this.filteredOData[i])] = this.filteredOData[i];
					} else {
						this.changedKondition.push(this.filteredOData[i]);
					}
				}
				this.oModel.setProperty("/kondHasChanged", true);
			}

			this.setAlleIndivValues(null); //setze Felder im Modell zurück
	
			this.byId("alleIndividualisierenDialog").close();
			//this.getView().byId("konditionList").getBinding("items").refresh(true); //Musste mit Fehler 2021/2072 geändert werden
			//TODO: Es geht nicht, wenn kein Wert eingetragen ist und auf individuialisieren gedrückt wird! Klären was in diesem Fall zu tun ist!
			this.getView().byId("konditionList").getModel().updateBindings(true);

			
		},
		
		validateChangeValueIndividProz: function(oEvent){
			var _oInput = oEvent.getSource();
			var val = _oInput.getValue();
			var ex = /^[0-9]+([\.?]|[\,?]){0,1}[0-9]{0,2}$/;
			if(!ex.test(val) && val.length > 0){
				this.byId("alleIndivIDProz").setValue(val.substring(0, val.length - 1));
			}
			this.changeValueIndividProz(oEvent);
		},
		validateChangeValueIndividProzMB: function(oEvent){
			var _oInput = oEvent.getSource();
			var val = _oInput.getValue();
			var ex = /^[0-9]+([\.?]|[\,?]){0,1}[0-9]{0,2}$/;
			if(!ex.test(val) && val.length > 0){
				this.byId("alleIndivIDProzMB").setValue(val.substring(0, val.length - 1));
			}
			this.changeValueIndividProzMB(oEvent);
		},
		validateChangeValueIndividProm: function(oEvent){
			var _oInput = oEvent.getSource();
			var val = _oInput.getValue();
			var ex = /^[0-9]+([\.?]|[\,?]){0,1}[0-9]{0,2}$/;
			if(!ex.test(val) && val.length > 0){
				this.byId("alleIndivIDProm").setValue(val.substring(0, val.length - 1));
			}
			this.changeValueIndividProm(oEvent);
		},
		validateChangeValueIndividEUR: function(oEvent){
			var _oInput = oEvent.getSource();
			var val = _oInput.getValue();
			var ex = /^[0-9]+([\.?]|[\,?]){0,1}[0-9]{0,2}$/;
			if(!ex.test(val) && val.length > 0){
				this.byId("alleIndivIDEUR").setValue(val.substring(0, val.length - 1));
			}
			this.changeValueIndividEUR(oEvent);
		},

		/*
			speichere aktuellen Wert aus dem Popup und nimm nur den Zahlenwert (durch substring).  
		 */
		changeValueIndividProz: function (oEvent) { //schreibt Werte aus Individualiseren Mask Input Prozent in Modell 
			//var valueProz = this.byId("alleIndivIDProz")._lastValue;
			var value = oEvent.getParameters("value").value;

			if (!(value === "")) {
				value = value.replace(/[_]/g, ''); // Entfernt alle "_" aus dem String
				var val = parseFloat(value.substring(0, 6).replace(/,/, ".")); // Komma durch Punkt ersetzen, da parseFloat sonst den Nachkommawert löscht
				this.oModel.setProperty("/alleIndivValueProz", val);
			} else {
				this.oModel.setProperty("/alleIndivValueProz", null);
			}
		},

		changeValueIndividProzMB: function (oEvent) { //schreibt Werte aus Individualiseren Mask Input Prozent in Modell 
			//var valueProz = this.byId("alleIndivIDProz")._lastValue;
			var value = oEvent.getParameters("value").value;

			if (!(value === "")) {
				value = value.replace(/[_]/g, ''); // Entfernt alle "_" aus dem String
				var val = parseFloat(value.substring(0, 6).replace(/,/, ".")); // Komma durch Punkt ersetzen, da parseFloat sonst den Nachkommawert löscht
				this.oModel.setProperty("/alleIndivValueProzMB", val);
			} else {
				this.oModel.setProperty("/alleIndivValueProzMB", null);
			}
		},

		changeValueIndividProm: function (oEvent) { //schreibt Werte aus Individualiseren Mask Input Promille in Modell 
			//var value = this.byId("alleIndivIDProm")._lastValue;
			var value = oEvent.getParameters("value").value;

			if (!(value === "")) {
				value = value.replace(/[_]/g, ''); // Entfernt alle "_" aus dem String
				var val = parseFloat(value.substring(0, 6).replace(/,/, ".")); // Komma durch Punkt ersetzen, da parseFloat sonst den Nachkommawert löscht
				this.oModel.setProperty("/alleIndivValueProm", val);
			} else {
				this.oModel.setProperty("/alleIndivValueProm", null);
			}
		},

		changeValueIndividEUR: function (oEvent) { //schreibt Werte aus Individualiseren Mask Input EUR in Modell 
			//var value = this.byId("alleIndivIDEUR")._lastValue;
			var value = oEvent.getParameters("value").value;

			if (!(value === "")) {
				value = value.replace(/[_]/g, ''); // Entfernt alle "_" aus dem String
				var val = parseFloat(value.substring(0, 7).replace(/,/, ".")); // Komma durch Punkt ersetzen, da parseFloat sonst den Nachkommawert löscht
				this.oModel.setProperty("/alleIndivValueEUR", val);
			} else {
				this.oModel.setProperty("/alleIndivValueEUR", null);
			}
		}

	});

});