sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/ColumnListItem",
	"sap/m/Label",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/Fragment",
	"sap/m/TablePersoController",
	"sap/m/MessageToast",
	"sap/m/Token",
	"de/pnw/icm/provisionsvertrag/vtr/model/formatter",
	"de/pnw/icm/provisionsvertrag/vtr/util/Utilities",
	"sap/base/util/UriParameters",
	"sap/ui/core/routing/HashChanger"
], function (Controller, Filter, FilterOperator, ColumnListItem, Label, JSONModel, Fragment, TablePersoController, MessageToast, Token,
	formatter, Utilities, UriParameters, HashChanger) {
	"use strict";

	return Controller.extend("de.pnw.icm.provisionsvertrag.vtr.controller.Master", {
		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf de.pnw.icm.provisionsvertrag.vtr.view.Master
		 */
		formatter: formatter,

		onInit: function (oEvent) {
			this.oRouter = this.getOwnerComponent().getRouter();
			this.oModel = this.getOwnerComponent().getModel("vertrag");
			this.oSperrenModel = this.getOwnerComponent().getModel("sperren");
			this.appViewModel = this.getOwnerComponent().getModel("appView");
			this.i18n = this.getOwnerComponent().getModel("i18n");
			

			// Spalten für Wertehilfe: StdVertragSet, VermittlerartSet, WhGebietSet und StdVereinbarungsNrSet setzen
			this.stdVertragColModel = new JSONModel({
				"cols": [{
					"label": "{vertrag>/StdVertragSet/CtrtstId/#@sap:label}",
					"template": "CtrtstId"
				}, {
					"label": "{vertrag>/StdVertragSet/CtrtstIdT/#@sap:label}",
					"template": "CtrtstIdT"
				}]
			});

			this.oColModel = new JSONModel({
				"cols": [{
					"label": "{vertrag>/VermittlerartSet/DescriptSh/#@sap:label}",
					"template": "DescriptSh"

				}, {
					"label": "{vertrag>/VermittlerartSet/IntTitle/#@sap:label}",
					"template": "IntTitle"
				}]
			});

			this.ZgebietColModel = new JSONModel({
				"cols": [{
					"label": "{vertrag>/WhGebietSet/ZGebiet/#@sap:label}",
					"template": "ZGebiet"

				}, {
					"label": "{vertrag>/WhGebietSet/Zgebiett/#@sap:label}",
					"template": "Zgebiett"
				}]
			});

			this.StcagrIdColModel = new JSONModel({
				"cols": [{
					"label": "{vertrag>/StdVereinbarungsNrSet/StcagrId/#@sap:label}",
					"template": "StcagrId"

				}, {
					"label": "{vertrag>/StdVereinbarungsNrSet/StcagrIdt/#@sap:label}",
					"template": "StcagrIdt"
				}]
			});

			this.HerkunftColModel = new JSONModel({
				"cols": [{
					"label": "{vertrag>/ZHerkunftSet/Herkunft/#@sap:label}",
					"template": "Herkunft"

				}, {
					"label": "{vertrag>/ZHerkunftSet/Herkunft/#@sap:label}",
					"template": "Herkunftt"
				}]
			});
			
			// globale Variable für Filter definieren
			this.CtrtbuId = this.byId("CtrtbuId");
			this.CtrtstId = this.byId("CtrtstId");
			this.IntTitle = this.byId("IntTitle");
			this.LeavDate = this.byId("LeavDate");
			this.Bpext = this.byId("Bpext");
			this.NameGrp1 = this.byId("NameGrp1");
			this.NameGrp2 = this.byId("NameGrp2");
			this.Zgebiet = this.byId("Zgebiet");
			this.BucagrId = this.byId("BucagrId");
			this.StcagrId = this.byId("StcagrId");
			this.Herkunft = this.byId("Herkunft");

			// proceed only if sap.ushell service is available
			if (sap.ushell && sap.ushell.Container && sap.ushell.Container.getService) {
				this.oCrossAppNav = sap.ushell.Container.getService("CrossApplicationNavigation");
				var oComponent = sap.ui.core.Component.getOwnerComponentFor(this.getView());
				this.oPersonalizationService = sap.ushell.Container.getService("Personalization");
				var oPersId = {
					container: "vertragList", // Any
					item: "vertragList" // Table id 
				};
				// define scope 
				var oScope = {
					keyCategory: this.oPersonalizationService.constants.keyCategory.FIXED_KEY,
					writeFrequency: this.oPersonalizationService.constants.writeFrequency.LOW,
					clientStorageAllowed: true
				};
				this.oPersonalizer = this.oPersonalizationService.getPersonalizer(oPersId, oScope, oComponent);

				this.oTablepersoService = new TablePersoController({
					table: this.getView().byId("vertragList"),
					persoService: this.oPersonalizer
				}).activate();

				// get default columns
				this.aDefaultColumns = this.getDefaultColumns();

				this.oPersonalizationService.getContainer("vertragList", oScope, oComponent)
					.done(function (oContainer) {
						this.oContainer = oContainer;
						this.oVariantSetAdapter = new sap.ushell.services.Personalization.VariantSetAdapter(this.oContainer);
						// get variant set which is stored in backend
						this.oVariantSet = this.oVariantSetAdapter.getVariantSet("vertragList");
						if (!this.oVariantSet) { //if not in backend, then create one
							this.oVariantSet = this.oVariantSetAdapter.addVariantSet("vertragList");
						}

						var defaultVariantKey = this.oVariantSet.getCurrentVariantKey();
						// array to store the existing variants
						var Variants = [],
							defaultVariantName = null;
						// now get the existing variants from the backend to show as list
						for (var key in this.oVariantSet.getVariantNamesAndKeys()) {
							if (this.oVariantSet.getVariantNamesAndKeys().hasOwnProperty(key)) {
								var oVariantItemObject = {};
								oVariantItemObject.Key = this.oVariantSet.getVariantNamesAndKeys()[key];
								oVariantItemObject.Name = key;
								Variants.push(oVariantItemObject);
								if (this.oVariantSet.getVariantNamesAndKeys()[key] === defaultVariantKey) {
									defaultVariantName = key;
								}
							}
						}

						// Attach to the variant management UI control
						this.appViewModel.setProperty("/VariantList", Variants);
						this.getView().byId("Variants").setModel(this.appViewModel);
						this.getView().byId("Variants").currentVariantSetModified(false);
						//set default variant, initial select and personalization
						this.getView().byId("Variants").setInitialSelectionKey(defaultVariantKey);
						this.getView().byId("Variants").setDefaultVariantKey(defaultVariantKey);
						this.setSelectedVariantToTable(defaultVariantName);

					}.bind(this));
			}

			// wird die Funktion this._onObjectMatched jedes Mal wenn die route eingetroffen ist
			this.oRouter.getRoute("master").attachPatternMatched(this._onObjectMatched, this);
		},
		onAfterRendering: function () {
			this.CtrtstId.setFilterFunction(function (sTerm, oItem) {
				return this.onLiveInput(sTerm, oItem);
			}.bind(this));

			this.IntTitle.setFilterFunction(function (sTerm, oItem) {
				return this.onLiveInput(sTerm, oItem);
			}.bind(this));

			this.Zgebiet.setFilterFunction(function (sTerm, oItem) {
				return this.onLiveInput(sTerm, oItem);
			}.bind(this));

			this.StcagrId.setFilterFunction(function (sTerm, oItem) {
				return this.onLiveInput(sTerm, oItem);
			}.bind(this));

			this.Herkunft.setFilterFunction(function (sTerm, oItem) {
				return this.onLiveInput(sTerm, oItem);
			}.bind(this));
			
			// this will apply a focus to the first Filter option called Provisionsvertr
			jQuery.sap.delayedCall(500, this, function() {
				sap.ui.getCore().byId(this.createId("CtrtbuId")).focus();
			});
		},

		getDefaultColumns: function () {
			var defaultColumns = [];
			if (this.oTablepersoService) {
				var initialTblStateMap = this.oTablepersoService._mInitialTableStateMap;
				var firstKey = Object.keys(initialTblStateMap)[0];
				defaultColumns = initialTblStateMap[firstKey];
			}
			return defaultColumns;
		},

		setVariantList: function () {
			var Variants = [];
			// now get the existing variants from the backend to show as list
			for (var key in this.oVariantSet.getVariantNamesAndKeys()) {
				if (this.oVariantSet.getVariantNamesAndKeys().hasOwnProperty(key)) {
					var oVariantItemObject = {};
					oVariantItemObject.Key = this.oVariantSet.getVariantNamesAndKeys()[key];
					oVariantItemObject.Name = key;
					Variants.push(oVariantItemObject);
				}
			}

			// Attach to the variant management UI control
			this.appViewModel.setProperty("/VariantList", Variants);
			this.appViewModel.refresh();
		},

		onSaveAs: function (oEvent) {
			var VariantParam = oEvent.getParameters();
			var aColumnsData = this.oTablepersoService._oPersonalizations.aColumns,
				CtrtbuId = this.appViewModel.getProperty("/CtrtbuId"),
				CtrtstId = this.appViewModel.getProperty("/CtrtstId"),
				IntTitle = this.appViewModel.getProperty("/IntTitle"),
				LeavDate = this.appViewModel.getProperty("/LeavDate"),
				Bpext = this.appViewModel.getProperty("/Bpext"),
				NameGrp1 = this.appViewModel.getProperty("/NameGrp1"),
				NameGrp2 = this.appViewModel.getProperty("/NameGrp2"),
				Zgebiet = this.appViewModel.getProperty("/Zgebiet"),
				BucagrId = this.appViewModel.getProperty("/BucagrId"),
				StcagrId = this.appViewModel.getProperty("/StcagrId"),
				Herkunft = this.appViewModel.getProperty("/Herkunft");

			// Check if the variant already exist, else create a new
			this.oVariant = this.oVariantSet.getVariant(VariantParam.key);
			if (!this.oVariant) {
				this.oVariant = this.oVariantSet.addVariant(VariantParam.name);
			}
			if (this.oVariant) {
				// Setzt die Spalten definition von Vertragsliste und Konditionen
				this.oVariant.setItemValue("vertragList", JSON.stringify(aColumnsData));
				this.oVariant.setItemValue("CtrtbuId", JSON.stringify(CtrtbuId));
				this.oVariant.setItemValue("CtrtstId", JSON.stringify(CtrtstId));
				this.oVariant.setItemValue("IntTitle", JSON.stringify(IntTitle));
				this.oVariant.setItemValue("LeavDate", JSON.stringify(LeavDate));
				this.oVariant.setItemValue("Bpext", JSON.stringify(Bpext));
				this.oVariant.setItemValue("NameGrp1", JSON.stringify(NameGrp1));
				this.oVariant.setItemValue("NameGrp2", JSON.stringify(NameGrp2));
				this.oVariant.setItemValue("Zgebiet", JSON.stringify(Zgebiet));
				this.oVariant.setItemValue("BucagrId", JSON.stringify(BucagrId));
				this.oVariant.setItemValue("StcagrId", JSON.stringify(StcagrId));
				this.oVariant.setItemValue("Herkunft", JSON.stringify(Herkunft));

				if (VariantParam.def === true) {
					this.oVariantSet.setCurrentVariantKey(this.oVariant.getVariantKey());
				}
				this.oContainer.save();
				this.oContainer.save().done(function () {
					this.setVariantList();
					// Tell the user that the personalization data was saved
					MessageToast.show(VariantParam.name + " " + Utilities.geti18nText(this.i18n, "saved", []));
				}.bind(this));
			}
		},

		onSelect: function (oEvent) {
			var selectedKey = oEvent.getParameter("key");
			for (var i = 0; i < oEvent.getSource().getVariantItems().length; i++) {
				if (oEvent.getSource().getVariantItems()[i].getProperty("key") === selectedKey) {
					var selectedVariant = oEvent.getSource().getVariantItems()[i].getProperty("text");
					break;
				}
			}
			this.setSelectedVariantToTable(selectedVariant);
		},

		/*
			Hole die entsprechenden Konfigs und setzte in der Tabelle
		*/
		setSelectedVariantToTable: function (oSelectedVariant) {
			var aColumns = [],
				CtrtbuId = "",
				CtrtstId = [],
				IntTitle = [],
				LeavDate = "",
				Bpext = "",
				NameGrp1 = "",
				NameGrp2 = "",
				Zgebiet = [],
				BucagrId = "",
				StcagrId = [],
				Herkunft = [];
			if (oSelectedVariant) {
				var oVariant = this.oVariantSet.getVariant(this.oVariantSet.getVariantKeyByName(oSelectedVariant));
				aColumns = JSON.parse(oVariant.getItemValue("vertragList"));
				CtrtbuId = JSON.parse(oVariant.getItemValue("CtrtbuId"));
				CtrtstId = JSON.parse(oVariant.getItemValue("CtrtstId"));
				IntTitle = JSON.parse(oVariant.getItemValue("IntTitle"));
				LeavDate = JSON.parse(oVariant.getItemValue("LeavDate"));
				Bpext = JSON.parse(oVariant.getItemValue("Bpext"));
				NameGrp1 = JSON.parse(oVariant.getItemValue("NameGrp1"));
				NameGrp2 = JSON.parse(oVariant.getItemValue("NameGrp2"));
				Zgebiet = JSON.parse(oVariant.getItemValue("Zgebiet"));
				BucagrId = JSON.parse(oVariant.getItemValue("BucagrId"));
				StcagrId = JSON.parse(oVariant.getItemValue("StcagrId"));
				Herkunft = JSON.parse(oVariant.getItemValue("Herkunft"));
			}
			// default *Standard*
			else {
				aColumns = this.aDefaultColumns;
			}
			this.oldColumns = aColumns.map(function (item) {
				var obj = {};
				obj.id = item.id;
				obj.order = item.order;
				obj.visible = item.visible;
				obj.group = item.group;
				return obj;
			});
			this.oldFilter = {
				CtrtbuId: CtrtbuId,
				CtrtstId: CtrtstId,
				IntTitle: IntTitle,
				LeavDate: LeavDate,
				Bpext: Bpext,
				NameGrp1: NameGrp1,
				NameGrp2: NameGrp2,
				Zgebiet: Zgebiet,
				BucagrId: BucagrId,
				StcagrId: StcagrId,
				Herkunft: Herkunft
			};
			var persData = {
				_persoSchemaVersion: "1.0",
				aColumns: aColumns
			};
			this.oTablepersoService.getPersoService().setPersData(persData);
			this.oTablepersoService.applyPersonalizations();
			this.oContainer.save();
			this.setFilter(CtrtbuId, CtrtstId, IntTitle, LeavDate, Bpext, NameGrp1, NameGrp2, Zgebiet, BucagrId, StcagrId, Herkunft);
		},

		setFilter: function (CtrtbuId, CtrtstId, IntTitle, LeavDate, Bpext, NameGrp1, NameGrp2, Zgebiet, BucagrId, StcagrId, Herkunft) {
			this.CtrtbuId.setValue(CtrtbuId);
			this.CtrtstId.removeAllTokens();
			this.IntTitle.removeAllTokens();
			this.LeavDate.setSelectedKey(LeavDate);
			this.Bpext.setValue(Bpext);
			this.NameGrp1.setValue(NameGrp1);
			this.NameGrp2.setValue(NameGrp2);
			this.Zgebiet.removeAllTokens();
			this.BucagrId.setValue(BucagrId);
			this.StcagrId.removeAllTokens();
			this.Herkunft.removeAllTokens();
			for (var i = 0; i < CtrtstId.length; i++) {
				var CtrtstIdTxt = CtrtstId[i];
				var CtrtstIdToken = new Token({
					text: CtrtstIdTxt,
					key: CtrtstIdTxt
				});
				this.CtrtstId.addToken(CtrtstIdToken);
			}
			for (var j = 0; j < IntTitle.length; j++) {
				var IntTitleTxt = IntTitle[j];
				var IntTitleToken = new Token({
					text: IntTitleTxt,
					key: IntTitleTxt
				});
				this.IntTitle.addToken(IntTitleToken);
			}
			for (var k = 0; k < Zgebiet.length; k++) {
				var ZGebietTxt = Zgebiet[k];
				var ZGebietToken = new Token({
					text: ZGebietTxt,
					key: ZGebietTxt
				});
				this.Zgebiet.addToken(ZGebietToken);
			}
			for (var l = 0; l < StcagrId.length; l++) {
				var StcagrIdTxt = StcagrId[l];
				var StcagrIdToken = new Token({
					text: StcagrIdTxt,
					key: StcagrIdTxt
				});
				this.StcagrId.addToken(StcagrIdToken);
			}
			for (var m = 0; m < Herkunft.length; m++) {
				var HerkunftTxt = Herkunft[m];
				var HerkunftToken = new Token({
					text: HerkunftTxt,
					key: HerkunftTxt
				});
				this.Herkunft.addToken(HerkunftToken);
			}

			this.onLiveChange();
		},

		onManage: function (oEvent) {
			var oParameters = oEvent.getParameters();

			// rename variants
			if (oParameters.renamed.length > 0) {
				oParameters.renamed.forEach(function (aRenamed) {
					var sVariant = this.oVariantSet.getVariant(aRenamed.key);
					sVariant.setVariantName(aRenamed.name);
				}.bind(this));
			}

			// default variant changed
			if (oParameters.def !== "*standard*") {
				this.oVariantSet.setCurrentVariantKey(oParameters.def);
			} else {
				this.oVariantSet.setCurrentVariantKey(null);
			}

			// Delete variants
			if (oParameters.deleted.length > 0) {
				oParameters.deleted.forEach(function (aDelete) {
					this.oVariantSet.delVariant(aDelete);
				}.bind(this));
			}
			this.oContainer.save();
			//  Save the Variant Container
			this.oContainer.save().done(function () {
				// Tell the user that the personalization data was saved
				MessageToast.show(Utilities.geti18nText(this.i18n, "changed", []));
			}.bind(this));
		},

		_onObjectMatched: function (oEvent) {
			this.onLiveChange();
			this.resetVariable();
		},

		resetVariable: function () {
			this.appViewModel.setProperty("/kondHasChanged", false);
			this.appViewModel.setProperty("/lavvHasChanged", false);
			this.appViewModel.setProperty("/lavvData", null);
			this.appViewModel.setProperty("/changedKondition", null);
			this.appViewModel.setProperty("/validFrom", null);
			this.appViewModel.setProperty("/chachedKond", null);
		},

		onPersoButtonPressed: function () {
			if (this.oTablepersoService) {
				this.oTablepersoService.openDialog();
				var sOldColumns = JSON.stringify(this.oldColumns);
				var that = this;
				this.oTablepersoService.attachPersonalizationsDone(function (oPerso) {
					//that.oTablepersoService.savePersonalizations();
					var aColumns = oPerso.getSource()._oPersonalizations.aColumns;
					var aNewColumns = aColumns.map(function (item) {
						var obj = {};
						obj.id = item.id;
						obj.order = item.order;
						obj.visible = item.visible;
						obj.group = item.group;
						return obj;
					});
					var sNewColumns = JSON.stringify(aNewColumns);
					// Wurde die Spalten Eingeschaften geändert? Wenn ja zeigt im Variant Titel
					if (sOldColumns !== sNewColumns) {
						that.setVariantTitle();
					}
				});
			}
		},

		setVariantTitle: function () {
			/*var variantTxt = this.byId("Variants-text");
			var title = variantTxt.getText().split("*")[0];
			variantTxt.setText(title + "*");*/
			var variant = this.getView().byId("Variants");
			variant.currentVariantSetModified(true);
			
		},

		onExpertModusPress: function (oEvent) {
			if (this.appViewModel.getProperty("/isExpertModus")) {
				this.appViewModel.setProperty("/isExpertModus", false);
				oEvent.getSource().setType("Transparent");
			} else {
				this.appViewModel.setProperty("/isExpertModus", true);
				oEvent.getSource().setType("Ghost");
			}
		},

		onUpdateFinished: function (oEvent) {
			// setzt den Tabellentitel nach einem Update
			var oTable = this.getView().byId("vertragList"),
				sTitle = "",
				iItems = oTable.getItems().length;

			if ((iItems >= 50) && (iItems % 50 === 0)) {
				sTitle = "(" + iItems + "+)";
			} else {
				sTitle = "(" + iItems + ")";
			}
			var txt = Utilities.geti18nText(this.i18n, "listTitle", [sTitle]); //oBundle.getText("listTitle", [sTitle]);
			this.getView().byId("tableTitle").setText(txt);
		},

		onPress: function (oEvent) {
			// Navigation zu einem vertrag
			var sPath = oEvent.getSource().getBindingContextPath().substr(1);
			this.navigateToVertrag(sPath);
		},

		navigateToVertrag: function (sPath) {
			Utilities.navToRoute(this.oRouter, "vertrag", sap.f.LayoutType.OneColumn, sPath);
		},

		getInputValue: function (inputId) {
			return inputId.getValue();
		},
		/*
			Tabelle filtern, wenn ein Token auf der Wertehilfe gelöscht wurde
		*/
		onMultiInputTokenUpdate: function (oEvent) {
			var oSource = oEvent.getSource();
			if (oEvent.getParameter("type") === "removed") {
				var selectedToken = oEvent.getParameter("removedTokens")[0];
				oSource.removeToken(selectedToken);
				this.onLiveChange();
			}
		},

		onLiveInput: function (sTerm, oItem) {
			var iIdx = sTerm.indexOf("*"),
				sNewValue = sTerm.replaceAll("*", ""),
				bReturn = {},
				sStartWPattern = "^" + sNewValue,
				sEndWPattern = sNewValue + "$";
			switch (iIdx) {
			case -1:
				//bReturn = oItem.getKey().match(new RegExp(sNewValue, "i"));
				bReturn = oItem.getKey().match(new RegExp(sStartWPattern, "i"));
				break;
			case 0:
				if (sTerm.charAt(sTerm.length - 1) === "*") {
					// Contains
					bReturn = oItem.getKey().match(new RegExp(sNewValue, "i"));
				} else {
					// End With
					bReturn = oItem.getKey().match(new RegExp(sEndWPattern, "i"));
				}
				break;
			case sTerm.length - 1:
				// Start With
				bReturn = oItem.getKey().match(new RegExp(sStartWPattern, "i"));
				break;
			default:
				bReturn = oItem.getKey().match(new RegExp(sTerm, "i"));
			}
			return bReturn;
		},

		onMultiInputSubmit: function (oEvent) {
			var oSource = oEvent.getSource();
			var aItems = oSource.getSuggestionItems(),
				sTerm = oSource.getValue();
			
			if (sTerm !== "") {
				oSource.setValue("");
				var aTokens = [];
	
				aItems.forEach(function (item) {
					var bReturn = this.onLiveInput(sTerm, item);
					if (bReturn) {
						var oToken = new Token({
							key: item.getKey(),
							text: item.getText()
						});
						aTokens.push(oToken);
					}
				}.bind(this));
	
				oSource.setTokens(aTokens);
			}
			
			this.onLiveChange();
		},

		getLeavDateFilter: function () {
			var sSelectedLeavDate = this.LeavDate.getSelectedKey(),
				aLeavDateFilter = [];
			switch (sSelectedLeavDate) {
			case "0": // aktiv
				aLeavDateFilter.push(new Filter("LeavDate", FilterOperator.GT, new Date()));
				break;
			case "1": // beendet
				aLeavDateFilter.push(new Filter("LeavDate", FilterOperator.LT, new Date()));
				break;
			case "2": // zukünftig beendet
				aLeavDateFilter.push(new Filter("LeavDate", FilterOperator.BT, new Date(), new Date("9999", "11", "31")));
				break;
			default: // alle
			}
			this.appViewModel.setProperty("/LeavDate", sSelectedLeavDate);
			return aLeavDateFilter;
		},

		onLiveChange: function () {
			// Tabelle filtern
			var CtrtbuIdFilter = [],
				stdVtragFilter = [],
				vermittlerartFilter = [],
				aLeavDateFilter = [],
				aBpextFilter = [],
				aNameGrp1Filter = [],
				aNameGrp2Filter = [],
				aZGebiet = [],
				aStcagrId = [],
				aHerkunft = [],
				aBucagrIdFilter = [],
				filters = [],
				CtrtbuId = this.CtrtbuId.getValue(),
				iBpext = this.Bpext.getValue(),
				sNameGrp1 = this.NameGrp1.getValue(),
				sNameGrp2 = this.NameGrp2.getValue(),
				BucagrId = this.BucagrId.getValue();

			// nur positivem Integer erlauben
			iBpext = iBpext.replace(/[^\d*]/g, "");
			this.Bpext.setValue(iBpext);
			
			CtrtbuId = CtrtbuId.replace(/[^\d*]/g, "");
			this.CtrtbuId.setValue(CtrtbuId);

			// Filterelemente erstellen
			
			CtrtbuIdFilter.push(
				new Filter("CtrtbuId", FilterOperator.EQ, CtrtbuId)
			);
			aBpextFilter.push(
				new Filter("Bpext", FilterOperator.EQ, iBpext)
			);
			aNameGrp1Filter.push(
				new Filter("NameGrp1", FilterOperator.Contains, sNameGrp1)
			);
			aNameGrp2Filter.push(
				new Filter("NameGrp2", FilterOperator.Contains, sNameGrp2)
			);
			if(BucagrId.replace(/^0+/, '').length >= 5 || BucagrId.replace(/^0+/, '').length === 0){
				aBucagrIdFilter.push(
					new Filter("BucagrId", FilterOperator.Contains, BucagrId)	
				);
				this.appViewModel.setProperty("/BucagrId", BucagrId);
			}
			

			aLeavDateFilter = this.getLeavDateFilter();
			stdVtragFilter = this.buildFilterWithToken(this.CtrtstId, "CtrtstId");
			vermittlerartFilter = this.buildFilterWithToken(this.IntTitle, "IntTitle");
			aZGebiet = this.buildFilterWithToken(this.Zgebiet, "Zgebiet");
			aStcagrId = this.buildFilterWithToken(this.StcagrId, "StcagrId");
			aHerkunft = this.buildFilterWithToken(this.Herkunft, "Herkunft");

			// Set Provisionsvertrag to local model for variant management
			this.appViewModel.setProperty("/CtrtbuId", CtrtbuId);
			this.appViewModel.setProperty("/NameGrp1", sNameGrp1);
			this.appViewModel.setProperty("/NameGrp2", sNameGrp2);
			this.appViewModel.setProperty("/Bpext", iBpext);
			
			var newFilter = {
				CtrtbuId: CtrtbuId,
				CtrtstId: this.appViewModel.getProperty("/CtrtstId"),
				IntTitle: this.appViewModel.getProperty("/IntTitle"),
				LeavDate: this.appViewModel.getProperty("/LeavDate"),
				Bpext: iBpext,
				NameGrp1: sNameGrp1,
				NameGrp2: sNameGrp2,
				Zgebiet: this.appViewModel.getProperty("/Zgebiet"),
				BucagrId: this.appViewModel.getProperty("/BucagrId"),
				StcagrId: this.appViewModel.getProperty("/StcagrId"),
				Herkunft: this.appViewModel.getProperty("/Herkunft")
			};
			if (this.oldFilter && (JSON.stringify(this.oldFilter) !== JSON.stringify(newFilter))) {
				this.setVariantTitle(true);
			}
	
			if(BucagrId.replace(/^0+/, '').length >= 5){
				filters = CtrtbuIdFilter.concat(stdVtragFilter, vermittlerartFilter, aLeavDateFilter, aBpextFilter, aNameGrp1Filter, aNameGrp2Filter, aZGebiet,
				aBucagrIdFilter, aStcagrId, aHerkunft);
			} else {
				filters = CtrtbuIdFilter.concat(stdVtragFilter, vermittlerartFilter, aLeavDateFilter, aBpextFilter, aNameGrp1Filter, aNameGrp2Filter, aZGebiet,
				aStcagrId, aHerkunft);
			}
			

			// Filter setzen
			this.filterBinding(filters);
		},

		filterBinding: function (filter) {
			// Tablle wird gefiltert
			var oBinding = this.byId("vertragList").getBinding("items");
			if (oBinding) {
				oBinding.filter(filter);
			}
		},

		onIntTitle: function () {
			// den Werthilfedialog für VermittlerartSet öffnen
			this.onValueHelp("VermittlerartDialog", this.oColModel, this.IntTitle.getTokens(), "/VermittlerartSet", "valueHelpDialog");
		},

		onStdVertrag: function () {
			// den Werthilfedialog für StdVertragSet öffnen
			this.onValueHelp("StdVertragDialog", this.stdVertragColModel, this.CtrtstId.getTokens(), "/StdVertragSet", "valueHelpDialog");
		},

		onZgebiet: function () {
			// den Werthilfedialog für Zgebiet öffnen
			this.onValueHelp("ZgebietDialog", this.ZgebietColModel, this.Zgebiet.getTokens(), "/WhGebietSet", "ZgebietValueHelpDialog");
		},

		onStcagrId: function () {
			// den Werthilfedialog für StdVertragSet öffnen
			this.onValueHelp("StcagrIdDialog", this.StcagrIdColModel, this.StcagrId.getTokens(), "/StdVereinbarungsNrSet",
				"StcagrIdValueHelpDialog");
		},

		onHerkunft: function () {
			// den Werthilfedialog für ZHerkunftSet öffnen
			this.onValueHelp("HerkunftDialog", this.HerkunftColModel, this.Herkunft.getTokens(), "/ZHerkunftSet",
				"HerkunftValueHelpDialog");
		},

		onValueHelp: function (fragment, oColModel, tokens, entity, dialogId) {
			/* 
				Werthilfedialog und entsprechende Wertehilfe setzen
			*/
			if (!this.byId(dialogId)) {
				Fragment.load({
					id: this.getView().getId(),
					name: "de.pnw.icm.provisionsvertrag.vtr.view.fragment." + fragment,
					controller: this
				}).then(function (oDialog) {
					this.getView().addDependent(oDialog);
					var aCols = oColModel.getData().cols;
					var oTable = oDialog.getTable();
					oTable.setModel(this.oModel);
					oTable.setModel(oColModel, "columns");
					if (oTable.bindRows) {
						oTable.bindAggregation("rows", entity);
					}
					if (oTable.bindItems) {
						oTable.bindAggregation("items", entity, function () {
							return new ColumnListItem({
								cells: aCols.map(function (column) {
									return new Label({
										text: "{" + column.template + "}"
									});
								})
							});
						});
					}
					oDialog.update();
					oDialog.setTokens(tokens);
					oDialog.open();
				}.bind(this));
			} else {
				this.byId(dialogId).open();
			}
		},
		/*
			sap.ui.model.Filter von ausgewähltem Filter bilden
		*/
		buildFilterWithToken: function (oMultiInputFilter, sPath) {
			var tokens = [],
				bFilters = [],
				aFilter = [];

			tokens = oMultiInputFilter.getTokens();

			if (tokens.length > 0) {
				for (var i = 0; i < tokens.length; i++) {
					bFilters.push(new Filter(sPath, FilterOperator.EQ, tokens[i].getText()));
					aFilter.push(tokens[i].getText());
				}
			}

			this.appViewModel.setProperty("/" + sPath, aFilter);

			return bFilters;
		},

		onValueHelpFilterDialogCancelPress: function (oEvent) {
			oEvent.getSource().close();
		},

		onValueHelpFilterDialogClose: function (oEvent) {
			oEvent.getSource().destroy();
		},

		onHerkunftDialogOkPress: function (oEvent) {
			/*
				ausgewählte Token für Standardvereinbarungsnummer holen, 
				im Eingabefeld setzen und die Liste filtern
			*/
			var aTokens = oEvent.getParameter("tokens");
			this.Herkunft.setTokens(aTokens);
			this.filterAfterValueHelp(oEvent);
		},

		onStcagrIdDialogOkPress: function (oEvent) {
			/*
				ausgewählte Token für Standardvereinbarungsnummer holen, 
				im Eingabefeld setzen und die Liste filtern
			*/
			var aTokens = oEvent.getParameter("tokens");
			this.StcagrId.setTokens(aTokens);
			this.filterAfterValueHelp(oEvent);
		},

		onZgebietDialogOkPress: function (oEvent) {
			/*
				ausgewählte Token für Gebiet holen, 
				im Eingabefeld setzen und die Liste filtern
			*/
			var aTokens = oEvent.getParameter("tokens");
			this.Zgebiet.setTokens(aTokens);
			this.filterAfterValueHelp(oEvent);
		},

		onVermittlerartDialogOkPress: function (oEvent) {
			/*
				ausgewählte Token für Vermittlerart holen, 
				im Eingabefeld setzen und die Liste filtern
			*/
			var aTokens = oEvent.getParameter("tokens");
			this.IntTitle.setTokens(aTokens);
			this.filterAfterValueHelp(oEvent);
		},

		onStdVertragDialogOkPress: function (oEvent) {
			/*
				ausgewählte Token für Standardvertrag holen, 
				im Eingabefeld setzen und die Liste filtern
			*/
			var aTokens = oEvent.getParameter("tokens");
			this.CtrtstId.setTokens(aTokens);
			this.filterAfterValueHelp(oEvent);
		},
		/*
			Liste Filter nach dem Auswahl von Filter im Dialog
		*/
		filterAfterValueHelp: function (oEvent) {
			oEvent.getSource().close();
			this.onLiveChange();
		},
		
		goToAendern: function(){
			this.appViewModel.setProperty("/editMode", true);
			var sSemanticObject = "ZIcmProvVtr",
				sAction = "edit";
			var sShellHash = sSemanticObject + "-" + sAction;
			
			this.crossAppNavigation(sShellHash);
		},
		
		goToAnzeigen: function(){
			this.appViewModel.setProperty("/editMode", false);
			var sSemanticObject = "ZIcmProvVtr",
				sAction = "display";
			var sShellHash = sSemanticObject + "-" + sAction;
					
			this.crossAppNavigation(sShellHash);
		},
		
		crossAppNavigation: function (sShellHash) {

			if (this.oCrossAppNav) {
				this.oCrossAppNav.toExternal({
					target: {
						shellHash: sShellHash
					}
				});
			}
		},

		onReset: function () {
			this.CtrtbuId.setValue("");
			this.IntTitle.destroyTokens();
			this.CtrtstId.destroyTokens();
			this.LeavDate.setSelectedKey();
			this.Bpext.setValue("");
			this.NameGrp1.setValue("");
			this.NameGrp2.setValue("");
			this.Zgebiet.destroyTokens();
			this.StcagrId.destroyTokens();
			this.Herkunft.destroyTokens();
			this.BucagrId.setValue("");

			this.appViewModel.setProperty("/CtrtbuId", "");
			this.appViewModel.setProperty("/CtrtstId", []);
			this.appViewModel.setProperty("/IntTitle", []);
			this.appViewModel.setProperty("/LeavDate", "");
			this.appViewModel.setProperty("/Bpext", "");
			this.appViewModel.setProperty("/NameGrp1", "");
			this.appViewModel.setProperty("/NameGrp2", "");
			this.appViewModel.setProperty("/Zgebiet", []);
			this.appViewModel.setProperty("/StcagrId", []);
			this.appViewModel.setProperty("/Herkunft", []);
			this.appViewModel.setProperty("/BucagrId", "");
			var variant = this.getView().byId("Variants");
			variant.currentVariantSetModified(false);

			this.filterBinding([]);
		}
	});
});