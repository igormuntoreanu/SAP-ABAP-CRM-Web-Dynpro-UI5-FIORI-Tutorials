sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/ResizeHandler",
	"sap/f/FlexibleColumnLayout"
], function (Controller, ResizeHandler, FlexibleColumnLayout) {
	"use strict";

	return Controller.extend("de.pnw.icm.provisionsvertrag.vtr.controller.App", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf de.pnw.icm.provisionsvertrag.vtr.view.App
		 */
		onInit: function () {
			this.oRouter = this.getOwnerComponent().getRouter();
			this.oRouter.attachRouteMatched(this.onRouteMatched, this);
			this.oRouter.attachBeforeRouteMatched(this.onBeforeRouteMatched, this);
			ResizeHandler.register(this.getView().byId("idFlexLayout"), this._onResize.bind(this));
		},

		onBeforeRouteMatched: function (oEvent) {
			this.oModel = this.getOwnerComponent().getModel("appView");

			var sLayout = oEvent.getParameters().arguments.layout;

			// If there is no layout parameter, query for the default level 0 layout (normally OneColumn)
			if (!sLayout) {
				var oNextUIState = this.getOwnerComponent().getHelper().getNextUIState(0);
				sLayout = oNextUIState.layout;
			}

			// Optional UX improvement:
			// The app may want to hide the old view early (before the routing hides it)
			// to prevent the view being temporarily shown aside the next view (during the transition to the next route)
			// if the views for both routes do not match semantically
			if (this.currentRouteName === "master") { // last viewed route was master
				var oMasterView = this.oRouter.getView("de.pnw.icm.provisionsvertrag.vtr.view.Master");
				this.getView().byId("idFlexLayout").removeBeginColumnPage(oMasterView);
			}

			// Update the layout of the FlexibleColumnLayout
			if (sLayout) {
				this.oModel.setProperty("/layout", sLayout);
			}
		},

		_updateLayout: function (sLayout) {
			// If there is no layout parameter, query for the default level 0 layout (normally OneColumn)
			if (!sLayout) {
				var oNextUIState = this.getOwnerComponent().getHelper().getNextUIState(0);
				sLayout = oNextUIState.layout;
			}

			// Update the layout of the FlexibleColumnLayout
			if (sLayout) {
				this.oModel.setProperty("/layout", sLayout);
			}
		},

		onRouteMatched: function (oEvent) {
			var sRouteName = oEvent.getParameter("name"),
				oArguments = oEvent.getParameter("arguments");

			this._updateUIElements();

			// Save the current route name
			this.currentRouteName = sRouteName;
			this.currentVertrag = oArguments.vertragPath;
			this.currentLeistung = oArguments.leistungPath;
			this.currentVerguetung = oArguments.verguetungPath;
		},

		onStateChanged: function (oEvent) {
			var bIsNavigationArrow = oEvent.getParameter("isNavigationArrow"),
				sLayout = oEvent.getParameter("layout");

			this._updateUIElements();

			// Replace the URL with the new layout if a navigation arrow was used
			if (bIsNavigationArrow) {
				this.oRouter.navTo(this.currentRouteName, {
					layout: sLayout,
					vertragPath: this.currentVertrag,
					leistungPath: this.currentLeistung,
					verguetungPath: this.currentVerguetung
				}, true);
			}
		},

		// Update the close/fullscreen buttons visibility
		_updateUIElements: function () {
			var oUIState = this.getOwnerComponent().getHelper().getCurrentUIState();
			this.oModel.setData(oUIState, true);
		},
		
		stateChecker: function(oEvent){
			if(oEvent.getParameter("layout") === "TwoColumnsMidExpanded"){
				this.oModel.setProperty("/sectionsShow", false);
			} else {
				this.oModel.setProperty("/sectionsShow", true);
			}
		},
		
		_onResize: function (oEvent) {
			var bPhone = (oEvent.size.width < FlexibleColumnLayout.TABLET_BREAKPOINT);
			this.getOwnerComponent().getModel("appView").setProperty("/isPhone", bPhone);
		},

		onExit: function () {
			this.oRouter.detachRouteMatched(this.onRouteMatched, this);
			this.oRouter.detachBeforeRouteMatched(this.onBeforeRouteMatched, this);
		}

	});

});