sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/Fragment",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/ValueState",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/MessageBox",
	"sap/m/MessageToast",
	"sap/ui/core/format/DateFormat",
	"sap/ui/core/routing/History",
	"de/pnw/icm/provisionsvertrag/vtr/controller/sections/LavvShow",
	"de/pnw/icm/provisionsvertrag/vtr/controller/sections/AllgemeinesShow",
	"de/pnw/icm/provisionsvertrag/vtr/controller/sections/AuszahlungShow",
	"de/pnw/icm/provisionsvertrag/vtr/controller/sections/BeziehungenShow",
	"de/pnw/icm/provisionsvertrag/vtr/controller/sections/KorrespondenzShow",
	"de/pnw/icm/provisionsvertrag/vtr/controller/sections/ReferenzenShow",
	"de/pnw/icm/provisionsvertrag/vtr/controller/sections/VermittlergruppenShow",
	"de/pnw/icm/provisionsvertrag/vtr/controller/sections/WPVShow",
	"de/pnw/icm/provisionsvertrag/vtr/util/Utilities",
	"sap/ui/model/odata/ODataUtils",
	"de/pnw/icm/provisionsvertrag/vtr/model/formatter"
], function (Controller, Fragment, JSONModel, ValueState, Filter, FilterOperator, MessageBox, MessageToast, DateFormat, History,
	LavvShow, AllgemeinesShow, AuszahlungShow, BeziehungenShow, KorrespondenzShow, ReferenzenShow, VermittlergruppenShow,
	WPVShow, Utilities, ODataUtils, formatter) {
	"use strict";

	return Controller.extend("de.pnw.icm.provisionsvertrag.vtr.controller.Vertrag", {
		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf de.pnw.icm.provisionsvertrag.vtr.view.Vertrag
		 */
		formatter: formatter,

		onInit: function () {
			this.oRouter = this.getOwnerComponent().getRouter();
			this.oModel = this.getOwnerComponent().getModel("appView");
			this.vertragModel = this.getOwnerComponent().getModel("vertrag");
			this.oMappingModel = this.getOwnerComponent().getModel("keyControlMapping");
			this.i18n = this.getOwnerComponent().getModel("i18n");
			this.oRouter.getRoute("vertrag").attachPatternMatched(this._onObjectMatched, this);
			this.oRouter.getRoute("leistung").attachPatternMatched(this._onObjectMatched, this);
			this.oSperrenModel = this.getOwnerComponent().getModel("sperren");
			this._sessionId = this.oModel.getProperty("/sessionID");
			
			if (sap.ushell && sap.ushell.Container) {
				this.oCrossAppNav = sap.ushell.Container.getService("CrossApplicationNavigation");
			}

			//Setze als Hilfskonstrukt das Tagesdatum als "Angelegt am" im Vertrag.view
			var techFromDate = new Date();
			this.oModel.setProperty("/techFromDate", techFromDate);

			var oHelpModel = new JSONModel();

			oHelpModel.setData({
				"conflictLavvZweigFlag": false, // Flag zeigt an, ob in einer der Sparten ein Konflikt herrscht
				"conflictLavvZweigA": ["A", false], // Flag ob für Sparte A ein Konflikt bei angehänten LaVven besteht
				"conflictLavvZweigB": ["B", false], // Flag ob für Sparte B ein Konflikt bei angehänten LaVven besteht
				"conflictLavvZweigD": ["D", false], // Flag ob für Sparte D ein Konflikt bei angehänten LaVven besteht
				"conflictLavvZweigG": ["G", false], // Flag ob für Sparte G ein Konflikt bei angehänten LaVven besteht
				"conflictLavvZweigH": ["H", false], // Flag ob für Sparte H ein Konflikt bei angehänten LaVven besteht
				"conflictLavvZweigJ": ["J", false], // Flag ob für Sparte J ein Konflikt bei angehänten LaVven besteht
				"conflictLavvZweigK": ["K", false], // Flag ob für Sparte K ein Konflikt bei angehänten LaVven besteht
				"conflictLavvZweigL": ["L", false], // Flag ob für Sparte L ein Konflikt bei angehänten LaVven besteht
				"conflictLavvZweigR": ["R", false], // Flag ob für Sparte R ein Konflikt bei angehänten LaVven besteht
				"conflictLavvZweigS": ["S", false], // Flag ob für Sparte S ein Konflikt bei angehänten LaVven besteht
				"conflictLavvZweigU": ["U", false], // Flag ob für Sparte U ein Konflikt bei angehänten LaVven besteht
				"conflictLavvZweigV": ["V", false], // Flag ob für Sparte V ein Konflikt bei angehänten LaVven besteht
				"conflictLavvZweigW": ["W", false], // Flag ob für Sparte W ein Konflikt bei angehänten LaVven besteht
				"LeavDateReached": false, // Wird in der _onObjectMatched Methode auf true gesetzt, wenn Abgangsdatum gesetzt ist
				"nextVersionMessageToastShown": false, // MessageToast nur einmalig anzeigen bei navigation von Master zu Vertrag  
				"isAlreadyInEditing": false
			});
			this.getOwnerComponent().setModel(oHelpModel, "oVertragGlobal");

			this.oVertragGlobal = this.getOwnerComponent().getModel("oVertragGlobal");
			this._aSectionKeys = ["AllgemeinesShow", "LavvShow", "AuszahlungShow", "KorrespondenzShow",
					"VermittlergruppenShow",
					"BeziehungenShow", "ReferenzenShow", "WPVShow"
				];
		},

		/*
			Element im View binden auch für die route leistung,
			globale Variablen werden auch hier definiert und zugewiesen
			this._newKond enthält die geänderte Kondition und
			this.validFrom das Gültig-Ab Datum
		*/
		_onObjectMatched: function (oEvent) {
			this._suchePath = oEvent.getParameter("arguments").vertragPath;
			this._vertragPath = oEvent.getParameter("arguments").vertragPath.replace("PvSucheSet", "ProvVertrSet");
			this.oModel.setProperty("/vertragPfad", this._vertragPath);
			this.isEditMode = this.oModel.getProperty("/editMode");
			if(this.isEditMode){
				this.oModel.setProperty("/lavvnChangable", true);
			}
			this.oModel.setProperty("/kondHasChanged", false);
			//this.oAppViewModel = this.oParentController.oModel;
			var oVertragModel = this.vertragModel,
				sPath1 = this._vertragPath + "/ProvVertrToPartner";
			
			Utilities.promiseODataRead(oVertragModel, sPath1, {}, []).then(
				function (oData) { //resolve
					this._sperrenVersnr = oData.CtrtbuId;
				}.bind(this),
				function (oError) { //reject
					//do nothing
				}
			);
			var sPath2 = this._vertragPath + "/ProvVertrToAuszahlung";
			Utilities.promiseODataRead(oVertragModel, sPath2, {}, []).then(
				function (oData) { //resolve
					this._sperrenPayeeIscd = oData.PayeeIscd;
				}.bind(this),
				function (oError) { //reject
					//do nothing
				}

			);

			this._newKond = this.oModel.getProperty("/changedKondition");
			this.validFrom = this.oModel.getProperty("/validFrom");
			var that = this;

			this.getView().bindElement({
				path: "/" + this._suchePath + "/PvSucheToProvVertr",
				parameters: {
					expand: "ProvVertrToPartner"
				},
				model: "vertrag",
				events: {
					change: function () {
						that.oVertragData = this.getModel("vertrag").getData("/" + that._vertragPath);
						if (!that.oVertragData) {
							that.displayInvalidPath();
						} else {
							// das momentan angezeigte Anfragedatum (CacsBusitimeB) im Feld Gültig am setzen
							that.byId("gueltigAm").setDateValue(that.oVertragData.CacsBusitimeB);

							// if (that.oVertragData.CocSperre) {
							if (that.oVertragData.CocSperre.includes("SPERRE")) {
								that.oModel.setProperty("/previousVersionAvailable", false);
								that.oModel.setProperty("/nextVersionAvailable", false);
								that._aSectionPseudoController = false;
								that.getView().byId("idObjectPageLayoutVertrag").destroySections();
								Fragment.load({
										name: "de.pnw.icm.provisionsvertrag.vtr.view.sections.ContentLocked",
										id: "idFragmentContentLocked"
									})
									.then(function (oFragment) {
										that.getView().byId("idObjectPageLayoutVertrag").addSection(oFragment);
									}.bind(this));
							} else {
								if (!that._aSectionPseudoController) {
									that.getView().byId("idObjectPageLayoutVertrag").destroySections();
								}
								that.checkIfVertragEndeRached();

								//Stellt die NameGrp1 in das AppView Modell, um es auch in der späteren Navigation im View nutzen zu können
								var NameGrp1 = that.vertragModel.getData("/" + that._vertragPath + "/ProvVertrToPartner/NameGrp1");
								that.oModel.setProperty("/NameGrp1", NameGrp1);

								//Busy Indicator öffnen
								Utilities._showBusyDialog();
								Promise.all([that._setNextVersionPath(), that._setPreviousVersionPath()]).then(function () {
									//Busy Indicator schließen
									if (that.oModel.getProperty("/compareModus")) {
										//Busy Indicator öffnen
										Utilities._showBusyDialog();
										Utilities.getPreviousVertrag(that.vertragModel, that._previousVertragVersionPath, that).then(
											function (oData) { //resolve
												that.createFragments();
											},
											function (oError) { //reject
												//Busy Indicator schließen
												Fragment.byId("idBusyFragment", "idBusyDialog").close();
												var bCompact = !!that.getView().$().closest(".sapUiSizeCompact").length,
													confirmMsg = oError.message;
												MessageBox.error(
													confirmMsg, {
														actions: [MessageBox.Action.CLOSE],
														styleClass: bCompact ? "sapUiSizeCompact" : "",
														onClose: function (sAction) {

														}
													}
												);
											}
										);
									} else {
										that.createFragments();
										Fragment.byId("idBusyFragment", "idBusyDialog").close();
									}
									/*
										Wenn der Änderungsmodus über einen Aufruf direkt der Provisionsvertrag-Bearbeiten App aus dem Launchpad betreten wird, 
										wird der Bearbeitungsgrund-Dialog bei Klick auf ein Listenelement aufgerufen
									*/
									if (that.oModel.getProperty("/bActionEdit")) {
										that.checkEdit();
									}
								});
							}

						}
					}
				}
			});

			/*
				Wechselt bei jedem neuen laden der Seite auf die Section Allgemeines, außer man kommt von den LaVvn, dann auf LaVv
			*/
			var idAllg = "idFragmentAllgemeines--AllgemeinesSection";
			var idLaVv = "idFragmentLavvShow--LavvSection";
			if(this.oModel.getProperty("/lastView")){
				this.byId("idObjectPageLayoutVertrag").setSelectedSection(idLaVv);
				this.oModel.setProperty("/lastView", null);
			} else {
				this.byId("idObjectPageLayoutVertrag").setSelectedSection(idAllg);
			}
		},

		displayInvalidPath: function () {
			var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length,
				confirmMsg = Utilities.geti18nText(this.i18n, "invalidPathMsg", []), //this.geti18nText("invalidPathMsg"),
				that = this;
			MessageBox.error(
				confirmMsg, {
					actions: [MessageBox.Action.CLOSE],
					styleClass: bCompact ? "sapUiSizeCompact" : "",
					onClose: function (sAction) {
						that.onNavBack();
					}
				}
			);
		},

		/*
			Fragmente mitsamt eigenem Pseudo-Controller für Sections erzeugen
			Setzen des ParentController
		*/
		createFragments: function () {
			this.decideSectionView();
			if (!this._aSectionPseudoController) {
				this._aSectionPseudoController = {};
				this._aSections = {};

				Promise.all([
					this._loadFragment("AllgemeinesShow", new AllgemeinesShow(this)),
					this._loadFragment("LavvShow", new LavvShow(this)),
					this._loadFragment("AuszahlungShow", new AuszahlungShow(this)),
					this._loadFragment("KorrespondenzShow", new KorrespondenzShow(this)),
					this._loadFragment("VermittlergruppenShow", new VermittlergruppenShow(this)),
					this._loadFragment("BeziehungenShow", new BeziehungenShow(this)),
					this._loadFragment("ReferenzenShow", new ReferenzenShow(this)),
					this._loadFragment("WPVShow", new WPVShow(this))
				]).then(function () {
					this._aSectionKeys.forEach(function (key) {
						this.getView().byId("idObjectPageLayoutVertrag").addSection(this._aSections[key]);
						this._aSectionPseudoController[key].setData();
						this._aSectionPseudoController.AllgemeinesShow.visualizeBlockLayoutChanges();
					}.bind(this));
				}.bind(this));
			}
			//ParentController von Fragmenten updaten
			else {
				this._aSectionKeys.forEach(function (key) {
				
					this._aSectionPseudoController[key].oParentController = this;
					this.getView().byId("idObjectPageLayoutVertrag").addSection(this._aSections[key]);
					this._aSectionPseudoController[key].setData();
					this._aSectionPseudoController.AllgemeinesShow.visualizeBlockLayoutChanges();
				}.bind(this));
			}

			// WPV und Makler Kommunikation anzeigen/ausblenden
			// Regel: Bereich WPV wird angezeigt, wenn Herkunft = 2 bzw. Makler, in der Regel wenn CtrtstId auf MAKLER endet.
			if (this.oVertragData.Herkunft === "2") {
				this.oModel.setProperty("/showWPV", true);
			} else {
				this.oModel.setProperty("/showWPV", false);
			}
			if (this.oVertragData.CtrtstId.endsWith("MAKLER")) {
				this.oModel.setProperty("/showMaklerKomm", true);
			} else {
				this.oModel.setProperty("/showMaklerKomm", false);
			}
		},
		
		/*
			Prüft ob der Kontext der Vertragsview OneColumn oder TwoColumnsMidExpanded ist
			letzteres soll nur die LaVv Section zeigen
		*/
		decideSectionView: function () {
			var hash = this.oView.oController.oRouter.oHashChanger.hash;
			var hashSplitArray = hash.split("/");
			var layout = hashSplitArray[hashSplitArray.length - 1];
			if (layout === "OneColumn") {
				this.oModel.setProperty("/sectionsShow", true);
			} else if (layout === "TwoColumnsMidExpanded") {
				this.oModel.setProperty("/sectionsShow", false);
			}
		},

		/*
			Instanziiert Fragment für Section
			Fügt Fragment zum Fragmente-Array _aSectionPseudoController hinzu
		*/
		_loadFragment: function (sFragmentName, oFragmentController) {
			this._aSectionPseudoController[sFragmentName] = oFragmentController;

			var fragment = Fragment.load({
					name: "de.pnw.icm.provisionsvertrag.vtr.view.sections." + sFragmentName,
					controller: oFragmentController,
					id: "idFragment" + sFragmentName
				})
				.then(function (oFragment) {
					this._aSections[sFragmentName] = oFragment;
				}.bind(this));
			return fragment;
		},

		checkIfVertragEndeRached: function () { //Die Funktion prüft ab ob Vertragsende in der Vergangenheit liegt -> Anmerkung 21.300: LaVvn nicht mehr änderbar wenn Abgangsdatum gesetzt ist
			var that = this;

			var oLeavDate = this.vertragModel.getData("/" + this._vertragPath + "/LeavDate");
			var	isHighDate = Utilities.checkHighDate(Utilities.dateToStr(oLeavDate));
			if (!isHighDate) {
				that.oVertragGlobal.setProperty("/LeavDateReached", true);
				that.oModel.setProperty("/lavvnChangable", false);

				if (that.oModel.getProperty("/editMode") && that.oVertragGlobal.getProperty("/LeavDateReached")) {
					var oHistory = History.getInstance();
					var sPreviousHash = oHistory.getPreviousHash();
					var msg = "Abgangsdatum ist gesetzt. Es können keine LaVven angehängt oder geändert werden.";
					if (sPreviousHash === "" || (sPreviousHash || "").endsWith("OneColumn")) {
						Utilities.shwoMessageToast(msg, 7000, false);
					}
				}
			} else {
				that.oVertragGlobal.setProperty("/LeavDateReached", false);
			}
		},

		/*
			Timeout Dialog für den Editiermodus
			nach 2 Minuten ohne Interaktion wird der Dialog geschlossen und in View Modus gewechselt
			Nicht gespeicherte Änderungen gehen verloren
		*/
		_countdownEditTime: function () {
			//globale Variable um von OPA darauf zugreifen zu können
			this.counter = new Date();
			var timeout = new Date();
			var oDateFormat = DateFormat.getTimeInstance({
				pattern: "mm:ss"
			});
			this.counter.setMinutes(2);
			this.counter.setSeconds(0);

			timeout.setMinutes(this.counter.getMinutes() - 2);
			timeout.setSeconds(this.counter.getSeconds());

			//Countdown für den Timeout-Dialog
			//wird Deaktiviert wenn der Bearbeitungsmodus verlassen wird oder der Zeitstempel erneuert wird.
			this.decrementCountdown = setInterval(function () {
				this.counter.setSeconds(this.counter.getSeconds() - 1);
				this.oModel.setProperty("/editCountdown", oDateFormat.format(this.counter));

				if (this.counter <= timeout) {
					clearInterval(this.decrementCountdown);
					this.oModel.setProperty("/editCountdown", "00:00");
					this.stopDecrementCountdown();
					this.onCancelEdit();
				}

			}.bind(this), 1000);
		},

		/*
			Setzt den Timer für die Inaktivität zurück
		*/
		resetInactiveTime: function (oEvent) {
			clearInterval(this._incrementInactiveTime);
			this.inactiveTime = 1;
			this._checkInactivity();
		},

		/*
			Eventlistener um den Timer für die Inaktivität zurückzusetzen
		*/
		_setInactivityListeners: function () {
			this._bind = this.resetInactiveTime.bind(this);
			document.addEventListener("mousemove", this._bind, false);
			document.addEventListener("keypress", this._bind, false);

			this.resetInactiveTime();
		},

		/* 
			Timer für die Inaktivität (Mausbewegung/Tastatureingabe) im Editiermodus
			nach 5 Minuten wird der Timeout Dialog angezeigt
		*/
		_checkInactivity: function () {
			//Setzt bei Inaktivität den Timer jede Minute hoch. Nach 5 Minuten ohne Aktivität wird der Timeout Dialog angezeigt
			//Wird bei Mausbewegung oder Tastatureingabe nicht zurückgesetzt
			//wird Deaktiviert wenn 5 Minuten vorbei sind und der Bearbeitungsmodus verlassen wird
			this._incrementInactiveTime = setInterval(function () {
				this.inactiveTime = this.inactiveTime + 1;
				if (this.inactiveTime === 5) {
					clearInterval(this._incrementInactiveTime);
					document.removeEventListener("mousemove", this._bind, false);
					document.removeEventListener("keypress", this._bind, false);

					if (!this.byId("idTimeoutDialog")) {
						Fragment.load({
							id: this.getView().getId(),
							name: "de.pnw.icm.provisionsvertrag.vtr.view.fragment.EditTimeout",
							controller: this
						}).then(function (oDialog) {
							this.getView().addDependent(oDialog);
							oDialog.open();
							this._countdownEditTime();
						}.bind(this));
					} else {
						this.byId("idTimeoutDialog").open();
						this._countdownEditTime();
					}
				}
			}.bind(this), 60000);
		},

		/* 
			Timeout Dialog schließen
			Editiermodus schließen und in View Modus wechseln
		*/
		onCancelEdit: function () {
			//2-min Countdown für Edit-Timeout deaktivieren
			this.stopDecrementCountdown();
			//Timeout Dialog schließen
			this.byId("idTimeoutDialog").close();

			// Wechsele Abhängig davon in welchem Modus die App geöffnet wurde auf die Selektionsseite
			// oder wieder zurück in den Anzeigemodus
			var bActionEdit = this.oModel.getProperty("/bActionEdit");
			if (bActionEdit) {
				this.deactivateBearbeitungsModus(false);
				this.stopRefreshCountdown();
				Utilities.navToRoute(this.oRouter, "master", sap.f.LayoutType.OneColumn);
			} else {
				//Bearbeitungsmodus verlassen
				this.switchToViewMode();
			}

		},

		/*
			Stoppt ein laufendes Interval
			spearate Funktion um in OPA testen zu können
		*/
		stopDecrementCountdown: function () {
			clearInterval(this.decrementCountdown);
		},

		stopRefreshCountdown: function () {
			clearInterval(this.refreshTimer);
		},

		/*
			Timer für den Editiermodus zurücksetzen
			neues Token senden
		*/
		onEditRefresh: function () {
			//Zeitstempel erneuern
			this._refreshEditTime();
			//2-min Countdown für Edit-Timeout deaktivieren
			this.stopDecrementCountdown();
			//Timeout Dialog schließen
			this.byId("idTimeoutDialog").close();
			//Prüfen auf Inaktivität aktivieren
			// this._setInactivityListeners();
		},

		/*
			Datensperrkonzept aktivieren
		*/
		onEdit: function () {
			this.checkEdit(); // TODO: Comment this line when deploying on FLP
			this.oModel.setProperty("/editMode", true); // TODO: Comment this line when deploying on FLP
			this.oModel.setProperty("/bActionEdit", true); // TODO: Comment this line when deploying on FLP
			// var sSemanticObject = "ZIcmProvVtr",
			// 	sAction = "edit",
			// 	sRoute = "vertrag/" + this._suchePath + "/OneColumn";
			// var sShellHash = sSemanticObject + "-" + sAction + "&/" + sRoute;
			// this.crossAppNavigation(sShellHash);
		},

		/*
			Datensperrkonzep
			BearbSperre lesen -> 	
			a) Gibt es keine -> Setzen mit Session ID
			b) Gibt es eine, die älter ist? -> update
			c) Gibt es eine, die neuer ist und die Session ID ist identisch -> update
			d) Gibt es eine, die neuer ist und die Session ID ist ungleich -> ablehnen
		*/
		checkEdit: function () {
			
			var sPath = "BearbSperreSet(CtrtbuId='" + this.oVertragData.CtrtbuId + "'" + ",SessionId='" + this._sessionId + "')";
			//Busy Indicator öffnen
			Utilities._showBusyDialog();
			Utilities.promiseODataRead(this.vertragModel, sPath, {}, []).then(
				function (oData) { //resolve
					// Vertrag könnte editiert werden
					delete oData.__metadata;
					oData.SessionId = this._sessionId;
					this._bearbSperrData = oData;
					if (!oData.SperrDatetime) { // Fall 1: Es liegt kein Eintrag vor
						
						Utilities.promiseODataCreate(this.vertragModel, "BearbSperreSet", oData).then(
							function (oJson) { //resolve
								//Busy Indicator schließen
								Fragment.byId("idBusyFragment", "idBusyDialog").close();
								//EditDialog öffnen 
								this.oVertragGlobal.setProperty("/isAlreadyInEditing", true);
								this._openEditDialog();
							}.bind(this),
							function (oError) { //reject
								//Busy Indicator schließen
								Fragment.byId("idBusyFragment", "idBusyDialog").close();
								var sErrorMsg = JSON.parse(oError.responseText).error.message.value;
								Utilities.displayErrorMessageBox(sErrorMsg, this.getView());
							}.bind(this)
						);
					} else { // Fall 2.1: Ein UPDATE mit geändertem Nutzer wird an das Backend geschickt
						this._refreshEditTime();
					}

				}.bind(this),
				function (oError) { //reject 
					/*
						Fall 2.2: der Wechsel in den Modus Bearbeiten abgelehnt 
						und der Nutzer mit einer Fehlermeldung darauf hingewiesen
						Anschließend wird der Nutzer auf die Ansichtsseite des selben Vertrags geroutet
					*/
					//Busy Indicator schließen
					Fragment.byId("idBusyFragment", "idBusyDialog").close();
					var sErrorMsg = JSON.parse(oError.responseText).error.message.value;
					this.displayErrorMessageBoxSperre(sErrorMsg, this.getView());
				}.bind(this)
			);
		},

		/*
			Erneuert den Zeitstempel für die Bearbeitung eines Vertrages
		*/
		_refreshEditTime: function () {
			var sPath = "BearbSperreSet(CtrtbuId='" + this.oVertragData.CtrtbuId + "'" + ",SessionId='" + this._sessionId + "')";
			Utilities.promiseODataUpdate(this.vertragModel, sPath, this._bearbSperrData).then(
				function (oJson) { //resolve
					//Busy Indicator schließen 
					Fragment.byId("idBusyFragment", "idBusyDialog").close();

					//EditDialog öffnen wenn noch kein Vertrag in Bearbeitung ist 
					//Dafür prüfen ob Editdialog geöffnet wurde && ob dieser Dialog bereits einmal gezeigt wurde
					if (this.oModel.getProperty("/editMode") && !this.oVertragGlobal.getProperty("/isAlreadyInEditing")) {
						this.oVertragGlobal.setProperty("/isAlreadyInEditing", true);
						this._openEditDialog();
					}
				}.bind(this),
				function (oError) { //reject
					//Timer zur 3-minütigen Prüfung deaktivieren
					this.stopRefreshCountdown();
					//Busy Indicator schließen
					Fragment.byId("idBusyFragment", "idBusyDialog").close();
					var sErrorMsg = JSON.parse(oError.responseText).error.message.value;
					Utilities.displayErrorMessageBox(sErrorMsg, this.getView());
				}.bind(this)
			);
		},

		_openEditDialog: function () {
			if (!this.editDialog) {
				Fragment.load({
					id: "idFragmentEditDialog",
					name: "de.pnw.icm.provisionsvertrag.vtr.view.fragment.EditDialog",
					controller: this
				}).then(function (oDialog) {
					oDialog.setModel(this.vertragModel);
					this.getView().addDependent(oDialog);
					this.editDialog = oDialog;
					oDialog.open();
				}.bind(this));
			} else {
				this.editDialog.open();
			}
		},

		closeEditDialog: function (oEvent) {

			// Wechsele Abhängig davon in welchem Modus die App geöffnet wurde auf die Selektionsseite
			// oder wieder zurück in den Anzeigemodus
			var lastHistory;
			if(window.history.state.sap.history.length > 1){
				lastHistory = window.history.state.sap.history[window.history.state.sap.history.length - 2];
			} else { //Dieser Fall kann nur auftreten, wenn aus Vermittler in edit gesprungen wird. Hier wird dann auf den Anzeigemodus des selben Vertrags gesprungen
				lastHistory = "";
			}
			
			
			if (lastHistory.split("/")[0].includes("ZIcmProvVtr-edit")) {	//Startseite PV Ändern App
				this.oModel.setProperty("/editMode", true);
				this.stopDecrementCountdown();
				this.deactivateBearbeitungsModus(false);
				Utilities.navToRoute(this.oRouter, "master", sap.f.LayoutType.OneColumn);
			} else { //Entsprechenden PV Vertrag im Anzeigemodus 
				this.switchToViewMode();
			}
			if (this.editDialog) {
				this.editDialog.close();
			}

		},

		onEditDialog: function (oEvent) {
			var sChgReason = Fragment.byId("idFragmentEditDialog", "idChgReason").getSelectedKey();
			this.oModel.setProperty("/ChgReason", sChgReason);
			this.editDialog.close();
			this.oModel.setProperty("/editMode", true);
			// für das CacsBusitimeB wird das aktuelle Datum genutzt
			var todayUTCDate = new Date();
			this._navigateToTemplate(todayUTCDate);
			
			var validFrom = new Date(this.oModel.getProperty("/validFrom"));
			this._checkVordatierteAenderung(validFrom); //Prüft vordatierte Änderung und wirkt ggf. Meldung

			// Prüft alle 3 Minuten 
			//wird Deaktiviert beim Verlassen des Bearbeitungsmodus und wenn das Erneuern des Zeitstempels fehlschlägt
			this.refreshTimer = setInterval(function () {
				this._refreshEditTime();
			}.bind(this), 180000);
			//Prüft auf Inaktivität
			this._setInactivityListeners();
		},
		
		_checkVordatierteAenderung: function (validFrom) {
			var that = this;
			return new Promise(function (resolve, reject) {
				that._getVertragVersionByDate(FilterOperator.GE, validFrom).then(function (sNextVertragPath) {
						//that.oModel.setProperty("/bVordatierteAenderung", true);
						// Im Beabeitungsmodus: Wird nicht die letzte Version gezogen, wird der Nutzer darüber informiert, dass eine vordatierte Änderung vorhanden ist
						if (that.oModel.getProperty("/editMode") && !that.oVertragGlobal.getProperty("/nextVersionMessageToastShown")) {
							that.oVertragGlobal.setProperty("/nextVersionMessageToastShown", true); // Toast nur einmalig
							var sMessage = "Eine vordatierte Änderung ist vorhanden. Beim Speichern einer neuen Änderung wird diese überschrieben.";
							Utilities.shwoMessageToast(sMessage, 7000, false);
						}
						resolve();
					},
					function () { //reject
						//that.oModel.setProperty("/bVordatierteAenderung", false);
						resolve();
					});
			});
		},

		/*
			Eingabefeld für das Gültig-Ab Datum,
			Validierung und Speicherung des Wertes im Modell
		*/
		onValidFromSet: function (oEvent) {
			var bValid = oEvent.getParameter("valid"),
				oSource = oEvent.getSource(),
				dateValue = oSource.getDateValue();
			if (bValid && dateValue) {
				oEvent.getSource().setValueState(ValueState.None);
				this.validFrom = dateValue.getTime();
				this.oModel.setProperty("/validFrom", this.validFrom);
				this.oModel.setProperty("/validFromDate", dateValue);
			} else {
				oEvent.getSource().setValueState(ValueState.Error);
				this.oModel.setProperty("/validFrom", null);
			}
			Fragment.byId("idFragmentEditDialog", "idEditBtnOk").setEnabled(bValid);
		},
		
		/*
			Bei Neuanlage (FlgStatus (Status Provisionsvertrag) = X) darf das Datum zurückdatiert (max. Bis BusiBegin) werden. 
			Initial wird das Feld dann mit dem Wert CtrtbuBdate (Vertragsbeginn) vorbelegt.
			Wenn die Flag auf False ist, dann ist die Datumsauswahl leer und es können nur Daten ab morgen bis 01. Des Folgemonats gewählt werden. 
		*/
		afterEditDialogOpened: function (oEvent) {
			var oValidFrom = Fragment.byId("idFragmentEditDialog", "idValidFrom"),
				dateTime = null,
				bEnabled = false,
				oValueState = ValueState.Error,
				oMinDate = null,
				oMaxDate = null;
			if (this.validFrom) {
				dateTime = new Date(this.validFrom);
				oValueState = ValueState.None;
			}
			if (!this.oVertragData.FlgStatus) {
				// Gültig-Ab soll in der zukunft liegen
				oMinDate = new Date(new Date().getTime() + (24 * 60 * 60 * 1000));
				//setMaxDate:
				var aktDate = new Date();
				var nextMonat = aktDate.getMonth() + 1;
				var aktJahr = aktDate.getYear() + 1900;
				oMaxDate = new Date(aktJahr, nextMonat, "01");
			} else {
				oMinDate = this.oVertragData.BusiBegin;
				oValueState = ValueState.None;
				dateTime = this.oVertragData.CtrtbuBdate;
				// Bei Neuanlage wird validFrom oder validFromDate sonst nicht gefüllt, da der Datepicker vorbelegt ist
				this.oModel.setProperty("/validFrom", oMinDate.getTime());
				this.oModel.setProperty("/validFromDate", oMinDate);
			}
			if (dateTime) {
				bEnabled = true;
			}
			oValidFrom.setDateValue(dateTime);
			oValidFrom.setMinDate(oMinDate);
			oValidFrom.setMaxDate(oMaxDate);
			oValidFrom.setValueState(oValueState);
			Fragment.byId("idFragmentEditDialog", "idEditBtnOk").setEnabled(bEnabled);
		},

		buildDateDDMMYYYY: function (date) {
			var dd = date.getDate();
			if (dd < 10) {
				dd = "0" + dd;
			}
			var MM = date.getMonth() + 1;
			if (MM < 10) {
				MM = "0" + MM;
			}
			var YYYY = date.getFullYear();
			return ("" + dd + "." + MM + "." + YYYY);
		},

		/*
			Beim Speichern wird geprüft, ob das Gültig-Ab Datum vorhanden ist, 
			wenn nicht sollte eine Fehlermeldung angezeigt, sonst
			werden die LaVvs mit Konditionen gebildet und vorbereitet
		*/
		saveLaVv: function () {
			var validFrom = this.oModel.getProperty("/validFrom");
			var lavvList = this.oModel.getProperty("/lavvData") || [];
			if (validFrom) {
				// vertrag bilden
				var obj = {},
					lavvObj = {},
					vertragObj = {},
					lavvKeys = [],
					lavvKey = "";
				obj.BusiBegin = new Date(validFrom);
				if (lavvList.length > 0) {
					for (var i = 0; i < lavvList.length; i++) {
						var oData = lavvList[i];
						var uri = oData.__metadata.uri;
						var key = uri.split("LeiVergVereinbarungenSet")[1];
						if (key) {
							lavvKey = "LeiVergVereinbarungenSet" + key;
							lavvObj[lavvKey] = {};
							lavvKeys.push(lavvKey);
						} else {
							key = uri.split("StdVertLavvSet")[1];
							lavvKey = "StdVertLavvSet" + key;
							lavvObj[lavvKey] = {};
							lavvKeys.push(lavvKey);
						}
					}
					if (this._newKond) {
						var kondKeys = Object.keys(this._newKond);
						for (var j = 0; j < kondKeys.length; j++) {
							var idx = lavvKeys.indexOf(kondKeys[j]);
							if (idx !== -1) {
								lavvObj[lavvKeys[idx]] = this._newKond[kondKeys[j]];
							}
						}
					}
					obj.ToLavv = lavvObj;
				} else {
					// No LaVv
					obj.ToLavv = {};
				}

				vertragObj[this._vertragPath] = obj;

				/*
				send data to backend
				*/

				this.sendDataToGW(vertragObj);

				//else if muss noch getestet werden, ob bei einer Neuanlage nun in dei Vergangenheit datiert 
				//werden kann und wenn kein Datum eingetragen ist dann das ganze den Fehler des leeren Datums wirft
			} else if (this.oVertragData.FlgStatus) {

				// Enter valid date
				var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length,
					errorMsg = Utilities.geti18nText(this.i18n, "errorMsgDatumLeer", []); //this.geti18nText("errorMsgDatumLeer");
				MessageBox.error(
					errorMsg, {
						styleClass: bCompact ? "sapUiSizeCompact" : ""
					}
				);
			} else {
				// Enter valid date
				bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
				errorMsg = Utilities.geti18nText(this.i18n, "errorMsgValidFrom", []); //this.geti18nText("errorMsgValidFrom");
				MessageBox.error(
					errorMsg, {
						styleClass: bCompact ? "sapUiSizeCompact" : ""
					}
				);

			}
		},

		/*
			die Funktion bildet	das JSON-Objekt mit untergeordneten Objekten, wenn vorhanden,
			und schickt an das Backend für die Erstellung der neuen Vertragsversion
		*/
		sendDataToGW: function (vertragObj) {
			Utilities._showBusyDialog();                
			var objData = vertragObj[this._vertragPath],
				vertragData = this.vertragModel.getData("/" + this._vertragPath),
				newCtrVersion = vertragData;

			var busiBegin = objData.BusiBegin;
			// „Erstellt am“ zeigt das Tagesdatum
			newCtrVersion.TechBegin = new Date();
			newCtrVersion.BusiBegin = busiBegin;
			// „Gültig bis“ wird mit dem Datum „31.12.9999“ befüllt 
			newCtrVersion.BusiEnd = new Date(9999, 11, 31);
			newCtrVersion.TimeZone = busiBegin.getTimezoneOffset().toString();
			newCtrVersion.ChgReason = this.oModel.getProperty("/ChgReason");
			newCtrVersion.ToLavv = {};
			newCtrVersion.ToLavv.results = [];

			delete newCtrVersion.Version;
			delete newCtrVersion.ToVersion;
			delete newCtrVersion.ToStdLavv;
			delete newCtrVersion.ProVertrToReferenzen;
			delete newCtrVersion.ProvVertrToAdressenliste;
			delete newCtrVersion.ProvVertrToAnsprechpartner;
			delete newCtrVersion.ProvVertrToAuszahlungBank;
			delete newCtrVersion.ProvVertrToKommMakler;
			delete newCtrVersion.ProvVertrToKorrespondenz;
			delete newCtrVersion.ProvVertrToOrgaStruktur;
			delete newCtrVersion.ProvVertrToPartner;
			delete newCtrVersion.ProvVertrToVermGruppen;
			delete newCtrVersion.ProvVertrToWpvKond;
			delete newCtrVersion.ProvVertrToWpvStamm;
			delete newCtrVersion.ProvVertrToAuszahlung;
			delete newCtrVersion.ProvVertrToSparkasse;

			var lavvKeys = Object.keys(objData.ToLavv);
			if (lavvKeys.length > 0) {
				for (var j = 0; j < lavvKeys.length; j++) {
					var lavvColumn2 = this.vertragModel.getData("/" + lavvKeys[j]),
						toKondTabKeys = Object.keys(objData.ToLavv[lavvKeys[j]]);

					lavvColumn2.ToKondTab = {};
					lavvColumn2.ToKondTab.results = [];

					delete lavvColumn2.__metadata;

					if (toKondTabKeys.length > 0) {
						for (var k = 0; k < toKondTabKeys.length; k++) {
							var kondTabColumn = this.vertragModel.getData("/" + toKondTabKeys[k]),
								changedKond = objData.ToLavv[lavvKeys[j]][toKondTabKeys[k]].ToKond;

							kondTabColumn.ToKond = {};
							kondTabColumn.ToKond.results = [];

							delete kondTabColumn.__metadata;

							if (changedKond.length > 0) {
								for (var l = 0; l < changedKond.length; l++) {
									changedKond[l].Datab = busiBegin;
								}
								kondTabColumn.ToKond.results = changedKond;
							}

							lavvColumn2.ToKondTab.results.push(kondTabColumn);
						}
					}
					newCtrVersion.ToLavv.results.push(lavvColumn2);
				}
			}

			var that = this;

			this.vertragModel.create("/ProvVertrSet", newCtrVersion, {
				success: function (response) {

					// um dem Nutzer einen Hinweis zu liefern, welche HK er zu welchem Datum geändert hat:
					var date = that.buildDateDDMMYYYY(newCtrVersion.BusiBegin),
						msg;
					if (!that.oVertragData.FlgStatus) { //Fehler 2985, erneute Prüfung, ob Neuanlage oder Änderung
						msg = "Der Provisionsvertrag " + newCtrVersion.CtrtbuId + ", wurde erfolgreich zum " + date + " geändert!";
					} else {
						msg = "Der Provisionsvertrag " + newCtrVersion.CtrtbuId + ", wurde erfolgreich zum " + date + " angelegt!";
					}

					//var msg = "Der Provisionsvertrag " + newCtrVersion.CtrtbuId +  ", wurde erfolgreich zum " + date + " geändert!";
					MessageToast.show(msg, {
						duration: 7000, // time till toast fades/decays
						closeOnBrowserNavigation: false // keep toast shown in spite of routing
					});

					that.onNavBack();
				},
				error: function (oError) {

					if (oError) {
						if (oError.message) {
							MessageBox.error(oError.message);
						}
					}
				}
			});

		},

		/*
			Vergleichmodus aktivieren/deaktivieren
		*/
		compareModus: function () {
			if (this.oModel.getProperty("/compareModus")) {
				this.oModel.setProperty("/compareModus", false);
				Fragment.byId("idFragmentLavvShow", "lavvList").updateItems();
				Fragment.byId("idFragmentWPVShow", "idTableAPProvisionen").updateItems();
				Fragment.byId("idFragmentWPVShow", "idTableVPProvisionen").updateItems();
				this.resetBlockLayoutVisualization("Allgemeines", this.oMappingModel);
				this.resetBlockLayoutVisualization("WPV", this.oMappingModel);
				this.resetBlockLayoutVisualization("Korrespondenz", this.oMappingModel);
			} else {
				// vorherige Vertragsversion holen und im Model setzen
				if (this.oModel.getProperty("/previousVersionAvailable")) {
					this.oModel.setProperty("/compareModus", true);
					//Busy Indicator öffnen
					Utilities._showBusyDialog();
					Utilities.getPreviousVertrag(this.vertragModel, this._previousVertragVersionPath, this).then(
						function (oData) { //resolve
							Fragment.byId("idFragmentLavvShow", "lavvList").updateItems();
							Fragment.byId("idFragmentWPVShow", "idTableAPProvisionen").updateItems();
							Fragment.byId("idFragmentWPVShow", "idTableVPProvisionen").updateItems();
							var oChangesAllgemeines = Utilities.compareJSONObject(this.oModel.getProperty("/previousVertrag"), this.oVertragData);
							this.visualizeBlockLayoutChanges("Allgemeines", oChangesAllgemeines);

							if (this.oModel.getProperty("/showWPV")) {
								var oChangesWPVStamm = Utilities.compareJSONObject(this.oModel.getProperty("/previousWpvStamm"), this.oCurrentWPVStamm);
								this.visualizeBlockLayoutChanges("WPV", oChangesWPVStamm);
							}

							if (this.oModel.getProperty("/showMaklerKomm")) {
								var oChangesMaklerKomm = Utilities.compareJSONObject(this.oModel.getProperty("/previousKommMakler"), this.oCurrentVertragKommMakler);
								this.visualizeBlockLayoutChanges("Korrespondenz", oChangesMaklerKomm);
							}

							var oChangesKorrespondenz = Utilities.compareJSONObject(this.oModel.getProperty("/previousKorrespondenz"), this.oCurrentVertragKorrespondenz);
							this.visualizeBlockLayoutChanges("Korrespondenz", oChangesKorrespondenz);

							Fragment.byId("idBusyFragment", "idBusyDialog").close();
						}.bind(this),
						function (oError) { //reject
							//Busy Indicator schließen
							Fragment.byId("idBusyFragment", "idBusyDialog").close();
							Utilities.displayErrorMessageBox(oError.message, this.getView());
						}.bind(this)
					);
				}
			}
		},

		/*
		Vergleichsmodus
		Markiert Änderungen farbig
		*/
		visualizeBlockLayoutChanges: function (oFragment, oChanges) {
			var oFragmentMapping = this.oMappingModel.getData()[oFragment];

			for (var key in oChanges) {
				var controlId = oFragmentMapping[key];
				if (controlId) {
					var control = Fragment.byId("idFragment" + oFragment + "Show", controlId);
					if (control) {
						var controlType = control.getMetadata().getName();
						switch (controlType) {
						case "sap.m.ObjectStatus":
							control.setState("Indication03");
							control.setTooltip(oChanges[key]);
							break;
						case "de.pnw.icm.provisionsvertrag.vtr.control.LabelExtended":
							control.setValueState("Indication03");
							if (typeof oChanges[key] === "string") { //falls true oder false
								if (oChanges[key] === "") {
									control.setTooltip(Utilities.geti18nText(this.i18n, "noValue", [])); //control.setTooltip(this.geti18nText("noValue"));
								} else {
									control.setTooltip(oChanges[key]);
								}
							}
							break;
						case "de.pnw.icm.provisionsvertrag.vtr.control.CheckBox":
							control.setValueState("Indication03");
							break;
						}
					}
				}
			}
		},

		/*
		Vergleichsmodus
		Setzt die farbige Markierung zurück
		*/
		resetBlockLayoutVisualization: function (oFragment, oMappingModel) {
			var oFragmentMapping = oMappingModel.getData()[oFragment];

			for (var key in oFragmentMapping) {
				var controlId = oFragmentMapping[key];
				if (controlId) {
					var control = Fragment.byId("idFragment" + oFragment + "Show", controlId);
					if (control) {
						var controlType = control.getMetadata().getName();
						switch (controlType) {
						case "sap.m.ObjectStatus":
							control.setState("None");
							control.destroyTooltip();
							break;
						case "de.pnw.icm.provisionsvertrag.vtr.control.LabelExtended":
							control.setValueState("None");
							control.destroyTooltip();
							break;
						case "de.pnw.icm.provisionsvertrag.vtr.control.CheckBox":
							control.setValueState("None");
							break;
						}
					}
				}
			}
		},

		/*
			Setzt den Pfad für die nächste Vertragsversion	
		*/
		_setNextVersionPath: function () {
			var that = this;
			return new Promise(function (resolve, reject) {
				that._getVertragVersionByDate(FilterOperator.GT, that.oVertragData.BusiBegin).then(function (sNextVertragPath) {
						that._nextVertragVersionPath = sNextVertragPath;
						that.oModel.setProperty("/nextVersionAvailable", true);
						resolve();
					},
					function () { //reject
						that.oModel.setProperty("/nextVersionAvailable", false);
						resolve();
					});
			});
		},

		/*
			Setzt den Pfad für die vorherige Vertragsversion	
		*/
		_setPreviousVersionPath: function () {
			var that = this;
			return new Promise(function (resolve, reject) {
				that._getVertragVersionByDate(FilterOperator.LT, that.oVertragData.BusiBegin).then(function (sPreviousVertragPath) {
						that._previousVertragVersionPath = sPreviousVertragPath;
						that.oModel.setProperty("/previousVersionAvailable", true);
						resolve();
					},
					function () { //reject
						that.oModel.setProperty("/previousVersionAvailable", false);
						resolve();
					});
			});
		},

		/*
			Abrufen der nächsten bzw. vorherigen Vertragsversion je nach Filter
		*/
		_getVertragVersionByDate: function (sFilterOperator, date) {
			var sPath = this._vertragPath + "/ToVersion",
				oUrlParameters = {
					"$top": 1
				},
				aFilter = [],
				currentVersionDate = Utilities.formatDate(date).replace(/%3A/g, ":");

			aFilter.push(
				new Filter({
					path: "CacsBusitimeB",
					operator: sFilterOperator,
					value1: currentVersionDate
				})
			);

			var that = this;
			return new Promise(function (resolve, reject) {
				Utilities.promiseODataRead(that.vertragModel, sPath, oUrlParameters, aFilter).then(
					function (oCompleteEntry) { //resolve
						var oVertragVersion = oCompleteEntry.results[0];
						if (oVertragVersion) {
							var sVersionURI = oVertragVersion.__metadata.uri;
							var iPos = sVersionURI.indexOf("ProvVertVersionSet");
							var sVersionPath = sVersionURI.substring(iPos, sVersionURI.length).replace("ProvVertVersionSet", "PvSucheSet");
							resolve(sVersionPath);
						} else {
							reject();
						}
					},
					function (oError) { //reject
						var bCompact = !!that.getView().$().closest(".sapUiSizeCompact").length,
							confirmMsg = oError.message;
						MessageBox.error(
							confirmMsg, {
								actions: [MessageBox.Action.CLOSE],
								styleClass: bCompact ? "sapUiSizeCompact" : "",
								onClose: function (sAction) {

								}
							}
						);
						reject();
					}
				);
			});
		},

		/*
			Blättern zur nachfolgenden Version
		*/
		nextVersion: function () {
			this.navigateToVertrag(this._nextVertragVersionPath);
		},

		/*
			Blättern zur vorherige Version
		*/
		previousVersion: function () {
			this.navigateToVertrag(this._previousVertragVersionPath);
		},

		/*
			Versionsauswahl: Dailog und Aktionen
		*/
		openVersion: function () {
			if (!this.byId("versionDialog")) {
				Fragment.load({
					id: this.getView().getId(),
					name: "de.pnw.icm.provisionsvertrag.vtr.view.fragment.Version",
					controller: this
				}).then(function (oDialog) {
					oDialog.setModel(this.getView().getModel("vertrag"));
					this.getView().addDependent(oDialog);
					oDialog.open();
				}.bind(this));
			} else {
				this.byId("versionDialog").open();
			}
		},

		/*
		openDebug öffnet ein einfaches fragment, welches nur ein Textfeld beinhaltet. Dieses kann alternativ zu einer 
		Konsolenausgabe genutzt werden. Manchmal reagiert es nicht ganz richtig. Der Text wird wie folgt gesetzt:
		//this.oModel.setProperty("/debugText", <textVariableHierEinfügen>);
		in der Vertrag View muss 
		<!--m:Button text="{i18n>debugText}" visible="{= ${appView>/editMode/} !== true }" press="openDebug"/-->
		einkommentiert werden. Wenn kein Text angezeigt wird, dann hat der Methodenaufruf, dann liegt das daran, dass 
		der Aufruf, der den <textVariableHierEinfügen> füllt nicht funktioniert hat.
		*/
		openDebug: function () {
			if (!this.byId("debugDialog")) {
				Fragment.load({
					id: this.getView().getId(),
					name: "de.pnw.icm.provisionsvertrag.vtr.view.fragment.debugging",
					controller: this
				}).then(function (oDialog) {
					oDialog.setModel(this.getView().getModel("vertrag"));
					this.getView().addDependent(oDialog);
					oDialog.open();
				}.bind(this));
			} else {
				this.byId("debugDialog").open();
			}

		},

		/*
			Aktion wenn eine Version ausgewählt wurde.
			Wird hier die View mit dem neuen Parameter aufgerufen
		*/
		versionSelect: function (oEvent) {
			var versionPath = oEvent.getSource().getBindingContextPath();
			versionPath = versionPath.replace("ProvVertVersionSet", "PvSucheSet");
			versionPath = versionPath.replace("BusiBegin", "CacsBusitimeB");
			versionPath = versionPath.replace("TechBegin", "Cacstechtime");

			//um auszulesen, wie der Vertragspath 
			//var debugPath = versionPath;
			//this.oModel.setProperty("/debugText", debugPath);

			this.oModel.setProperty("/lavvData", null);
			this.byId("versionDialog").close();
			this.navigateToVertrag(versionPath.substr(1));

			//this.byId("gueltigAm").setValue(null); //Setzt den Wert des Datepickers zurück

		},

		handleClose: function (oEvent) {
			this.byId("versionDialog").close();
		},

		handleCloseDebug: function (oEvent) {
			this.byId("debugDialog").close();
		},

		/*
			Vorgehen: Aktuellen path nehmen und dann den timestamp busibegin durch das eingegebene Datum ersetzen.
			TechBegin wird durch das aktuelle TagesDatum ersetzt.
			Neu: alle Daten werden mit aktueller CtrtbuId, Cacstechtime = aktueller Datetime Zeitstempel 
			und CacsBusitimeB = eingetragenes Datum geladen.
		*/
		onGueltigAm: function (oEvent) {
			// Hole Date aus Datepicker und konvertiere in yyyy-mm-ddThh%3Amm%3Ass
			var oEnteredDate = oEvent.getSource().getDateValue();
			this._navigateToTemplate(oEnteredDate);
		},

		_navigateToTemplate: function (oEnteredDate) {
			var sEnteredDate = Utilities.formatDate(oEnteredDate);

			// für das techBegin wird das aktuelle Datum genutzt
			var todayUTCDate = new Date();
			// konvertiere Tagesdatum in yyyy-mm-ddThh%3Amm%3Ass
			todayUTCDate = Utilities.formatDate(todayUTCDate);

			var sCtrtbuId = Utilities.urlEncodeEmptySpace(this.oVertragData.CtrtbuId);

			// baue neuen Path zusammen aus der alten Verm-Nr und den neuen Zeiten aus dem Datepicker und LocalTime
			var newPath = Utilities.buildPvSuchePath(sEnteredDate, todayUTCDate, sCtrtbuId);

			// Signalisiere, dass die LaVvn neu geladen werden sollen, wenn navTo erfolgt
			this.oModel.setProperty("/lavvData", null);

			// Absprung in die entsprechende Version, die zu dem Beginndatum passt.
			this.navigateToVertrag(newPath);

			/*
			// hole aktuellen Pfad
			var versionPath = this._vertragPath;
			// Pfad zwischenspeichern   
			var oldPath = versionPath;
			var length = oldPath.length;
			// Der offset berechnet die Position des zweiten timestamps, da die Verm-Nr bei unterschiedlicher Länge
			// den zweiten timestamp (techBegin) verschiebt. Ein Vermittler mit einstelliger Verm-Nr hat mindestens eine Pathlänge von 122 
			var offset = length - 122;

			// !!!!!!!!!!! Hinweis IE11:
			// die Funktion new Date(date + "UTC").toISOString() liefert in allen Browsern ein valides Datum, außer im IE
			// hier geht die Ergänzung + "UTC" nicht !!!!!!!!! Es wird umgangen mit der eigenen formatDate Funktion. 

			// Hole Date aus Datepicker und konvertiere in yyyy-mm-ddThh%3Amm%3Ass
			var enteredDate = new Date(oEvent.getSource().getDateValue());
			enteredDate = Utilities.formatDate(enteredDate);

			// für das techBegin wird das aktuelle Datum genutzt
			var todayUTCDate = new Date();
			// konvertiere Tagesdatum in yyyy-mm-ddThh%3Amm%3Ass
			todayUTCDate = Utilities.formatDate(todayUTCDate);
			// baue neuen Path zusammen aus der alten Verm-Nr und den neuen Zeiten aus dem Datepicker und LocalTime
			var newPath = oldPath.substr(0, 40) + enteredDate + oldPath.substr(63, 34 + offset) + todayUTCDate + oldPath.substr(120 + offset,
				2);

			// Signalisiere, dass die LaVvn neu geladen werden sollen, wenn navTo erfolgt
			this.oModel.setProperty("/lavvData", null);

			// Absprung in die entsprechende Version, die zu dem Beginndatum passt.
			this.oRouter.navTo("vertrag", {
				layout: sap.f.LayoutType.OneColumn,
				vertragPath: newPath,
				leistungPath: false
			});
			*/
		},

		/*
			Navigation zu einem Vertrag
		*/
		navigateToVertrag: function (vertragPath) {
			this.oModel.setProperty("/lavvData", null);
			this.oRouter.navTo("vertrag", {
				layout: sap.f.LayoutType.OneColumn,
				vertragPath: vertragPath
			});
		},

		/*
			Bevor der User zurück navigiert, wird geprüft ob es eine nicht gespeicgerte Änderung gibt,
			ggf. um eine Bestätigung nachfragen
		*/
		beforeNavBack: function (oEvent) {
			var bShow = oEvent.getSource().getId().endsWith("idButtonShow");
			if (this.oModel.getProperty("/lavvHasChanged")) {
				var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length,
					confirmMsg = Utilities.geti18nText(this.i18n, "confirmMsg", []), //this.geti18nText("confirmMsg"),
					that = this;
				MessageBox.confirm(
					confirmMsg, {
						actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
						styleClass: bCompact ? "sapUiSizeCompact" : "",
						onClose: function (sAction) {
							if (sAction === "OK") {
								that.onNavBack(bShow);
							}
						}
					}
				);
			} else {
				this.onNavBack(bShow);
			}
		},

		onNavBack: function (bShow) {
			
			this.onCloseResetProperties(bShow);
			if(Fragment.byId("idBusyFragment", "idBusyDialog")){
				Fragment.byId("idBusyFragment", "idBusyDialog").close();
			}
			if (bShow) {
				this.switchToViewMode();
			} else {
				Utilities.navToRoute(this.oRouter, "master", sap.f.LayoutType.OneColumn);
			}
		},

		/*
			closeType gibt an, wie die Seite verlassen werden soll, es gibt dafür aktuell die Optionen:
			- in View Modus gehen (switchToViewMode)						
			- Seite verlassen aber semantisches Object edit nicht verlassen
			- Seite verlassen aber semantisches Object view nicht verlassen
			- Timer läuft ab, dann je nach Option des Timer fragments
			=> Die Eingabe ist immer false, außer das semantische Objekt muss mit switchToViewMode gewechselt werden
			TODO: Ist keine schöne Lösung, dafür ggf eine bessere Variante bauen
		*/
		onCloseResetProperties: function (closeType) {
			this.oModel.setProperty("/lavvHasChanged", false);
			this.oModel.setProperty("/changedKondition", null);
			this.oModel.setProperty("/validFrom", null);
			this.oModel.setProperty("/compareModus", false);
			this.oModel.setProperty("/previousLavv", null);
			this.oModel.setProperty("/previousVertrag", null);
			this.oModel.setProperty("/lavvnChangable", false);
			//reset Datepicker
			this.getView().byId("gueltigAm").setValue(null);
			//reset messageToast availability
			this.oVertragGlobal.setProperty("/nextVersionMessageToastShown", false);
			//Timer für das erneuern des Zeitstempels deaktivieren
			this.stopRefreshCountdown();
			//Timer zum Prüfen auf Inaktivität deaktivieren
			clearInterval(this._incrementInactiveTime);
			//Eventlistener entfernen
			document.removeEventListener("mousemove", this._bind, false);
			document.removeEventListener("keypress", this._bind, false);
			Utilities.deleteStoredOData(this.vertragModel, true);
			this.oVertragGlobal.setProperty("/isAlreadyInEditing", false); 
			if (this.isEditMode && !closeType) {
				this.deactivateBearbeitungsModus(false);
			}
		},

		/*
			Wechselt vom Editier-Modus in den View-Modus
			Löscht den Eintrag für die Bearbeitung aus der Tabelle 
		*/
		switchToViewMode: function () {
			// Wechselt in den Modus Anzeigen mit Cross Navigation
			//Busy Indicator öffnen
			Utilities._showBusyDialog();
			
			this.deactivateBearbeitungsModus(true);
		},
		
		/*
			Sofern es eine aktive Sperre dieser Session gibt, muss diese gelöst werden.
		*/
		deactivateBearbeitungsModus: function (mode) {
			var sPath = "BearbSperreSet(CtrtbuId='" + this.oVertragData.CtrtbuId + "'" + ",SessionId='" + this._sessionId + "')";
			Utilities.promiseODataDelete(this.vertragModel, sPath).then(
				function (oJson) { //resolve
					//Busy Indicator schließen und Bearbeitung aktivieren
					Fragment.byId("idBusyFragment", "idBusyDialog").close();
					var sSemanticObject = "ZIcmProvVtr",
						sAction = "display",
						sRoute = "vertrag/" + this._suchePath + "/OneColumn";
					var sShellHash = sSemanticObject + "-" + sAction + "&/" + sRoute;
					if (mode) {
						this.oModel.setProperty("/editMode", false);
						this.oVertragGlobal.setProperty("/isAlreadyInEditing", false); 
						// this.crossAppNavigation(sShellHash); // TODO: Disomment this line when deploying on FLP
						this.oModel.setProperty("/bActionEdit", false); // TODO: Comment this line when deploying on FLP
					}
				}.bind(this),
				function (oError) { //reject
					//Busy Indicator schließen
					Fragment.byId("idBusyFragment", "idBusyDialog").close();
					var sErrorMsg = JSON.parse(oError.responseText).error.message.value;
					Utilities.displayErrorMessageBox(sErrorMsg, this.getView());
				}.bind(this)
			);
		},

		crossAppNavigation: function (sShellHash) {

			if (this.oCrossAppNav) {
				this.oCrossAppNav.toExternal({
					target: {
						shellHash: sShellHash
					}
				});
			}
		},
		
		displayErrorMessageBoxSperre: function (sMessage, view) {
			var that = this;
			var bCompact = !!view.$().closest(".sapUiSizeCompact").length,
				confirmMsg = sMessage;
			MessageBox.error(
				confirmMsg, {
					actions: [MessageBox.Action.CLOSE],
					styleClass: bCompact ? "sapUiSizeCompact" : "",
					onClose: function (sAction) {
						that.switchToViewMode();
					}
				}
			);
		},

	});

});