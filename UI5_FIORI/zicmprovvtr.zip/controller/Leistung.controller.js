sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageBox",
	"de/pnw/icm/provisionsvertrag/vtr2/util/Utilities"
], function (Controller, MessageBox, Utilities) {
	"use strict";

	return Controller.extend("de.pnw.icm.provisionsvertrag.vtr2.controller.Leistung", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf de.pnw.icm.provisionsvertrag.vtr2.view.Leistung
		 */
		onInit: function () {
			this.oRouter = this.getOwnerComponent().getRouter();
			this.oModel = this.getOwnerComponent().getModel("appView");
			this.vertragModel = this.getOwnerComponent().getModel("vertrag");
			this.i18n = this.getOwnerComponent().getModel("i18n");

			this.oRouter.getRoute("leistung").attachMatched(this._onObjectMatched, this);
			this.oRouter.getRoute("verguetung").attachMatched(this._onObjectMatched, this);
		},
		/*
			Element im View binden auch für die route verguetung (Konditionen),
			globale Variablen werden auch hier zugewiesen
		*/
		_onObjectMatched: function (oEvent) {
			this._vertragPath = oEvent.getParameter("arguments").vertragPath;
			this._leistungPath = oEvent.getParameter("arguments").leistungPath;
			this.oModel.setProperty("/lastView", "Leistung");
			this.isEditMode = this.oModel.getProperty("/editMode");
				
			if (this.vertragModel.getData("/" + this._leistungPath)) {
				this.getView().bindElement({
					path: "/" + this._leistungPath,
					model: "vertrag"
				});
			} else {
				this.oRouter.navTo("vertrag", {
					layout: sap.f.LayoutType.OneColumn,
					vertragPath: this._vertragPath,
					leistungPath: this._leistungPath
				});
			}

		},

		/*
			Nach dem Anzeigen der Liste von vergütungsarten, wird das erste Element ausgewählt
		*/
		onUpdateFinished: function (oEvent) {
			if (this.byId("verguetungsartenList").getItems().length > 0) {
				this._verguetungPath = this.byId("verguetungsartenList").getItems()[0].getBindingContextPath().substr(1);
				this.onPress();
			}
		},

		beforeNavigateToView: function (sNextLayout, sNextView) {
			if (this.oModel.getProperty("/kondHasChanged")) {
				var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length,
					confirmMsg = Utilities.geti18nText(this.i18n, "confirmMsg", []), //this.getView().getModel("i18n").getResourceBundle().getText("confirmMsg"),
					that = this;
				MessageBox.confirm(
					confirmMsg, {
						actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
						styleClass: bCompact ? "sapUiSizeCompact" : "",
						onClose: function (sAction) {
							if (sAction === "OK") {
								that.navigateToView(sNextLayout, sNextView);
							}
						}
					}
				);
			} else {
				this.navigateToView(sNextLayout, sNextView);
			}
		},

		/*
			 Trigger of Press Action on the list:
			 Setzt den Wert von vZweg im Modell, abhängig davon wird zusätliche Filter für die Konditionen implementiert
			 Beim Wechseln auf Elemente sollte auch geprüft werden, 
			 ob es eine nicht gespeicherte Änderungen auf den Konditionen gibt
		*/
		onPress: function (oEvent) {
			if (oEvent) {
				this._verguetungPath = oEvent.getSource().getBindingContextPath().substr(1);
			}
			this._vZweg = this.byId("vZweg").getText();
			this.oModel.setProperty("/vZweg", this._vZweg);

			if (this.oModel.getProperty("/kondHasChanged")) {
				var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length,
					confirmMsg = Utilities.geti18nText(this.i18n, "confirmMsg", []), //this.getView().getModel("i18n").getResourceBundle().getText("confirmMsg"),
					that = this;
				MessageBox.confirm(
					confirmMsg, {
						actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
						styleClass: bCompact ? "sapUiSizeCompact" : "",
						onClose: function (sAction) {
							if (sAction === "OK") {
								that.navToVerguetung();
							}
						}
					}
				);
			} else {
				this.navToVerguetung();
			}

		},

		/*
			Navigation zu den Konditionen mit dem Pfad
		*/
		navToVerguetung: function () {
			this.oRouter.navTo("verguetung", {
				layout: sap.f.LayoutType.TwoColumnsMidExpanded,
				vertragPath: this._vertragPath,
				leistungPath: this._leistungPath,
				verguetungPath: this._verguetungPath
			});
		},
		/*
			Aktionen wenn es keine Vergüntungsarten zu der LaVv gibt. Wird hier eine TwoColumnsMidExpanded dargestellt
			handleFullScreen: 2te Spalten im Vollbildmodus
			handleExitFullScreen: Vollbildmodus verlassen
			handleClose: 2te Spalte schließen, züruck auf dem Vertrag
			navigateToView: Navigation zu einer Route
		*/
		handleFullScreen: function () {
			var sNextLayout = this.oModel.getProperty("/actionButtonsInfo/midColumn/fullScreen");
			this.navigateToView(sNextLayout, "leistung");
		},

		handleExitFullScreen: function () {
			var sNextLayout = this.oModel.getProperty("/actionButtonsInfo/midColumn/exitFullScreen");
			this.navigateToView(sNextLayout, "leistung");
		},

		handleClose: function () {
			this.navigateToView(sap.f.LayoutType.OneColumn, "vertrag");
		},

		navigateToView: function (sNextLayout, sNextView) {
			this.oRouter.navTo(sNextView, {
				layout: sNextLayout,
				vertragPath: this._vertragPath,
				leistungPath: this._leistungPath
			});
		}

	});

});