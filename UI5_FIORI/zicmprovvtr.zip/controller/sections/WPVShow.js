sap.ui.define([
	"sap/ui/base/ManagedObject",
	"sap/ui/core/Fragment",
	"sap/base/util/isEmptyObject",
	"sap/ui/core/CustomData",
	"de/pnw/icm/provisionsvertrag/vtr2/util/Utilities"
], function (ManagedObject, Fragment, isEmptyObject, CustomData, Utilities) {
	"use strict";
	return ManagedObject.extend("de.pnw.icm.provisionsvertrag.vtr2.controller.sections.WPVShow", {

		constructor: function (oArgs) {
			this.oParentController = oArgs;
			// Subscribe resetReferenzen. Es wird verwenden, wenn der Benutzer vom Bearbeitungsmodus in den Ansichtsmodus wechseln
			this.oParentController.getOwnerComponent().getEventBus().subscribeOnce(
				"WPVShow",
				"reset",
				this.resetWPV,
				this);
		},

		/*
			Abrufen der WPV-Daten eines Vertrages 
			Section WPV ausblenden, wenn Datensatz WPVStamm leer ist
		*/
		setData: function () {
			this._vertragPath = this.oParentController._vertragPath;
			this.oSection = Fragment.byId("idFragmentWPVShow", "idObjectPageSectionWPV");
			this.oAppViewModel = this.oParentController.oModel;
			this.oI18nModel = this.oParentController.i18n;
			var that = this;

			this.oSection.bindElement({
				path: "/" + this._vertragPath,
				parameters: {
					expand: "ProvVertrToWpvStamm,ProvVertrToWpvKond,ProvVertrToWpvStamm/WpvStammToWpvKondAp"
				},
				model: "vertrag",
				events: {
					change: function () {
						var sPath = this.sPath.replace("ProvVertrSet", "WpvStammSet");
						that.oParentController.oCurrentWPVStamm = this.getModel("vertrag").getProperty(sPath);
						sPath = this.sPath.replace("ProvVertrSet", "WpvKondApSet");
						that.oParentController.oCurrentWPVKondAp = this.getModel("vertrag").getProperty(sPath);
						if (that.oParentController.oCurrentWPVStamm) {
							that.oAppViewModel.setProperty("/WPVData", that.oParentController.oCurrentWPVStamm);
							//delete that.oParentController.oCurrentWPVStamm.__metadata;
							that.oParentController.resetBlockLayoutVisualization("WPV", that.oParentController.oMappingModel);
							if (that.oAppViewModel.getProperty("/compareModus")) {
								var oChangesWPVStamm = Utilities.compareJSONObject(that.oAppViewModel.getProperty("/previousWpvStamm"), that.oParentController
									.oCurrentWPVStamm);
								that.oParentController.visualizeBlockLayoutChanges("WPV", oChangesWPVStamm);
							}
						}
						if (that.oParentController.oCurrentWPVKondAp) {
							//delete that.oParentController.oCurrentWPVStamm.__metadata;
							that.oParentController.resetBlockLayoutVisualization("WPV", that.oParentController.oMappingModel);
							if (that.oAppViewModel.getProperty("/compareModus")) {
								var oChangesWPVKondAp = Utilities.compareJSONObject(that.oAppViewModel.getProperty("/previousWpvKondAp"), that.oParentController
									.oCurrentWPVKondAp);
								that.oParentController.visualizeBlockLayoutChanges("WPV", oChangesWPVKondAp);
							}
						}
						
						
					}
				}
			});
		},
		
		onAfterClose: function (oEvent) {
			oEvent.getSource().destroy();
		},
		/*
			- die geänderten Zeilen in der Liste raussuchen
			- und die entsprechenden Spalten (key, value) mit einem Tooltip und ausgewählter Farbe in der View markieren.
		*/
		visualizeWPVChanges: function (aItem, sWpType) {
			var previousWpvKond = this.oAppViewModel.getProperty("/previousWpvKond"),
				bCompareModus = this.oAppViewModel.getProperty("/compareModus"),
				oCurrentWpvKey = {};
			// currentLavv holen und einem JSON Object mit dem Binding Context bilden
			aItem.forEach(function (oItem) {
				var sPath = oItem.getBindingContextPath(),
					oData = oItem.getModel("vertrag").getProperty(sPath),
					oCell = oItem.getCells()[1];
				if (oData && oCell) {
					/*
					var uri = oData.__metadata.uri,
						key = uri.split("WpvKondSet")[1],
						*/
					var sArt = oData.Art,
						sSparte = oData.Sparte,
						sVerguetungsart = oData.Verguetungsart;
					var key = sArt + sSparte + sVerguetungsart,
						currentVerguetungssatz = oData.Verguetungssatz;
					// Vorherige Markierung löschen
					oCell.setValueState("None");
					oCell.destroyTooltip();
					oItem.destroyCustomData();
					// Beide Datensätze vergleichen: wenn compareModus aktiv
					if (bCompareModus && key && previousWpvKond) {
						if (previousWpvKond[key]) {
							// Datensatz in der vorherigen Version vorhanden
							var previousVerguetungssatz = previousWpvKond[key].Verguetungssatz;
							if (previousVerguetungssatz !== currentVerguetungssatz) {
								oCell.setValueState("Indication03");
								if (previousVerguetungssatz === "") {
									previousVerguetungssatz = Utilities.geti18nText(this.oI18nModel, "noValue", []);
								}
								oCell.setTooltip(previousVerguetungssatz);
							}
						} else {
							// Datensatz in der vorherigen Version nicht vorhanden
							// hinzugefügte Zeilen in der View markieren: wenn compareModus aktiv
							var customData = new CustomData({
								key: "compare",
								value: "orange",
								writeToDom: true
							});
							oItem.addCustomData(customData);
						}
						oCurrentWpvKey[key] = key;
					}
				}
			});
			var iDeletedWpvKond = 0,
				txt = "",
				isWpvKondMsg = false;
			// gelöschte LaVv rechnen
			if (bCompareModus) {
				var oKond = {};
				Object.keys(previousWpvKond || []).forEach(function (key) {
					if (key.endsWith(sWpType)) {
						oKond[key] = previousWpvKond[key];
					}
				});
				iDeletedWpvKond = Utilities.getTableDifference(oKond, oCurrentWpvKey).deleted || 0;
				if (iDeletedWpvKond !== 0) {
					isWpvKondMsg = true;
				}
			}
			// Text anzeigen
			if (iDeletedWpvKond === 1) {
				txt = Utilities.geti18nText(this.oI18nModel, "laVvMsg1", [iDeletedWpvKond]);
			} else if (iDeletedWpvKond > 1) {
				txt = Utilities.geti18nText(this.oI18nModel, "laVvMsg2", [iDeletedWpvKond]);
			}
			this.oAppViewModel.setProperty("/WpvKondMsg" + sWpType, txt);
			this.oAppViewModel.setProperty("/isWpvKondMsg" + sWpType, isWpvKondMsg);
		},

		onAPUpdated: function (oEvent) {
			var aItem = oEvent.getSource().getItems();
			this.visualizeWPVChanges(aItem, "AP");
		},

		onVPUpdated: function (oEvent) {
			var aItem = oEvent.getSource().getItems();
			this.visualizeWPVChanges(aItem, "VP");
		},

		resetWPV: function () {
			//ProvVertrToWpvStamm,ProvVertrToWpvKond,ProvVertrToWpvStamm/WpvStammToWpvKondAp
			var that = this;
			Utilities.promiseODataRead(this.oParentController.getOwnerComponent().getModel("vertrag"), this.oParentController._vertragPath +
				"/ProvVertrToWpvStamm", {}, []).then(
				function (oData) { //resolve
					that.vertragModel = that.oParentController.getOwnerComponent().getModel("vertrag");
					if (that.vertragModel && oData) {
						that.vertragModel.setProperty("/" + that.oParentController._vertragPath + "/ProvVertrToWpvStamm/" + "Kreisnummer", oData.Kreisnummer);
						that.vertragModel.setProperty("/" + that.oParentController._vertragPath + "/ProvVertrToWpvStamm/" + "Regionalzentrum", oData.Regionalzentrum);
						that.vertragModel.setProperty("/" + that.oParentController._vertragPath + "/ProvVertrToWpvStamm/" + "OrgaLbs", oData.OrgaLbs);
						that.vertragModel.setProperty("/" + that.oParentController._vertragPath + "/ProvVertrToWpvStamm/" + "Statusvertrt", oData.Statusvertrt);
						that.vertragModel.setProperty("/" + that.oParentController._vertragPath + "/ProvVertrToWpvStamm/" + "ZZahlart", oData.ZZahlart);
						that.vertragModel.setProperty("/" + that.oParentController._vertragPath + "/ProvVertrToWpvStamm/" + "ZZahlartt", oData.ZZahlartt);
						that.vertragModel.setProperty("/" + that.oParentController._vertragPath + "/ProvVertrToWpvStamm/" + "Vertyp", oData.Vertyp);
						that.vertragModel.setProperty("/" + that.oParentController._vertragPath + "/ProvVertrToWpvStamm/" + "Vertypt", oData.Vertypt);
						that.vertragModel.setProperty("/" + that.oParentController._vertragPath + "/ProvVertrToWpvStamm/" + "Bestandsbildt", oData.Bestandsbildt);
						that.vertragModel.setProperty("/" + that.oParentController._vertragPath + "/ProvVertrToWpvStamm/" + "Sofo", oData.Sofo);
						that.vertragModel.setProperty("/" + that.oParentController._vertragPath + "/ProvVertrToWpvStamm/" + "Sofot", oData.Sofot);
						that.vertragModel.setProperty("/" + that.oParentController._vertragPath + "/ProvVertrToWpvStamm/" + "KzDeckung", oData.KzDeckung);
						that.vertragModel.setProperty("/" + that.oParentController._vertragPath + "/ProvVertrToWpvStamm/" + "KzDeckungt", oData.KzDeckungt);
					}
				}.bind(this));

			Utilities.promiseODataRead(this.oParentController.getOwnerComponent().getModel("vertrag"), this.oParentController._vertragPath +
				"/ProvVertrToWpvStamm/WpvStammToWpvKondAp/", {}, []).then(
				function (oData) { //resolve
					that.vertragModel = that.oParentController.getOwnerComponent().getModel("vertrag");
					if (that.vertragModel && oData) {
						that.vertragModel.setProperty("/" + that.oParentController._vertragPath + "/ProvVertrToWpvStamm/WpvStammToWpvKondAp/" +
							"ZProvShukt", oData.ZProvShukt);
						that.vertragModel.setProperty("/" + that.oParentController._vertragPath + "/ProvVertrToWpvStamm/WpvStammToWpvKondAp/" +
							"ZProvShuk", oData.ZProvShuk);
						that.vertragModel.setProperty("/" + that.oParentController._vertragPath + "/ProvVertrToWpvStamm/WpvStammToWpvKondAp/" +
							"ApSacht", oData.ApSacht);
						that.vertragModel.setProperty("/" + that.oParentController._vertragPath + "/ProvVertrToWpvStamm/WpvStammToWpvKondAp/" +
							"ApSach", oData.ApSach);
						that.vertragModel.setProperty("/" + that.oParentController._vertragPath + "/ProvVertrToWpvStamm/WpvStammToWpvKondAp/" +
							"ZProvLebt", oData.ZProvLebt);
						that.vertragModel.setProperty("/" + that.oParentController._vertragPath + "/ProvVertrToWpvStamm/WpvStammToWpvKondAp/" +
							"ZProvLeb", oData.ZProvLeb);
						that.vertragModel.setProperty("/" + that.oParentController._vertragPath + "/ProvVertrToWpvStamm/WpvStammToWpvKondAp/" +
							"ApHaftt", oData.ApHaftt);
						that.vertragModel.setProperty("/" + that.oParentController._vertragPath + "/ProvVertrToWpvStamm/WpvStammToWpvKondAp/" +
							"ApHaft", oData.ApHaft);
					}

				}.bind(this));

			Utilities.promiseODataRead(this.oParentController.getOwnerComponent().getModel("vertrag"), this.oParentController._vertragPath +
				"/ProvVertrToWpvKond", {}, []).then(
				function (oData) { //resolve
					if (oData.results) {
						that.vertragModel = that.oParentController.getOwnerComponent().getModel("vertrag");
						if (that.vertragModel) {
							var konds = that.vertragModel.getProperty("/" + that.oParentController._vertragPath + "/ProvVertrToWpvKond");
							if (konds) {
								konds.forEach(function (oEntity, i) {
									that.vertragModel.setProperty("/" + oEntity + "/Verguetungssatz", oData.results[i].Verguetungssatz);
								});
							}
						}
					}
				}.bind(this));
		}
	});
});