sap.ui.define([
	"sap/ui/base/ManagedObject",
	"sap/ui/core/Fragment",
	"sap/base/util/isEmptyObject",
	"sap/ui/core/CustomData",
	"de/pnw/icm/provisionsvertrag/vtr/util/Utilities"
], function (ManagedObject, Fragment, isEmptyObject, CustomData, Utilities) {
	"use strict";
	return ManagedObject.extend("de.pnw.icm.provisionsvertrag.vtr.controller.sections.WPVShow", {

		constructor: function (oArgs) {
			this.oParentController = oArgs;
		},

		/*
			Abrufen der WPV-Daten eines Vertrages 
			Section WPV ausblenden, wenn Datensatz WPVStamm leer ist
		*/
		setData: function () {
			this._vertragPath = this.oParentController._vertragPath;
			this.oSection = Fragment.byId("idFragmentWPVShow", "idObjectPageSectionWPV");
			this.oAppViewModel = this.oParentController.oModel;
			this.oI18nModel = this.oParentController.i18n;
			var that = this;
			this.oSection.bindElement({
				path: "/" + this._vertragPath,
				parameters: {
					expand: "ProvVertrToWpvStamm,ProvVertrToWpvKond,ProvVertrToWpvStamm/WpvStammToWpvKondAp"
				},
				model: "vertrag",
				events: {
					change: function () {
						var sPath = this.sPath.replace("ProvVertrSet", "WpvStammSet");
						that.oParentController.oCurrentWPVStamm = this.getModel("vertrag").getProperty(sPath);
						if (that.oParentController.oCurrentWPVStamm) {
							//delete that.oParentController.oCurrentWPVStamm.__metadata;
							that.oParentController.resetBlockLayoutVisualization("WPV", that.oParentController.oMappingModel);
							if (that.oAppViewModel.getProperty("/compareModus")) {
								var oChangesWPVStamm = Utilities.compareJSONObject(that.oAppViewModel.getProperty("/previousWpvStamm"), that.oParentController
									.oCurrentWPVStamm);
								that.oParentController.visualizeBlockLayoutChanges("WPV", oChangesWPVStamm);
							}
						}
					}
				}
			});
		},
		/*
			- die geänderten Zeilen in der Liste raussuchen
			- und die entsprechenden Spalten (key, value) mit einem Tooltip und ausgewählter Farbe in der View markieren.
		*/
		visualizeWPVChanges: function (aItem, sWpType) {
			var previousWpvKond = this.oAppViewModel.getProperty("/previousWpvKond"),
				bCompareModus = this.oAppViewModel.getProperty("/compareModus"),
				oCurrentWpvKey = {};
			// currentLavv holen und einem JSON Object mit dem Binding Context bilden
			aItem.forEach(function (oItem) {
				var sPath = oItem.getBindingContextPath(),
					oData = oItem.getModel("vertrag").getProperty(sPath),
					oCell = oItem.getCells()[1];
				if (oData && oCell) {
					/*
					var uri = oData.__metadata.uri,
						key = uri.split("WpvKondSet")[1],
						*/
					var sArt = oData.Art,
						sSparte = oData.Sparte,
						sVerguetungsart = oData.Verguetungsart;
					var key = sArt + sSparte + sVerguetungsart,
						currentVerguetungssatz = oData.Verguetungssatz;
					// Vorherige Markierung löschen
					oCell.setValueState("None");
					oCell.destroyTooltip();
					oItem.destroyCustomData();
					// Beide Datensätze vergleichen: wenn compareModus aktiv
					if (bCompareModus && key && previousWpvKond) {
						if (previousWpvKond[key]) {
							// Datensatz in der vorherigen Version vorhanden
							var previousVerguetungssatz = previousWpvKond[key].Verguetungssatz;
							if (previousVerguetungssatz !== currentVerguetungssatz) {
								oCell.setValueState("Indication03");
								if (previousVerguetungssatz === "") {
									previousVerguetungssatz = Utilities.geti18nText(this.oI18nModel, "noValue", []);
								}
								oCell.setTooltip(previousVerguetungssatz);
							}
						} else {
							// Datensatz in der vorherigen Version nicht vorhanden
							// hinzugefügte Zeilen in der View markieren: wenn compareModus aktiv
							var customData = new CustomData({
								key: "compare",
								value: "orange",
								writeToDom: true
							});
							oItem.addCustomData(customData);
						}
						oCurrentWpvKey[key] = key;
					}
				}
			});
			var iDeletedWpvKond = 0,
				txt = "",
				isWpvKondMsg = false;
			// gelöschte LaVv rechnen
			if (bCompareModus) {
				var oKond = {};
				Object.keys(previousWpvKond || []).forEach(function (key) {
					if (key.endsWith(sWpType)) {
						oKond[key] = previousWpvKond[key];
					}
				});
				iDeletedWpvKond = Utilities.getTableDifference(oKond, oCurrentWpvKey).deleted || 0;
				if (iDeletedWpvKond !== 0) {
					isWpvKondMsg = true;
				}
			}
			// Text anzeigen
			if (iDeletedWpvKond === 1) {
				txt = Utilities.geti18nText(this.oI18nModel, "laVvMsg1", [iDeletedWpvKond]);
			} else if (iDeletedWpvKond > 1) {
				txt = Utilities.geti18nText(this.oI18nModel, "laVvMsg2", [iDeletedWpvKond]);
			}
			this.oAppViewModel.setProperty("/WpvKondMsg" + sWpType, txt);
			this.oAppViewModel.setProperty("/isWpvKondMsg" + sWpType, isWpvKondMsg);
		},

		onAPUpdated: function (oEvent) {
			var aItem = oEvent.getSource().getItems();
			this.visualizeWPVChanges(aItem, "AP");
		},

		onVPUpdated: function (oEvent) {
			var aItem = oEvent.getSource().getItems();
			this.visualizeWPVChanges(aItem, "VP");
		}
	});
});