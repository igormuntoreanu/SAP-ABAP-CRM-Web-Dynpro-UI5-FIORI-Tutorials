sap.ui.define([
	"sap/ui/base/ManagedObject",
	"sap/ui/core/Fragment",
	"de/pnw/icm/provisionsvertrag/vtr2/util/Utilities",
	"de/pnw/icm/provisionsvertrag/vtr2/model/formatter",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	'sap/ui/core/library'
], function (ManagedObject, Fragment, Utilities, formatter, JSONModel, Filter, FilterOperator, coreLibrary) {
	"use strict";

	var ValueState = coreLibrary.ValueState;

	return ManagedObject.extend("de.pnw.icm.provisionsvertrag.vtr2.controller.sections.AuszahlungEdit", {
		formatter: formatter,

		constructor: function (oArgs) {
			this.oParentController = oArgs;
		},

		/*
			Abrufen der Auszahlung-Daten eines Vertrages 
		*/

		setData: function () {
			this.oI18nModel = this.oParentController.i18n;
			this._vertragPath = this.oParentController._vertragPath;
			this._suchePath = this.oParentController._suchePath;
			if (this.oParentController._sperrenPayeeIscd) {
				this._sperrenVersnr = this.oParentController._sperrenPayeeIscd.substr(1);
				this._sperrenKnz = this.oParentController._sperrenPayeeIscd.substr(0, 1);
			}
			var oSperrenModel = this.oParentController.oSperrenModel;
			this.oSection = Fragment.byId("idFragmentAuszahlungEdit", "AuszahlungSectionEdit");
			if (this.oSection) {
				this.oSection.bindElement({
					path: "/" + this._vertragPath,
					parameters: {
						expand: "ProvVertrToAuszahlungBank,ProvVertrToAuszahlung"
					},
					model: "vertrag",
					events: {
						change: function () {}
					}
				});
			}
			var oTableModelVI = new JSONModel(),
				oTableVI = Fragment.byId("idFragmentAuszahlungEdit", "idTableSperrinfoVIEdit");
			if (oTableVI) {
				oTableVI.setModel(oTableModelVI);
				//Busy Indicator öffnen
				Utilities._showBusyDialog();
				// Filter um SperrenSet auszulesen 
				var aFilter = [];
				aFilter.push(
					new Filter({
						path: "Objekttyp",
						operator: "EQ",
						value1: "VM"
					})
				);
				if (this._sperrenVersnr) {
					aFilter.push(
						new Filter({
							path: "Versnr",
							operator: "EQ",
							value1: this._sperrenVersnr
						})
					);
				}
				if (this._sperrenKnz) {
					aFilter.push(
						new Filter({
							path: "SpartenKz",
							operator: "EQ",
							value1: this._sperrenKnz
						})
					);
				}
				// Für den Fall, dass die Nummer nicht geliefert wird, darf keine Anfrage an CD gehen
				if (this._sperrenVersnr !== "") {
					Utilities.promiseODataRead(oSperrenModel, "SperrenSet", {}, aFilter).then(
						function (oData) { //resolve
							var sperrenModel = new JSONModel();
							// TODO: Hier ggf Map verwenden, wenn es zu Problemen kommt
							var count = [];
							oData.results.forEach(function (item, i) {
								delete item.__metadata;
								if (item.Proid === "09") { // Prüfe auf Buchungssperre
									if (!count.includes(item.Lockr)) { // Prüfe ob gleichartiges Element bereits in Tabelle
										count.push(item.Lockr);
										count.push(item.Fdate);
										sperrenModel.oData[i] = item;
									} else if (count[count.indexOf(item.Lockr) + 1] > item.Fdate) { // Prüfe ob dieses item ggf ein äteres Fdate hat als das in der Tabelle
										sperrenModel.oData[count.indexOf(item.Lockr) / 2] = item;
									}
								}
							});
							this._sperrenModel = sperrenModel;
							oTableVI.setModel(this._sperrenModel);

							Fragment.byId("idBusyFragment", "idBusyDialog").close();
						}.bind(this),
						function (oError) { //reject
							//Busy Indicator schließen
							Fragment.byId("idBusyFragment", "idBusyDialog").close();
							var sErrorMsg = (jQuery.parseXML(oError.responseText).querySelector("message") || "").textContent + " (VM - AuszahlungEdit.js: setData())";
							Utilities.displayErrorMessageBox(sErrorMsg, this.oParentController.getView());
						}.bind(this)
					);
				}
			}
			var oHintText = Fragment.byId("idFragmentAuszahlungEdit", "idFormattedTextAuszahlungEdit");
			if (oHintText) {
				oHintText.setHtmlText("<em style=\"color:rgb(102, 102, 102);\">" + Utilities.geti18nText(this.oParentController.i18n,
						"hintCurrentData", []) +
					"</em>");
			}
		},

		onAfterClose: function (oEvent) {
			oEvent.getSource().destroy();
		},

		onAbrklassifChange: function (oEvent) {
			this.oParentController.oModel.setProperty("/auszahlungHasChanged", true);
			var sId = oEvent.getSource().getId();
			if (sId.includes("ComboBox")) {
				this._checkEntryValue(oEvent);
				return;
			}
		},

		_checkEntryValue: function (oEvent) {
			var oValidatedComboBox = oEvent.getSource(),
				sSelectedKey = oValidatedComboBox.getSelectedKey(),
				sValue = oValidatedComboBox.getValue();

			if (!sSelectedKey && sValue) {
				oValidatedComboBox.setValueState(ValueState.Error);
				oValidatedComboBox.setValueStateText("Bitte geben Sie einen gültigen Eintrag ein");
			} else {
				oValidatedComboBox.setValueState(ValueState.None);
			}
		}
	});
});