sap.ui.define([
	"sap/ui/base/ManagedObject",
	"sap/ui/core/Fragment",
	"de/pnw/icm/provisionsvertrag/vtr/util/Utilities",
	"de/pnw/icm/provisionsvertrag/vtr/model/formatter"
], function (ManagedObject, Fragment, Utilities, formatter) {
	"use strict";
	return ManagedObject.extend("de.pnw.icm.provisionsvertrag.vtr.controller.sections.AbrechnungShow", {
		formatter: formatter,
		
		constructor: function (oArgs) {
			this.oParentController = oArgs;
		},

		/*
			Abrufen der Abrechnungsdaten eines Vertrages 
		*/
		setData: function () {
			this._vertragPath = this.oParentController._vertragPath;
			this.oSection = Fragment.byId("idFragmentAbrechnungShow", "AbrechnungSection");
			this.oAppViewModel = this.oParentController.oModel;
			var that = this;
			this.oSection.bindElement({
				path: "/" + this.oParentController._vertragPath,
				parameters: {
					expand: "ProvVertrToAbrechnung"
				},
				model: "vertrag",
				events: {
					change: function (oEvent) {
						var sPath = this.sPath.replace("ProvVertrSet", "AbrechnungSet");
						that.oParentController.oCurrentVertragAbrechnung = this.getModel("vertrag").getProperty(sPath);
						if (that.oParentController.oCurrentVertragAbrechnung) {
							delete that.oParentController.oCurrentVertragAbrechnung.__metadata;
							that.oParentController.resetBlockLayoutVisualization("Abrechnung", that.oParentController.oMappingModel);
							if (that.oAppViewModel.getProperty("/compareModus")) {
								var oChangesAbrechnung = Utilities.compareJSONObject(that.oAppViewModel.getProperty("/previousAbrechnung"), that.oParentController
									.oCurrentVertragAbrechnung);
								that.oParentController.visualizeBlockLayoutChanges("Abrechnung", oChangesAbrechnung);
							}
						}
					}
				}
			});
		}

	});
});