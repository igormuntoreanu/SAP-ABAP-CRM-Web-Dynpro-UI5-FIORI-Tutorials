sap.ui.define([
	"sap/ui/base/ManagedObject",
	"de/pnw/icm/provisionsvertrag/vtr2/util/Utilities",
	"de/pnw/icm/provisionsvertrag/vtr2/model/formatter",
	"sap/ui/core/Fragment"
], function (ManagedObject, Utilities, formatter, Fragment) {
	"use strict";
	return ManagedObject.extend("de.pnw.icm.provisionsvertrag.vtr2.controller.sections.AllgemeinesShow", {
		formatter: formatter,

		constructor: function (oArgs) {
			this.oParentController = oArgs;
			// Subscribe resetAllgemeines. Es wird verwenden, wenn der Benutzer vom Bearbeitungsmodus in den Ansichtsmodus wechseln
			this.oParentController.getOwnerComponent().getEventBus().subscribeOnce(
				"AllgemeinesShow",
				"reset",
				this.resetAllgemeines,
				this);
		},

		//keine Funktion aber wird benötigt um über alle setData iterieren zu können
		setData: function () {
			this._vertragPath = this.oParentController._vertragPath;
			this.oSection = Fragment.byId("idFragmentAllgemeinesShow", "AllgemeinesSection");
			this.oAppViewModel = this.oParentController.oModel;
			this.oI18nModel = this.oParentController.i18n;
			this.oSection.bindElement({
				path: "/" + this._vertragPath,
				parameters: {
					expand: "ProvVertrToPartner"
				},
				model: "vertrag",
				events: {
					change: function () {}
				}
			});
		},

		visualizeBlockLayoutChanges: function () {
			this.oAppViewModel = this.oParentController.oModel;
			this.oParentController.resetBlockLayoutVisualization("Allgemeines", this.oParentController.oMappingModel);
			if (this.oAppViewModel.getProperty("/compareModus")) {
				var oChangesAllgemeines = Utilities.compareJSONObject(this.oAppViewModel.getProperty("/previousVertrag"), this.oParentController.oVertragData);
				this.oParentController.visualizeBlockLayoutChanges("Allgemeines", oChangesAllgemeines);
			}
		},

		resetAllgemeines: function () {
			var that = this;
			Utilities.promiseODataRead(this.oParentController.getOwnerComponent().getModel("vertrag"), this.oParentController._vertragPath, {}, [])
				.then(
					function (oData) { //resolve
						that.vertragModel = that.oParentController.getOwnerComponent().getModel("vertrag");
						if (that.vertragModel) {
							that.vertragModel.setProperty("/" + this._vertragPath + "/" + "Vertriebsschiene", oData.Vertriebsschiene);
							that.vertragModel.setProperty("/" + this._vertragPath + "/" + "IntTitle", oData.IntTitle);
							that.vertragModel.setProperty("/" + this._vertragPath + "/" + "IntTitlet", oData.IntTitlet);
							that.vertragModel.setProperty("/" + this._vertragPath + "/" + "ZAgenturknz", oData.ZAgenturknz);
							that.vertragModel.setProperty("/" + this._vertragPath + "/" + "ZAgenturknzt", oData.ZAgenturknzt);
							that.vertragModel.setProperty("/" + this._vertragPath + "/" + "ZVertriebskennziffer", oData.ZVertriebskennziffer);
							that.vertragModel.setProperty("/" + this._vertragPath + "/" + "ZVertragsmodell", oData.ZVertragsmodell);
							that.vertragModel.setProperty("/" + this._vertragPath + "/" + "ZVertragsmodellt", oData.ZVertragsmodellt);
							that.vertragModel.setProperty("/" + this._vertragPath + "/" + "ZVertrieb", oData.ZVertrieb);
							that.vertragModel.setProperty("/" + this._vertragPath + "/" + "ZVertriebt", oData.ZVertriebt);
							that.vertragModel.setProperty("/" + this._vertragPath + "/" + "ZBenutzer", oData.ZBenutzer);
							that.vertragModel.setProperty("/" + this._vertragPath + "/" + "Notizen", oData.Notizen);
							that.vertragModel.setProperty("/" + this._vertragPath + "/" + "Herkunft", oData.Herkunft);
							that.vertragModel.setProperty("/" + this._vertragPath + "/" + "Herkunftt", oData.Herkunftt);
							that.vertragModel.setProperty("/" + this._vertragPath + "/" + "ZGebiet", oData.ZGebiet);
							that.vertragModel.setProperty("/" + this._vertragPath + "/" + "ZGebiett", oData.ZGebiett);
							that.vertragModel.setProperty("/" + this._vertragPath + "/" + "ZVermvertMit", oData.ZVermvertMit);
							that.vertragModel.setProperty("/" + this._vertragPath + "/" + "ZVermvertMitt", oData.ZVermvertMitt);
							that.vertragModel.setProperty("/" + this._vertragPath + "/" + "ZMarkenauftritt", oData.ZMarkenauftritt);
							that.vertragModel.setProperty("/" + this._vertragPath + "/" + "ZMarkenauftrittt", oData.ZMarkenauftrittt);
							that.vertragModel.setProperty("/" + this._vertragPath + "/" + "ZSchadenvollmacht", oData.ZSchadenvollmacht);
							that.vertragModel.setProperty("/" + this._vertragPath + "/" + "ZSchadenvollmachtt", oData.ZSchadenvollmachtt);
							that.vertragModel.setProperty("/" + this._vertragPath + "/" + "ZAktualisierung", oData.ZAktualisierung);
							that.vertragModel.setProperty("/" + this._vertragPath + "/" + "ZAktualisierungt", oData.ZAktualisierungt);
							that.vertragModel.setProperty("/" + this._vertragPath + "/" + "CtrtbuBdate", oData.CtrtbuBdate);
							that.vertragModel.setProperty("/" + this._vertragPath + "/" + "EntrDate", oData.EntrDate);
							that.vertragModel.setProperty("/" + this._vertragPath + "/" + "LeavDate", oData.LeavDate);
							that.vertragModel.setProperty("/" + this._vertragPath + "/" + "Lvrsidt", oData.Lvrsidt);
							that.vertragModel.setProperty("/" + this._vertragPath + "/" + "CtrtbuEdate", oData.CtrtbuEdate);
							that.vertragModel.setProperty("/" + this._vertragPath + "/" + "ZAid", oData.ZAid);
							that.vertragModel.setProperty("/" + this._vertragPath + "/" + "ZBic", oData.ZBic);
							that.vertragModel.setProperty("/" + this._vertragPath + "/" + "ZFinanzit", oData.ZFinanzit);
							that.vertragModel.setProperty("/" + this._vertragPath + "/" + "ZInstitut", oData.ZInstitut);
							that.vertragModel.setProperty("/" + this._vertragPath + "/" + "ZSkAgT", oData.ZSkAgT);
							that.vertragModel.setProperty("/" + this._vertragPath + "/" + "ZSiebelnutzer", oData.ZSiebelnutzer);
							that.vertragModel.setProperty("/" + this._vertragPath + "/" + "ZSiebelSchadenbearb", oData.ZSiebelSchadenbearb);
						}
					}.bind(this));
		}
	});
});