sap.ui.define([
	"sap/ui/base/ManagedObject",
	"de/pnw/icm/provisionsvertrag/vtr/util/Utilities",
	"de/pnw/icm/provisionsvertrag/vtr/model/formatter",
	"sap/ui/core/Fragment"
], function (ManagedObject, Utilities, formatter, Fragment) {
	"use strict";
	return ManagedObject.extend("de.pnw.icm.provisionsvertrag.vtr.controller.sections.AllgemeinesShow", {
		formatter: formatter,

		constructor: function (oArgs) {
			this.oParentController = oArgs;
		},

		//keine Funktion aber wird benötigt um über alle setData iterieren zu können
		setData: function () {
			//this.oI18nModel = this.oParentController.i18n;
			
			//var allgemeinTitle = Fragment.byId("idFragmentAllgemeinesShow", "titleOfAllgemeines");
			//allgemeinTitle.setHtmlText("<h3 style=\"color:rgb(0, 0, 0);\">" + "<u>" + Utilities.geti18nText(this.oI18nModel, "ALLGEMEINES", []) + "</u>" + "</h3>");
		},

		visualizeBlockLayoutChanges: function () {
			this.oAppViewModel = this.oParentController.oModel;
			this.oParentController.resetBlockLayoutVisualization("Allgemeines", this.oParentController.oMappingModel);
			if (this.oAppViewModel.getProperty("/compareModus")) {
				var oChangesAllgemeines = Utilities.compareJSONObject(this.oAppViewModel.getProperty("/previousVertrag"), this.oParentController.oVertragData);
				this.oParentController.visualizeBlockLayoutChanges("Allgemeines", oChangesAllgemeines);
			}
		}

	});
});