sap.ui.define([
	"sap/ui/base/ManagedObject",
	"sap/ui/core/Fragment",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageBox",
	"de/pnw/icm/provisionsvertrag/vtr/util/Utilities",
	"sap/ui/core/CustomData",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/MessageToast"
], function (ManagedObject, Fragment, JSONModel, MessageBox, Utilities, CustomData, Filter, FilterOperator, MessageToast) {
	"use strict";
	return ManagedObject.extend("de.pnw.icm.provisionsvertrag.vtr.controller.sections.LavvShow", {

		constructor: function (oArgs) {
			this.oParentController = oArgs;

		},

		/*
			Abrufen der Lavv Daten eines Vertrages 
		*/
		setData: function () {
			var sPath = this.oParentController._vertragPath + "/ToLavv";
			this.oVertragModel = this.oParentController.vertragModel;
			this.oAppViewModel = this.oParentController.oModel;
			this.oVertragGlobal = this.oParentController.oVertragGlobal;
			this.oI18nModel = this.oParentController.i18n;
			this.oSection = Fragment.byId("idFragmentLavvShow", "LavvSection");

			this.lavvModel = new JSONModel();
			/*
				Überprüfen ob es eine bestehende laVv in app view gibt, sonst OData Abruf
			*/
			var oOldLavv = this.oAppViewModel.getProperty("/lavvData");

			if (oOldLavv !== null) {
				this.lavvModel.setData(oOldLavv);
				Fragment.byId("idFragmentLavvShow", "lavvList").setModel(this.lavvModel);
			} else {
				//Busy Indicator öffnen
				Utilities._showBusyDialog();
				Utilities.promiseODataRead(this.oVertragModel, sPath, {}, []).then(
					function (oData) { //resolve
						this.lavvModel.setData(oData.results);
						this.oAppViewModel.setProperty("/lavvData", oData.results);
						Fragment.byId("idFragmentLavvShow", "lavvList").setModel(this.lavvModel);
						Fragment.byId("idBusyFragment", "idBusyDialog").close();
					}.bind(this),
					function (oError) { //reject
						//Busy Indicator schließen
						Fragment.byId("idBusyFragment", "idBusyDialog").close();
						var sErrorMsg = (jQuery.parseXML(oError.responseText).querySelector("message") || "").textContent;
						Utilities.displayErrorMessageBox(sErrorMsg, this.oParentController.getView());
					}.bind(this)
				);
			}
			
			//var lavvTitle = Fragment.byId("idFragmentLavvShow", "titleOfLavv");
			//lavvTitle.setHtmlText("<h3 style=\"color:rgb(0, 0, 0);\">" + "<u>" + Utilities.geti18nText(this.oI18nModel, "LAVVshort", [])+"</u>" + "</h3>");
			
		},

		onUpdated: function (oEvent) {
			var aItem = oEvent.getSource().getItems(),
				previousLavv = this.oAppViewModel.getProperty("/previousLavv"),
				bCompareModus = this.oAppViewModel.getProperty("/compareModus"),
				oCurrentLavvKey = {};

			// currentLavv holen und einem JSON Object mit dem Binding Context bilden
			aItem.forEach(function (oItem) {
				var sPath = oItem.getBindingContextPath().substr(1),
					oData = this.lavvModel.getData()[sPath];
				if (oData) {
					var key = oData.BucagrId;
					// Vorherige Custom Data löschen
					oItem.getCustomData().forEach(function (oCustumData) {
						if (oCustumData.getKey() === "compare") {
							oCustumData.destroy();
						}
					});
					if (key) {
						// Beide Datensätze vergleichen: wenn compareModus aktiv
						if (bCompareModus && previousLavv) {
							if (!(key in previousLavv)) {
								// hinzugefügte Zeilen in der View markieren: wenn compareModus aktiv
								var customData = new CustomData({
									key: "compare",
									value: "orange",
									writeToDom: true
								});
								oItem.addCustomData(customData);
							}
							oCurrentLavvKey[key] = key;
						}
					}

				}
			}.bind(this));
			var iDeletedLaVv = 0,
				txt = "",
				isLaVvMsg = false;
			// gelöschte LaVv rechnen
			if (bCompareModus) {
				iDeletedLaVv = Utilities.getTableDifference(previousLavv, oCurrentLavvKey).deleted || 0;
				if (iDeletedLaVv !== 0) {
					isLaVvMsg = true;
				}
			}
			// Text anzeigen
			if (iDeletedLaVv === 1) {
				txt = Utilities.geti18nText(this.oI18nModel, "laVvMsg1", [iDeletedLaVv]);
			} else if (iDeletedLaVv > 1) {
				txt = Utilities.geti18nText(this.oI18nModel, "laVvMsg2", [iDeletedLaVv]);
			}
			this.oAppViewModel.setProperty("/laVvMsg", txt);
			this.oAppViewModel.setProperty("/isLaVvMsg", isLaVvMsg);
		},

		/*
			Öffnet den Dialog zum Hinzufügen der LaVvn an den Provisionsvertrag
		*/
		addLaVv: function () {
			if (!this.oParentController.byId("addLaVvDialog")) {
				Fragment.load({
					id: this.oParentController.getView().getId(),
					name: "de.pnw.icm.provisionsvertrag.vtr.view.fragment.addLaVvDialog",
					controller: this
				}).then(function (oDialog) {
					oDialog.setModel(this.oParentController.getView().getModel("localVertrag"));
					this.oParentController.getView().addDependent(oDialog);
					oDialog.getBinding("items").filter([]);
					oDialog.open();
				}.bind(this));
			} else {
				this.oParentController.byId("addLaVvDialog").getBinding("items").filter([]);
				this.oParentController.byId("addLaVvDialog").open();
			}
		},

		/*
			Meldungsfeld zur Bestätigung der Aktion, bevor die Änderungen zurückgesetzt werden	
		*/
		beforeResetLaVv: function () {
			if (this.oAppViewModel.getProperty("/lavvHasChanged")) {
				var bCompact = !!this.oParentController.getView().$().closest(".sapUiSizeCompact").length,
					confirmMsg = Utilities.geti18nText(this.oI18nModel, "confirmResetMsg", []), //this.geti18nText("confirmResetMsg"),
					that = this;
				MessageBox.confirm(
					confirmMsg, {
						actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
						styleClass: bCompact ? "sapUiSizeCompact" : "",
						onClose: function (sAction) {
							if (sAction === "OK") {
								that.resetLaVv();
							}
						}
					}
				);
			} else {
				this.resetLaVv();
			}
		},

		/* 
			Alle im Bearbeitungsmodus dürchgesführten Änderungen zurücksetzen.
			Setzt die Property lavvHasChanged zu false,
			da keine Änderung durchgeführt wurde
		*/
		resetLaVv: function () {
			// Signalisiere readLaVv, dass es keine LaVvn gibt und das es bitte neue ziehen soll und das aktuelle oCompleteEntry nutzen soll 
			this.oAppViewModel.setProperty("/lavvData", null);
			
			this.checkDoubleLavvZweig([]);
			
			this.oAppViewModel.setProperty("/lavvHasChanged", false);
			this.oAppViewModel.setProperty("/changedKondition", null);
			this.oAppViewModel.setProperty("/chachedKond", null);
			this.oAppViewModel.setProperty("/kondHasChanged", false);
			this.setData();
		},

		handleCloseAddLavv: function () {},

		/*
			Die Daten der ausgewählten Lavv wird im OData-Modell geholt,
			im JSONModell eingefügt und die LaVV-Liste aktualisiert.
			Setzt die Property lavvHasChanged zu true,
			da eine Änderung durchgeführt wurde
		*/
		handleAddLavv: function (oEvent) {
			var aContexts = oEvent.getParameter("selectedContexts"),
				sPath = [],
				lavvList = this.lavvModel.getData();
			sPath = aContexts.map(function (item) {
				return item.sPath;
			});

			for (var i = 0; i < sPath.length; i++) {
				var stdLavvObj = this.oVertragModel.getProperty(sPath[i]);
				if (lavvList.indexOf(stdLavvObj) === -1) {
					lavvList.push(stdLavvObj);
				}
			}

			this.oAppViewModel.setProperty("/lavvData", lavvList);
			this.lavvModel.setData(lavvList);

			this.checkDoubleLavvZweig(lavvList); //Prüfe auf Spatendoubletten bei den augaählten LaVven

			Fragment.byId("idFragmentLavvShow", "lavvList").getBinding("items").refresh();
			this.oAppViewModel.setProperty("/lavvHasChanged", true);
		},

		checkDoubleLavvZweig: function (lavvlist) { //Prüfe auf Spatendoubletten bei den augaählten LaVven

			var VZweigList = [];
			var i;
			for (i = 0; i < lavvlist.length; i++) {
				VZweigList.push(lavvlist[i].ZVerszweig); //Bestücke leeres Array mit ZVerszweig aller ausgwählten LaVven
			}

			//var VZweigListUnique = jQuery.unique(VZweigList);

			var VZweigListUnique = []; //Ereuge neuen neuen Array für unique Werte
			for (i = 0; i < VZweigList.length; i++) {
				if ((VZweigListUnique.indexOf(VZweigList[i]) === -1)) {
					VZweigListUnique.push(VZweigList[i]);
				}
			}

			//var VZweigListUnique = VZweigList.filter((v, i, a) => a.indexOf(v) === i); //Erzeuge Array mit uniquen Einträgen
			var StatisticsPerVZweig = [];
			var countEntriesInNonUnique;

			for (i = 0; i < VZweigListUnique.length; i++) {
				countEntriesInNonUnique = 0;
				for (var j = 0; j < VZweigList.length; j++) {
					if (VZweigListUnique[i] === VZweigList[j]) {
						countEntriesInNonUnique++;
					}
				}
				StatisticsPerVZweig.push([VZweigListUnique[i], countEntriesInNonUnique]); //Erstelle Statistik (Count pro Verszweig)
			}

			//var conflictLavvZweig = [];

			// Reset für alle Spartendublikat Flags
			this.oVertragGlobal.setProperty("/conflictLavvZweigA", ["A", false]);
			this.oVertragGlobal.setProperty("/conflictLavvZweigB", ["B", false]);
			this.oVertragGlobal.setProperty("/conflictLavvZweigD", ["D", false]);
			this.oVertragGlobal.setProperty("/conflictLavvZweigG", ["G", false]);
			this.oVertragGlobal.setProperty("/conflictLavvZweigH", ["H", false]);
			this.oVertragGlobal.setProperty("/conflictLavvZweigJ", ["J", false]);
			this.oVertragGlobal.setProperty("/conflictLavvZweigK", ["K", false]);
			this.oVertragGlobal.setProperty("/conflictLavvZweigL", ["L", false]);
			this.oVertragGlobal.setProperty("/conflictLavvZweigR", ["R", false]);
			this.oVertragGlobal.setProperty("/conflictLavvZweigS", ["S", false]);
			this.oVertragGlobal.setProperty("/conflictLavvZweigU", ["U", false]);
			this.oVertragGlobal.setProperty("/conflictLavvZweigV", ["V", false]);
			this.oVertragGlobal.setProperty("/conflictLavvZweigW", ["W", false]);

			// Setze zutreffende Spartendublikat Flags auf true
			for (i = 0; i < VZweigListUnique.length; i++) {
				if (StatisticsPerVZweig[i][1] > 1) {
					var string = "/conflictLavvZweig" + StatisticsPerVZweig[i][0];
					this.oVertragGlobal.setProperty(string, [StatisticsPerVZweig[i][0], true]);

					//	conflictLavvZweig.push(StatisticsPerVZweig[i][0]);
				}
			}

			//this.getOwnerComponent().getModel("oVertragGlobal").setProperty("/conflictLavvZweig", conflictLavvZweig);

			if (VZweigListUnique.length !== VZweigList.length) {
				var msg = "Es wurden mehrere LaVven zu einer Sparte gefunden. Bitte löschen Sie die unzutreffenden Einträge.";
				MessageToast.show(msg, {
					duration: 7000, // time till toast fades/decays
					closeOnBrowserNavigation: false // keep toast shown in spite of routing
				});
				this.oVertragGlobal.setProperty("/conflictLavvZweigFlag", true); //Setze Flag, ob es aktuelle Dubikate gibt (Steuert Anzeige Save + Methode onPress)
			} else {
				this.oVertragGlobal.setProperty("/conflictLavvZweigFlag", false); //Setze Flag, ob es aktuelle Dubikate gibt (Steuert Anzeige Save + Methode onPress)
			}

		},

		/*
			Bei einer Suche auf StdLavv
		*/
		handleSearchLavv: function (oEvent) {
			var sValue = oEvent.getParameter("value"),
				oFilter = [];
			if (sValue) {
				oFilter = new Filter("Bezeichnung", FilterOperator.Contains, sValue);
			}

			var oBinding = oEvent.getSource().getBinding("items");
			oBinding.filter(oFilter);
		},

		/*
			löscht die ausgewählte LaVv im JSON-Modell und
			setzt die Property lavvHasChanged als true,
			da eine Änderung durchgeführt wurde
		*/
		deleteLaVv: function (oEvent) {
			var selectedItem = oEvent.getSource().getParent().getParent(),
				itemPath = selectedItem.getBindingContextPath().substr(1);
			Fragment.byId("idFragmentLavvShow", "lavvList").getModel().getData().splice(itemPath, 1);
			var lavvList = this.lavvModel.getData();
			this.oAppViewModel.setProperty("/lavvData", lavvList);
			this.lavvModel.setData(lavvList);
			this.checkDoubleLavvZweig(lavvList);
			Fragment.byId("idFragmentLavvShow", "lavvList").getBinding("items").refresh();
			this.oAppViewModel.setProperty("/lavvHasChanged", true);
		},

		/*
			Entsprechender Pfad wird gebildet, dann 
			wird die Route "leistung" (LaVv) aufgerufen
		*/
		onPress: function (oEvent) {
			var sPath = oEvent.getSource().getBindingContextPath().substr(1),
				oData = this.lavvModel.getData()[sPath];

			if (this.oParentController.oVertragGlobal.getProperty("/conflictLavvZweigFlag") === false) // BEGINN: Kontrollstruktur, um Navigieren bei inkompat. LaVven auswahl zu unterbinden
			{
				if (oData) {
					var uri = oData.__metadata.uri;
					var key = uri.split("LeiVergVereinbarungenSet")[1];
					var sLeistungPath;
					if (key) {
						sLeistungPath = "LeiVergVereinbarungenSet" + key;
						this.navToLeistung(sLeistungPath);
					} else {
						key = uri.split("StdVertLavvSet")[1];
						sLeistungPath = "StdVertLavvSet" + key;
						this.navToLeistung(sLeistungPath);
					}
				}
			}
		},

		navToLeistung: function (sLeistungsPath) {
			//			var oLeistung = oEvent.getSource().getBindingContext("vertrag").getObject();
			this.oParentController.oRouter.navTo("leistung", {
				layout: sap.f.LayoutType.TwoColumnsMidExpanded,
				vertragPath: this.oParentController._suchePath,
				leistungPath: sLeistungsPath
					/*			
								pVbusiBegin: this._oArguments.pVbusiBegin,
								pVCtrtbuId: this._oArguments.pVCtrtbuId,
								pVtechBegin: this._oArguments.pVTechBegin,
								busiBegin: oLeistung.BusiBegin.toISOString().replace(".000Z", ""),
								techBegin: oLeistung.TechBegin.toISOString().replace(".000Z", "")
							*/
			});
		}

	});
});