sap.ui.define([
	"sap/ui/base/ManagedObject",
	"sap/ui/core/Fragment",
	"de/pnw/icm/provisionsvertrag/vtr/util/Utilities",
	"de/pnw/icm/provisionsvertrag/vtr/model/formatter"
], function (ManagedObject, Fragment, Utilities, formatter) {
	"use strict";
	return ManagedObject.extend("de.pnw.icm.provisionsvertrag.vtr.controller.sections.ReferenzenShow", {
		formatter: formatter,
		
		constructor: function (oArgs) {
			this.oParentController = oArgs;
		},

		/*
			Abrufen der Referenzen-Daten eines Vertrages 
		*/
		setData: function () {
			
			this._vertragPath = this.oParentController._vertragPath;
			this._suchePath = this.oParentController._suchePath;
			this.oAppViewModel = this.oParentController.oModel;
			this.oSection = Fragment.byId("idFragmentReferenzenShow", "ReferenzenSection");
			this.oSection.bindElement({
				path: "/" + this._vertragPath,
				parameters: {
					expand: "ProVertrToReferenzen"
				},
				model: "vertrag",
				events: {
					change: function () {}
				}
			});
			
		},
		
		openVertrag: function (oEvent) {
			var sSelectedCtrtbuId = oEvent.getSource().getText(),
				sOldCtrtbuId = this.oParentController.oVertragData.CtrtbuId;
			var sNewVertragPath = this._suchePath.replace(sOldCtrtbuId, sSelectedCtrtbuId);

			// Absprung zum Vertrag mit ausgewähltem Parameter.
			this.oParentController.navigateToVertrag(sNewVertragPath);
		}

	});
});