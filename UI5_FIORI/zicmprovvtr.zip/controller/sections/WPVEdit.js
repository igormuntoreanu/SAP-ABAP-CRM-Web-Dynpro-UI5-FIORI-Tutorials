sap.ui.define([
	"sap/ui/base/ManagedObject",
	"sap/ui/core/Fragment",
	"sap/base/util/isEmptyObject",
	"sap/ui/core/CustomData",
	"de/pnw/icm/provisionsvertrag/vtr2/util/Utilities",
	'sap/ui/core/library',
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageBox",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
], function (ManagedObject, Fragment, isEmptyObject, CustomData, Utilities, coreLibrary, JSONModel, MessageBox, Filter, FilterOperator) {
	"use strict";

	var ValueState = coreLibrary.ValueState;

	return ManagedObject.extend("de.pnw.icm.provisionsvertrag.vtr2.controller.sections.WPVEdit", {

		constructor: function (oArgs) {
			this.oParentController = oArgs;
			this.oAppViewModel = this.oParentController.oModel;
			this.oI18nModel = this.oParentController.i18n;
		},

		/*
			Abrufen der WPV-Daten eines Vertrages 
			Section WPV ausblenden, wenn Datensatz WPVStamm leer ist
		*/
		setData: function () {
			this.oVertragModel = this.oParentController.vertragModel;
			this._vertragPath = this.oParentController._vertragPath;
			this.oSection = Fragment.byId("idFragmentWPVEdit", "idObjectPageSectionWPVEdit");
			this.oAppViewModel = this.oParentController.oModel;
			this.oI18nModel = this.oParentController.i18n;
			
			if (this.oAppViewModel.getProperty("/wpvProvisions")) { // 07.12.2021 - PRNPROV-191
				// When Navigating to a Lavv Detail, make sure we do not lost the given data.
				this.wpvProvisions = this.oAppViewModel.getProperty("/wpvProvisions");
			} else {
				this.wpvProvisions = new JSONModel();	
			}
			
			var that = this;
			if (this.oSection) {
				this.oSection.bindElement({
					path: "/" + this._vertragPath,
					parameters: {
						expand: "ProvVertrToWpvStamm,ProvVertrToWpvKond,ProvVertrToWpvStamm/WpvStammToWpvKondAp"
					},
					model: "vertrag",
					events: {
						change: function () {
							var oProperty = this.getModel("vertrag").getProperty(this.sPath + "/ProvVertrToWpvKond");
							if (oProperty && oProperty.length > 0) {
								var array = [];
								oProperty.forEach(function (oEntity, i) {
									array.push(that.oParentController.getOwnerComponent().getModel("vertrag").getProperty("/" + oEntity));
								});
								that.wpvProvisions.setData(array);
							}

							that.oAppViewModel.setProperty("/wpvProvisions", that.wpvProvisions);

							Fragment.byId("idFragmentWPVEdit", "idTableAPProvisionenEdit").setModel(that.wpvProvisions);
							Fragment.byId("idFragmentWPVEdit", "idTableVPProvisionenEdit").setModel(that.wpvProvisions);

							// var vertragg = this.getModel("vertrag").getProperty(this.sPath);
							// if (vertragg) {
							// 	if (vertragg.LabelVmArt === "AO" || vertragg.LabelVmArt === "SK" || vertragg.LabelVmArt === "MK" || vertragg.LabelVmArt ===
							// 		"SO") {
							// 		var wpvVpProvisionenVerguetungssatz = Fragment.byId("idFragmentWPVEdit", "WpvVpProvisionenVerguetungssatz");
							// 		wpvVpProvisionenVerguetungssatz.setEditable(true);
							// 		var wpvApProvisionenVerguetungssatz = Fragment.byId("idFragmentWPVEdit", "WpvApProvisionenVerguetungssatz");
							// 		oEvent.getSource.setEditable(true);
							// 	}
							// }

							var sPath = this.sPath.replace("ProvVertrSet", "WpvStammSet");
							that.oParentController.oCurrentWPVStamm = this.getModel("vertrag").getProperty(sPath);
							if (that.oParentController.oCurrentWPVStamm) {
								that.oAppViewModel.setProperty("/WPVData", that.oParentController.oCurrentWPVStamm);
								//delete that.oParentController.oCurrentWPVStamm.__metadata;
								that.oParentController.resetBlockLayoutVisualization("WPV", that.oParentController.oMappingModel, true);
								if (that.oAppViewModel.getProperty("/compareModus")) {
									var oChangesWPVStamm = Utilities.compareJSONObject(that.oAppViewModel.getProperty("/previousWpvStamm"), that.oParentController
										.oCurrentWPVStamm);
									that.oParentController.visualizeBlockLayoutChanges("WPV", oChangesWPVStamm);
								}
							}
						}
					}
				});
			}
		},

		onAfterClose: function (oEvent) {
			oEvent.getSource().destroy();
		},

		formatDecimal: function (oEvent) {
			this.oParentController.oModel.setProperty("/wpvHasChanged", true);
			//Only allow Numbers and with 2 Decimal digits
			var regex = /^[0-9]\d{0,8}(,\d{0,2})?$/;
			var isValid = false;
			var parameters = oEvent.getParameters();
			isValid = regex.test(parameters.newValue);
			if (isValid === false && parameters.newValue !== "" && parameters.newValue !== "0,") {
				//Only allows digits and comma
				var input = parameters.newValue.replace(/[^\d,]/g, "");
				//Remove after 3 digits after comma and keep until second digit
				input = input.replace(/^(\d+,?\d{0,2})\d*$/, "$1");
				//Remove duplicated commas
				input = input.replace(/(,[^,]*),/g, "$1");
				//Remove comma if first position of the string
				input = input.replace(/^,/g, "");
				//Remove 0 if first position of the string
				if (!input === "0,00") {
					input = input.replace(/^[0]/g, "");
				}
				if (input === "00") {
					input = "";
				}
				oEvent.getSource().setValue(input);
			}

			// if (parameters.newValue === "0,") { PRNPROV-181
			// 	oEvent.getSource().setValue("0,00");
			// }
		},

		formatNumber: function (oEvent) {
			this.oParentController.oModel.setProperty("/wpvHasChanged", true);
			var parameters = oEvent.getParameters();
			//Only allows digits
			var input = parameters.newValue.replace(/[^\d]/g, "");
			oEvent.getSource().setValue(input);
		},

		onWpvChange: function (oEvent) {
			this.oParentController.oModel.setProperty("/wpvHasChanged", true);
			var sId = oEvent.getSource().getId();
			if (sId.includes("idTableAPProvisionenEdit") || sId.includes("idTableVPProvisionenEdit")) {
				var parameters = oEvent.getParameters();

				if (parameters.newValue !== "") {
					//Do not allow last position with comma
					var input = parameters.newValue.replace(/,$/g, "");

					var res = input.split(",");
					// If there is no decimal point or only one decimal place found.
					if (res.length === 1 || res[1].length < 3) {
						// Replace comma with point to do the conversion
						input = input.replace(/,/g, ".");
						// Set the number to two decimal places
						var value = Number(input);
						value = value.toFixed(2);
						// Replace point with comma
						value = value.replace(/\./g, ",");
					}

					oEvent.getSource().setValue(value);
				}
			}
			if (sId.includes("ComboBox")) {
				this._checkEntryValue(oEvent);
				return;
			}
		},

		deleteWpvAp: function (oEvent) {
			var selectedItem = oEvent.getSource().getParent().getParent(),
				itemPath = parseInt(selectedItem.getBindingContextPath().substr(1), 10);
			// Delete selected Item line
			Fragment.byId("idFragmentWPVEdit", "idTableAPProvisionenEdit").getModel().getData().splice(itemPath, 1);
			Fragment.byId("idFragmentWPVEdit", "idTableAPProvisionenEdit").getModel().refresh();
			Fragment.byId("idFragmentWPVEdit", "idTableAPProvisionenEdit").getBinding("items").refresh();
			this.oAppViewModel.setProperty("/wpvApHasChanged", true);
			this.oAppViewModel.setProperty("/wpvProvisions", this.wpvProvisions);
		},

		deleteWpvVp: function (oEvent) {
			var selectedItem = oEvent.getSource().getParent().getParent(),
				itemPath = parseInt(selectedItem.getBindingContextPath().substr(1), 10);

			// Delete selected Item line
			Fragment.byId("idFragmentWPVEdit", "idTableVPProvisionenEdit").getModel().getData().splice(itemPath, 1);
			Fragment.byId("idFragmentWPVEdit", "idTableVPProvisionenEdit").getModel().refresh();
			Fragment.byId("idFragmentWPVEdit", "idTableVPProvisionenEdit").getBinding("items").refresh();
			this.oAppViewModel.setProperty("/wpvVpHasChanged", true);
			this.oAppViewModel.setProperty("/wpvProvisions", this.wpvProvisions);
		},

		beforeResetWpv: function (Verguetungsart) {
			if ((this.oAppViewModel.getProperty("/wpvApHasChanged") && Verguetungsart === "AP") ||
				(this.oAppViewModel.getProperty("/wpvVpHasChanged") && Verguetungsart === "VP")) {
				var bCompact = !!this.oParentController.getView().$().closest(".sapUiSizeCompact").length,
					confirmMsg = Utilities.geti18nText(this.oI18nModel, "confirmResetMsg", []),
					that = this;
				MessageBox.confirm(
					confirmMsg, {
						actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
						styleClass: bCompact ? "sapUiSizeCompact" : "",
						onClose: function (sAction) {
							if (sAction === "OK") {
								that.resetWpv(Verguetungsart);
							}
						}
					}
				);
			} else {
				this.resetWpv(Verguetungsart);
			}
		},

		resetWpv: function (Verguetungsart) {
			//Busy Indicator öffnen
			Utilities._showBusyDialog();
			var that = this;
			Utilities.promiseODataRead(this.oVertragModel, this._vertragPath + "/ProvVertrToWpvKond", {}, []).then(
				function (oData) { //resolve
					var apKondsGW = oData.results.filter(function (line) {
						return line.Verguetungsart === Verguetungsart;
					});
					var wpvList = that.wpvProvisions.getData();
					var opposite = Verguetungsart === "AP" ? "VP" : "AP";
					var oppositeList = [];
					if (wpvList && wpvList.length > 0) {
						oppositeList = wpvList.filter(function (line) {
							return line.Verguetungsart === opposite;
						});
					}

					var finalList = oppositeList.concat(apKondsGW);
					that.wpvProvisions.setData(finalList);

					if (Verguetungsart === "AP") {
						Fragment.byId("idFragmentWPVEdit", "idTableAPProvisionenEdit").getModel().refresh();
						Fragment.byId("idFragmentWPVEdit", "idTableAPProvisionenEdit").getBinding("items").refresh();
						this.oAppViewModel.setProperty("/wpvApHasChanged", false);
					} else {
						Fragment.byId("idFragmentWPVEdit", "idTableVPProvisionenEdit").getModel().refresh();
						Fragment.byId("idFragmentWPVEdit", "idTableVPProvisionenEdit").getBinding("items").refresh();
						this.oAppViewModel.setProperty("/wpvVpHasChanged", false);
					}

					that.oAppViewModel.setProperty("/wpvProvisions", that.wpvProvisions);

					Fragment.byId("idBusyFragment", "idBusyDialog").close();
				}.bind(this),
				function (oError) { //reject
					//Busy Indicator schließen
					Fragment.byId("idBusyFragment", "idBusyDialog").close();
					var sErrorMsg = (jQuery.parseXML(oError.responseText).querySelector("message") || "").textContent;
					sErrorMsg = sErrorMsg + " (VM - WPVEdit.js: resetWpv())";
					Utilities.displayErrorMessageBox(sErrorMsg, this.oParentController.getView());
				}.bind(this)
			);
		},

		WpvKondMultiSelect: function (Verguetungsart, Modus) {
			var that = this;
			if (Modus === "All") {
				var aFilter = []; //16.11.2021

				aFilter.push(
					new Filter({
						path: "Verguetungsart",
						operator: FilterOperator.EQ,
						value1: Verguetungsart
					})
				);

				//28.10.2021
				Utilities.promiseODataRead(this.oVertragModel, this._vertragPath + "/ProvVertrToStdWpvKond", {}, aFilter).then(
					function (oData) { //resolve
						var wpvList = that.wpvProvisions.getData();
						if (!$.isArray(wpvList)) { // 28.10.2021
							wpvList = [];
						}
						for (var i = 0; i < oData.results.length; i++) {
							if (oData.results[i].Verguetungsart === "") { // 28.10.2021
								oData.results[i].Verguetungsart = Verguetungsart;
							}
							if (oData.results[i].Verguetungsart === Verguetungsart) {
								var duplicated = wpvList.filter(function (line) {
									return (line.Art === oData.results[i].Art && line.Artt === oData.results[i].Artt && line.Verguetungsart === oData.results[
										i].Verguetungsart);
								});

								if (!duplicated.length > 0) {
									wpvList.push(oData.results[i]);
								}
							}
						}
						
						that.wpvProvisions.setData(wpvList);
						that.oAppViewModel.setProperty("/wpvProvisions", that.wpvProvisions);
					}.bind(this),
					function (oError) { //do nothing
					}.bind(this)
				);
			} else if (Modus === "None") {
				var wpvList = this.wpvProvisions.getData();
				wpvList = wpvList.filter(function (line) {
					return line.Verguetungsart !== Verguetungsart;
				});
				this.wpvProvisions.setData(wpvList);
				this.oAppViewModel.setProperty("/wpvProvisions", this.wpvProvisions);
			}

			if (Verguetungsart === "AP") {
				Fragment.byId("idFragmentWPVEdit", "idTableAPProvisionenEdit").getModel().refresh();
				Fragment.byId("idFragmentWPVEdit", "idTableAPProvisionenEdit").getBinding("items").refresh();
				this.oAppViewModel.setProperty("/wpvApHasChanged", true);
			} else {
				Fragment.byId("idFragmentWPVEdit", "idTableVPProvisionenEdit").getModel().refresh();
				Fragment.byId("idFragmentWPVEdit", "idTableVPProvisionenEdit").getBinding("items").refresh();
				this.oAppViewModel.setProperty("/wpvVpHasChanged", true);
			}
		},

		addWpvKond: function (Verguetungsart) {
			if (Verguetungsart === "AP") {
				if (!this.addWpvApKondDialog) {
					this.addWpvApKondDialog = Fragment.load({
						id: "idFragmentWPVEdit--addWpvApKondDialog",
						name: "de.pnw.icm.provisionsvertrag.vtr2.view.fragment.addWpvApKondDialog",
						controller: this
					}).then(function (oDialog) {
						this._createModelToAdd(Verguetungsart, oDialog);
						
						//28.10.2021
						if (!sap.ui.getCore().getModel("FragmentsGlobal")) {
							var oFragmentsGlobal = new JSONModel();
							var arrayFragments = [];
							oFragmentsGlobal.setData(arrayFragments);
							sap.ui.getCore().setModel(oFragmentsGlobal, "FragmentsGlobal");
						}

						var fragmentModel = sap.ui.getCore().getModel("FragmentsGlobal");
						var fragmentModelData = fragmentModel.getData();
						fragmentModelData["addWpvApKondDialog"] = oDialog;
						fragmentModel.setData(fragmentModelData);
						//28.10.2021
						
						this.addWpvApKondDialog = oDialog;
					}.bind(this));
				} else {
					this._createModelToAdd(Verguetungsart, this.addWpvApKondDialog);
				}
			} else {
				if (!this.addWpvVpKondDialog) {
					this.addWpvVpKondDialog = Fragment.load({
						id: "idFragmentWPVEdit--addWpvVpKondDialog",
						name: "de.pnw.icm.provisionsvertrag.vtr2.view.fragment.addWpvVpKondDialog",
						controller: this
					}).then(function (oDialog) {
						this._createModelToAdd(Verguetungsart, oDialog);
						
						//28.10.2021
						if (!sap.ui.getCore().getModel("FragmentsGlobal")) {
							var oFragmentsGlobal = new JSONModel();
							var arrayFragments = [];
							oFragmentsGlobal.setData(arrayFragments);
							sap.ui.getCore().setModel(oFragmentsGlobal, "FragmentsGlobal");
						}

						var fragmentModel = sap.ui.getCore().getModel("FragmentsGlobal");
						var fragmentModelData = fragmentModel.getData();
						fragmentModelData["addWpvVpKondDialog"] = oDialog;
						fragmentModel.setData(fragmentModelData);
						//28.10.2021
						
						this.addWpvVpKondDialog = oDialog;
					}.bind(this));
				} else {
					this._createModelToAdd(Verguetungsart, this.addWpvVpKondDialog);
				}
			}
		},

		handleSearchLavv: function (oEvent) {
			var sValue = oEvent.getParameter("value"),
				oFilter = [];
			if (sValue) {
				oFilter = new Filter("Artt", FilterOperator.Contains, sValue);
			}

			var oBinding = oEvent.getSource().getBinding("items");
			oBinding.filter(oFilter);
		},

		handleAddWpvApKond: function (oEvent) {
			var aContexts = oEvent.getParameter("selectedContexts");
			var sPath = [];
			var wpvList = this.wpvProvisions.getData();
			if (!$.isArray(wpvList)) { // 28.10.2021
				wpvList = [];
			}

			sPath = aContexts.map(function (item) {
				return item.sPath;
			});

			for (var i = 0; i < sPath.length; i++) {
				var newLine = this.wpvListToAdd.getProperty(sPath[i]);
				if (newLine) {
					wpvList.push(newLine);
				}
			}
			this.wpvProvisions.setData(wpvList);
			this.oAppViewModel.setProperty("/wpvProvisions", this.wpvProvisions);

			Fragment.byId("idFragmentWPVEdit", "idTableAPProvisionenEdit").getModel().refresh();
			Fragment.byId("idFragmentWPVEdit", "idTableAPProvisionenEdit").getBinding("items").refresh();
			this.oAppViewModel.setProperty("/wpvApHasChanged", true);

		},

		handleAddWpvVpKond: function (oEvent) {
			var aContexts = oEvent.getParameter("selectedContexts");
			var sPath = [];
			var wpvList = this.wpvProvisions.getData();
			if (!$.isArray(wpvList)) { // 28.10.2021
				wpvList = [];
			}

			sPath = aContexts.map(function (item) {
				return item.sPath;
			});

			for (var i = 0; i < sPath.length; i++) {
				var newLine = this.wpvListToAdd.getProperty(sPath[i]);
				if (newLine) {
					wpvList.push(newLine);
				}
			}

			this.wpvProvisions.setData(wpvList);
			this.oAppViewModel.setProperty("/wpvProvisions", this.wpvProvisions);

			Fragment.byId("idFragmentWPVEdit", "idTableVPProvisionenEdit").getModel().refresh();
			Fragment.byId("idFragmentWPVEdit", "idTableVPProvisionenEdit").getBinding("items").refresh();
			this.oAppViewModel.setProperty("/wpvVpHasChanged", true);

		},

		_createModelToAdd: function (Verguetungsart, oDialog) {
			//Busy Indicator öffnen
			Utilities._showBusyDialog();
			this.wpvListToAdd = new JSONModel();
			var aFilter = []; //16.11.2021

			aFilter.push(
				new Filter({
					path: "Verguetungsart",
					operator: FilterOperator.EQ,
					value1: Verguetungsart
				})
			);

			var that = this;
			Utilities.promiseODataRead(this.oVertragModel, this._vertragPath + "/ProvVertrToStdWpvKond", {}, aFilter).then(
				function (oData) { //resolve
					//var fullList = oData.results.filter(function (line) {
					//	return line.Verguetungsart === Verguetungsart;
					//});
					var fullList = oData.results;
					var actualList = that.wpvProvisions.getData();
					var missingOnList = [];

					for (var i = 0; i < fullList.length; i++) {
						if (fullList[i].Verguetungsart === "") {
							fullList[i].Verguetungsart = Verguetungsart;
						}
						if (actualList.length > 0) {
							var isOnList = actualList.filter(function (line) {
								return line.Art === fullList[i].Art && line.Artt === fullList[i].Artt && line.Verguetungsart === fullList[i].Verguetungsart;
							});
							//Add it to the missingOnList
							if (isOnList.length === 0) {
								missingOnList.push(fullList[i]);
							}
						} else {
							missingOnList.push(fullList[i]);
						}
					}

					that.wpvListToAdd.setData(missingOnList);
					oDialog.setModel(that.wpvListToAdd);
					oDialog.getModel().refresh();
					that.oParentController.getView().addDependent(oDialog);
					oDialog.open();

					Fragment.byId("idBusyFragment", "idBusyDialog").close();
				}.bind(this),
				function (oError) { //reject
					//Busy Indicator schließen
					Fragment.byId("idBusyFragment", "idBusyDialog").close();
					var sErrorMsg = (jQuery.parseXML(oError.responseText).querySelector("message") || "").textContent;
					sErrorMsg = sErrorMsg + " (VM - WPVEdit.js: _createModelToAdd())";
					Utilities.displayErrorMessageBox(sErrorMsg, this.oParentController.getView());
				}.bind(this)
			);
		},

		_checkEntryValue: function (oEvent) {
			var oValidatedComboBox = oEvent.getSource(),
				sSelectedKey = oValidatedComboBox.getSelectedKey(),
				sValue = oValidatedComboBox.getValue();

			if (!sSelectedKey && sValue) {
				oValidatedComboBox.setValueState(ValueState.Error);
				oValidatedComboBox.setValueStateText("Bitte geben Sie einen gültigen Eintrag ein");
			} else {
				oValidatedComboBox.setValueState(ValueState.None);
			}
		}

	});
});