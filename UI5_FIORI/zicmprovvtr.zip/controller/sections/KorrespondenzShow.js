sap.ui.define([
	"sap/ui/base/ManagedObject",
	"sap/ui/core/Fragment",
	"de/pnw/icm/provisionsvertrag/vtr2/control/CheckBox",
	"de/pnw/icm/provisionsvertrag/vtr2/control/LabelExtended",
	"de/pnw/icm/provisionsvertrag/vtr2/util/Utilities",
	"de/pnw/icm/provisionsvertrag/vtr2/model/formatter"
], function (ManagedObject, Fragment, CheckBox, LabelExtended, Utilities, formatter) {
	"use strict";
	return ManagedObject.extend("de.pnw.icm.provisionsvertrag.vtr2.controller.sections.KorrespondenzShow", {
		formatter: formatter,
		constructor: function (oArgs) {
			this.oParentController = oArgs;
			// Subscribe resetKorrespondez. Es wird verwenden, wenn der Benutzer vom Bearbeitungsmodus in den Ansichtsmodus wechseln
			this.oParentController.getOwnerComponent().getEventBus().subscribeOnce(
					"KorrespondezShow",
					"reset",
					this.resetKorrespondez,
					this);
		},

		/*
			Abrufen der Korrespondenz-Daten eines Vertrages 
		*/
		setData: function () {
			this._vertragPath = this.oParentController._vertragPath;
			this.oSection = Fragment.byId("idFragmentKorrespondenzShow", "KorrespondenzSection");
			this.oAppViewModel = this.oParentController.oModel;
			var that = this;
			this.oSection.bindElement({
				path: "/" + this._vertragPath,
				parameters: {
					expand: "ProvVertrToKorrespondenz,ProvVertrToKommMakler,ProvVertrToAdressenliste"
				},
				model: "vertrag",
				events: {
					change: function (oEvent) {
						var oForm = Fragment.byId("idFragmentKorrespondenzShow", "idSimpleFormMakler");
						oForm.destroyContent();
						var oModel = this.getModel("vertrag");
						var oPath = oModel.getProperty(this.sPath);
						if(oPath) {
							var provVertrToKommMakler = oPath.ProvVertrToKommMakler;
							if (provVertrToKommMakler) {
								var aKommMaklerKeys = provVertrToKommMakler.__list;	
							}
						}
						var sKorrespondenzPath = this.sPath.replace("ProvVertrSet", "KorrespondenzSet");
						that.oParentController.oCurrentVertragKorrespondenz = this.getModel("vertrag").getProperty(sKorrespondenzPath);
						if (aKommMaklerKeys && that.oParentController.oCurrentVertragKorrespondenz) {
							that.oParentController.resetBlockLayoutVisualization("Korrespondenz", that.oParentController.oMappingModel);
							delete that.oParentController.oCurrentVertragKorrespondenz.__metadata;
							var aKommMakler = [];
							aKommMaklerKeys.forEach(function (key, i) {
								var oKommMakler = this.getModel("vertrag").getProperty("/" + key);
								aKommMakler.push(oKommMakler);
							}.bind(this));

							var aKommMaklerSorted = aKommMakler.sort(function (a, b) {
								return (a.Artt > b.Artt) ? 1 : -1;
							});
							var oMaklerKomm = {};
							that.oParentController.oCurrentVertragKommMakler = {};
							that.aKommMaklerSorted = aKommMaklerSorted;
							aKommMaklerSorted.forEach(function (oEntity, i) {
								oForm.addContent(
									new LabelExtended({
										id: Fragment.createId("idFragmentKorrespondenzShow", "idKorrespondenzMakler" + (oEntity.Artt)),
										text: "Makler Korrespondenz Leistung " + oEntity.Artt
									})
								);
								oForm.addContent(
									new CheckBox({
										id: "idObjectStatusKorrespondenzEdit" + oEntity.Artt,
										selected: oEntity.FlgVorh,
										enabled: "{appView>/editMode}",
										editable: "{appView>/editMode}"
									})
								);

								oMaklerKomm[(oEntity.Artt)] = "idKorrespondenzMakler" + (oEntity.Artt).replace(/\W/g, "");
								that.oParentController.oCurrentVertragKommMakler[(oEntity.Artt)] = oEntity.FlgVorh;
							});
							var oKorrespondenz = that.oParentController.oMappingModel.getProperty("/Korrespondenz");
							Object.keys(oMaklerKomm || []).forEach(function (key) {
								oKorrespondenz[key] = oMaklerKomm[key];
							});
							that.oParentController.oMappingModel.setProperty("/Korrespondenz", oKorrespondenz);

							if (that.oAppViewModel.getProperty("/compareModus")) {
								// Versionsvergleich für Korrenzpondenz
								var oChangesKorrespondenz = Utilities.compareJSONObject(that.oAppViewModel.getProperty("/previousKorrespondenz"), that.oParentController
									.oCurrentVertragKorrespondenz);
								that.oParentController.visualizeBlockLayoutChanges("Korrespondenz", oChangesKorrespondenz, that.oParentController.oMappingModel);

								if (that.oAppViewModel.getProperty("/showMaklerKomm")) {
									// Versionsvergleich für Makler Kommunikation falls aktiv
									var oChangesMaklerKomm = Utilities.compareJSONObject(that.oAppViewModel.getProperty("/previousKommMakler"), that.oParentController
										.oCurrentVertragKommMakler);
									that.oParentController.visualizeBlockLayoutChanges("Korrespondenz", oChangesMaklerKomm, that.oParentController.oMappingModel);
								}
							}
						}
					}
				}
			});

			var oHintText = Fragment.byId("idFragmentKorrespondenzShow", "idFormattedTextKorrespondenz");
			oHintText.setHtmlText("<em style=\"color:rgb(102, 102, 102);\">" + Utilities.geti18nText(this.oParentController.i18n,
				"hintCurrentData", []) + "</em>");
		},
		
		onAfterClose: function (oEvent) {
			oEvent.getSource().destroy();
		},
		
		resetKorrespondez: function () {
			var that = this;
			Utilities.promiseODataRead(this.oParentController.getOwnerComponent().getModel("vertrag"), this.oParentController._vertragPath + "/ProvVertrToKorrespondenz", {}, []).then(
					function (oData) { //resolve
						that.vertragModel = this.oParentController.getOwnerComponent().getModel("vertrag");
						that.vertragModel.setProperty("/" + this._vertragPath + "/ProvVertrToKorrespondenz" + "/" + "Coprct", oData.Coprct);
						that.vertragModel.setProperty("/" + this._vertragPath + "/ProvVertrToKorrespondenz" + "/" + "BusiBegin", oData.BusiBegin);
						that.vertragModel.setProperty("/" + this._vertragPath + "/ProvVertrToKorrespondenz" + "/" + "ZKontoauszbeg", oData.ZKontoauszbeg);
						that.vertragModel.setProperty("/" + this._vertragPath + "/ProvVertrToKorrespondenz" + "/" + "ZKontoauszt", oData.ZKontoauszt);
						that.vertragModel.setProperty("/" + this._vertragPath + "/ProvVertrToKorrespondenz" + "/" + "ZKontoausz", oData.ZKontoausz);
						that.vertragModel.setProperty("/" + this._vertragPath + "/ProvVertrToKorrespondenz" + "/" + "ZVermittlerduplikat", oData.ZVermittlerduplikat);
						that.vertragModel.setProperty("/" + this._vertragPath + "/ProvVertrToKorrespondenz" + "/" + "Coprc", oData.Coprc);
						that.vertragModel.setProperty("/" + this._vertragPath + "/ProvVertrToKorrespondenz" + "/" + "CtrtbuId", oData.CtrtbuId);
						that.vertragModel.setProperty("/" + this._vertragPath + "/ProvVertrToKorrespondenz" + "/" + "Email", oData.Email);
						that.vertragModel.setProperty("/" + this._vertragPath + "/ProvVertrToKorrespondenz" + "/" + "IndReceiv", oData.IndReceiv);
						that.vertragModel.setProperty("/" + this._vertragPath + "/ProvVertrToKorrespondenz" + "/" + "Receiver", oData.Receiver);
						that.vertragModel.setProperty("/" + this._vertragPath + "/ProvVertrToKorrespondenz" + "/" + "ReceiverDsc", oData.ReceiverDsc);
						that.vertragModel.setProperty("/" + this._vertragPath + "/ProvVertrToKorrespondenz" + "/" + "Telefonnummer", oData.Telefonnummer);
						that.vertragModel.setProperty("/" + this._vertragPath + "/ProvVertrToKorrespondenz" + "/" + "Version", oData.Version);
					}.bind(this));
					
			Utilities.promiseODataRead(this.oParentController.getOwnerComponent().getModel("vertrag"), this.oParentController._vertragPath + "/ProvVertrToKommMakler", {}, []).then(
					function (oData) { //resolve
						if (this.aKommMaklerSorted) {
							this.aKommMaklerSorted.forEach(function (oEntity, i) {
								var marklerKomm = oData.results.filter(function(line) { 
									return line.Artt === oEntity.Artt;
								});
								that._resetField("CheckBox", "idObjectStatusKorrespondenzEdit" + oEntity.Artt, oData[oEntity.Artt]);
							});
						}
					}.bind(this));
		},
		
		_resetField: function(sType, sId, sValue) {
			var field = Fragment.byId("idFragmentAllgemeinesShow", sId);
			if (field) {
				if (sType === "Text") {
					field.setText(sValue);
				} else if (sType === "CheckBox") {
					field.setSelected(sValue);
				}  else if (sType === "Date") {
					field.setText(Utilities.dateToStr(sValue));
				}
			}
		}
	});
});