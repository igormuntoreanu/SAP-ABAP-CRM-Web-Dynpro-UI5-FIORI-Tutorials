sap.ui.define([
	"sap/ui/base/ManagedObject",
	"sap/ui/core/Fragment",
	"de/pnw/icm/provisionsvertrag/vtr2/util/Utilities",
	"de/pnw/icm/provisionsvertrag/vtr2/model/formatter"
], function (ManagedObject, Fragment, Utilities, formatter) {
	"use strict";
	return ManagedObject.extend("de.pnw.icm.provisionsvertrag.vtr2.controller.sections.VermittlergruppenShow", {
		formatter: formatter,

		constructor: function (oArgs) {
			this.oParentController = oArgs;
		},

		/*
			Abrufen der Vermittlergruppen-Daten eines Vertrages 
		*/
		setData: function () {
			this._vertragPath = this.oParentController._vertragPath;
			this.oAppViewModel = this.oParentController.oModel;
			this.oSection = Fragment.byId("idFragmentVermittlergruppenShow", "VermittlergruppenSection");
			if (this.oSection) {
				this.oSection.bindElement({
					path: "/" + this._vertragPath,
					parameters: {
						expand: "ProvVertrToVermGruppen"
					},
					model: "vertrag",
					events: {
						change: function (oEvent) {
							// 1. Überprüfen ob die Daten(Vermgruppen) vorhanden sind (oldVermgruppe)

							// 2. Daten (Vermgruppen) holen (newVermgruppe)

							// 3. Beide Datensätze vergleichen: wenn compareModus aktiv
							/*
								Utilities.compareJSON(obj1, obj2) liefert die Änderungen in Form (Key, Value).
								Beim Aufruf sollten oldVermgruppe als erster Parameter und newVermgruppe als zweiter mitgegeben.
							*/
							// 4. Unterschied in der View markieren: wenn compareModus aktiv
							/*
							 * Mit einem Mapping zwischen Key, Contron-Id und Control-Typ werden Änderungen mit dem Tooltip und Farbe in der View markiert.
							 * Für LaVv mit dem Mapping zwischen Key und Control-Id holen wir die ganze Zeile und setzen wir ein CustomData
							 */
							// 5 newVermgruppe in JSON als oldVermgruppe speichern
						}
					}
				});
			}
		},
		
		/*
			Absprung in die VMG-App
		*/
		goToVmg: function (oEvent) {
		var obj = oEvent.getSource().getBindingContext("vertrag").getObject();
		var target, params;
		this.oCrossAppNav = sap.ushell.Container.getService("CrossApplicationNavigation");
			if (this.oCrossAppNav) {
				target = {
					semanticObject: "ZIcmVmg",
					action: "display"
				};
				params = {
					"SemObj": "ZIcmProvVtr2",
					"CtrtbuId": obj.CtrtbuId,
					"ZVmgNr": obj.ZVmgNr,
					"ZHerkunft": obj.ZHerkunft,
					"CacsBusitimeB": obj.CacsBusitimeB.toISOString().toString(),
					"Cacstechtime": obj.Cacstechtime.toISOString().toString()
				};
				Utilities.crossAppNavigation(this.oCrossAppNav, target, params);
			}
		},

		onAfterClose: function (oEvent) {
			oEvent.getSource().destroy();
		}

	});
});