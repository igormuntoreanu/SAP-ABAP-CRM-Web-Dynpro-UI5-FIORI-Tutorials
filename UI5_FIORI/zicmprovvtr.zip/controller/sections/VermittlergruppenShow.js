sap.ui.define([
	"sap/ui/base/ManagedObject",
	"sap/ui/core/Fragment",
	"de/pnw/icm/provisionsvertrag/vtr/model/formatter"
], function (ManagedObject, Fragment, formatter) {
	"use strict";
	return ManagedObject.extend("de.pnw.icm.provisionsvertrag.vtr.controller.sections.VermittlergruppenShow", {
		formatter: formatter,
		
		constructor: function (oArgs) {
			this.oParentController = oArgs;
		},

		/*
			Abrufen der Vermittlergruppen-Daten eines Vertrages 
		*/
		setData: function () {
			this._vertragPath = this.oParentController._vertragPath;
			this.oAppViewModel = this.oParentController.oModel;
			this.oSection = Fragment.byId("idFragmentVermittlergruppenShow", "VermittlergruppenSection");
			this.oSection.bindElement({
				path: "/" + this._vertragPath,
				parameters: {
					expand: "ProvVertrToVermGruppen"
				},
				model: "vertrag",
				events: {
					change: function (oEvent) {
						// 1. Überprüfen ob die Daten(Vermgruppen) vorhanden sind (oldVermgruppe)

						// 2. Daten (Vermgruppen) holen (newVermgruppe)

						// 3. Beide Datensätze vergleichen: wenn compareModus aktiv
						/*
							Utilities.compareJSON(obj1, obj2) liefert die Änderungen in Form (Key, Value).
							Beim Aufruf sollten oldVermgruppe als erster Parameter und newVermgruppe als zweiter mitgegeben.
						*/
						// 4. Unterschied in der View markieren: wenn compareModus aktiv
						/*
						 * Mit einem Mapping zwischen Key, Contron-Id und Control-Typ werden Änderungen mit dem Tooltip und Farbe in der View markiert.
						 * Für LaVv mit dem Mapping zwischen Key und Control-Id holen wir die ganze Zeile und setzen wir ein CustomData
						 */
						// 5 newVermgruppe in JSON als oldVermgruppe speichern
					}
				}
			});
		}

	});
});