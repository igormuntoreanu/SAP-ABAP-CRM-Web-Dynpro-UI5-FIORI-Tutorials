sap.ui.define([
	"sap/ui/base/ManagedObject",
	"sap/m/MessageBox",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/Fragment",
	"de/pnw/icm/provisionsvertrag/vtr/util/Utilities",
	"de/pnw/icm/provisionsvertrag/vtr/model/formatter"
], function (ManagedObject, MessageBox, JSONModel, Fragment, Utilities, formatter) {
	"use strict";
	return ManagedObject.extend("de.pnw.icm.provisionsvertrag.vtr.controller.sections.BeziehungenShow", {
		formatter: formatter,
		constructor: function (oArgs) {
			this.oParentController = oArgs;
		},
		/*
			Abrufen der Beziehungsdaten eines Vertrages 
		*/
		setData: function () {
			//this.oModel = this.getOwnerComponent().getModel("appView");
			this._vertragPath = this.oParentController._vertragPath;
			this._suchePath = this.oParentController._suchePath;
			this.oAppViewModel = this.oParentController.oModel;
			
			var oVertragModel = this.oParentController.vertragModel,
				sPath1 = this._vertragPath + "/ProvVertrToAnsprechpartner";
			Utilities.promiseODataRead(oVertragModel, sPath1, {}, []).then(
				function (oData) { //resolve
					// show Ansprechpartner?
					if(oData.results.length < 1){
						this.oAppViewModel.setProperty("/showAnsprechpartner", false);
					} else {
						this.oAppViewModel.setProperty("/showAnsprechpartner", true);
					}
				}.bind(this),
				function (oError) { //reject
					//do nothing
				}
			);	

			var oTreeModel = new JSONModel(),
				oTreeTable = Fragment.byId("idFragmentBeziehungenShow", "orgaStruktur");
			oTreeTable.setModel(oTreeModel, "orgaTreeModel");

			var sPath = this._vertragPath + "/ProvVertrToOrgaStruktur";
			//Busy Indicator öffnen
			Utilities._showBusyDialog();
			
			Utilities.promiseODataRead(oVertragModel, sPath, {}, []).then(
				function (oData) { //resolve
					// TreeModel
					
					var oTree = {};
					oData.results.forEach(function (item, i) {
						delete item.__metadata;
						oTree[item.Otjid] = item;
						// jedem Knoten ein untergeordnetes Container-Array hinzufügen
						oTree[item.Otjid].children = [];
					});

					// die untergeordneten Container-Arrays füllen
					var iTreeLevel = 0;
					for (var i in oTree) {
						var sParentKey = oTree[i].ParentOtjid;
						if (oTree[sParentKey] && sParentKey !== "") {
							oTree[sParentKey].children.push(oTree[i]);
							oTree[sParentKey].CtrtbuId = "";
							iTreeLevel++;
						}
					}

					// die Stammknoten (kein übergeordnetes Element gefunden) suchen und daraus den Hierarchiebaum erstellen
					var root = [];
					for (var j in oTree) {
						sParentKey = oTree[j].ParentOtjid;
						if (!oTree[sParentKey] || sParentKey === "") {
							root.push(oTree[j]);
						}
					}

					var data = {
						root: root
					};

					oTreeModel.setData(data);
					oTreeTable.expandToLevel(iTreeLevel);
					//oTreeTable.getVisibleRowCountMode();
					oTreeTable.setVisibleRowCountMode("Auto");
					//Busy Indicator schließen
					Fragment.byId("idBusyFragment", "idBusyDialog").close();
				}.bind(this),
				function (oError) { //reject
					//Busy Indicator schließen
					Fragment.byId("idBusyFragment", "idBusyDialog").close();
					var sErrorMsg = (jQuery.parseXML(oError.responseText).querySelector("message") || "").textContent;
					Utilities.displayErrorMessageBox(sErrorMsg, this.oParentController.getView());
				}.bind(this)
			);
		},

		openVertrag: function (oEvent) {
			var sSelectedCtrtbuId = oEvent.getSource().getText(),
				sOldCtrtbuId = this.oParentController.oVertragData.CtrtbuId;
			var sNewVertragPath = this._suchePath.replace(sOldCtrtbuId, sSelectedCtrtbuId);

			// Absprung zum Vertrag mit ausgewähltem Parameter.
			this.oParentController.navigateToVertrag(sNewVertragPath);
		}

	});
});