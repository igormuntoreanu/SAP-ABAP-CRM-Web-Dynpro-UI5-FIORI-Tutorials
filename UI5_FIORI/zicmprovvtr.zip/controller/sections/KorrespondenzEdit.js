sap.ui.define([
	"sap/ui/base/ManagedObject",
	"sap/ui/core/Fragment",
	"de/pnw/icm/provisionsvertrag/vtr2/control/CheckBox",
	"de/pnw/icm/provisionsvertrag/vtr2/control/LabelExtended",
	"de/pnw/icm/provisionsvertrag/vtr2/util/Utilities",
	"de/pnw/icm/provisionsvertrag/vtr2/model/formatter",
	'sap/ui/core/library'
], function (ManagedObject, Fragment, CheckBox, LabelExtended, Utilities, formatter, coreLibrary) {
	"use strict";

	var ValueState = coreLibrary.ValueState;
	var globalThis = {};

	return ManagedObject.extend("de.pnw.icm.provisionsvertrag.vtr2.controller.sections.KorrespondenzEdit", {
		formatter: formatter,
		constructor: function (oArgs) {
			this.oParentController = oArgs;
		},

		/*
			Abrufen der Korrespondenz-Daten eines Vertrages 
		*/
		setData: function () {
			this._vertragPath = this.oParentController._vertragPath;
			this.oSection = Fragment.byId("idFragmentKorrespondenzEdit", "KorrespondenzSectionEdit");
			this.oAppViewModel = this.oParentController.oModel;
			globalThis = this;
			var that = this;
			if (this.oSection) {
				this.oSection.bindElement({
					path: "/" + this._vertragPath,
					parameters: {
						expand: "ProvVertrToKorrespondenz,ProvVertrToKommMakler,ProvVertrToAdressenliste"
					},
					model: "vertrag",
					events: {
						change: function (oEvent) {
							var oForm = Fragment.byId("idFragmentKorrespondenzEdit", "idSimpleFormMaklerEdit");
							oForm.destroyContent();
							var oModel = this.getModel("vertrag");
							var oPath = oModel.getProperty(this.sPath);
							if (oPath) {
								var provVertrToKommMakler = oPath.ProvVertrToKommMakler;
								if (provVertrToKommMakler) {
									var aKommMaklerKeys = provVertrToKommMakler.__list;
								}
							}
							var sKorrespondenzPath = this.sPath.replace("ProvVertrSet", "KorrespondenzSet");
							that.oParentController.oCurrentVertragKorrespondenz = this.getModel("vertrag").getProperty(sKorrespondenzPath);
							if (aKommMaklerKeys && that.oParentController.oCurrentVertragKorrespondenz) {
								that.oParentController.resetBlockLayoutVisualization("Korrespondenz", that.oParentController.oMappingModel, true);
								//delete that.oParentController.oCurrentVertragKorrespondenz.__metadata;
								var aKommMakler = [];
								aKommMaklerKeys.forEach(function (key, i) {
									var oKommMakler = this.getModel("vertrag").getProperty("/" + key);
									aKommMakler.push(oKommMakler);
								}.bind(this));

								var aKommMaklerSorted = aKommMakler.sort(function (a, b) {
									return (a.Artt > b.Artt) ? 1 : -1;
								});
								var oMaklerKomm = {};
								that.oParentController.oCurrentVertragKommMakler = {};
								that.aKommMaklerSorted = aKommMaklerSorted;
								aKommMaklerSorted.forEach(function (oEntity, i) {
									oForm.addContent(
										new LabelExtended({
											id: Fragment.createId("idFragmentKorrespondenzEdit", "idKorrespondenzMakler" + (oEntity.Artt)),
											text: "Makler Korrespondenz Leistung " + oEntity.Artt
										})
									);

									oForm.addContent(
										new CheckBox({
											id: "idObjectStatusKorrespondenzEdit" + oEntity.Artt,
											selected: oEntity.FlgVorh,
											enabled: "{appView>/editMode}",
											editable: "{appView>/editMode}",
											select: that.onKorrespondezChange
										})
									);

									oMaklerKomm[(oEntity.Artt)] = "idKorrespondenzMakler" + (oEntity.Artt).replace(/\W/g, "");
									that.oParentController.oCurrentVertragKommMakler[(oEntity.Artt)] = oEntity.FlgVorh;
								});
								var oKorrespondenz = that.oParentController.oMappingModel.getProperty("/Korrespondenz");
								Object.keys(oMaklerKomm || []).forEach(function (key) {
									oKorrespondenz[key] = oMaklerKomm[key];
								});
								that.oParentController.oMappingModel.setProperty("/Korrespondenz", oKorrespondenz);

								if (that.oAppViewModel.getProperty("/compareModus")) {
									// Versionsvergleich für Korrenzpondenz
									var oChangesKorrespondenz = Utilities.compareJSONObject(that.oAppViewModel.getProperty("/previousKorrespondenz"), that.oParentController
										.oCurrentVertragKorrespondenz);
									that.oParentController.visualizeBlockLayoutChanges("Korrespondenz", oChangesKorrespondenz, that.oParentController.oMappingModel);

									if (that.oAppViewModel.getProperty("/showMaklerKomm")) {
										// Versionsvergleich für Makler Kommunikation falls aktiv
										var oChangesMaklerKomm = Utilities.compareJSONObject(that.oAppViewModel.getProperty("/previousKommMakler"), that.oParentController
											.oCurrentVertragKommMakler);
										that.oParentController.visualizeBlockLayoutChanges("Korrespondenz", oChangesMaklerKomm, that.oParentController.oMappingModel);
									}
								}
							}
						}
					}
				});
			}
			var oHintText = Fragment.byId("idFragmentKorrespondenzEdit", "idFormattedTextKorrespondenzEdit");
			if (oHintText) {
				oHintText.setHtmlText("<em style=\"color:rgb(102, 102, 102);\">" + Utilities.geti18nText(this.oParentController.i18n,
					"hintCurrentData", []) + "</em>");
			}
		},

		onAfterClose: function (oEvent) {
			oEvent.getSource().destroy();
		},

		onKorrespondezChange: function (oEvent) {
			globalThis.oParentController.oModel.setProperty("/korrespondenzHasChanged", true);
			var sId = oEvent.getSource().getId();
			if (sId.includes("ComboBox")) {
				globalThis._checkEntryValue(oEvent);
				return;
			}
		},

		_checkEntryValue: function (oEvent) {
			var oValidatedComboBox = oEvent.getSource(),
				sSelectedKey = oValidatedComboBox.getSelectedKey(),
				sValue = oValidatedComboBox.getValue();

			if (!sSelectedKey && sValue) {
				oValidatedComboBox.setValueState(ValueState.Error);
				oValidatedComboBox.setValueStateText("Bitte geben Sie einen gültigen Eintrag ein");
			} else {
				oValidatedComboBox.setValueState(ValueState.None);
			}
		}
	});
});