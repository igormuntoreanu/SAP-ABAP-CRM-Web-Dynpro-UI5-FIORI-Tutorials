sap.ui.define([
	"sap/ui/base/ManagedObject",
	"de/pnw/icm/provisionsvertrag/vtr2/util/Utilities",
	"de/pnw/icm/provisionsvertrag/vtr2/model/formatter",
	"sap/ui/core/Fragment",
	'sap/ui/core/library',
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
], function (ManagedObject, Utilities, formatter, Fragment, coreLibrary, Filter, FilterOperator) {
	"use strict";

	var ValueState = coreLibrary.ValueState;

	return ManagedObject.extend("de.pnw.icm.provisionsvertrag.vtr2.controller.sections.AllgemeinesEdit", {
		formatter: formatter,

		constructor: function (oArgs) {
			this.oParentController = oArgs;
			// sap.ui.getCore().getMessageManager().registerObject(this.oParentController.getView(), true);
		},

		//keine Funktion aber wird benötigt um über alle setData iterieren zu können
		setData: function () {
			this._vertragPath = this.oParentController._vertragPath;
			this.oVertragModel = this.oParentController.vertragModel;
			this.oAppViewModel = this.oParentController.oModel;
			this.oSection = Fragment.byId("idFragmentAllgemeinesEdit", "AllgemeinesSectionEdit");
			if (this.oSection) {
				var that = this;
				this.oSection.bindElement({
					path: "/" + this._vertragPath,
					parameters: {
						expand: "ProvVertrToPartner"
					},
					model: "vertrag",
					events: {
						change: function () {
							// 12.12.2021 - PRNPROV-187 - Begin
							// Filter Agentur ComboBox according to the Intitle
							//Busy Indicator öffnen
							Utilities._showBusyDialog();
							var oVertrag = that.oVertragModel.getProperty("/" + that._vertragPath);
							var sIntTitle = oVertrag.IntTitle;
							var aFilter = []; 
							aFilter.push(
								new Filter({
									path: "IntTitle",
									operator: FilterOperator.EQ,
									value1: sIntTitle
								})
							);
							
							Utilities.promiseODataRead(that.oVertragModel, "WhAgenturknzSet", {}, aFilter).then(
								function (oData) { //resolve
									that.oAppViewModel.setProperty("/agenturData", oData.results);
									Fragment.byId("idBusyFragment", "idBusyDialog").close();
								}.bind(that),
								function (oError) { //reject
									//Busy Indicator schließen
									Fragment.byId("idBusyFragment", "idBusyDialog").close();
									var sErrorMsg = (jQuery.parseXML(oError.responseText).querySelector("message") || "").textContent;
									sErrorMsg = sErrorMsg + " (VM - AllgemeinesEdit.js: setData())";
									Utilities.displayErrorMessageBox(sErrorMsg, that.oParentController.getView());
								}.bind(that)
							);
							// 12.12.2021 - PRNPROV-187 - End
						}
					}
				});
			}
		},

		onAfterClose: function (oEvent) {
			oEvent.getSource().destroy();
		},

		onAllgemeinesChange: function (oEvent) {
			this.oParentController.oModel.setProperty("/allgemeinesHasChanged", true);
			var sId = oEvent.getSource().getId();
			var parameters = oEvent.getParameters();
			var oSource = oEvent.getSource();

			if (sId.includes("ComboBox")) {
				this._checkEntryValueComboBox(oEvent);
				return;
			}

			if (sId.includes("DatePicker")) {
				this._handleValueState(parameters.valid, oSource);
				//Due to the formatter, the binding is simulated as One-way, not updating then the Model
				//var invertedDate = parameters.newValue.substr(3, 2) + '.' + parameters.newValue.substr(0, 2) + '.' + parameters.newValue.substr(6, 4);
				if (parameters.newValue) { //01.11.2021
					var utcDate = new Date(Date.UTC(parameters.newValue.substr(6, 4), parameters.newValue.substr(3, 2) - 1, parameters.newValue.substr(
						0, 2)));
					var dateObject = new Date(utcDate);
				}
			}

			if (sId.includes("Benutzer")) {
				var regex = /^[a-zA-Z]{1}[0-9]{6}$/;
				var isValid = false;
				isValid = regex.test(parameters.newValue);
				this._handleValueState(isValid, oSource);
			}

			if (sId.includes("LeavDateDatePicker")) {
				this.oParentController.getOwnerComponent().getModel("vertrag").setProperty("/" + this._vertragPath + "/" + "LeavDate", dateObject);
			}

			if (sId.includes("CtrtbuEdateDatePicker")) {
				this.oParentController.getOwnerComponent().getModel("vertrag").setProperty("/" + this._vertragPath + "/" + "CtrtbuEdate",
					dateObject);
			}

			if (sId.includes("EntrDateDatePicker")) {
				this.oParentController.getOwnerComponent().getModel("vertrag").setProperty("/" + this._vertragPath + "/" + "EntrDate", dateObject);
			}

			if (sId.includes("CtrtbuBdateDatePicker")) {
				this.oParentController.getOwnerComponent().getModel("vertrag").setProperty("/" + this._vertragPath + "/" + "CtrtbuBdate",
					dateObject);
			}
		},

		formatNumber: function (oEvent) {
			this.oParentController.oModel.setProperty("/allgemeinesHasChanged", true);
			var parameters = oEvent.getParameters();
			//Only allows digits
			var input = parameters.newValue.replace(/[^\d]/g, "");
			oEvent.getSource().setValue(input);
		},

		visualizeBlockLayoutChanges: function () {
			this.oAppViewModel = this.oParentController.oModel;
			this.oParentController.resetBlockLayoutVisualization("Allgemeines", this.oParentController.oMappingModel, true);
			if (this.oAppViewModel.getProperty("/compareModus")) {
				var oChangesAllgemeines = Utilities.compareJSONObject(this.oAppViewModel.getProperty("/previousVertrag"), this.oParentController.oVertragData);
				this.oParentController.visualizeBlockLayoutChanges("Allgemeines", oChangesAllgemeines);
			}
		},

		_checkEntryValueComboBox: function (oEvent) {
			var oValidatedComboBox = oEvent.getSource(),
				sSelectedKey = oValidatedComboBox.getSelectedKey(),
				sValue = oValidatedComboBox.getValue();

			if (!sSelectedKey && sValue) {
				oValidatedComboBox.setValueState(ValueState.Error);
				oValidatedComboBox.setValueStateText("Bitte geben Sie einen gültigen Eintrag ein");
			} else {
				oValidatedComboBox.setValueState(ValueState.None);
			}
		},

		_handleValueState: function (bValid, oSource) {
			if (!bValid) {
				oSource.setValueState(ValueState.Error);
				oSource.setValueStateText("Bitte geben Sie einen gültigen Eintrag ein");
			} else {
				oSource.setValueState(ValueState.None);
			}
		}
	});
});