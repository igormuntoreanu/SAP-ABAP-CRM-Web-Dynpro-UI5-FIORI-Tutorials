sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/ui/Device",
	"sap/ui/model/json/JSONModel",
	"de/pnw/icm/provisionsvertrag/vtr/model/models",
	"sap/f/FlexibleColumnLayoutSemanticHelper",
	"sap/ui/core/routing/HashChanger",
	"de/pnw/icm/provisionsvertrag/vtr/util/Utilities"
], function (UIComponent, Device, JSONModel, models, FlexibleColumnLayoutSemanticHelper, HashChanger, Utilities) {
	"use strict";

	return UIComponent.extend("de.pnw.icm.provisionsvertrag.vtr.Component", {

		metadata: {
			manifest: "json"
		},

		/**
		 * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
		 * @public
		 * @override nothing
		 */
		init: function () {
			// call the base component's init function
			UIComponent.prototype.init.apply(this, arguments);

			var hash = new HashChanger().getHash(),
				bActionEdit = false,
				editMode = false; 
				
				
				
			var sessionID = '';
			var chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
			var charsLength = chars.length;
			for( var i = 0; i < 8; i++){
				sessionID += chars.charAt(Math.floor(Math.random()*charsLength));
			} 
				
			var semacticObject = hash.split("&")[0].split("-")[1];
			
			//Semantisches Objekt im localen Launchpad umgehen!
			//Zusätzlich muss die Crossappnavigation auf dem Master deaktiviert werden
			if (semacticObject === "edit") {
				bActionEdit = true;
				editMode = true;
			}
			
			var oModel = new JSONModel();

			// sap.ushell.services.AppConfiguration.getCurrentApplication().sShellHash

			oModel.setData({
				"lavvnChangable": false,
				"sessionID": sessionID,
				"bActionEdit": bActionEdit, // Action zum Öffnen der App
				"showAnsprechpartner": true, //Ansprechpartner subsection hiding when no data applied -> Default true
				"editMode": editMode, // Anzeige im Edit-Modus
				"editable": false,
				"validFrom": null, // GültigAb-Datum
				"validFromDate": null, // GültigAb-Datum als Objekt
				"vZweg": null, // Wert der Spalte vZweg in Lavv
				"lavvHasChanged": false, // Es wurden Änderungen vorgenommen welche noch nicht zum Speichern vorgemerkt sind
				"kondHasChanged": false, // Es wurden Änderungen vorgenommen welche noch nicht zum Speichern vorgemerkt sind
				"bInFullScreen": false, // Vollbildmodus
				"alleIndivValue": null, // Wert, der genutzt wird um alle angezeigten Konditionen zu individualisieren -> gesetzt in alleIndividualisierenDialog.fragment
				"changedKondition": {}, // speicher geänderte Konditionen zwischen
				"lavvData": null,
				"vertragList": [], // Spalten Definition des Vertragsübersichts 
				"konditionList": [], // Spalten definition der Konditionen
				"VariantList": [], // Variant Liste
				"isExpertModus": false, // Expert Modus für die Suche
				"compareModus": false, // Vergleich-Modus
				"isLaVvMsg": false, // Änderung an LaVv
				"laVvMsg": "", // LaVv Änderung Text
				"isWpvKondMsgAP": false, // Änderung an Wpv AP
				"isWpvKondMsgVP": false, // Änderung an Wpv VP
				"sectionsShow": true,
				"showWPV": false, // Anzeige der Sektion WPV
				"showMaklerKomm": false, // Anzeige der Untersektion Maklerkommunikation
				"KonwaStdProzentVis": false, // Globale Variable die steuert ob im Dialog Individualisierung von Werten mit der Einheit Prozent angeboten werden soll
				"KonwaStdProzentMBVis": false, // Globale Variable die steuert ob im Dialog Individualisierung von Werten mit der Einheit Prozent MB angeboten werden soll
				"KonwaStdPromilleVis": false, // Globale Variable die steuert ob im Dialog Individualisierung von Werten mit der Einheit Promille angeboten werden soll
				"KonwaStdEURVis": false, // Globale Variable die steuert ob im Dialog Individualisierung von Werten mit der Einheit EUR angeboten werden soll
				"alleIndivValueProz": null, // Wert, der genutzt wird um alle angezeigten Konditionen zu individualisieren -> gesetzt in alleIndividualisierenDialog.fragment
				"alleIndivValueProzMB": null, // Wert, der genutzt wird um alle angezeigten Konditionen zu individualisieren -> gesetzt in alleIndividualisierenDialog.fragment
				"alleIndivValueProm": null, // Wert, der genutzt wird um alle angezeigten Konditionen zu individualisieren -> gesetzt in alleIndividualisierenDialog.fragment
				"alleIndivValueEUR": null, // Wert, der genutzt wird um alle angezeigten Konditionen zu individualisieren -> gesetzt in alleIndividualisierenDialog.fragment
				"lastView": null
			});

			this.setModel(oModel, "appView");
			Utilities.checkIfEditable().then(
				function (bEditable) { //resolve
					oModel.setProperty("/editable", bEditable);
				},
				function (oError) { //reject
					oModel.setProperty("/editable", false);
				}
			);

			// enable routing
			this.getRouter().initialize();

			// set the device model
			this.setModel(models.createDeviceModel(), "device");
		},

		getHelper: function () {
			var oFCL = this.getRootControl().byId("idFlexLayout"),
				oParams = jQuery.sap.getUriParameters(),
				oSettings = {
					defaultTwoColumnLayoutType: sap.f.LayoutType.TwoColumnsMidExpanded,
					defaultThreeColumnLayoutType: sap.f.LayoutType.TwoColumnsMidExpanded,
					mode: oParams.get("mode"),
					initialColumnsCount: oParams.get("initial"),
					maxColumnsCount: oParams.get("max")
				};

			return FlexibleColumnLayoutSemanticHelper.getInstanceFor(oFCL, oSettings);
		}
	});
});